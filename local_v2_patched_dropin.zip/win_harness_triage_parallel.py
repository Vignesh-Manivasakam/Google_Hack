﻿#!/usr/bin/env python3
"""
Parallel Single-GPU Batched ADK Harness Triage Matrix (H1..H6) + Legal Submission Exporter (v2)
- 1 Shared 16GB GPU Dynamic Batcher (max_batch_size=4, vision/audio stripped, zero WDDM spill)
- 4 Parallel CPU Sandbox Threads (.tgz extract, AST code graph, /tmp/repro.py TDD, pytest)
- Per-Role Sampling Asymmetry (0.0/1536 fast localizer & verifier vs 0.1/3584 surgical editor)
- 100% Real Container-A Fidelity: 10 legal tools, include_thoughts=False, Tier-2 flexible edit_file.
"""
import argparse, concurrent.futures, csv, dataclasses, datetime as dt, gc, json, os, queue
import re, shutil, subprocess, tempfile, threading, time, zipfile
from pathlib import Path
import torch

from win_local_sandbox import (
    ensure_repo_venv,
    extract_tgz_windows_safe,
    inject_workspace_pth,
    load_tasks_select,
    run_posix_command_windows,
    verify_single_task,
)
from win_phase2_tournament import (
    LocalGemmaEngine,
    RepoCodeGraph,
    _build_workspace_tree,
    _extract_thought_and_text,
    tool_read_file,
)

os.environ["PYTHONUTF8"] = "1"

CANARY_8_IDS = [
    "fastapi_14964", "fastapi_15588", "fastapi_15023",
    "rich_4076", "rich_4006", "rich_4075",
    "requests_7433", "requests_7505",
]

REAL_TOOLS = {
    "run_command": {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a shell command in /workspace (grep -rn, python3 /tmp/repro.py, pytest, git diff).",
            "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]},
        },
    },
    "read_file": {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read lines [start_line, end_line] of an existing file in /workspace.",
            "parameters": {
                "type": "object",
                "properties": {"filepath": {"type": "string"}, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
                "required": ["filepath"],
            },
        },
    },
    "edit_file": {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Replace old_string with new_string in an existing file in /workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string"},
                    "old_string": {"type": "string"},
                    "new_string": {"type": "string"},
                    "allow_multiple": {"type": "boolean"},
                },
                "required": ["filepath", "old_string", "new_string"],
            },
        },
    },
    "write_file": {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or overwrite filepath in /workspace with content.",
            "parameters": {
                "type": "object",
                "properties": {"filepath": {"type": "string"}, "content": {"type": "string"}},
                "required": ["filepath", "content"],
            },
        },
    },
    "get_status": {
        "type": "function",
        "function": {
            "name": "get_status",
            "description": "Return git status and remaining tool-call budget.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    "submit_patch": {
        "type": "function",
        "function": {
            "name": "submit_patch",
            "description": "Finalize and submit the current /workspace git diff for grading.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    "search_similar_code": {
        "type": "function",
        "function": {
            "name": "search_similar_code",
            "description": "Semantic/symbol search over the repository AST code graph.",
            "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "k": {"type": "integer"}}, "required": ["query"]},
        },
    },
    "get_code_neighbors": {
        "type": "function",
        "function": {
            "name": "get_code_neighbors",
            "description": "Get callers, callees, and imports of an AST node in the repository graph.",
            "parameters": {"type": "object", "properties": {"node": {"type": "string"}}, "required": ["node"]},
        },
    },
    "get_code_subgraph": {
        "type": "function",
        "function": {
            "name": "get_code_subgraph",
            "description": "Retrieve 2-hop AST ego-subgraph (callers, imports, sibling methods) around node.",
            "parameters": {"type": "object", "properties": {"node": {"type": "string"}, "depth": {"type": "integer"}}, "required": ["node"]},
        },
    },
    "code_analyzer": {
        "type": "function",
        "function": {
            "name": "code_analyzer",
            "description": "Delegate a read-only codebase question (callers, conventions, line numbers) to an isolated analyzer sub-agent.",
            "parameters": {"type": "object", "properties": {"request": {"type": "string"}}, "required": ["request"]},
        },
    },
}


def tool_edit_file_flexible(ws: Path, filepath: str, old_string: str, new_string: str, allow_multiple: bool = False) -> dict:
    rel = filepath.strip().lstrip("/").removeprefix("workspace/")
    fp = (ws / rel).resolve()
    if not fp.exists() or not fp.is_file():
        return {"status": "error", "error_type": "FileEditError", "message": f"File not found: {rel}"}
    if not old_string:
        return {"status": "error", "error_type": "FileEditError", "message": "old_string cannot be empty."}
    content = fp.read_text(encoding="utf-8", errors="replace").replace("\r\n", "\n")
    old_n = old_string.replace("\r\n", "\n")
    new_n = new_string.replace("\r\n", "\n")

    cnt = content.count(old_n)
    if cnt == 1 or (cnt > 1 and allow_multiple):
        updated = content.replace(old_n, new_n) if allow_multiple else content.replace(old_n, new_n, 1)
        fp.write_text(updated, encoding="utf-8", newline="\n")
        return {"status": "ok", "strategy": "exact", "occurrences": cnt if allow_multiple else 1}
    if cnt > 1:
        return {"status": "error", "error_type": "MultipleMatchesError", "message": f"Found {cnt} matches; include more context lines."}

    src_lines = content.split("\n")
    old_lines = [ln.strip() for ln in old_n.strip("\n").split("\n")]
    m = len(old_lines)
    matches = [i for i in range(len(src_lines) - m + 1) if [src_lines[i + j].strip() for j in range(m)] == old_lines]
    if len(matches) == 1:
        idx = matches[0]
        updated_lines = src_lines[:idx] + new_n.strip("\n").split("\n") + src_lines[idx + m :]
        fp.write_text("\n".join(updated_lines), encoding="utf-8", newline="\n")
        return {"status": "ok", "strategy": "flexible", "occurrences": 1}
    return {"status": "error", "error_type": "NoMatchError", "message": "old_string not found. Call read_file around target lines first."}


def tool_write_file(ws: Path, filepath: str, content: str) -> dict:
    rel = filepath.strip().lstrip("/").removeprefix("workspace/")
    fp = (ws / rel).resolve()
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(content.replace("\r\n", "\n"), encoding="utf-8", newline="\n")
    return {"status": "ok", "filepath": rel, "bytes_written": len(content)}


def graph_subgraph_2hop(code_graph: RepoCodeGraph, node: str) -> dict:
    hop1 = code_graph.neighbors(node)
    nbs = hop1.get("neighbors", [])[:6]
    hop2 = {}
    for nb in nbs:
        nb_id = nb["target"] if isinstance(nb, dict) and "target" in nb else str(nb)
        hop2[nb_id] = code_graph.neighbors(nb_id).get("neighbors", [])[:5]
    return {"status": "ok", "root": hop1.get("node", node), "hop1": nbs, "hop2": hop2}


def strip_protected_files_from_diff(diff_text: str) -> str:
    if not diff_text.strip():
        return ""
    kept, cur, drop = [], [], False
    for line in diff_text.splitlines(keepends=True):
        if line.startswith("diff --git "):
            if cur and not drop:
                kept.extend(cur)
            cur = [line]
            m = re.search(r" b/(.+)$", line.strip())
            p = m.group(1) if m else ""
            parts = p.split("/")
            drop = (
                "tests" in parts or "test" in parts
                or Path(p).name.startswith("test_") or Path(p).name.endswith("_test.py")
                or Path(p).name in ("conftest.py", "pytest.ini", "tox.ini")
            )
        else:
            cur.append(line)
    if cur and not drop:
        kept.extend(cur)
    return "".join(kept).strip()


class BatchedGemmaServer:
    def __init__(self, model_id: str, max_batch_size: int = 4, batch_wait_sec: float = 0.03):
        self.engine = LocalGemmaEngine(model_id=model_id, adapter_dir=None)
        for parent in (self.engine.model, getattr(self.engine.model, "model", None)):
            if parent is not None:
                for attr in ("vision_tower", "audio_tower", "embed_vision", "embed_audio"):
                    if hasattr(parent, attr):
                        delattr(parent, attr)
        gc.collect()
        torch.cuda.empty_cache()
        self.tokenizer = self.engine.tokenizer
        self.tokenizer.padding_side = "left"
        self.max_batch_size = max_batch_size
        self.batch_wait_sec = batch_wait_sec
        self.q = queue.Queue()
        self._stop = False
        self._worker = threading.Thread(target=self._loop, daemon=True)
        self._worker.start()

    def generate_turn(self, messages: list[dict], tools: list[dict] | None, temperature: float = 0.1, thinking_budget: int = 2560) -> tuple[str, list[dict]]:
        ev = threading.Event()
        slot = {}
        self.q.put((messages, tools, temperature, min(1536, thinking_budget), ev, slot))
        ev.wait()
        if "err" in slot:
            raise slot["err"]
        return slot["res"]

    def _format_prompt(self, messages: list[dict], tools: list[dict] | None) -> str:
        try:
            if tools:
                return self.tokenizer.apply_chat_template(messages, tools=tools, tokenize=False, add_generation_prompt=True)
        except Exception:
            pass
        return self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

    def _loop(self):
        while not self._stop:
            try:
                first = self.q.get(timeout=0.1)
            except queue.Empty:
                continue
            batch = [first]
            deadline = time.time() + self.batch_wait_sec
            while len(batch) < self.max_batch_size and time.time() < deadline:
                rem = max(0.0, deadline - time.time())
                try:
                    batch.append(self.q.get(timeout=rem))
                except queue.Empty:
                    break
            try:
                if len(batch) == 1:
                    item = batch[0]
                    if len(item) == 7:
                        msgs, tools, temp, max_tok, tb_cap, ev, slot = item
                    else:
                        msgs, tools, temp, max_tok, ev, slot = item
                        tb_cap = None
                    slot["res"] = self.engine.generate_turn(
                        msgs, tools=tools, temperature=temp, max_new_tokens=max_tok, thinking_budget=tb_cap
                    )
                    ev.set()
                else:
                    norm_batch = [
                        b if len(b) == 7 else (b[0], b[1], b[2], b[3], None, b[4], b[5])
                        for b in batch
                    ]
                    prompts = [self._format_prompt(b[0], b[1]) for b in norm_batch]
                    temp = max(b[2] for b in norm_batch)
                    max_tok = max(b[3] for b in norm_batch)
                    tb_cap = max((int(b[4]) for b in norm_batch if b[4]), default=None)
                    try:
                        orig_trunc_side = getattr(self.tokenizer, "truncation_side", "right")
                        self.tokenizer.truncation_side = "left"
                        try:
                            enc = self.tokenizer(prompts, return_tensors="pt", padding=True, truncation=True, max_length=13312).to(self.engine.model.device)
                        finally:
                            self.tokenizer.truncation_side = orig_trunc_side
                        in_len = enc["input_ids"].shape[1]
                        logits_proc = (
                            self.engine._build_thinking_cap_processors(in_len, tb_cap)
                            if hasattr(self.engine, "_build_thinking_cap_processors") else None
                        )
                        gen_kw = dict(
                            max_new_tokens=max_tok,
                            do_sample=(temp > 0.0),
                            temperature=temp if temp > 0.0 else None,
                            top_p=0.90 if temp > 0.0 else None,
                            pad_token_id=self.tokenizer.pad_token_id,
                        )
                        if logits_proc is not None:
                            gen_kw["logits_processor"] = logits_proc
                        with torch.inference_mode():
                            out = self.engine.model.generate(**enc, **gen_kw)
                        for i, b in enumerate(norm_batch):
                            raw = self.tokenizer.decode(out[i, in_len:], skip_special_tokens=False)
                            for eos_tok in ("<pad>", "<eos>", "<end_of_turn>"):
                                raw = raw.replace(eos_tok, "")
                            b[6]["res"] = (raw.strip(), LocalGemmaEngine._parse_gemma4_tool_calls(raw))
                            b[5].set()
                    except RuntimeError:
                        torch.cuda.empty_cache()
                        for msgs, tools, t_i, m_i, tb_i, ev, slot in norm_batch:
                            slot["res"] = self.engine.generate_turn(
                                msgs, tools=tools, temperature=t_i, max_new_tokens=m_i, thinking_budget=tb_i
                            )
                            ev.set()
            except Exception as exc:
                for b in batch:
                    ev_b = b[5] if len(b) == 7 else b[4]
                    slot_b = b[6] if len(b) == 7 else b[5]
                    if not ev_b.is_set():
                        slot_b["err"] = exc
                        ev_b.set()


ANALYZER_PROMPT = (
    "You are a read-only Codebase Analyzer. In <= 4 tool calls, inspect files/callers using read_file, "
    "search_similar_code, get_code_neighbors, get_code_subgraph, or grep via run_command. Return exact filepaths, "
    "line ranges, caller dependencies, and adjacent error/decorator conventions."
)

LOCALIZER_PROMPT = (
    "You are Stage 1: Repository Localizer. Using <= 5 read/search/subgraph/grep calls, produce a concise Localization Brief with:\n"
    "1. Exact source filepath(s) and class/function line ranges to change.\n"
    "2. Blast-radius callers/imports across the repo (never allow deleting a re-exported public symbol).\n"
    "3. Adjacent coding/warning/error message conventions in that module.\n"
    "4. Exact existing pytest file (`pytest tests/test_<mod>.py -p no:anyio -W ignore::DeprecationWarning -q --tb=short`)."
)

REPRODUCER_PROMPT = (
    "You are Stage 2: Bug Reproducer (TDD Setup). Note that existing repository tests pass before your edit, so you must:\n"
    "1. Run a 1-line `PYTHONPATH=src:. python3 -c \"...\"` command via run_command that reproduces the exact bug/missing behavior "
    "described in the Problem Description, AND verify the existing pytest module collects cleanly.\n"
    "2. Output a concise Reproduction & Test Spec containing BOTH the exact `python3 -c` bug-repro assertion command and the existing `pytest` regression command."
)

EDITOR_GATED_PROMPT = (
    "You are the Surgical Code Editor inside an iterative Edit-Verify loop. Note: you do NOT have submit_patch; "
    "a separate GateVerifier will test both your bug fix and regressions next.\n"
    "1. Read +/-40 lines around the target symbol with read_file before calling edit_file.\n"
    "2. Make the minimal surgical fix required by the issue. NEVER delete public classes/functions that are imported elsewhere; "
    "preserve existing validators, imports, and return types.\n"
    "3. If Test Feedback shows an ImportError, AssertionError, or failing reproduction check from the previous iteration, inspect `git diff` "
    "and fix the exact root cause.\n"
    "4. Run `PYTHONPATH=src:. python3 -m py_compile <file>` via run_command, then summarize your edit in 2 sentences to hand off to GateVerifier."
)

EDITOR_DIRECT_PROMPT = (
    "You are the Surgical Code Editor. Keep thoughts concise and emit a tool call every turn.\n"
    "1. Read +/-40 lines around the target with read_file before calling edit_file.\n"
    "2. Make minimal surgical edits without deleting re-exported public classes or existing validators.\n"
    "3. MANDATORY BEFORE SUBMITTING: Run BOTH a `PYTHONPATH=src:. python3 -c \"...\"` check verifying the issue fix AND "
    "`PYTHONPATH=src:. pytest <test_file> -p no:anyio -W ignore::DeprecationWarning -q --tb=short`.\n"
    "4. Only after both pass (`exit_code == 0`) and `git diff` is non-empty, call submit_patch."
)

GATE_VERIFIER_PROMPT = (
    "You are the Gate Verifier & Patch Submitter. You CANNOT edit files; your job is to test the workspace diff and guard submission.\n"
    "1. Run `git diff`, the existing module `PYTHONPATH=src:. pytest <test_file> -p no:anyio -W ignore::DeprecationWarning -q --tb=short` (catches regressions!), "
    "AND a `PYTHONPATH=src:. python3 -c \"...\"` assertion testing the exact new behavior/warning/edge-case requested in the issue!\n"
    "2. Check ALL THREE conditions:\n"
    "   (a) `git diff` is minimal and does not delete re-exported public symbols.\n"
    "   (b) Existing pytest suite passes (`exit_code == 0`).\n"
    "   (c) Issue reproduction check passes (`exit_code == 0`).\n"
    "3. IF ALL THREE PASS: Immediately call `submit_patch`!\n"
    "4. IF ANYTHING FAILS OR DIFF IS EMPTY: Do NOT call submit_patch. Output a concise Failure Diagnostic quoting the exact traceback "
    "and what the Editor must fix in the next loop iteration."
)


@dataclasses.dataclass
class TriageCandidate:
    cid: str
    arch: str
    ed_temp: float = 0.1
    fast_temp: float = 0.0
    include_thoughts: bool = False
    ed_thinking: int = 3584
    fast_thinking: int = 1536
    max_loop_iters: int = 3
    note: str = ""


CANDIDATES = [
    TriageCandidate("H1_b0_clean_tuned", "h1_b0_tuned", note="B0 + temp0.1 + include_thoughts=False + 28 budget"),
    TriageCandidate("H2_seq2_clean", "h2_seq2_clean", note="2-stage Seq + asymmetric thinking + real tools"),
    TriageCandidate("H3_loop_hardgate", "h3_loop_hardgate", note="Localizer -> Loop3[Editor(no submit) + GateVerifier(repro+pytest->submit)]"),
    TriageCandidate("H4_tdd_repro_hardgate", "h4_repro_loop_hardgate", note="Localizer -> TDD_Repro -> Loop3[Editor + GateVerifier]"),
    TriageCandidate("H5_parallel_loc_loop", "h5_parallel_loc_loop", note="Parallel[GraphSubgraphLoc, GrepLoc] -> Loop3[Editor + GateVerifier]"),
    TriageCandidate("H6_hybrid_analyzer_loop", "h6_hybrid_analyzer_loop", note="Loop3[Editor(+code_analyzer AgentTool, no submit) + GateVerifier]"),
]


def run_agent_stage(
    server: BatchedGemmaServer,
    ws: Path,
    py_exe: Path,
    code_graph: RepoCodeGraph,
    system_prompt: str,
    user_prompt: str,
    tool_names: list[str],
    temp: float,
    thinking_budget: int,
    include_thoughts: bool,
    max_steps: int,
    budget_state: dict,
) -> dict:
    tools = [REAL_TOOLS[n] for n in tool_names]
    msgs = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    can_submit = "submit_patch" in tool_names
    last_text = ""

    for step in range(1, max_steps + 1):
        if budget_state["steps"] >= 38 or budget_state["submitted"]:
            break
        budget_state["steps"] += 1

        raw_txt, calls = server.generate_turn(msgs, tools=tools, temperature=temp, thinking_budget=thinking_budget)
        thought, plain_txt = _extract_thought_and_text(raw_txt)
        if plain_txt:
            last_text = plain_txt
        elif thought:
            last_text = thought

        if not calls:
            if step >= 2 or (not can_submit and budget_state["edits_this_stage"] > 0):
                break
            budget_state["malformed"] += 1
            msgs.append({"role": "assistant", "content": plain_txt or "Ready."})
            msgs.append({"role": "user", "content": "Emit your next tool call now, or provide your final structured handoff summary."})
            continue

        tc = calls[0]
        fn, args = tc["name"], tc["arguments"]
        budget_state["trace"].append(f"{fn}({str(args.get('filepath') or args.get('command') or args.get('query') or args.get('node') or args.get('request') or '')[:48]})")
        print(f"    ? [{budget_state.get('tid', '?'):15s}] s{budget_state['steps']:02d} -> {budget_state['trace'][-1]}", flush=True)
        print(f"    ? [{budget_state.get('tid', '?'):15s}] s{budget_state['steps']:02d} -> {budget_state['trace'][-1]}", flush=True)

        if fn not in tool_names:
            budget_state["malformed"] += 1
            obs = {"error_type": "ToolNotAllowedError", "error": f"Tool `{fn}` is not available to this sub-agent. Available: {tool_names}"}
        elif fn == "submit_patch":
            subprocess.run(["git", "add", "-N", "."], cwd=str(ws), capture_output=True)
            cur_diff = subprocess.run(["git", "diff", "HEAD"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout or ""
            if not strip_protected_files_from_diff(cur_diff):
                obs = {"status": "error", "message": "Cannot submit empty source patch."}
            else:
                budget_state["submitted"] = True
                break
        elif fn == "read_file":
            obs = tool_read_file(ws, str(args.get("filepath", "")), args.get("start_line"), args.get("end_line"))
        elif fn == "edit_file":
            obs = tool_edit_file_flexible(ws, str(args.get("filepath", "")), str(args.get("old_string", "")), str(args.get("new_string", "")), bool(args.get("allow_multiple", False)))
            if obs["status"] == "ok":
                budget_state["edit_oks"] += 1
                budget_state["edits_this_stage"] += 1
            else:
                budget_state["edit_fails"] += 1
        elif fn == "write_file":
            obs = tool_write_file(ws, str(args.get("filepath", "")), str(args.get("content", "")))
            budget_state["edits_this_stage"] += 1
        elif fn == "run_command":
            obs = run_posix_command_windows(str(args.get("command", "")), ws, py_exe)
        elif fn == "get_status":
            st = subprocess.run(["git", "status", "-s"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
            obs = {"status": "ok", "git_status": st[:1000], "tool_calls_remaining": max(0, 38 - budget_state["steps"])}
        elif fn == "search_similar_code":
            obs = code_graph.search(str(args.get("query", "")), int(args.get("k", 8) or 8))
        elif fn == "get_code_neighbors":
            obs = code_graph.neighbors(str(args.get("node", "")))
        elif fn == "get_code_subgraph":
            obs = graph_subgraph_2hop(code_graph, str(args.get("node", "")))
        elif fn == "code_analyzer":
            sub_state = {"steps": budget_state["steps"], "edit_oks": 0, "edit_fails": 0, "edits_this_stage": 0, "malformed": 0, "submitted": False, "trace": []}
            sub_res = run_agent_stage(
                server, ws, py_exe, code_graph, ANALYZER_PROMPT, str(args.get("request", "")),
                ["read_file", "run_command", "search_similar_code", "get_code_neighbors", "get_code_subgraph"],
                cfg_temp := 0.0, 1536, False, max_steps=4, budget_state=sub_state,
            )
            budget_state["steps"] = sub_state["steps"]
            budget_state["trace"].extend([f"analyzer->{x}" for x in sub_state["trace"]])
            obs = {"status": "ok", "analysis": sub_res["final_text"]}
        else:
            obs = {"status": "error", "error": f"Unhandled tool {fn}"}

        call_id = f"c_{budget_state['steps']}"
        asst_msg = {
            "role": "assistant",
            "content": "",
            "tool_calls": [{"id": call_id, "type": "function", "function": {"name": fn, "arguments": args}}],
        }
        if include_thoughts and thought:
            asst_msg["reasoning_content"] = thought
        msgs.append(asst_msg)
        msgs.append({"role": "tool", "tool_call_id": call_id, "name": fn, "content": json.dumps(obs, ensure_ascii=False)[:4800]})

    return {"final_text": last_text[:1800]}


def run_single_episode(cfg: TriageCandidate, task: dict, server: BatchedGemmaServer, gemma_dir: Path, venv_root: Path, patches_dir: Path, traces_dir: Path) -> dict:
    tid, repo = task["instance_id"], task["repo"]
    py_exe = ensure_repo_venv(venv_root, repo, wheels_dir=gemma_dir / "wheels")
    code_graph = RepoCodeGraph(gemma_dir, repo, task["base_commit"])
    bstate = {"tid": tid, "steps": 0, "edit_oks": 0, "edit_fails": 0, "edits_this_stage": 0, "malformed": 0, "submitted": False, "trace": []}
    agent_patch = ""

    try:
        with tempfile.TemporaryDirectory(prefix=f"tri_{cfg.cid}_{tid}_") as tmp_s:
            ws = extract_tgz_windows_safe(gemma_dir / "snapshots" / f"{tid}.tgz", Path(tmp_s) / "workspace")
            subprocess.run(["git", "config", "core.autocrlf", "false"], cwd=str(ws), capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=str(ws), capture_output=True)
            subprocess.run(["git", "commit", "-m", "baseline", "--allow-empty", "-q"], cwd=str(ws), capture_output=True)
            inject_workspace_pth(py_exe, ws)

            ws_tree = _build_workspace_tree(ws)
            issue_prompt = f"Repository: {repo}\n\nProblem Description:\n{task['problem_statement'][:3200]}\n\nWorkspace Layout:\n{ws_tree}"

            loc_tools = ["read_file", "run_command", "search_similar_code", "get_code_neighbors", "get_code_subgraph"]
            ed_gated_tools = ["read_file", "edit_file", "write_file", "run_command", "get_status"]
            gate_tools = ["run_command", "read_file", "get_status", "submit_patch"]

            if cfg.arch == "h1_b0_tuned":
                all_b0 = ["run_command", "read_file", "edit_file", "write_file", "get_status", "submit_patch", "search_similar_code", "get_code_neighbors", "get_code_subgraph", "code_analyzer"]
                run_agent_stage(server, ws, py_exe, code_graph, EDITOR_DIRECT_PROMPT, issue_prompt, all_b0, cfg.ed_temp, cfg.ed_thinking, cfg.include_thoughts, max_steps=28, budget_state=bstate)

            elif cfg.arch == "h2_seq2_clean":
                s1 = run_agent_stage(server, ws, py_exe, code_graph, LOCALIZER_PROMPT, issue_prompt, loc_tools, cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=6, budget_state=bstate)
                ed_in = f"{issue_prompt}\n\n## Localization Brief:\n{s1['final_text']}"
                run_agent_stage(server, ws, py_exe, code_graph, EDITOR_DIRECT_PROMPT, ed_in, ed_gated_tools + ["submit_patch"], cfg.ed_temp, cfg.ed_thinking, cfg.include_thoughts, max_steps=16, budget_state=bstate)

            else:
                if cfg.arch == "h5_parallel_loc_loop":
                    g1 = run_agent_stage(server, ws, py_exe, code_graph, LOCALIZER_PROMPT, issue_prompt, ["search_similar_code", "get_code_neighbors", "get_code_subgraph", "read_file"], cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=4, budget_state=bstate)
                    g2 = run_agent_stage(server, ws, py_exe, code_graph, LOCALIZER_PROMPT, issue_prompt, ["run_command", "read_file"], cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=4, budget_state=bstate)
                    loc_brief = f"### Graph Brief:\n{g1['final_text']}\n\n### Grep/Test Brief:\n{g2['final_text']}"
                elif cfg.arch == "h6_hybrid_analyzer_loop":
                    loc_brief = "Use `code_analyzer` or `read_file` to inspect target files and blast-radius callers."
                else:
                    s1 = run_agent_stage(server, ws, py_exe, code_graph, LOCALIZER_PROMPT, issue_prompt, loc_tools, cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=5, budget_state=bstate)
                    loc_brief = s1["final_text"]

                feedback = "Iteration 1: No edits applied yet."
                if cfg.arch == "h4_repro_loop_hardgate":
                    rep = run_agent_stage(server, ws, py_exe, code_graph, REPRODUCER_PROMPT, f"{issue_prompt}\n\n## Localization Brief:\n{loc_brief}", ["run_command", "read_file"], cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=3, budget_state=bstate)
                    feedback = f"TDD Reproduction & Pytest Spec:\n{rep['final_text']}"

                ed_tools_loop = ed_gated_tools + (["code_analyzer"] if cfg.arch == "h6_hybrid_analyzer_loop" else [])
                for it in range(1, cfg.max_loop_iters + 1):
                    if bstate["submitted"] or bstate["steps"] >= 36:
                        break
                    bstate["edits_this_stage"] = 0
                    ed_user = f"{issue_prompt}\n\n## Localization Brief:\n{loc_brief}\n\n## Test Feedback (Loop {it}/{cfg.max_loop_iters}):\n{feedback}"
                    run_agent_stage(server, ws, py_exe, code_graph, EDITOR_GATED_PROMPT, ed_user, ed_tools_loop, cfg.ed_temp, cfg.ed_thinking, cfg.include_thoughts, max_steps=7, budget_state=bstate)
                    if bstate["steps"] >= 37:
                        break
                    cur_diff = subprocess.run(["git", "diff", "-U3"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout[:2400]
                    gv_user = f"{issue_prompt}\n\n## Localization Brief:\n{loc_brief}\n\n## Current Workspace Diff:\n```diff\n{cur_diff}\n```"
                    gv = run_agent_stage(server, ws, py_exe, code_graph, GATE_VERIFIER_PROMPT, gv_user, gate_tools, cfg.fast_temp, cfg.fast_thinking, cfg.include_thoughts, max_steps=4, budget_state=bstate)
                    if bstate["submitted"]:
                        break
                    feedback = gv["final_text"] or "Verification did not pass; inspect git diff, run repro + pytest, and fix root cause."

            subprocess.run(["git", "add", "-N", "."], cwd=str(ws), capture_output=True)
            raw_patch = subprocess.run(["git", "diff", "HEAD"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout or ""
            agent_patch = strip_protected_files_from_diff(raw_patch)
            (patches_dir / f"{tid}.patch").write_text(agent_patch + "\n", encoding="utf-8")
    except Exception as exc:
        bstate["trace"].append(f"EXC:{exc}")

    vres = verify_single_task(task, agent_patch, gemma_dir / "snapshots", venv_root, wheels_dir=gemma_dir / "wheels")
    resolved = bool(vres.get("resolved"))
    rec = {
        "instance_id": tid,
        "repo": repo,
        "resolved": resolved,
        "submitted_via_gate": bstate["submitted"],
        "steps": bstate["steps"],
        "edit_oks": bstate["edit_oks"],
        "edit_fails": bstate["edit_fails"],
        "malformed": bstate["malformed"],
        "patch_len": len(agent_patch),
        "trace": bstate["trace"],
        "pytest_tail": (vres.get("stdout_tail") or vres.get("error") or "")[-500:],
    }
    (traces_dir / f"{tid}.json").write_text(json.dumps(rec, indent=2, ensure_ascii=False), encoding="utf-8")
    return rec


def eval_candidate_parallel(cfg: TriageCandidate, tasks: list[dict], server: BatchedGemmaServer, gemma_dir: Path, venv_root: Path, out_dir: Path, workers: int, cached: dict | None = None) -> tuple[dict, dict]:
    cdir = out_dir / cfg.cid
    pdir, tdir = cdir / "patches", cdir / "traces"
    pdir.mkdir(parents=True, exist_ok=True)
    tdir.mkdir(parents=True, exist_ok=True)

    for r in sorted({t["repo"] for t in tasks}):
        ensure_repo_venv(venv_root, r, wheels_dir=gemma_dir / "wheels")

    results_by_id = dict(cached or {})
    todo = [t for t in tasks if t["instance_id"] not in results_by_id]
    t0 = time.time()
    print(f"\n==================== [{cfg.cid}] ({len(todo)} new + {len(results_by_id)} cached = {len(tasks)} tasks | workers={workers}) ====================", flush=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(run_single_episode, cfg, t, server, gemma_dir, venv_root, pdir, tdir): t["instance_id"] for t in todo}
        done_n = len(results_by_id)
        for fut in concurrent.futures.as_completed(futs):
            rec = fut.result()
            results_by_id[rec["instance_id"]] = rec
            done_n += 1
            print(
                f"  [{done_n:2d}/{len(tasks)}] {rec['instance_id']:18s} | resolved={str(rec['resolved']):5s} | "
                f"gate_sub={str(rec['submitted_via_gate']):5s} | steps={rec['steps']:2d} | ef={rec['edit_fails']} | patch={rec['patch_len']}c",
                flush=True,
            )

    recs = [results_by_id[t["instance_id"]] for t in tasks]
    n = len(recs)
    res_cnt = sum(1 for r in recs if r["resolved"])
    tot_steps = sum(r["steps"] for r in recs)
    tot_ef = sum(r["edit_fails"] for r in recs)
    tot_mal = sum(r["malformed"] for r in recs)
    scr = round(100.0 * (1.0 - (tot_mal + tot_ef) / max(1, tot_steps)), 2)
    summary = {
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "cid": cfg.cid,
        "arch": cfg.arch,
        "num_tasks": n,
        "resolved_count": res_cnt,
        "resolved_pct": round(100.0 * res_cnt / max(1, n), 2),
        "scr_pct": scr,
        "avg_steps": round(tot_steps / max(1, n), 2),
        "edit_fail_total": tot_ef,
        "malformed_total": tot_mal,
        "duration_min": round((time.time() - t0) / 60.0, 2),
        "note": cfg.note,
    }
    (cdir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"[✓] {cfg.cid} ({n} tasks): resolved={summary['resolved_pct']}% ({res_cnt}/{n}) | SCR={scr}% | EditFail={tot_ef} | {summary['duration_min']} min", flush=True)
    return summary, results_by_id


def export_legal_submission(cfg: TriageCandidate, sub_dir: Path, zip_path: Path):
    if sub_dir.exists():
        shutil.rmtree(sub_dir)
    for sub in ("configs", "prompts", "sub_agents"):
        (sub_dir / sub).mkdir(parents=True, exist_ok=True)

    (sub_dir / "eval_config.yaml").write_text(
        "evaluation:\n  timeout_seconds: 180\n  max_tool_calls: 42\n  max_time_minutes: 8\n  max_turns: 65\n", encoding="utf-8"
    )
    (sub_dir / "configs" / "sampling_editor.yaml").write_text(
        f"temperature: {cfg.ed_temp}\ntop_p: 0.90\nseed: 42\nmax_output_tokens: 12288\n"
        f"thinking_config:\n  thinking_budget: {cfg.ed_thinking}\n  include_thoughts: false\n",
        encoding="utf-8",
    )
    (sub_dir / "configs" / "sampling_fast.yaml").write_text(
        f"temperature: {cfg.fast_temp}\ntop_p: 0.90\nseed: 42\nmax_output_tokens: 8192\n"
        f"thinking_config:\n  thinking_budget: {cfg.fast_thinking}\n  include_thoughts: false\n",
        encoding="utf-8",
    )

    allowed_vars = {"problem_description"}
    if cfg.arch == "h1_b0_tuned":
        (sub_dir / "prompts" / "analyzer.md").write_text(ANALYZER_PROMPT + "\n", encoding="utf-8")
        (sub_dir / "prompts" / "system.md").write_text(EDITOR_DIRECT_PROMPT + "\n", encoding="utf-8")
        (sub_dir / "sub_agents" / "code_analyzer.yaml").write_text(
            "name: code_analyzer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ndescription: Read-only codebase analyzer.\n"
            "instruction: !include ../prompts/analyzer.md\ntools:\n  - read_file\n  - run_command\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n"
            "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
        )
        (sub_dir / "agent.yaml").write_text(
            "name: swe_e4b_champion\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ndescription: Context-clean SWE agent.\n"
            "instruction: !include prompts/system.md\ntools:\n  - run_command\n  - read_file\n  - edit_file\n  - write_file\n"
            "  - get_status\n  - submit_patch\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n"
            "  - agent_tool:\n      config_path: sub_agents/code_analyzer.yaml\n      skip_summarization: true\n"
            "generate_content_config: !include configs/sampling_editor.yaml\n", encoding="utf-8"
        )
    elif cfg.arch == "h2_seq2_clean":
        allowed_vars.add("localization_brief")
        (sub_dir / "prompts" / "localizer.md").write_text(LOCALIZER_PROMPT + "\n", encoding="utf-8")
        (sub_dir / "prompts" / "editor.md").write_text(EDITOR_DIRECT_PROMPT + "\n\n## Localization Brief:\n{localization_brief}\n", encoding="utf-8")
        (sub_dir / "sub_agents" / "localizer.yaml").write_text(
            "name: repo_localizer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/localizer.md\n"
            "output_key: localization_brief\ntools:\n  - read_file\n  - run_command\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n"
            "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
        )
        (sub_dir / "sub_agents" / "editor.yaml").write_text(
            "name: surgical_editor\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninclude_contents: none\ninstruction: !include ../prompts/editor.md\n"
            "tools:\n  - read_file\n  - edit_file\n  - write_file\n  - run_command\n  - get_status\n  - submit_patch\n"
            "generate_content_config: !include ../configs/sampling_editor.yaml\n", encoding="utf-8"
        )
        (sub_dir / "agent.yaml").write_text(
            "agent_class: SequentialAgent\nname: swe_seq2_champion\ndescription: 2-stage SWE agent.\n"
            "sub_agents:\n  - config_path: sub_agents/localizer.yaml\n  - config_path: sub_agents/editor.yaml\n", encoding="utf-8"
        )
    else:
        allowed_vars.update({"localization_brief", "test_feedback", "graph_brief", "grep_brief"})
        (sub_dir / "prompts" / "localizer.md").write_text(LOCALIZER_PROMPT + "\n", encoding="utf-8")
        (sub_dir / "prompts" / "reproducer.md").write_text(REPRODUCER_PROMPT + "\n\n## Localization Brief:\n{localization_brief}\n", encoding="utf-8")

        loc_ref = "{graph_brief}\n\n{grep_brief}" if cfg.arch == "h5_parallel_loc_loop" else ("{localization_brief}" if cfg.arch != "h6_hybrid_analyzer_loop" else "Inspect via code_analyzer and read_file.")
        fb_ref = "\n\n## Latest Test Feedback:\n{test_feedback}\n" if cfg.arch == "h4_repro_loop_hardgate" else ""

        (sub_dir / "prompts" / "code_editor.md").write_text(
            f"{EDITOR_GATED_PROMPT}\n\n## Problem Summary:\n{{problem_description}}\n\n## Localization Brief:\n{loc_ref}{fb_ref}\n", encoding="utf-8"
        )
        (sub_dir / "prompts" / "gate_verifier.md").write_text(
            f"{GATE_VERIFIER_PROMPT}\n\n## Localization Brief:\n{loc_ref}\n", encoding="utf-8"
        )

        extra_analyzer_yaml = ""
        if cfg.arch == "h6_hybrid_analyzer_loop":
            (sub_dir / "prompts" / "analyzer.md").write_text(ANALYZER_PROMPT + "\n", encoding="utf-8")
            (sub_dir / "sub_agents" / "code_analyzer.yaml").write_text(
                "name: code_analyzer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/analyzer.md\n"
                "tools:\n  - read_file\n  - run_command\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n"
                "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
            )
            extra_analyzer_yaml = "  - agent_tool:\n      config_path: code_analyzer.yaml\n      skip_summarization: true\n"

        (sub_dir / "sub_agents" / "code_editor.yaml").write_text(
            "name: code_editor\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ndescription: Surgical editor without submit_patch.\n"
            "instruction: !include ../prompts/code_editor.md\ntools:\n  - read_file\n  - edit_file\n  - write_file\n  - run_command\n  - get_status\n"
            + extra_analyzer_yaml + "generate_content_config: !include ../configs/sampling_editor.yaml\n", encoding="utf-8"
        )
        gv_out_key = "output_key: test_feedback\n" if cfg.arch == "h4_repro_loop_hardgate" else ""
        (sub_dir / "sub_agents" / "gate_verifier.yaml").write_text(
            "name: gate_verifier\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ndescription: Pytest gate verifier and patch submitter.\n"
            f"instruction: !include ../prompts/gate_verifier.md\n{gv_out_key}tools:\n  - run_command\n  - read_file\n  - get_status\n  - submit_patch\n"
            "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
        )
        (sub_dir / "sub_agents" / "repair_loop.yaml").write_text(
            f"agent_class: LoopAgent\nname: repair_verify_loop\ndescription: Iterative edit and pytest verification loop.\n"
            f"max_iterations: {cfg.max_loop_iters}\nsub_agents:\n  - config_path: code_editor.yaml\n  - config_path: gate_verifier.yaml\n",
            encoding="utf-8",
        )

        if cfg.arch == "h6_hybrid_analyzer_loop":
            (sub_dir / "agent.yaml").write_text(
                f"agent_class: LoopAgent\nname: swe_hybrid_loop_champion\ndescription: Tool-gated SWE loop agent.\n"
                f"max_iterations: {cfg.max_loop_iters}\nsub_agents:\n  - config_path: sub_agents/code_editor.yaml\n  - config_path: sub_agents/gate_verifier.yaml\n",
                encoding="utf-8",
            )
            (sub_dir / "sub_agents" / "repair_loop.yaml").unlink()
        elif cfg.arch == "h5_parallel_loc_loop":
            (sub_dir / "sub_agents" / "graph_loc.yaml").write_text(
                "name: graph_localizer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/localizer.md\n"
                "output_key: graph_brief\ntools:\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n  - read_file\n"
                "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
            )
            (sub_dir / "sub_agents" / "grep_loc.yaml").write_text(
                "name: grep_localizer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/localizer.md\n"
                "output_key: grep_brief\ntools:\n  - run_command\n  - read_file\n"
                "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
            )
            (sub_dir / "sub_agents" / "parallel_loc.yaml").write_text(
                "agent_class: ParallelAgent\nname: dual_localizer\ndescription: Parallel graph and grep localizers.\n"
                "sub_agents:\n  - config_path: graph_loc.yaml\n  - config_path: grep_loc.yaml\n", encoding="utf-8"
            )
            (sub_dir / "agent.yaml").write_text(
                "agent_class: SequentialAgent\nname: swe_parallel_loop_champion\ndescription: Parallel localizer + gated repair loop.\n"
                "sub_agents:\n  - config_path: sub_agents/parallel_loc.yaml\n  - config_path: sub_agents/repair_loop.yaml\n", encoding="utf-8"
            )
        else:
            (sub_dir / "sub_agents" / "localizer.yaml").write_text(
                "name: repo_localizer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/localizer.md\n"
                "output_key: localization_brief\ntools:\n  - read_file\n  - run_command\n  - search_similar_code\n  - get_code_neighbors\n  - get_code_subgraph\n"
                "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
            )
            stages = "  - config_path: sub_agents/localizer.yaml\n"
            if cfg.arch == "h4_repro_loop_hardgate":
                (sub_dir / "sub_agents" / "reproducer.yaml").write_text(
                    "name: baseline_reproducer\nmodel: gemma-4-e4b-it-qat-w4a16-ct\ninstruction: !include ../prompts/reproducer.md\n"
                    "output_key: test_feedback\ntools:\n  - run_command\n  - read_file\n"
                    "generate_content_config: !include ../configs/sampling_fast.yaml\n", encoding="utf-8"
                )
                stages += "  - config_path: sub_agents/reproducer.yaml\n"
            stages += "  - config_path: sub_agents/repair_loop.yaml\n"
            (sub_dir / "agent.yaml").write_text(
                f"agent_class: SequentialAgent\nname: swe_hardgate_loop_champion\ndescription: Gated TDD loop SWE agent.\nsub_agents:\n{stages}",
                encoding="utf-8",
            )

    for md in (sub_dir / "prompts").glob("*.md"):
        found = set(re.findall(r"\{([^{}]+)\}", md.read_text(encoding="utf-8")))
        illegal = found - allowed_vars
        assert not illegal, f"Illegal ADK template vars {illegal} in {md.name}!"

    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(sub_dir.rglob("*")):
            if f.is_file():
                assert f.suffix in {".yaml", ".yml", ".md", ".txt", ".py", ".json", ".safetensors"}, f"Illegal ext: {f}"
                zf.write(f, f.relative_to(sub_dir).as_posix())
    print(f"[✓] Exported & validated Kaggle submission: {zip_path.resolve()} ({zip_path.stat().st_size:,} bytes)")


def append_csv(csv_path: Path, stage: str, row: dict):
    out = {"stage": stage, **row}
    exists = csv_path.exists()
    with open(csv_path, "a", newline="", encoding="utf-8") as cf:
        w = csv.DictWriter(cf, fieldnames=list(out.keys()))
        if not exists:
            w.writeheader()
        w.writerow(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gemma_dir", type=Path, default=Path("."))
    ap.add_argument("--model_id", type=str, default=r"..\gemma-4-e4b-it")
    ap.add_argument("--venv_root", type=Path, default=Path(r"..\.win_venvs"))
    ap.add_argument("--out_dir", type=Path, default=Path(r"..\triage_matrix_run"))
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--candidates", nargs="+", default=[c.cid for c in CANDIDATES])
    ap.add_argument("--top_k_val20", type=int, default=2)
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.out_dir / "triage_experiments.csv"

    val20_tasks = load_tasks_select(args.gemma_dir / "tasks.jsonl", "val20")
    tmap = {t["instance_id"]: t for t in val20_tasks}
    canary_tasks = [tmap[tid] for tid in CANARY_8_IDS if tid in tmap]

    cmap = {c.cid: c for c in CANDIDATES}
    selected = [cmap[k] for k in args.candidates if k in cmap]

    server = BatchedGemmaServer(model_id=args.model_id, max_batch_size=args.batch_size)

    canary_board = []
    canary_caches = {}
    for cfg in selected:
        summ, cache = eval_candidate_parallel(cfg, canary_tasks, server, args.gemma_dir, args.venv_root, args.out_dir / "canary8", args.workers)
        append_csv(csv_path, "canary8", summ)
        canary_board.append((summ["resolved_count"], summ["scr_pct"], -summ["edit_fail_total"], cfg))
        canary_caches[cfg.cid] = cache

    canary_board.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
    finalists = [x[3] for x in canary_board[: max(1, args.top_k_val20)]]
    print("\n[🏆] PROMOTING TOP FINALISTS TO FULL VAL20:", [f.cid for f in finalists])

    val20_board = []
    for cfg in finalists:
        summ, _ = eval_candidate_parallel(cfg, val20_tasks, server, args.gemma_dir, args.venv_root, args.out_dir / "val20", args.workers, cached=canary_caches[cfg.cid])
        append_csv(csv_path, "val20", summ)
        val20_board.append((summ["resolved_count"], summ["scr_pct"], -summ["edit_fail_total"], cfg))

    val20_board.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
    champ = val20_board[0][3]
    print(f"\n[👑] CHAMPION HARNESS LOCKED: {champ.cid}")
    export_legal_submission(champ, args.out_dir / "champion_v2_submission", args.out_dir / "submission_today.zip")


if __name__ == "__main__":
    main()
