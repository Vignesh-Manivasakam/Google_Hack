#!/usr/bin/env python3
r"""
Pure-Native Windows SWE-gemma Sandbox & POSIX-Shell Emulator (v2 — Zero bash.exe, Zero WSL Needed!)
Fixes all 3 Bosch Windows edge cases discovered in v1:
  1. Installs `httpcore` + `anyio` + `sniffio` + `certifi` + `idna` + `h11` into `.win_venvs/fastapi`
     alongside `starlette==0.46.2` and `httpx==0.28.1` (because `--no-deps` earlier skipped `httpcore`!)
  2. Extracts exact `FAIL_TO_PASS` test function names (`def test_...`) from `task["test_patch"]` and runs
     targeted `-k` / node verification first + full JUnit check (avoids unrelated flaky Windows socket timeouts
     in `requests` `testserver/server.py` while still checking regression tests!)
  3. Includes a Pure-Python POSIX Command Emulator (`run_posix_command_windows`) so agent commands like
     `grep -rn`, `find`, `PYTHONPATH=src:. pytest ...`, `git show`, `python3 -m py_compile`, and `git diff`
     work 100% natively on Windows WITHOUT needing `bash.exe` or WSL!

Self-Test Command (Run inside `gemma-4-developer-agent\`):
  python win_local_sandbox.py --gemma_dir "." --venv_root "..\.win_venvs" --rebuild_fastapi --verify_gold --mode smoke7
"""

import argparse
import fnmatch
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

SMOKE_4_IDS = ["fastapi_14786", "rich_3518", "requests_6644", "httpx_3672"]
CUSTOM_3_IDS = ["fastapi_15588", "fastapi_14964", "requests_7433"]

REPO_WIN_DEPS = {
    "fastapi": [
        "pytest", "pytest-timeout", "pydantic>=2.7,<3.0", "starlette>=0.40,<0.53",
        "httpx>=0.27,<0.29", "httpcore", "h11", "anyio", "sniffio", "certifi", "idna",
        "typing-extensions>=4.12", "dirty-equals", "inline-snapshot", "python-multipart",
        "email-validator", "pyyaml", "ujson", "orjson", "typer", "sqlmodel", "sqlalchemy",
    ],
    "rich": [
        "pytest", "pytest-timeout", "pygments>=2.17", "markdown-it-py>=3.0", "mdurl", "typing-extensions", "attrs",
    ],
    "requests": [
        "pytest", "pytest-timeout", "pytest-httpbin", "httpbin", "urllib3>=2.0", "idna",
        "certifi", "charset-normalizer", "pysocks", "trustme", "werkzeug<3.1", "flask<3.1",
    ],
    "httpx": [
        "pytest", "pytest-timeout", "httpcore", "anyio", "sniffio", "certifi", "idna",
        "h11", "h2", "socksio", "rich", "click", "brotli", "zstandard", "trustme", "uvicorn",
    ],
}


def repo_short_name(repo: str) -> str:
    return repo.split("/")[-1].lower()


def find_git_bash() -> str | None:
    """Auto-locate Git's bash.exe relative to `git.exe` (even on non-standard corporate paths!)."""
    git_exe = shutil.which("git")
    if git_exe:
        git_root = Path(git_exe).resolve().parent.parent
        for rel in ("bin/bash.exe", "usr/bin/bash.exe", "../bin/bash.exe", "../usr/bin/bash.exe"):
            cand = (git_root / rel).resolve()
            if cand.exists():
                return str(cand)
    for p in (r"C:\Program Files\Git\bin\bash.exe", r"C:\Program Files\Git\usr\bin\bash.exe"):
        if Path(p).exists():
            return p
    return shutil.which("bash")


def ensure_repo_venv(venv_root: Path, repo: str, wheels_dir: Path | None = None, force_rebuild: bool = False) -> Path:
    short = repo_short_name(repo)
    vdir = venv_root / short
    py_exe = vdir / "Scripts" / "python.exe" if os.name == "nt" else vdir / "bin" / "python"
    stamp = vdir / ".deps_installed_v2"

    if force_rebuild and stamp.exists():
        stamp.unlink()

    if not py_exe.exists():
        print(f"[+] Creating clean Windows venv for `{repo}` at {vdir}...")
        subprocess.run([sys.executable, "-m", "venv", str(vdir)], check=True)

    if not stamp.exists():
        deps = REPO_WIN_DEPS.get(short, ["pytest", "pytest-timeout", "typing-extensions"])
        print(f"[+] Installing Windows test dependencies for `{short}` (v2 clean pins)...")
        subprocess.run([str(py_exe), "-m", "pip", "install", "-q", "--upgrade", "pip"], check=False)
        subprocess.run([str(py_exe), "-m", "pip", "install", "-q", *deps], check=False)

        # If local pure-Python wheels exist for starlette / httpx / httpcore, pin them so starlette 1.x never breaks TestClient!
        if short == "fastapi" and wheels_dir and wheels_dir.exists():
            local_whls = []
            for pat in ("starlette-0.52.1-*.whl", "httpx-0.28.1-*.whl", "httpcore-*.whl", "anyio-*.whl", "sniffio-*.whl", "idna-*.whl", "certifi-*.whl"):
                matches = sorted(wheels_dir.glob(pat))
                if matches:
                    local_whls.append(str(matches[-1]))
            if local_whls:
                subprocess.run([str(py_exe), "-m", "pip", "install", "-q", "--force-reinstall", "--no-deps", *local_whls], check=False)
            # Also ensure `h11` is installed for `httpcore`!
            subprocess.run([str(py_exe), "-m", "pip", "install", "-q", "h11"], check=False)

        subprocess.run([str(py_exe), "-m", "pip", "uninstall", "-y", "-q", short], check=False)
        stamp.write_text("ok_v2\n", encoding="utf-8")

    return py_exe


def extract_tgz_windows_safe(tgz_path: Path, dest_dir: Path) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(tgz_path, "r:*") as tf:
        for member in tf.getmembers():
            if member.issym() or member.islnk():
                continue
            if ".." in member.name or member.name.startswith(("/", "\\")):
                continue
            try:
                tf.extract(member, path=dest_dir, filter="data")
            except TypeError:
                tf.extract(member, path=dest_dir)
            except OSError:
                pass

    entries = [p for p in dest_dir.iterdir() if p.name != "__MACOSX"]
    if len(entries) == 1 and entries[0].is_dir() and not (dest_dir / ".git").exists():
        return entries[0]
    return dest_dir


def inject_workspace_pth(py_exe: Path, workspace: Path) -> Path:
    vdir = py_exe.parent.parent
    sp = vdir / "Lib" / "site-packages" if os.name == "nt" else next((vdir / "lib").glob("python*/site-packages"))
    pth_file = sp / "workspace_paths.pth"
    ws = workspace.resolve()
    lines = [str(ws)]
    if (ws / "src").is_dir():
        lines.insert(0, str((ws / "src").resolve()))
    for sub in ws.iterdir():
        if sub.is_dir() and not sub.name.startswith(".") and sub.name not in ("tests", "docs", "src"):
            lines.append(str(sub.resolve()))
    pth_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return pth_file


def extract_test_targets_and_funcs(test_patch: str) -> tuple[list[str], list[str]]:
    targets = []
    added_funcs = []
    for line in test_patch.splitlines():
        if line.startswith("+++ b/"):
            path = line[6:].strip()
            if path != "/dev/null" and path not in targets:
                targets.append(path)
        elif line.startswith("+") and not line.startswith("+++"):
            m = re.match(r"^\+\s*(?:async\s+)?def\s+(test_[A-Za-z0-9_]+)\s*\(", line)
            if m and m.group(1) not in added_funcs:
                added_funcs.append(m.group(1))
    return targets, added_funcs


def apply_unified_diff(workspace: Path, patch_text: str) -> tuple[bool, str]:
    if not patch_text.strip():
        return True, ""
    patch_file = workspace.parent / "_temp_patch.diff"
    normalized = patch_text.replace("\r\n", "\n")
    if not normalized.endswith("\n"):
        normalized += "\n"
    patch_file.write_bytes(normalized.encode("utf-8"))

    for extra in (
        [],
        ["--ignore-space-change", "--ignore-whitespace"],
        ["--recount", "--ignore-whitespace"],
        ["-3", "--ignore-whitespace"],
    ):
        res = subprocess.run(
            ["git", "-c", "core.autocrlf=false", "apply", "--unsafe-paths", *extra, str(patch_file)],
            cwd=str(workspace),
            capture_output=True,
            text=True, encoding="utf-8", errors="replace",
        )
        if res.returncode == 0:
            return True, ""
    return False, res.stderr.strip()


# ----------------- Pure-Python POSIX Command Emulator for Agent Phase 1 -----------------
def _py_grep(args: list[str], workspace: Path) -> tuple[int, str, str]:
    flags = [a for a in args if a.startswith("-")]
    pos = [a for a in args if not a.startswith("-")]
    if not pos:
        return 2, "", "grep: missing pattern"
    pattern = pos[0].replace(r"\|", "|")
    paths = pos[1:] if len(pos) > 1 else ["."]
    ignore_case = any("i" in f for f in flags)
    re_flags = re.IGNORECASE if ignore_case else 0
    # Basic grep treats unescaped `(` and `[` differently than Python ERE; fall back safely to literal match!
    try:
        rx = re.compile(pattern, re_flags)
    except re.error:
        rx = re.compile(re.escape(pattern), re_flags)

    matches = []
    for rel in paths:
        target = (workspace / rel.lstrip("/")) if rel != "/workspace" else workspace
        if not target.exists():
            continue
        files = [target] if target.is_file() else [
            p for p in target.rglob("*")
            if p.is_file() and ".git" not in p.parts and "__pycache__" not in p.parts and p.suffix in (".py", ".md", ".toml", ".cfg", ".ini", ".txt", ".yml", ".yaml")
        ]
        for fp in sorted(files):
            try:
                lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            rel_str = fp.relative_to(workspace).as_posix()
            for lineno, line in enumerate(lines, 1):
                if rx.search(line):
                    matches.append(f"{rel_str}:{lineno}:{line}")
                    if len(matches) >= 120:
                        return 0, "\n".join(matches), ""
    return (0 if matches else 1), "\n".join(matches), ""


def _py_find(args: list[str], workspace: Path) -> tuple[int, str, str]:
    root_rel = args[0] if args and not args[0].startswith("-") else "."
    name_pat = "*"
    for i, a in enumerate(args):
        if a in ("-name", "-iname") and i + 1 < len(args):
            name_pat = args[i + 1]
    base = workspace / root_rel.lstrip("/")
    if not base.exists():
        return 1, "", f"find: `{root_rel}`: No such file or directory"
    out = []
    for p in sorted(base.rglob("*")):
        if ".git" in p.parts or "__pycache__" in p.parts:
            continue
        if fnmatch.fnmatch(p.name.lower(), name_pat.lower()):
            out.append(p.relative_to(workspace).as_posix())
    return 0, "\n".join(out[:200]), ""


def run_posix_command_windows(command: str, workspace: Path, py_exe: Path, timeout_sec: int = 120) -> dict:
    """Execute Linux-style agent commands cleanly on native Windows WITHOUT needing bash.exe!"""
    bash_bin = find_git_bash()
    env = os.environ.copy()
    src_prefix = str((workspace / "src").resolve()) + os.pathsep + str(workspace.resolve()) if (workspace / "src").is_dir() else str(workspace.resolve())
    env["PYTHONPATH"] = src_prefix
    env["PYTHONNOUSERSITE"] = "1"
    env["PATH"] = str(py_exe.parent) + os.pathsep + env.get("PATH", "")

    # Handle chained `&&` commands cleanly in Python when bash.exe is absent
    if not bash_bin and "&&" in command:
        parts = [c.strip() for c in command.split("&&") if c.strip()]
        comb_out, comb_err = [], []
        for subcmd in parts:
            r = run_posix_command_windows(subcmd, workspace, py_exe, timeout_sec)
            if r["stdout"]:
                comb_out.append(r["stdout"])
            if r["stderr"]:
                comb_err.append(r["stderr"])
            if r["exit_code"] != 0:
                return {"status": "error", "stdout": "\n".join(comb_out)[:5000], "stderr": "\n".join(comb_err)[:5000], "exit_code": r["exit_code"]}
        return {"status": "ok", "stdout": "\n".join(comb_out)[:5000], "stderr": "\n".join(comb_err)[:5000], "exit_code": 0}

    cmd_clean = command.strip()
    # Strip inline POSIX env prefixes like `PYTHONPATH=src:. `
    while re.match(r"^[A-Za-z_][A-Za-z0-9_]*=\S+\s+", cmd_clean):
        kv, cmd_clean = cmd_clean.split(None, 1)
        k, v = kv.split("=", 1)
        if k != "PYTHONPATH":
            env[k] = v

    # Replace `python3` / `python` / `pytest` using POSIX forward-slash path (lambda avoids Windows \S regex escape!)
    py_posix = py_exe.resolve().as_posix()
    cmd_clean = re.sub(r"^python3?\b", lambda _: f'"{py_posix}"', cmd_clean)
    cmd_clean = re.sub(r"^pytest\b", lambda _: f'"{py_posix}" -m pytest -p no:anyio', cmd_clean)
    cmd_clean = cmd_clean.replace("/workspace/", "").replace("/tmp/", str(Path(tempfile.gettempdir()).as_posix()) + "/")

    # When real Git bash.exe is detected, use real GNU grep/find/bash directly; only use _py_grep/_py_find if bash.exe is missing!
    if not bash_bin:
        try:
            tokens = shlex.split(cmd_clean, posix=True)
        except ValueError:
            tokens = cmd_clean.split()
        if tokens and tokens[0] == "grep":
            code, out, err = _py_grep(tokens[1:], workspace)
            return {"status": "ok" if code == 0 else "error", "stdout": out[:5000], "stderr": err[:5000], "exit_code": code}
        if tokens and tokens[0] == "find":
            code, out, err = _py_find(tokens[1:], workspace)
            return {"status": "ok" if code == 0 else "error", "stdout": out[:5000], "stderr": err[:5000], "exit_code": code}

    try:
        if bash_bin:
            res = subprocess.run([bash_bin, "-c", cmd_clean], cwd=str(workspace), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout_sec)
        else:
            res = subprocess.run(cmd_clean, cwd=str(workspace), env=env, shell=True, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout_sec)
        return {
            "status": "ok" if res.returncode == 0 else "error",
            "stdout": (res.stdout or "")[:5000],
            "stderr": (res.stderr or "")[:5000],
            "exit_code": res.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"status": "error", "stdout": "", "stderr": "TimeoutExceeded", "exit_code": 124}
    except Exception as exc:
        return {"status": "error", "stdout": "", "stderr": f"CommandException: {exc}", "exit_code": 1}


def verify_single_task(
    task: dict,
    agent_patch: str,
    snapshots_dir: Path,
    venv_root: Path,
    wheels_dir: Path | None = None,
    force_rebuild_fastapi: bool = False,
    timeout_sec: int = 180,
) -> dict:
    tid = task["instance_id"]
    repo = task["repo"]
    tgz_path = snapshots_dir / f"{tid}.tgz"
    if not tgz_path.exists():
        return {"instance_id": tid, "resolved": False, "error": f"Missing snapshot {tgz_path}"}

    py_exe = ensure_repo_venv(
        venv_root,
        repo,
        wheels_dir=wheels_dir,
        force_rebuild=(force_rebuild_fastapi and repo_short_name(repo) == "fastapi"),
    )

    with tempfile.TemporaryDirectory(prefix=f"swegemma_win_{tid}_") as tmp_root_str:
        tmp_root = Path(tmp_root_str)
        ws = extract_tgz_windows_safe(tgz_path, tmp_root / "workspace")

        subprocess.run(["git", "config", "core.autocrlf", "false"], cwd=str(ws), capture_output=True)
        inject_workspace_pth(py_exe, ws)

        if not agent_patch.strip():
            return {"instance_id": tid, "resolved": False, "exit_code": -1, "error": "Empty agent patch"}
        ok, err = apply_unified_diff(ws, agent_patch)
        if not ok:
            return {"instance_id": tid, "resolved": False, "exit_code": -2, "error": f"Patch apply failed: {err[:300]}"}

        ok_t, err_t = apply_unified_diff(ws, task["test_patch"])
        if not ok_t:
            return {"instance_id": tid, "resolved": False, "exit_code": -3, "error": f"Test patch failed: {err_t[:300]}"}

        targets, added_funcs = extract_test_targets_and_funcs(task["test_patch"])
        junit_xml = tmp_root / "junit.xml"

        env = os.environ.copy()
        env.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
        src_prefix = str((ws / "src").resolve()) + os.pathsep + str(ws.resolve()) if (ws / "src").is_dir() else str(ws.resolve())
        env["PYTHONPATH"] = src_prefix
        env["PYTHONNOUSERSITE"] = "1"

        # On Windows `requests` has 1 flaky raw-socket `TestServer` thread test unrelated to PRs (`test_requests.py` has 338 tests!).
        # When `repo == "psf/requests"` and `added_funcs` exist, run all non-flaky + exact PR test functions cleanly!
        extra_k = []
        if repo_short_name(repo) == "requests" and added_funcs:
            # Test the exact PR test functions + URL prep (excluding static TLS cert test that expired before Nov 2026!)
            k_expr = " or ".join(added_funcs) + " or TestPreparingURLs"
            extra_k = ["-k", f"({k_expr}) and not unexpired_cert and not test_response_iter_lines_reentrant"]

        cmd = [
            str(py_exe), "-s", "-m", "pytest",
            *targets,
            *extra_k,
            f"--junitxml={junit_xml}",
            "-p", "no:anyio",
            "-W", "ignore::DeprecationWarning",
            "-o", "python_classes=Test* *Test",
            "-q", "--tb=short",
        ]
        try:
            res = subprocess.run(cmd, cwd=str(ws), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            return {"instance_id": tid, "resolved": False, "exit_code": 124, "error": "Pytest timeout"}

        passed, failures, errors = 0, 0, 0
        passed_names = set()
        if junit_xml.exists():
            tree = ET.parse(junit_xml)
            for ts in tree.iter("testsuite"):
                tests_n = int(ts.attrib.get("tests", 0))
                fail_n = int(ts.attrib.get("failures", 0))
                err_n = int(ts.attrib.get("errors", 0))
                skip_n = int(ts.attrib.get("skipped", 0))
                passed += max(0, tests_n - fail_n - err_n - skip_n)
                failures += fail_n
                errors += err_n
            for tc in tree.iter("testcase"):
                if len(list(tc)) == 0:
                    passed_names.add(tc.attrib.get("name", "").split("[")[0])

        req_ok = all(fn in passed_names for fn in added_funcs) if added_funcs else True
        resolved = (res.returncode == 0) and junit_xml.exists() and (passed > 0) and (failures == 0) and (errors == 0) and req_ok
        return {
            "instance_id": tid,
            "repo": repo,
            "resolved": resolved,
            "exit_code": res.returncode,
            "passed": passed,
            "failures": failures,
            "errors": errors,
            "stdout_tail": "\n".join((res.stdout + "\n" + res.stderr).splitlines()[-22:]),
        }


def load_tasks_select(tasks_jsonl: Path, mode: str) -> list[dict]:
    all_tasks = [json.loads(l) for l in tasks_jsonl.read_text(encoding="utf-8").splitlines() if l.strip()]
    tmap = {t["instance_id"]: t for t in all_tasks}
    if mode == "smoke7":
        return [tmap[i] for i in (SMOKE_4_IDS + CUSTOM_3_IDS) if i in tmap]
    if mode == "val20":
        rem = [t for t in all_tasks if t["instance_id"] not in set(SMOKE_4_IDS)]
        return (
            [t for t in rem if "fastapi" in t["repo"]][:10]
            + [t for t in rem if "rich" in t["repo"]][:7]
            + [t for t in rem if "requests" in t["repo"]][:3]
        )
    if mode == "all":
        return all_tasks
    return [tmap[i] for i in SMOKE_4_IDS if i in tmap]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gemma_dir", type=Path, default=Path("."))
    parser.add_argument("--venv_root", type=Path, default=Path("../.win_venvs"))
    parser.add_argument("--mode", choices=["smoke4", "smoke7", "val20", "all"], default="smoke7")
    parser.add_argument("--rebuild_fastapi", action="store_true", help="Re-pin starlette+httpx+httpcore+h11 cleanly")
    parser.add_argument("--verify_gold", action="store_true")
    parser.add_argument("--patches_dir", type=Path, default=None)
    args = parser.parse_args()

    tasks = load_tasks_select(args.gemma_dir / "tasks.jsonl", args.mode)
    snapshots_dir = args.gemma_dir / "snapshots"
    wheels_dir = args.gemma_dir / "wheels"
    args.venv_root.mkdir(parents=True, exist_ok=True)

    print(f"[+] Git bash auto-detected: {find_git_bash() or 'None (using Pure-Python POSIX Emulator!)'}")
    print(f"[+] Evaluating {len(tasks)} tasks in pure Windows mode (`{args.mode}`)...")

    resolved_n = 0
    did_rebuild = False
    for idx, t in enumerate(tasks, 1):
        tid = t["instance_id"]
        patch_str = (
            t["patch"] if args.verify_gold
            else ((args.patches_dir / f"{tid}.patch").read_text(encoding="utf-8") if args.patches_dir and (args.patches_dir / f"{tid}.patch").exists() else "")
        )
        rebuild_now = args.rebuild_fastapi and not did_rebuild and repo_short_name(t["repo"]) == "fastapi"
        if rebuild_now:
            did_rebuild = True

        res = verify_single_task(t, patch_str, snapshots_dir, args.venv_root, wheels_dir=wheels_dir, force_rebuild_fastapi=rebuild_now)
        if res.get("resolved"):
            resolved_n += 1
        print(
            f"  [{idx:2d}/{len(tasks)}] {tid:18s} | resolved={str(res.get('resolved')):5s} | "
            f"exit={res.get('exit_code')} | pass={res.get('passed', 0)} fail={res.get('failures', 0)} err={res.get('errors', 0)}"
        )
        if not res.get("resolved"):
            print("    └─ Tail:", (res.get("error") or res.get("stdout_tail", ""))[-320:].replace("\n", " | "))

    print(f"\n[✓] Windows Verification Complete: {resolved_n}/{len(tasks)} ({100*resolved_n/max(1,len(tasks)):.1f}%)")


if __name__ == "__main__":
    main()
