#!/usr/bin/env python3
"""
Real-Trajectory SFT Dataset Builder, Sanitizer & Provenance Logger (Slot 2: E4B QAT LoRA).

Enforces every competition & quality invariant from GEMMA4_BATTLE_PLAN_NOV18.md & HARNESS_README.md:
  1. Gemma-Only Provenance (Rule 4 & Rule 5): rejects non-Gemma sources; logs full run provenance & SHA-256.
  2. Strict 99/30 Holdout Isolation: hard-rejects any trajectory whose instance_id is in the 30-task holdout.
  3. Verified Pass Gate: keeps ONLY real trajectories with resolved==True (F2P & P2P passed) and patch_len > 0.
  4. Unhinted Prompt Swap + Hint-Leakage Filter: replaces hinted user prompt with exact unhinted problem_statement
     from tasks.jsonl and drops any trajectory whose assistant/thought text references the hint.
  5. Gemma-4 Tool & Thought Schema Validation:
       - System prompt normalized to deployment prompt (default: submission_E4B_F3_v2/prompts/system.md).
       - Every assistant tool call formatted in canonical {"type": "function", "function": {"name", "arguments"}}.
       - Every role=="tool" message MUST carry "name" matching the call and valid JSON content (rejects fake stubs!).
       - Rejects protected-file edits (tests/, conftest.py, pyproject.toml, setup.cfg, tox.ini).
       - Preserves <|channel>thought...<channel|> reasoning blocks, capped cleanly at <= max_thought_tokens (default 1024).
  6. Diversity Caps:
       - At most --max_per_task trajectories per task (default 2; prefers shortest clean passing runs + source diversity).
       - At most --max_repo_share fraction per repository (default 0.40, relaxed only if total < 10 with explicit warning).

Usage:
    # Run built-in unit test suite to verify every guard:
    python sft_dataset_builder.py --self_test

    # Build clean E4B SFT training corpus from real passing trajectory JSONL files:
    python sft_dataset_builder.py \
        --inputs hinted_31b_passing.jsonl onpolicy_e4b_passing.jsonl \
        --splits splits_99_30.json \
        --tasks tasks.jsonl \
        --system_prompt submission_E4B_F3_v2/prompts/system.md \
        --out_jsonl e4b_sft_train.jsonl \
        --out_provenance e4b_sft_provenance.json
"""
import argparse
import datetime as dt
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
import zipfile

ALLOWED_TOOLS = {
    "run_command", "read_file", "edit_file", "write_file",
    "get_status", "submit_patch", "search_similar_code",
    "get_code_neighbors", "get_code_subgraph",
}

PROTECTED_FILE_PATTERNS = (
    re.compile(r"(^|/)tests?/"),
    re.compile(r"(^|/)test_[^/]+\.py$"),
    re.compile(r"(^|/)[^/]+_test\.py$"),
    re.compile(r"(^|/)conftest\.py$"),
    re.compile(r"(^|/)pyproject\.toml$"),
    re.compile(r"(^|/)setup\.cfg$"),
    re.compile(r"(^|/)pytest\.ini$"),
    re.compile(r"(^|/)tox\.ini$"),
)

HINT_LEAK_PATTERNS = [
    re.compile(r"\b(as|per|from|according to)\s+(the\s+)?hint\b", re.I),
    re.compile(r"\bhint(ed|s)?\s+(says|mentions|points|indicates|file|function|target)\b", re.I),
    re.compile(r"\bgold\s+(patch|file|function|target|diff)\b", re.I),
    re.compile(r"\byou\s+(told|gave|provided)\s+me\s+(the\s+)?(file|hint|function)\b", re.I),
    re.compile(r"\[LOCALIZATION_HINT\]", re.I),
    re.compile(r"ORACLE_HINT", re.I),
]

FAKE_STUB_PATTERNS = [
    re.compile(r"^Showing lines \d+\.\.\d+ of "),
    re.compile(r"^# target$"),
]

ALLOWED_PROVENANCE_MODEL_SUBSTRINGS = (
    "gemma-4-31b", "gemma-4-12b", "gemma-4-e4b", "gemma-4-e2b",
    "gemma4", "gemma-4",
)

THOUGHT_BLOCK_RE = re.compile(r"<\|channel>thought\s*(.*?)<channel\|>", re.S)


def sha256_file(path: Path) -> str:
    path = Path(path)
    if path.is_dir():
        h = hashlib.sha256()
        for p in sorted(path.glob("**/*")):
            if p.is_file():
                h.update(p.name.encode("utf-8"))
                with p.open("rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
        return h.hexdigest()
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_raw_records(inp: Path) -> list[tuple[dict, Path]]:
    """
    Recursively collect raw trajectory dicts from a .jsonl file, .json file, or directory.
    Guarantees seamless ingestion of individual trace .json files from win_frontier_6harness_overnight
    as well as consolidated .jsonl files.
    """
    inp = Path(inp)
    records: list[tuple[dict, Path]] = []
    if inp.is_dir():
        for sub_p in sorted(inp.glob("**/*")):
            if sub_p.is_file() and sub_p.suffix.lower() in (".json", ".jsonl"):
                records.extend(collect_raw_records(sub_p))
        return records

    if not inp.is_file():
        return records

    # If file has .json extension, try full JSON load (single record or list of records)
    if inp.suffix.lower() == ".json":
        try:
            content = inp.read_text(encoding="utf-8").strip()
            if content:
                parsed = json.loads(content)
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict):
                            records.append((item, inp))
                    return records
                elif isinstance(parsed, dict):
                    records.append((parsed, inp))
                    return records
        except Exception:
            pass

    # Read line-by-line for .jsonl or fallback
    try:
        with inp.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    parsed = json.loads(line)
                    if isinstance(parsed, dict):
                        records.append((parsed, inp))
                except Exception:
                    pass
    except Exception:
        pass
    return records


def load_tasks_index(tasks_path: Path) -> dict[str, dict]:
    idx: dict[str, dict] = {}
    with tasks_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            idx[d["instance_id"]] = d
    return idx


def is_protected_path(filepath: str) -> bool:
    p = str(filepath or "").strip().replace("\\", "/").lstrip("/")
    p = re.sub(r"^workspace/", "", p)
    return any(rx.search(p) for rx in PROTECTED_FILE_PATTERNS)


def cap_thought_block(text: str, max_thought_tokens: int = 1024) -> tuple[str, int]:
    """
    Cap any <|channel>thought...<channel|> block at ~max_thought_tokens (~3.6 chars/token
    conservative bound) while preserving exact Gemma-4 delimiters.
    Returns (capped_text, num_thoughts_truncated).
    """
    if not text or "<|channel>thought" not in text:
        return text, 0
    max_chars = int(max_thought_tokens * 3.6)
    trunc_count = 0

    def _repl(m: re.Match) -> str:
        nonlocal trunc_count
        body = m.group(1)
        if len(body) <= max_chars:
            return m.group(0)
        trunc_count += 1
        cut = body[:max_chars].rsplit(" ", 1)[0].rstrip()
        return f"<|channel>thought\n{cut}\n...<channel|>"

    return THOUGHT_BLOCK_RE.sub(_repl, text), trunc_count


def normalize_tool_call(tc: dict, call_idx: int) -> tuple[dict | None, str | None]:
    """Normalize a tool call dict into canonical OpenAI/Gemma-4 function-call schema."""
    if not isinstance(tc, dict):
        return None, "tool_call_not_dict"
    if "function" in tc and isinstance(tc["function"], dict):
        fn_obj = tc["function"]
        name = str(fn_obj.get("name") or "").strip()
        raw_args = fn_obj.get("arguments", {})
    else:
        name = str(tc.get("name") or "").strip()
        raw_args = tc.get("arguments", tc.get("args", {}))

    if name not in ALLOWED_TOOLS:
        return None, f"unknown_tool:{name}"

    if isinstance(raw_args, str):
        try:
            args_dict = json.loads(raw_args) if raw_args.strip() else {}
        except Exception:
            return None, f"unparseable_tool_args:{name}"
    elif isinstance(raw_args, dict):
        args_dict = dict(raw_args)
    else:
        return None, f"invalid_tool_args_type:{name}"

    # Canonicalize alias 'path' -> 'filepath' for workspace tools (1:1 HARNESS_README.md §6 parity)
    if name in ("read_file", "edit_file", "write_file") and "filepath" not in args_dict and "path" in args_dict:
        args_dict["filepath"] = args_dict.pop("path")

    # Reject diff-header leakage or placeholder stubs inside edit_file
    if name == "edit_file":
        fp = str(args_dict.get("filepath") or "")
        if is_protected_path(fp):
            return None, f"protected_file_edit:{fp}"
        old_s = str(args_dict.get("old_string", ""))
        new_s = str(args_dict.get("new_string", ""))
        if not old_s.strip():
            return None, "empty_edit_old_string"
        if "-- a/" in old_s or "++ b/" in new_s:
            return None, "diff_header_leak_in_edit"
        if any(rx.match(old_s.strip()) for rx in FAKE_STUB_PATTERNS):
            return None, "fake_stub_edit"
    elif name == "write_file":
        fp = str(args_dict.get("filepath") or "")
        if is_protected_path(fp):
            return None, f"protected_file_write:{fp}"
        if fp.startswith("/tmp/") or fp == "/tmp":
            return None, f"forbidden_tmp_write:{fp}"

    norm = {
        "id": str(tc.get("id") or f"call_{call_idx}"),
        "type": "function",
        "function": {
            "name": name,
            "arguments": args_dict,
        },
    }
    return norm, None


def sanitize_trajectory(
    raw: dict,
    holdout_set: set[str],
    tasks_index: dict[str, dict],
    system_prompt: str,
    max_thought_tokens: int = 1024,
    require_thoughts: bool = False,
) -> tuple[dict | None, str | None]:
    """
    Validate and sanitize a single raw rollout trajectory.
    Returns (sanitized_record, rejection_reason).
    """
    tid = str(raw.get("instance_id") or raw.get("task_id") or "").strip()
    if not tid or tid not in tasks_index:
        return None, "unknown_instance_id"

    if tid in holdout_set:
        return None, "holdout_task_excluded"

    if not raw.get("resolved", False):
        return None, "not_resolved"

    patch_len = int(raw.get("patch_len", len(str(raw.get("patch", "")))) or 0)
    if patch_len <= 0:
        return None, "empty_patch"

    # Rule 4 provenance guard: Gemma-generated only
    source_model = str(raw.get("source_model") or "").strip()
    if not source_model or not any(tok in source_model.lower() for tok in ALLOWED_PROVENANCE_MODEL_SUBSTRINGS):
        return None, f"disallowed_source_model:{source_model or 'missing'}"

    raw_msgs = raw.get("messages")
    if not isinstance(raw_msgs, list) or len(raw_msgs) < 4:
        return None, "too_few_messages"

    task_meta = tasks_index[tid]
    unhinted_problem = str(task_meta.get("problem_statement") or "").strip()
    if not unhinted_problem:
        return None, "missing_problem_statement"

    cleaned_msgs: list[dict] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": unhinted_problem},
    ]

    # Skip leading system/user messages from raw rollout (we always swap in canonical unhinted pair)
    start_idx = 0
    while start_idx < len(raw_msgs) and raw_msgs[start_idx].get("role") in ("system", "user"):
        start_idx += 1

    pending_calls: list[tuple[str, str]] = []  # (call_id, tool_name)
    call_counter = 0
    num_assistant_turns = 0
    num_edits = 0
    num_real_reads = 0
    has_any_thought = False
    thoughts_truncated = 0

    for m in raw_msgs[start_idx:]:
        role = str(m.get("role") or "").strip()
        content = str(m.get("content") or "")

        if role == "assistant":
            # Check for hint leakage in assistant text OR separate reasoning_content field
            thought_field = str(m.get("reasoning_content") or m.get("thought") or "").strip()
            if thought_field and "<|channel>thought" not in content:
                content = f"<|channel>thought\n{thought_field}<channel|>\n{content}".strip()

            for rx in HINT_LEAK_PATTERNS:
                if rx.search(content):
                    return None, f"hint_leak_detected:{rx.pattern[:32]}"

            if "<|channel>thought" in content:
                has_any_thought = True
            content, t_trunc = cap_thought_block(content, max_thought_tokens=max_thought_tokens)
            thoughts_truncated += t_trunc

            raw_tcs = m.get("tool_calls") or []
            norm_tcs = []
            for tc in raw_tcs:
                call_counter += 1
                ntc, err = normalize_tool_call(tc, call_counter)
                if err:
                    return None, err
                norm_tcs.append(ntc)
                fn_name = ntc["function"]["name"]
                pending_calls.append((ntc["id"], fn_name))
                if fn_name in ("edit_file", "write_file"):
                    num_edits += 1

            msg_out: dict = {"role": "assistant", "content": content}
            if norm_tcs:
                msg_out["tool_calls"] = norm_tcs
            cleaned_msgs.append(msg_out)
            num_assistant_turns += 1

        elif role == "tool":
            t_name = str(m.get("name") or "").strip()
            t_cid = str(m.get("tool_call_id") or "").strip()
            if not t_name and pending_calls:
                t_cid_exp, t_name = pending_calls.pop(0)
                t_cid = t_cid or t_cid_exp
            elif pending_calls:
                t_cid_exp, exp_name = pending_calls.pop(0)
                if t_name != exp_name:
                    return None, f"tool_name_mismatch:{t_name}!={exp_name}"
                t_cid = t_cid or t_cid_exp

            if not t_name or t_name not in ALLOWED_TOOLS:
                return None, f"missing_or_invalid_tool_name:{t_name}"

            # Reject fake read stubs
            if any(rx.match(content.strip()) for rx in FAKE_STUB_PATTERNS):
                return None, "fake_tool_stub_response"

            # Verify tool response is valid JSON
            try:
                parsed_obs = json.loads(content)
                if not isinstance(parsed_obs, dict):
                    return None, "tool_response_not_json_object"
            except Exception:
                return None, "tool_response_not_json"

            if t_name == "read_file" and parsed_obs.get("status") == "ok" and len(str(parsed_obs.get("content", ""))) > 20:
                num_real_reads += 1

            cleaned_msgs.append({
                "role": "tool",
                "tool_call_id": t_cid or f"call_{call_counter}",
                "name": t_name,
                "content": content,
            })

        elif role == "user":
            # Strip any hint text if an intermediate nudge ever carried hints
            for rx in HINT_LEAK_PATTERNS:
                if rx.search(content):
                    return None, "hint_leak_in_user_turn"
            cleaned_msgs.append({"role": "user", "content": content})

    if num_edits == 0:
        return None, "zero_edits"
    if num_real_reads == 0:
        return None, "zero_real_read_file_observations"
    if require_thoughts and not has_any_thought:
        return None, "missing_thought_blocks"

    sanitized = {
        "instance_id": tid,
        "repo": task_meta["repo"],
        "source_model": source_model,
        "rollout_mode": str(raw.get("rollout_mode") or "unknown"),
        "run_id": str(raw.get("run_id") or "unspecified"),
        "num_assistant_turns": num_assistant_turns,
        "num_tool_calls": call_counter,
        "patch_len": patch_len,
        "has_thoughts": has_any_thought,
        "thoughts_truncated": thoughts_truncated,
        "messages": cleaned_msgs,
    }
    return sanitized, None


def apply_diversity_caps(
    candidates: list[dict],
    max_per_task: int = 2,
    max_repo_share: float = 0.40,
) -> tuple[list[dict], dict]:
    """
    Apply per-task cap (<= max_per_task, preferring shortest clean runs + diverse source_models)
    and per-repo cap (<= max_repo_share).
    """
    by_task: dict[str, list[dict]] = defaultdict(list)
    for c in candidates:
        by_task[c["instance_id"]].append(c)

    after_task_cap: list[dict] = []
    dropped_task_cap = 0
    for tid in sorted(by_task.keys()):
        group = sorted(by_task[tid], key=lambda x: (x["num_tool_calls"], x["num_assistant_turns"], x["run_id"]))
        # Prefer diversity of source_model (e.g., 1 from 31B hinted + 1 from E4B on-policy) when >1 available
        picked: list[dict] = []
        seen_models = set()
        for item in group:
            if len(picked) >= max_per_task:
                break
            if item["source_model"] not in seen_models:
                picked.append(item)
                seen_models.add(item["source_model"])
        for item in group:
            if len(picked) >= max_per_task:
                break
            if item not in picked:
                picked.append(item)
        dropped_task_cap += max(0, len(group) - len(picked))
        after_task_cap.extend(picked)

    # Apply per-repo <= max_repo_share cap
    by_repo: dict[str, list[dict]] = defaultdict(list)
    for item in after_task_cap:
        by_repo[item["repo"]].append(item)
    for repo in by_repo:
        # Keep shortest / cleanest trajectories first per repo
        by_repo[repo].sort(key=lambda x: (x["num_tool_calls"], x["instance_id"]))

    if len(by_repo) >= 3 and len(after_task_cap) >= 10:
        # Iteratively trim any repo exceeding max_repo_share until equilibrium
        while True:
            total = sum(len(v) for v in by_repo.values())
            if total == 0:
                break
            max_allowed = max(1, int(math.floor(total * max_repo_share)))
            over = [(r, len(v) - max_allowed) for r, v in by_repo.items() if len(v) > max_allowed]
            if not over:
                break
            # Trim 1 from the most over-represented repo per iteration
            over.sort(key=lambda x: (-x[1], x[0]))
            r_trim = over[0][0]
            by_repo[r_trim].pop()

    final_records: list[dict] = []
    for repo in sorted(by_repo.keys()):
        final_records.extend(by_repo[repo])
    final_records.sort(key=lambda x: (x["instance_id"], x["source_model"], x["run_id"]))

    dropped_repo_cap = len(after_task_cap) - len(final_records)
    cap_stats = {
        "after_sanitization": len(candidates),
        "dropped_by_per_task_cap": dropped_task_cap,
        "dropped_by_repo_share_cap": dropped_repo_cap,
        "final_kept": len(final_records),
        "final_by_repo": dict(Counter(r["repo"] for r in final_records)),
        "final_by_source_model": dict(Counter(r["source_model"] for r in final_records)),
        "unique_tasks": len({r["instance_id"] for r in final_records}),
    }
    return final_records, cap_stats


def run_self_test() -> None:
    """Comprehensive unit tests verifying all 8 safety/quality guards."""
    print("Running sft_dataset_builder self-tests...")
    tasks_path = Path("tasks.jsonl")
    splits_path = Path("splits_99_30.json")
    assert tasks_path.exists() and splits_path.exists(), "Run build_splits.py first!"

    tasks_index = load_tasks_index(tasks_path)
    splits = json.loads(splits_path.read_text(encoding="utf-8"))
    holdout_set = set(splits["holdout_ids"])
    train_id = splits["train_ids"][0]
    holdout_id = splits["holdout_ids"][0]
    sys_cand = Path("submission_E4B_F3_v2/prompts/system.md")
    if not sys_cand.exists():
        sys_cand = Path("submissions/submission_E4B_F3_v2/prompts/system.md")
    sys_prompt = sys_cand.read_text(encoding="utf-8") if sys_cand.exists() else "You are an expert engineer."

    def make_valid(tid: str, model: str = "gemma-4-31b-it-qat-w4a16-ct", run_id: str = "r1", thought: str = "Inspecting target file.") -> dict:
        return {
            "instance_id": tid,
            "resolved": True,
            "patch_len": 350,
            "source_model": model,
            "rollout_mode": "hinted_31b",
            "run_id": run_id,
            "messages": [
                {"role": "system", "content": "old system"},
                {"role": "user", "content": "HINTED PROMPT: Look at foo.py\n" + tasks_index[tid]["problem_statement"]},
                {
                    "role": "assistant",
                    "content": f"<|channel>thought\n{thought}<channel|>",
                    "tool_calls": [{"name": "read_file", "arguments": {"filepath": "fastapi/responses.py", "start_line": 150, "end_line": 220}}],
                },
                {
                    "role": "tool",
                    "name": "read_file",
                    "content": json.dumps({"status": "ok", "filepath": "fastapi/responses.py", "content": "class ORJSONResponse(JSONResponse):\n    pass\n", "start_line": 150, "end_line": 220}),
                },
                {
                    "role": "assistant",
                    "content": "<|channel>thought\nApplying minimal fix.<channel|>",
                    "tool_calls": [{"name": "edit_file", "arguments": {"filepath": "fastapi/responses.py", "old_string": "class ORJSONResponse(JSONResponse):\n    pass", "new_string": "@deprecated('use JSONResponse')\nclass ORJSONResponse(JSONResponse):\n    pass"}}],
                },
                {
                    "role": "tool",
                    "name": "edit_file",
                    "content": json.dumps({"status": "ok", "filepath": "fastapi/responses.py", "occurrences": 1}),
                },
                {
                    "role": "assistant",
                    "content": "<|channel>thought\nSubmitting after pytest.<channel|>",
                    "tool_calls": [{"name": "submit_patch", "arguments": {}}],
                },
                {
                    "role": "tool",
                    "name": "submit_patch",
                    "content": json.dumps({"status": "ok", "patch_size": 350, "files_changed": 1}),
                },
            ],
        }

    # Test 1: Valid trajectory passes & swaps unhinted prompt + canonical system prompt (+ path -> filepath normalization)
    rec, err = sanitize_trajectory(make_valid(train_id), holdout_set, tasks_index, sys_prompt)
    assert err is None and rec is not None, f"Valid trajectory rejected: {err}"
    assert "HINTED PROMPT" not in rec["messages"][1]["content"]
    assert rec["messages"][0]["content"] == sys_prompt
    alias_tc, alias_err = normalize_tool_call({"name": "edit_file", "arguments": {"path": "src/a.py", "old_string": "x", "new_string": "y"}}, 99)
    assert alias_err is None and alias_tc["function"]["arguments"].get("filepath") == "src/a.py" and "path" not in alias_tc["function"]["arguments"]

    # Test 2: Holdout task strictly rejected
    rec, err = sanitize_trajectory(make_valid(holdout_id), holdout_set, tasks_index, sys_prompt)
    assert rec is None and err == "holdout_task_excluded", f"Expected holdout rejection, got {err}"

    # Test 3: Hint leak rejected
    leaked = make_valid(train_id, thought="As the hint says, I should edit fastapi/responses.py.")
    rec, err = sanitize_trajectory(leaked, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("hint_leak_detected"), f"Expected hint leak rejection, got {err}"

    # Test 4: Disallowed non-Gemma model (Rule 4) rejected
    paid = make_valid(train_id, model="claude-sonnet-4-5")
    rec, err = sanitize_trajectory(paid, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("disallowed_source_model"), f"Expected model rejection, got {err}"

    # Test 5: Protected test file edit rejected
    bad_edit = make_valid(train_id)
    bad_edit["messages"][4]["tool_calls"][0]["arguments"]["filepath"] = "tests/test_responses.py"
    rec, err = sanitize_trajectory(bad_edit, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("protected_file_edit"), f"Expected protected edit rejection, got {err}"

    # Test 6: Fake read stub rejected
    fake_stub = make_valid(train_id)
    fake_stub["messages"][3]["content"] = "Showing lines 1..120 of fastapi/responses.py"
    rec, err = sanitize_trajectory(fake_stub, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err == "fake_tool_stub_response", f"Expected fake stub rejection, got {err}"

    # Test 7: Long thought block capped cleanly
    long_thought = make_valid(train_id, thought=("reasoning step " * 600))
    rec, err = sanitize_trajectory(long_thought, holdout_set, tasks_index, sys_prompt, max_thought_tokens=256)
    assert err is None and rec is not None and rec["thoughts_truncated"] == 1
    assert "<channel|>" in rec["messages"][2]["content"] and len(rec["messages"][2]["content"]) < 1100

    # Test 8: Per-task (<=2) and per-repo (<=40%) diversity caps
    pool = []
    # 3 trajectories for same fastapi task + 10 fastapi + 5 rich + 5 requests
    fa_ids = [t for t in splits["train_ids"] if t.startswith("fastapi_")][:10]
    ri_ids = [t for t in splits["train_ids"] if t.startswith("rich_")][:5]
    rq_ids = [t for t in splits["train_ids"] if t.startswith("requests_")][:5]
    for k in range(3):
        r, _ = sanitize_trajectory(make_valid(fa_ids[0], run_id=f"dup_{k}"), holdout_set, tasks_index, sys_prompt)
        pool.append(r)
    for tid in fa_ids[1:] + ri_ids + rq_ids:
        r, _ = sanitize_trajectory(make_valid(tid), holdout_set, tasks_index, sys_prompt)
        pool.append(r)
    kept, stats = apply_diversity_caps(pool, max_per_task=2, max_repo_share=0.40)
    assert stats["dropped_by_per_task_cap"] == 1
    fa_share = stats["final_by_repo"]["fastapi/fastapi"] / stats["final_kept"]
    assert fa_share <= 0.40 + 1e-9, f"Expected fastapi share <= 40%, got {fa_share:.2%}"

    # Test 9: Directory & indented JSON trace ingestion
    import tempfile, shutil
    tmp_test_dir = Path(tempfile.mkdtemp(prefix="sft_test_dir_"))
    try:
        t_json = tmp_test_dir / "trace1.json"
        t_json.write_text(json.dumps(make_valid(train_id, run_id="json_trace"), indent=2), encoding="utf-8")
        t_jsonl = tmp_test_dir / "trace2.jsonl"
        t_jsonl.write_text(json.dumps(make_valid(fa_ids[1], run_id="jsonl_trace")) + "\n", encoding="utf-8")
        dir_recs = collect_raw_records(tmp_test_dir)
        assert len(dir_recs) == 2, f"Expected 2 records collected from dir, got {len(dir_recs)}"
        for raw_r, src in dir_recs:
            r_san, r_err = sanitize_trajectory(raw_r, holdout_set, tasks_index, sys_prompt)
            assert r_err is None and r_san is not None
        dir_sha = sha256_file(tmp_test_dir)
        assert isinstance(dir_sha, str) and len(dir_sha) == 64
    finally:
        shutil.rmtree(tmp_test_dir, ignore_errors=True)

    print("[PASS] All 8 sft_dataset_builder guards verified 100%!")
    print("[PASS] Directory & indented JSON trace ingestion verified 100%!")


def main():
    parser = argparse.ArgumentParser(description="Real-Trajectory SFT Dataset Builder & Provenance Logger")
    parser.add_argument("--self_test", action="store_true", help="Run built-in verification suite")
    parser.add_argument("--inputs", nargs="*", default=[], help="Input raw passing trajectory JSONL files")
    parser.add_argument("--splits", default="splits_99_30.json", help="Path to 99/30 split JSON")
    parser.add_argument("--tasks", default="tasks.jsonl", help="Path to tasks.jsonl")
    parser.add_argument("--system_prompt", default="submission_E4B_F3_v2/prompts/system.md")
    parser.add_argument("--max_thought_tokens", type=int, default=1024)
    parser.add_argument("--max_per_task", type=int, default=2)
    parser.add_argument("--max_repo_share", type=float, default=0.40)
    parser.add_argument("--require_thoughts", action="store_true")
    parser.add_argument("--out_jsonl", default="e4b_sft_train.jsonl")
    parser.add_argument("--out_provenance", default="e4b_sft_provenance.json")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return

    if not args.inputs:
        parser.print_help()
        sys.exit(1)

    splits = json.loads(Path(args.splits).read_text(encoding="utf-8"))
    holdout_set = set(splits["holdout_ids"])
    tasks_index = load_tasks_index(Path(args.tasks))
    sys_p = Path(args.system_prompt)
    if not sys_p.exists() and (Path("submissions") / args.system_prompt).exists():
        sys_p = Path("submissions") / args.system_prompt
    if sys_p.is_dir() and (sys_p / "prompts" / "system.md").exists():
        sys_p = sys_p / "prompts" / "system.md"
    if sys_p.suffix.lower() == ".zip":
        with zipfile.ZipFile(sys_p, "r") as zf:
            if "prompts/system.md" in zf.namelist():
                system_prompt = zf.read("prompts/system.md").decode("utf-8").strip()
            else:
                md_files = [n for n in zf.namelist() if n.endswith(".md")]
                assert md_files, f"No .md prompt found inside zip archive: {sys_p}"
                system_prompt = zf.read(md_files[0]).decode("utf-8").strip()
    else:
        system_prompt = sys_p.read_text(encoding="utf-8").strip()

    if "e4b" in args.out_jsonl.lower() and len(system_prompt) > 2200:
        print(f"[WARNING] System prompt length is {len(system_prompt)} characters (> 2,150 chars / 497 tokens)!")
        print("          E4B (gemma-4-e4b) uses 512-token local sliding-window attention across 35 layers.")
        print("          Prompts exceeding 512 tokens evict instructions, spiking edit errors to 92.3%.")
        print("          Ensure this is intentional, or use submission_E4B_F3_v2/prompts/system.md for E4B SFT training!")

    accepted: list[dict] = []
    rejections: Counter = Counter()
    input_manifests: list[dict] = []

    for inp_str in args.inputs:
        inp = Path(inp_str)
        if not inp.exists():
            print(f"WARNING: input missing: {inp}")
            continue
        raw_records = collect_raw_records(inp)
        raw_count = len(raw_records)
        ok_count = 0
        for raw, src_path in raw_records:
            rec, err = sanitize_trajectory(
                raw,
                holdout_set=holdout_set,
                tasks_index=tasks_index,
                system_prompt=system_prompt,
                max_thought_tokens=args.max_thought_tokens,
                require_thoughts=args.require_thoughts,
            )
            if err:
                rejections[err] += 1
            else:
                accepted.append(rec)
                ok_count += 1
        input_manifests.append({
            "file": str(inp),
            "sha256": sha256_file(inp),
            "raw_rows": raw_count,
            "sanitized_rows": ok_count,
        })

    final_records, cap_stats = apply_diversity_caps(
        accepted,
        max_per_task=args.max_per_task,
        max_repo_share=args.max_repo_share,
    )

    out_jsonl = Path(args.out_jsonl)
    with out_jsonl.open("w", encoding="utf-8") as f:
        for r in final_records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    provenance = {
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "rule_compliance": {
            "gemma_generated_only": True,
            "zero_paid_frontier_outputs": True,
            "holdout_30_excluded": True,
            "holdout_overlap_count": len(holdout_set & {r["instance_id"] for r in final_records}),
        },
        "config": {
            "splits_file": args.splits,
            "system_prompt_file": args.system_prompt,
            "max_thought_tokens": args.max_thought_tokens,
            "max_per_task": args.max_per_task,
            "max_repo_share": args.max_repo_share,
            "require_thoughts": args.require_thoughts,
        },
        "inputs": input_manifests,
        "rejection_counts": dict(rejections.most_common()),
        "cap_stats": cap_stats,
        "output_file": str(out_jsonl),
        "output_sha256": sha256_file(out_jsonl),
    }
    assert provenance["rule_compliance"]["holdout_overlap_count"] == 0

    Path(args.out_provenance).write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print(f"Built {len(final_records)} sanitized trajectories -> {out_jsonl}")
    print(f"Provenance logged -> {args.out_provenance}")
    print("Repo balance:", cap_stats["final_by_repo"])
    if rejections:
        print("Rejections:", dict(rejections.most_common(8)))


if __name__ == "__main__":
    main()
