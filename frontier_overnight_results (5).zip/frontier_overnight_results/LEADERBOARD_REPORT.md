# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-21 10:32:27 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`E4B_F3_v2`** | `0.0%` (0/8) | `4/8` | `47.37%` | `17` | `23.75` | `49.38m` | Compact 497-tok Copilot + 4 Trap Laws prompt for E4B |
