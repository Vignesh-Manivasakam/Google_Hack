#!/usr/bin/env python3
"""
win_phase2_tournament.py — Core shared utilities for local evaluation, AST code graph, and sandbox file operations.
Patched v4 (Definitive):
1. Uses AutoModelForCausalLM (resolves Gemma4ForConditionalGeneration cleanly in 10s, zero UNEXPECTED weight mismatch!).
2. Strips vision/audio towers + pins the 5.49 GiB `embed_tokens_per_layer` (PLE) lookup table to CPU RAM with an auto-verified CUDA output hook -> drops GPU VRAM from 14.79 / 13.90 GiB down to ~8.41 GiB / 16.00 GiB!
3. Fixes `AttributeError: 'list' object has no attribute 'items'` in `RepoCodeGraph` when `graphs/*.json` stores NetworkX list-of-dicts `nodes`!
4. Full native Gemma 4 `<|"|>...<|"|>` & unquoted-key tool-call parser + startup-verified multi-turn chat template formatter!
"""
from pathlib import Path
import ast as _py_ast
import gc
import json
import re
import sys

# Enforce Python >= 3.12 (prevents Protocol.__instancecheck__ false positives on 3.11)
assert sys.version_info >= (3, 12), (
    f"FATAL: This script requires Python >= 3.12 to avoid false-positive pytest results "
    f"(Protocol.__instancecheck__ behavior changed in 3.12). Current: {sys.version}"
)


def _extract_thought_and_text(raw_txt: str) -> tuple[str, str]:
    """Extract <|channel>thought ... <channel|> tokens and return (thought, plain_text)."""
    thought_m = re.search(r"<\|channel>thought\n?(.*?)<channel\|>", raw_txt, flags=re.DOTALL)
    if not thought_m:
        thought_m = re.search(r"<\|thought\|>\n?(.*?)<thought\|>", raw_txt, flags=re.DOTALL)
    if not thought_m:
        thought_m = re.search(r"<thought>(.*?)</thought>", raw_txt, flags=re.DOTALL)
    thought = thought_m.group(1).strip() if thought_m else ""
    plain = re.sub(r"<\|channel>thought\n?.*?<channel\|>", "", raw_txt, flags=re.DOTALL)
    plain = re.sub(r"<\|thought\|>\n?.*?<thought\|>", "", plain, flags=re.DOTALL)
    plain = re.sub(r"<thought>.*?</thought>", "", plain, flags=re.DOTALL)
    plain = re.sub(r"(?:<\|tool_call\|?>|<tool_call>).*?(?:<tool_call\|?>|</tool_call>)", "", plain, flags=re.DOTALL)
    for tok in ("<|turn|>", "<turn|>", "<end_of_turn>", "<eos>", "<pad>"):
        plain = plain.replace(tok, "")
    return thought, plain.strip()


def _build_workspace_tree(ws: Path) -> str:
    """Build a filtered text tree representation of the workspace."""
    entries = []
    if not ws.exists():
        return ""
    for p in sorted(ws.rglob("*")):
        if any(ign in p.parts for ign in [".git", "__pycache__", ".pytest_cache", "node_modules", ".eggs", ".tox"]):
            continue
        try:
            rel = p.relative_to(ws).as_posix()
        except ValueError:
            continue
        if p.is_dir():
            entries.append(f"{rel}/")
        else:
            entries.append(rel)
        if len(entries) >= 200:
            entries.append("... (truncated to 200 entries)")
            break
    return "\n".join(entries)


def tool_read_file(ws: Path, filepath: str, start_line: int | None = None, end_line: int | None = None) -> dict:
    """Windowed read_file tool with 150-line default window and truncation metadata."""
    rel = str(filepath).strip().lstrip("/").removeprefix("workspace/")
    if not rel:
        return {"status": "error", "error_type": "FileNotFoundError", "message": "filepath is required."}
    fp = (ws / rel).resolve()
    if not fp.exists() or not fp.is_file():
        return {"status": "error", "error_type": "FileNotFoundError", "message": f"File not found: {rel}"}
    try:
        lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as exc:
        return {"status": "error", "message": f"Cannot read {rel}: {exc}"}
    total_lines = len(lines)
    s = max(1, int(start_line)) if start_line is not None else 1
    e = min(total_lines, int(end_line)) if end_line is not None else min(total_lines, s + 149)
    if s > total_lines:
        return {"status": "ok", "content": "", "start_line": s, "end_line": e, "total_lines": total_lines, "is_truncated": False}
    selected = lines[s - 1:e]
    content = "\n".join(f"{s + i:5d} | {line}" for i, line in enumerate(selected))
    is_truncated = (e < total_lines)
    return {
        "status": "ok",
        "content": content,
        "start_line": s,
        "end_line": e,
        "total_lines": total_lines,
        "is_truncated": is_truncated,
    }


def tool_edit_file(ws: Path, filepath: str, old_string: str, new_string: str, allow_multiple: bool = False) -> dict:
    """Flexible edit_file replacement with exact old_string matching."""
    rel = str(filepath).strip().lstrip("/").removeprefix("workspace/")
    fp = (ws / rel).resolve()
    if not fp.exists() or not fp.is_file():
        return {"status": "error", "error_type": "FileNotFoundError", "message": f"File not found: {rel}"}
    try:
        text = fp.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        return {"status": "error", "message": f"Cannot read {rel}: {exc}"}
    old_norm = old_string.replace("\r\n", "\n")
    text_norm = text.replace("\r\n", "\n")
    if old_norm not in text_norm:
        return {"status": "error", "error_type": "NoMatchError", "message": f"old_string not found in {rel}. Re-read lines around target."}
    count = text_norm.count(old_norm)
    if count > 1 and not allow_multiple:
        return {"status": "error", "error_type": "MultipleMatchesError", "message": f"old_string matched {count} times in {rel}. Add more surrounding lines for unique context."}
    replaced = text_norm.replace(old_norm, new_string.replace("\r\n", "\n"), 1 if not allow_multiple else -1)
    fp.write_text(replaced, encoding="utf-8", newline="\n")
    return {"status": "ok", "filepath": rel, "replacements": count if allow_multiple else 1}


def _normalize_graph_data(data) -> dict:
    """Normalize both NetworkX list-of-dicts (`{'nodes': [...], 'links': [...]}`) and dict-keyed `{'nodes': {...}}` schemas!"""
    if not isinstance(data, dict):
        return {}
    raw_nodes = data.get("nodes", {})
    nodes_dict = {}
    if isinstance(raw_nodes, dict):
        for nid, ndata in raw_nodes.items():
            nodes_dict[str(nid)] = dict(ndata) if isinstance(ndata, dict) else {"name": str(nid), "value": ndata}
    elif isinstance(raw_nodes, list):
        for idx, item in enumerate(raw_nodes):
            if isinstance(item, dict):
                nid = str(item.get("id") or item.get("node_id") or item.get("qualified_name") or item.get("name") or f"node_{idx}")
                d = dict(item)
                d.setdefault("calls", [])
                d.setdefault("called_by", [])
                if "start_line" not in d:
                    for lk in ("lineno", "line", "line_start"):
                        if lk in d and d[lk] is not None:
                            d["start_line"] = d[lk]
                            break
                if "end_line" not in d:
                    for ek in ("end_lineno", "line_end"):
                        if ek in d and d[ek] is not None:
                            d["end_line"] = d[ek]
                            break
                if "filepath" not in d:
                    for fk in ("file", "path", "relpath"):
                        if fk in d and d[fk]:
                            d["filepath"] = d[fk]
                            break
                nodes_dict[nid] = d
            else:
                nodes_dict[str(item)] = {"name": str(item), "calls": [], "called_by": []}

    raw_edges = data.get("links") or data.get("edges") or []
    if isinstance(raw_edges, list):
        for ed in raw_edges:
            if isinstance(ed, dict):
                u = str(ed.get("source") or ed.get("from") or "")
                v = str(ed.get("target") or ed.get("to") or "")
                if u and v:
                    if u in nodes_dict:
                        c_list = nodes_dict[u].setdefault("calls", [])
                        if isinstance(c_list, list) and v not in c_list and len(c_list) < 25:
                            c_list.append(v)
                    if v in nodes_dict:
                        cb_list = nodes_dict[v].setdefault("called_by", [])
                        if isinstance(cb_list, list) and u not in cb_list and len(cb_list) < 25:
                            cb_list.append(u)
    return nodes_dict


class RepoCodeGraph:
    """Pre-built AST code graph navigation (search, neighbors, subgraph) + live workspace AST fallback."""
    def __init__(self, gemma_dir: Path, repo: str, base_commit: str, ws: Path | None = None):
        short = repo.split("/")[-1].lower()
        gpath = Path(gemma_dir) / "graphs" / f"{short}_{base_commit}.json"
        self.nodes: dict = {}
        if gpath.exists():
            try:
                data = json.loads(gpath.read_text(encoding="utf-8"))
                self.nodes = _normalize_graph_data(data)
            except Exception:
                self.nodes = {}
        if not self.nodes and ws is not None and Path(ws).exists():
            self.index_workspace(Path(ws))

    def index_workspace(self, ws: Path) -> None:
        """Build fast in-memory AST symbol & call index directly from /workspace Python files if prebuilt graph is missing."""
        if isinstance(self.nodes, list):
            self.nodes = _normalize_graph_data({"nodes": self.nodes})
        if self.nodes:
            return
        defined_names = {}
        raw_calls = {}
        for pyf in ws.rglob("*.py"):
            if any(p in pyf.parts for p in (".git", "__pycache__", ".tox", "docs_src")):
                continue
            try:
                rel = pyf.relative_to(ws).as_posix()
                src = pyf.read_text(encoding="utf-8", errors="replace")
                tree = _py_ast.parse(src)
            except Exception:
                continue
            for node in _py_ast.walk(tree):
                if isinstance(node, (_py_ast.ClassDef, _py_ast.FunctionDef, _py_ast.AsyncFunctionDef)):
                    nid = f"{rel}:{node.name}:L{node.lineno}"
                    doc = (_py_ast.get_docstring(node) or "")[:160]
                    callees = []
                    for sub in _py_ast.walk(node):
                        if isinstance(sub, _py_ast.Call):
                            if isinstance(sub.func, _py_ast.Name):
                                callees.append(sub.func.id)
                            elif isinstance(sub.func, _py_ast.Attribute):
                                callees.append(sub.func.attr)
                    self.nodes[nid] = {
                        "filepath": rel,
                        "name": node.name,
                        "start_line": node.lineno,
                        "end_line": getattr(node, "end_lineno", node.lineno + 30),
                        "doc": doc,
                        "calls": sorted(set(callees))[:15],
                        "called_by": [],
                    }
                    defined_names.setdefault(node.name, []).append(nid)
                    raw_calls[nid] = set(callees)
        for caller_id, cset in raw_calls.items():
            for cname in cset:
                for target_id in defined_names.get(cname, []):
                    if target_id != caller_id and len(self.nodes[target_id]["called_by"]) < 15:
                        self.nodes[target_id]["called_by"].append(caller_id)

    def _ensure_dict(self) -> dict:
        if isinstance(self.nodes, list):
            self.nodes = _normalize_graph_data({"nodes": self.nodes})
        elif not isinstance(self.nodes, dict):
            self.nodes = {}
        return self.nodes

    def search(self, query: str, k: int = 8) -> dict:
        nodes_map = self._ensure_dict()
        q_str = str(query).strip()
        q_low = q_str.lower()
        q_toks = [t for t in re.findall(r"[a-z0-9_]+", q_low) if len(t) >= 2]
        scored = []
        for nid, node_data in nodes_map.items():
            nid_low = nid.lower()
            name_low = str(node_data.get("name", "")).lower() if isinstance(node_data, dict) else ""
            txt = (nid_low + " " + json.dumps(node_data, ensure_ascii=False)).lower()
            score = 0
            if q_low and q_low in name_low:
                score += 10
            elif q_low and q_low in nid_low:
                score += 6
            for tok in q_toks:
                if tok == name_low:
                    score += 8
                elif tok in nid_low:
                    score += 4
                elif tok in txt:
                    score += 1
            if score > 0:
                entry = nid
                if isinstance(node_data, dict) and "start_line" in node_data and ":L" not in nid:
                    entry = f"{node_data.get('filepath', nid)}:L{node_data['start_line']}-{node_data.get('end_line', '')}"
                scored.append((score, entry))
        scored.sort(key=lambda x: x[0], reverse=True)
        return {"status": "ok", "query": q_str, "matches": [x[1] for x in scored[: max(1, int(k or 8))]]}

    def neighbors(self, node: str) -> dict:
        nodes_map = self._ensure_dict()
        q = str(node).strip()
        if not q:
            return {"status": "ok", "node": q, "neighbors": []}
        q_low = q.lower()
        target = next(
            (nid for nid in nodes_map if nid == q or (isinstance(nodes_map[nid], dict) and str(nodes_map[nid].get("name", "")) == q) or nid.endswith(f":{q}") or nid.endswith(f".{q}") or nid.endswith(f"::{q}")),
            None,
        )
        if not target:
            target = next((nid for nid in nodes_map if q_low in nid.lower()), None)
        if not target:
            return {"status": "ok", "node": q, "neighbors": []}
        node_info = nodes_map.get(target, {})
        calls_l = node_info.get("calls", []) if isinstance(node_info, dict) else []
        cby_l = node_info.get("called_by", []) if isinstance(node_info, dict) else []
        neighbors = (list(calls_l) if isinstance(calls_l, list) else []) + (list(cby_l) if isinstance(cby_l, list) else [])
        return {
            "status": "ok",
            "node": target,
            "start_line": node_info.get("start_line") if isinstance(node_info, dict) else None,
            "end_line": node_info.get("end_line") if isinstance(node_info, dict) else None,
            "neighbors": neighbors[:15],
        }

    def subgraph(self, node: str, hops: int = 2) -> dict:
        nodes_map = self._ensure_dict()
        nb = self.neighbors(node)
        target = nb.get("node", node)
        if target not in nodes_map:
            return {"status": "ok", "node": node, "nodes": []}
        visited = set()
        frontier = {target}
        for _ in range(hops):
            nxt = set()
            for cur in frontier:
                if cur not in visited:
                    visited.add(cur)
                    n_info = nodes_map.get(cur, {})
                    if isinstance(n_info, dict):
                        c1 = n_info.get("calls", [])
                        c2 = n_info.get("called_by", [])
                        if isinstance(c1, list):
                            nxt.update(str(x["target"]) if isinstance(x, dict) and "target" in x else str(x) for x in c1)
                        if isinstance(c2, list):
                            nxt.update(str(x["source"]) if isinstance(x, dict) and "source" in x else str(x) for x in c2)
            frontier = {x for x in (nxt - visited) if x in nodes_map}
        return {"status": "ok", "node": target, "nodes": list(visited)[:25]}


def _to_gemma4_literal(val) -> str:
    """Serialize Python objects into Gemma 4 native `<|"|>...<|"|>` / unquoted-key format."""
    if val is None:
        return "null"
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        return f'<|"|>{val}<|"|>'
    if isinstance(val, list):
        return "[" + ",".join(_to_gemma4_literal(x) for x in val) + "]"
    if isinstance(val, dict):
        parts = []
        for k in sorted(val.keys(), key=lambda x: str(x)):
            clean_k = re.sub(r"[^A-Za-z0-9_]", "_", str(k)) or "key"
            parts.append(f"{clean_k}:{_to_gemma4_literal(val[k])}")
        return "{" + ",".join(parts) + "}"
    return f'<|"|>{str(val)}<|"|>'


def _sanitize_tool_obs_dict(obs_raw) -> dict:
    """Ensure tool response content is always a clean JSON-safe Python dict."""
    if isinstance(obs_raw, dict):
        d = obs_raw
    elif isinstance(obs_raw, str):
        s = obs_raw.strip()
        try:
            parsed = json.loads(s)
            d = parsed if isinstance(parsed, dict) else {"result": parsed}
        except Exception:
            d = {"output": obs_raw[:4500]}
    else:
        d = {"result": str(obs_raw)[:4500]}

    clean = {}
    for k, v in d.items():
        ks = re.sub(r"[^A-Za-z0-9_]", "_", str(k)) or "field"
        if isinstance(v, str) and len(v) > 4200:
            clean[ks] = v[:4200] + "...(truncated)"
        elif isinstance(v, (bool, int, float, str)) or v is None:
            clean[ks] = v
        else:
            s_val = json.dumps(v, ensure_ascii=False)
            if len(s_val) > 4200:
                clean[ks] = s_val[:4200] + "...(truncated)"
            else:
                clean[ks] = v
    return clean or {"status": "ok"}


def _build_gemma4_hybrid_device_map(model_id: str) -> dict | None:
    """
    Route vision/audio towers AND the 5.49 GiB `embed_tokens_per_layer` PLE table directly to CPU RAM,
    while routing all 42 active transformer layers (`8.41 GiB`) directly to GPU 0!
    """
    mdir = Path(model_id)
    idx_file = mdir / "model.safetensors.index.json"
    if not idx_file.exists():
        return None
    try:
        data = json.loads(idx_file.read_text(encoding="utf-8"))
        weight_map = data.get("weight_map", {})
        if not weight_map:
            return None
        mm_tokens = ("vision", "audio", "multi_modal", "mm_projector", "sound")
        prefixes = set()
        has_ple = False
        for k in weight_map.keys():
            parts = k.split(".")
            if "embed_tokens_per_layer" in parts:
                idx_p = parts.index("embed_tokens_per_layer")
                prefixes.add(".".join(parts[: idx_p + 1]))
                has_ple = True
            elif len(parts) >= 3 and parts[0] == "model" and parts[1] == "language_model":
                prefixes.add(".".join(parts[:3]))
            elif len(parts) >= 2 and parts[0] == "model":
                prefixes.add(f"{parts[0]}.{parts[1]}")
            else:
                prefixes.add(parts[0])
        dmap = {}
        for p in sorted(prefixes):
            low = p.lower()
            if any(tok in low for tok in mm_tokens) or (has_ple and "embed_tokens_per_layer" in low):
                dmap[p] = "cpu"
            else:
                dmap[p] = 0
        return dmap
    except Exception:
        return None


class LocalGemmaEngine:
    """Local Gemma 4 inference wrapper with 10s direct safetensors loading, 8.41 GiB VRAM PLE offload & native tool calls."""

    @staticmethod
    def _parse_gemma4_kv_body(body: str) -> dict:
        body = body.strip()
        if not body or body == "{}":
            return {}
        if body.startswith("{") and body.endswith("}"):
            try:
                res = json.loads(body)
                if isinstance(res, dict):
                    return res
            except Exception:
                pass

        inner = body[1:-1].strip() if (body.startswith("{") and body.endswith("}")) else body
        placeholders = {}

        def _repl_delim(m):
            key = f"__G4STR_{len(placeholders)}__"
            placeholders[key] = m.group(1)
            return json.dumps(key)

        stage1 = re.sub(r'<\|"\|>(.*?)<\|"\|>', _repl_delim, inner, flags=re.DOTALL)

        out = []
        in_str = False
        esc = False
        i = 0
        n = len(stage1)
        while i < n:
            ch = stage1[i]
            if in_str:
                out.append(ch)
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                i += 1
            else:
                if ch == '"':
                    in_str = True
                    out.append(ch)
                    i += 1
                else:
                    m = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*:", stage1[i:])
                    if m and (not out or out[-1] in ("{", ",", " ", "\n", "\t", "\r")):
                        kname = m.group(1)
                        if kname not in ("true", "false", "null"):
                            out.append(f'"{kname}":')
                            i += m.end()
                            continue
                    out.append(ch)
                    i += 1

        stage2 = "{" + "".join(out) + "}"
        stage2 = re.sub(r":\s*True\b", ": true", stage2)
        stage2 = re.sub(r":\s*False\b", ": false", stage2)
        stage2 = re.sub(r":\s*None\b", ": null", stage2)

        def _restore(obj):
            if isinstance(obj, str):
                if obj in placeholders:
                    return placeholders[obj]
                for pk, pv in placeholders.items():
                    if pk in obj:
                        obj = obj.replace(pk, pv)
                return obj
            if isinstance(obj, dict):
                return {str(_restore(k)).strip().strip('"').strip("'"): _restore(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_restore(x) for x in obj]
            return obj

        try:
            parsed = json.loads(stage2)
            if isinstance(parsed, dict):
                return _restore(parsed)
        except Exception:
            pass

        fallback = {}
        for km in re.finditer(r'["\']?([A-Za-z_][A-Za-z0-9_]*)["\']?\s*:\s*"(__G4STR_\d+__)"', stage2):
            fallback[km.group(1)] = placeholders.get(km.group(2), "")
        for km in re.finditer(r'["\']?([A-Za-z_][A-Za-z0-9_]*)["\']?\s*:\s*"((?:\\.|[^"\\])*)"', stage2):
            if km.group(1) not in fallback:
                try:
                    fallback[km.group(1)] = json.loads(f'"{km.group(2)}"')
                except Exception:
                    fallback[km.group(1)] = km.group(2)
        for km in re.finditer(r'["\']?([A-Za-z_][A-Za-z0-9_]*)["\']?\s*:\s*(-?\d+|true|false)', stage2):
            k, v = km.group(1), km.group(2)
            if k not in fallback:
                fallback[k] = (v == "true") if v in ("true", "false") else int(v)
        return fallback

    @classmethod
    def _parse_gemma4_tool_calls(cls, text: str) -> list[dict]:
        calls = []
        tc_blocks = re.findall(r"(?:<\|tool_call\|?>|<tool_call>)\s*(.*?)\s*(?:<tool_call\|?>|</tool_call>)", text, flags=re.DOTALL)
        for blk in tc_blocks:
            m = re.match(r"call:([A-Za-z0-9_]+)\s*(\{.*\})\s*$", blk, flags=re.DOTALL)
            if m:
                fn = m.group(1).strip()
                args = cls._parse_gemma4_kv_body(m.group(2))
                calls.append({"type": "function", "function": {"name": fn, "arguments": args}, "name": fn, "arguments": args})
            else:
                try:
                    j = json.loads(blk)
                    if isinstance(j, dict):
                        fn = j["function"]["name"] if ("function" in j and isinstance(j["function"], dict)) else j.get("name", "")
                        args = j["function"].get("arguments", {}) if ("function" in j and isinstance(j["function"], dict)) else j.get("arguments", {})
                        if isinstance(args, str):
                            args = json.loads(args)
                        if fn:
                            calls.append({"type": "function", "function": {"name": fn, "arguments": args}, "name": fn, "arguments": args})
                except Exception:
                    pass

        if not calls:
            for m in re.finditer(r"call:([A-Za-z0-9_]+)\s*\{", text):
                fn = m.group(1).strip()
                start_brace = m.end() - 1
                i, depth, n = start_brace, 0, len(text)
                in_g4 = in_dq = esc = False
                end_brace = -1
                while i < n:
                    if not in_dq and text.startswith('<|"|>', i):
                        in_g4 = not in_g4
                        i += 5
                        continue
                    ch = text[i]
                    if in_g4:
                        i += 1
                        continue
                    if in_dq:
                        if esc:
                            esc = False
                        elif ch == "\\":
                            esc = True
                        elif ch == '"':
                            in_dq = False
                        i += 1
                        continue
                    if ch == '"':
                        in_dq = True
                    elif ch == "{":
                        depth += 1
                    elif ch == "}":
                        depth -= 1
                        if depth == 0:
                            end_brace = i
                            break
                    i += 1
                if end_brace != -1:
                    args = cls._parse_gemma4_kv_body(text[start_brace:end_brace + 1])
                    calls.append({"type": "function", "function": {"name": fn, "arguments": args}, "name": fn, "arguments": args})
        return calls

    def __init__(self, model_id: str, adapter_dir: Path | None = None):
        from transformers import AutoTokenizer, AutoModelForCausalLM
        import torch
        import torch.nn as nn

        class _CpuPinnedEmbedding(nn.Module):
            """Keep giant 5.49 GiB PLE embedding table in CPU RAM and transfer only looked-up token slices (~20 KB/step) to GPU!"""
            def __init__(self, emb: nn.Module):
                super().__init__()
                self._cpu_emb = emb.to("cpu")

            def forward(self, input_ids, *args, **kwargs):
                orig_dev = input_ids.device
                out = self._cpu_emb(input_ids.to("cpu"), *args, **kwargs)
                return out.to(device=orig_dev, non_blocking=True)

            def __getattr__(self, name: str):
                try:
                    return super().__getattr__(name)
                except AttributeError:
                    return getattr(self._cpu_emb, name)

        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # NEVER call Gemma4ForCausalLM on a Gemma4ForConditionalGeneration checkpoint!
        # AutoModelForCausalLM resolves config.architectures[0] cleanly with 2076/2076 matched keys in ~10s!
        dmap = _build_gemma4_hybrid_device_map(model_id)
        print(f"[+] Fast-loading {model_id} onto GPU 0 (hybrid PLE/multimodal CPU offload={bool(dmap)})...", flush=True)
        loaded_model = None
        if dmap:
            try:
                loaded_model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, device_map=dmap)
            except TypeError:
                loaded_model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, device_map=dmap)
            except Exception as exc:
                print(f"[WARN] Hybrid device_map fallback ({exc}); loading with device_map={{'': 0}}...", flush=True)
                loaded_model = None

        if loaded_model is None:
            try:
                loaded_model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, device_map={"": 0})
            except TypeError:
                loaded_model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, device_map={"": 0})

        # Detach accelerate hooks so deleted/offloaded modules don't leak GPU VRAM
        try:
            from accelerate.hooks import remove_hook_from_submodules
            remove_hook_from_submodules(loaded_model)
        except Exception:
            pass
        for attr_h in ("hf_device_map", "_hf_hook"):
            if hasattr(loaded_model, attr_h):
                try:
                    delattr(loaded_model, attr_h)
                except Exception:
                    pass

        # 1. Purge all vision/audio/multimodal towers
        purged = []
        strip_exact = {
            "vision_tower", "audio_tower", "embed_vision", "embed_audio",
            "multi_modal_projector", "vision_projector", "audio_projector",
            "mm_projector", "audio_model", "vision_model",
        }
        strip_sub = ("vision", "audio", "multi_modal", "mm_projector", "sound")
        ple_targets = []
        for parent_name, parent_mod in list(loaded_model.named_modules()):
            for child_name in list(getattr(parent_mod, "_modules", {}).keys()):
                low = child_name.lower()
                if child_name == "embed_tokens_per_layer":
                    ple_targets.append((parent_mod, child_name))
                elif child_name in strip_exact or any(tok in low for tok in strip_sub):
                    try:
                        sub_m = parent_mod._modules[child_name]
                        if sub_m is not None:
                            sub_m.to("meta")
                    except Exception:
                        pass
                    del parent_mod._modules[child_name]
                    if hasattr(parent_mod, child_name):
                        try:
                            delattr(parent_mod, child_name)
                        except Exception:
                            pass
                    purged.append(f"{parent_name}.{child_name}".lstrip("."))

        # 2. Wrap `embed_tokens_per_layer` (5.49 GiB PLE lookup table) on CPU and self-verify with a 2-token CUDA forward pass!
        for p_mod, c_name in ple_targets:
            orig_ple = getattr(p_mod, c_name)
            wrapped_ple = _CpuPinnedEmbedding(orig_ple)
            setattr(p_mod, c_name, wrapped_ple)

        self.model = loaded_model
        del loaded_model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.empty_cache()

        # Self-verify CUDA forward pass with CPU-pinned PLE; auto-restore to GPU only if HF internals require CUDA weight tensor
        if ple_targets and torch.cuda.is_available():
            try:
                with torch.inference_mode():
                    _ = self.model(input_ids=torch.tensor([[2, 100]], device="cuda:0"))
                print(f"[+] Verified CPU-pinned `embed_tokens_per_layer` (freed ~5.49 GiB GPU VRAM -> ~8.41 GiB active)!", flush=True)
            except Exception as ple_exc:
                print(f"[WARN] Restoring PLE table to GPU ({ple_exc})...", flush=True)
                for p_mod, c_name in ple_targets:
                    w = getattr(p_mod, c_name)
                    if isinstance(w, _CpuPinnedEmbedding):
                        setattr(p_mod, c_name, w._cpu_emb.to("cuda:0"))

        if adapter_dir and Path(adapter_dir).exists():
            from peft import PeftModel
            print(f"[+] Attaching PEFT adapter from {adapter_dir}...", flush=True)
            self.model = PeftModel.from_pretrained(self.model, str(adapter_dir))
        self.model.eval()

        self._tool_schema_mode = self._probe_chat_template()
        print(f"[+] Multi-turn Gemma 4 chat template verified (mode={self._tool_schema_mode})!", flush=True)

    def _probe_chat_template(self) -> str:
        dummy_tools = [{
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Read file",
                "parameters": {"type": "object", "properties": {"filepath": {"type": "string"}}, "required": ["filepath"]},
            },
        }]
        for mode in ("dict_content", "str_content", "json_args_str_content"):
            try:
                test_msgs = [
                    {"role": "system", "content": "You are a helpful engineer."},
                    {"role": "user", "content": "Inspect a.py"},
                    {
                        "role": "assistant",
                        "content": "",
                        "tool_calls": [{
                            "id": "c1",
                            "type": "function",
                            "function": {
                                "name": "read_file",
                                "arguments": json.dumps({"filepath": "a.py"}) if mode == "json_args_str_content" else {"filepath": "a.py"},
                            },
                        }],
                    },
                    {
                        "role": "tool",
                        "tool_call_id": "c1",
                        "name": "read_file",
                        "content": {"status": "ok", "content": "x = 1"} if mode == "dict_content" else json.dumps({"status": "ok", "content": "x = 1"}),
                    },
                ]
                rendered = self.tokenizer.apply_chat_template(test_msgs, tools=dummy_tools, tokenize=False, add_generation_prompt=True)
                if rendered and "read_file" in rendered:
                    return mode
            except Exception:
                continue
        return "native_stitch"

    def format_messages_safe(self, messages: list[dict], tools: list[dict] | None = None) -> str:
        """Render multi-turn tool conversations safely without triggering Jinja crashes."""
        mode = getattr(self, "_tool_schema_mode", "str_content")
        if mode != "native_stitch":
            norm_msgs = []
            for m in messages:
                role = m.get("role", "user")
                if role == "assistant" and m.get("tool_calls"):
                    norm_tcs = []
                    for tc in m["tool_calls"]:
                        fn_obj = tc.get("function", tc)
                        fn_name = fn_obj.get("name", "")
                        fn_args = fn_obj.get("arguments", {})
                        if isinstance(fn_args, str) and mode != "json_args_str_content":
                            try:
                                fn_args = json.loads(fn_args)
                            except Exception:
                                fn_args = {}
                        elif isinstance(fn_args, dict) and mode == "json_args_str_content":
                            fn_args = json.dumps(fn_args, ensure_ascii=False)
                        norm_tcs.append({
                            "id": tc.get("id", "call_1"),
                            "type": "function",
                            "function": {"name": fn_name, "arguments": fn_args},
                        })
                    norm_msgs.append({"role": "assistant", "content": m.get("content") or "", "tool_calls": norm_tcs})
                elif role == "tool":
                    obs_dict = _sanitize_tool_obs_dict(m.get("content", {}))
                    norm_msgs.append({
                        "role": "tool",
                        "tool_call_id": m.get("tool_call_id", "call_1"),
                        "name": m.get("name", "tool"),
                        "content": obs_dict if mode == "dict_content" else json.dumps(obs_dict, ensure_ascii=False),
                    })
                else:
                    norm_msgs.append({"role": role, "content": str(m.get("content") or "")})
            try:
                if tools:
                    return self.tokenizer.apply_chat_template(norm_msgs, tools=tools, tokenize=False, add_generation_prompt=True)
                return self.tokenizer.apply_chat_template(norm_msgs, tokenize=False, add_generation_prompt=True)
            except Exception:
                pass

        head_msgs = [m for m in messages[:2] if m.get("role") in ("system", "user")]
        base = self.tokenizer.apply_chat_template(head_msgs, tools=tools, tokenize=False, add_generation_prompt=False) if tools else self.tokenizer.apply_chat_template(head_msgs, tokenize=False, add_generation_prompt=False)
        use_g4_tags = "<|turn|>" in base
        t_open = "<|turn|>" if use_g4_tags else "<start_of_turn>"
        t_close = "<turn|>" if use_g4_tags else "<end_of_turn>"

        parts = [base.rstrip("\n")]
        i = len(head_msgs)
        while i < len(messages):
            m = messages[i]
            role = m.get("role")
            if role == "assistant" and m.get("tool_calls"):
                tc = m["tool_calls"][0]
                fn_obj = tc.get("function", tc)
                fn_name = fn_obj.get("name", "")
                fn_args = fn_obj.get("arguments", {})
                if isinstance(fn_args, str):
                    try:
                        fn_args = json.loads(fn_args)
                    except Exception:
                        fn_args = {}
                call_str = f"<|tool_call>call:{fn_name}{_to_gemma4_literal(fn_args)}<tool_call|>"
                if i + 1 < len(messages) and messages[i + 1].get("role") == "tool":
                    obs_d = _sanitize_tool_obs_dict(messages[i + 1].get("content", {}))
                    resp_str = f"<|tool_response>response:{fn_name}{_to_gemma4_literal(obs_d)}<tool_response|>"
                    parts.append(f"{t_open}model\n<|thought|>\n<thought|>{call_str}{resp_str}")
                    if i + 2 < len(messages):
                        parts[-1] += t_close
                    i += 2
                    continue
                else:
                    parts.append(f"{t_open}model\n{call_str}{t_close}")
            elif role == "assistant":
                parts.append(f"{t_open}model\n{m.get('content', '')}{t_close}")
            elif role == "user":
                parts.append(f"{t_open}user\n{m.get('content', '')}{t_close}")
            i += 1

        joined = "\n".join(parts)
        if not joined.endswith("model\n") and (not messages or messages[-1].get("role") != "tool" or joined.endswith(t_close)):
            joined += f"\n{t_open}model\n"
        return joined

    def _tokenize_head_tail(self, prompt: str, max_length: int = 14336, head_keep: int = 3072) -> dict:
        """Preserve system/task head AND latest tool-output/turn tail; never right-truncate <|turn>model\\n."""
        import torch
        raw = self.tokenizer(prompt, return_tensors="pt", truncation=False)
        ids = raw["input_ids"]
        if ids.shape[1] > max_length:
            tail_keep = max(512, max_length - head_keep)
            ids = torch.cat([ids[:, :head_keep], ids[:, -tail_keep:]], dim=1)
        attn = torch.ones_like(ids)
        return {"input_ids": ids.to("cuda:0"), "attention_mask": attn.to("cuda:0")}

    def _build_thinking_cap_processors(self, prompt_len: int, thinking_budget: int | None):
        if not thinking_budget or int(thinking_budget) <= 0:
            return None
        try:
            from transformers import LogitsProcessor, LogitsProcessorList
        except Exception:
            return None

        close_ids = self.tokenizer.encode("<channel|>", add_special_tokens=False)
        if not close_ids or len(close_ids) != 1:
            return None
        close_tok_id = int(close_ids[0])
        open_ids = self.tokenizer.encode("<|channel>", add_special_tokens=False)
        open_tok_id = int(open_ids[0]) if len(open_ids) == 1 else None
        budget = int(thinking_budget)

        class _ThinkingBudgetCap(LogitsProcessor):
            def __call__(self, input_ids, scores):
                gen_len = input_ids.shape[1] - prompt_len
                if gen_len < budget:
                    return scores
                for row in range(input_ids.shape[0]):
                    gen_seq = input_ids[row, prompt_len:].tolist()
                    if close_tok_id in gen_seq:
                        continue
                    # Only force-close if we are inside a thought channel (or at budget limit without closing)
                    if open_tok_id is None or open_tok_id in gen_seq:
                        scores[row, :] = float("-inf")
                        scores[row, close_tok_id] = 0.0
                return scores

        return LogitsProcessorList([_ThinkingBudgetCap()])

    def generate_turn(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        temperature: float = 0.2,
        max_new_tokens: int = 2048,
        thinking_budget: int | None = None,
    ) -> tuple[str, list[dict]]:
        import torch
        prompt = self.format_messages_safe(messages, tools=tools)
        inputs = self._tokenize_head_tail(prompt, max_length=14336, head_keep=3072)
        prompt_len = int(inputs["input_ids"].shape[1])
        logits_proc = self._build_thinking_cap_processors(prompt_len, thinking_budget)
        gen_kwargs = dict(
            max_new_tokens=max_new_tokens,
            temperature=temperature if temperature > 0 else None,
            top_p=0.95 if temperature > 0 else None,
            do_sample=(temperature > 0),
            pad_token_id=self.tokenizer.pad_token_id,
        )
        if logits_proc is not None:
            gen_kwargs["logits_processor"] = logits_proc
        with torch.inference_mode():
            outputs = self.model.generate(**inputs, **gen_kwargs)
        new_tokens = outputs[0][prompt_len:]
        raw_text = self.tokenizer.decode(new_tokens, skip_special_tokens=False)
        calls = self._parse_gemma4_tool_calls(raw_text)
        return raw_text, calls
