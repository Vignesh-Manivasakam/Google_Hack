#!/usr/bin/env python3
"""
Fast 0-GPU Re-Grader & Gold Sanity Checker for Local Windows Harness.
Run from: C:\\Users\\mqg1cob\\Documents\\Google Hack\\gemma-4-developer-agent

Usage:
  1) Verify fixed pytest plugins (pytest-timeout & pytest-httpbin) against gold patches:
     python -u regrade_overnight_patches.py --verify_gold
  2) Re-grade all saved non-empty patches from last night's run (~2 min, 0 GPU):
     python -u regrade_overnight_patches.py
"""
import argparse
import json
import os
import sys
from pathlib import Path

# Enforce Python >= 3.12 (prevents Protocol.__instancecheck__ false positives on 3.11)
assert sys.version_info >= (3, 12), (
    f"FATAL: This script requires Python >= 3.12 to avoid false-positive pytest results "
    f"(Protocol.__instancecheck__ behavior changed in 3.12). Current: {sys.version}"
)

os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)

from win_local_sandbox import verify_single_task


def load_tasks_map(tasks_path: Path) -> dict[str, dict]:
    out = {}
    with tasks_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out[obj["instance_id"]] = obj
    return out


def find_snapshots_dir(gemma_dir: Path) -> Path:
    for cand in [gemma_dir / "snapshots", gemma_dir / "repos", gemma_dir]:
        if cand.is_dir() and any(cand.glob("*.tgz")):
            return cand
    return gemma_dir / "snapshots"


def run_gold_sanity(tasks_map: dict[str, dict], snap_dir: Path, venv_root: Path, wheels_dir: Path) -> int:
    gold_ids = ["fastapi_15588", "fastapi_15023", "requests_7433", "requests_7505", "rich_4076"]
    print("=== GOLD PATCH PLUGIN SANITY CHECK (pytest-timeout + pytest-httpbin) ===", flush=True)
    ok_cnt = 0
    tested = 0
    for tid in gold_ids:
        t = tasks_map.get(tid)
        if not t or not t.get("patch"):
            print(f"  [SKIP] {tid} not found in tasks.jsonl", flush=True)
            continue
        tested += 1
        res = verify_single_task(t, t["patch"], snap_dir, venv_root, wheels_dir=wheels_dir)
        passed = bool(res.get("resolved"))
        if passed:
            ok_cnt += 1
        tail = (res.get("stdout_tail") or res.get("error") or "").replace("\n", " ")[:180]
        print(f"  [{'PASS' if passed else 'FAIL'}] {tid:16s} | rc={res.get('exit_code')} | {tail}", flush=True)
    print(f"[GOLD RESULT] {ok_cnt}/{tested} gold patches resolved cleanly.\n", flush=True)
    return 0 if ok_cnt == tested else 1


def run_regrade(results_dir: Path, tasks_map: dict[str, dict], snap_dir: Path, venv_root: Path, wheels_dir: Path) -> None:
    patch_files = sorted(results_dir.glob("r1_*/*/patches/*.patch"))
    if not patch_files:
        print(f"[WARN] No saved patches found under {results_dir}/r1_*/*/patches/*.patch")
        return

    print(f"=== RE-GRADING SAVED OVERNIGHT PATCHES ({len(patch_files)} files under {results_dir}) ===", flush=True)
    report = []
    solved_rows = []
    for pf in patch_files:
        patch_txt = pf.read_text(encoding="utf-8", errors="replace").strip()
        if not patch_txt:
            continue
        tid = pf.stem
        cid = pf.parent.parent.name
        stage = pf.parent.parent.parent.name
        task = tasks_map.get(tid)
        if not task:
            continue

        # Read previous trace status if present
        old_resolved = None
        trace_json = pf.parent.parent / "traces" / f"{tid}.json"
        if trace_json.is_file():
            try:
                old_resolved = bool(json.loads(trace_json.read_text(encoding="utf-8")).get("resolved"))
            except Exception:
                pass

        res = verify_single_task(task, patch_txt, snap_dir, venv_root, wheels_dir=wheels_dir)
        new_resolved = bool(res.get("resolved"))
        row = {
            "stage": stage,
            "candidate": cid,
            "instance_id": tid,
            "patch_len": len(patch_txt),
            "old_resolved": old_resolved,
            "new_resolved": new_resolved,
            "exit_code": res.get("exit_code"),
            "tail": (res.get("stdout_tail") or res.get("error") or "")[-220:],
        }
        report.append(row)
        tag = "PASS ✨" if new_resolved else "FAIL  "
        if new_resolved:
            solved_rows.append(row)
        print(f"  [{tag}] {stage:10s} | {cid:20s} | {tid:16s} | old={str(old_resolved):5s} -> new={str(new_resolved):5s} | rc={res.get('exit_code')}", flush=True)

    out_path = results_dir / "regrade_report.json"
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\n[DONE] True Verified Solves: {len(solved_rows)}/{len(report)} non-empty patches. Saved -> {out_path}", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser(description="0-GPU Gold Check & Re-Grader for Local Overnight Patches")
    ap.add_argument("--gemma_dir", type=Path, default=Path("."))
    ap.add_argument("--venv_root", type=Path, default=Path(r"..\.win_venvs"))
    ap.add_argument("--results_dir", type=Path, default=Path(r"..\frontier_overnight_results"))
    ap.add_argument("--verify_gold", action="store_true", help="Run gold patch sanity check first")
    args = ap.parse_args()
    args.gemma_dir = args.gemma_dir.resolve()
    args.venv_root = args.venv_root.resolve()
    args.results_dir = args.results_dir.resolve()

    tasks_path = args.gemma_dir / "tasks.jsonl"
    if not tasks_path.is_file():
        print(f"[ERROR] tasks.jsonl not found at {tasks_path.resolve()}")
        sys.exit(2)

    tasks_map = load_tasks_map(tasks_path)
    snap_dir = find_snapshots_dir(args.gemma_dir)
    wheels_dir = args.gemma_dir / "wheels"

    if args.verify_gold:
        rc = run_gold_sanity(tasks_map, snap_dir, args.venv_root, wheels_dir)
        if rc != 0:
            print("[WARN] Not all gold patches passed — check venv plugin installation (pytest-timeout / pytest-httpbin).")
    run_regrade(args.results_dir, tasks_map, snap_dir, args.venv_root, wheels_dir)


if __name__ == "__main__":
    main()
