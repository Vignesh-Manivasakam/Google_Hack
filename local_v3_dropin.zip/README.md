# Local v3 Drop-in Package (Python 3.12 + RTX 2000 Ada Remote GPU Machine)
**Release Date:** Nov 18, 2026

## 🚀 What is this?
Drop-in replacement for the local Windows SWE-gemma harness on your remote GPU machine (`gemma-4-developer-agent\`).
Fixes all 4 local harness bugs and adds first-class support for `E4B_F3_v2` and `B5_Lean_31B`.

## 🛠️ Fixes Applied in v3:
1. **Python >= 3.12 Guard:** Enforces `assert sys.version_info >= (3, 12)` at startup across `win_frontier_6harness_overnight.py`, `win_local_sandbox.py`, and `regrade_overnight_patches.py`. Prevents false-positive solves from `Protocol.__instancecheck__` behavior on 3.11.
2. **Absolute Path Resolution (.resolve()):** Calls `.resolve()` on `venv_root`, `gemma_dir`, `out_dir`, and `py_exe` so relative paths (like `..\.win_venvs`) never fail inside `%TEMP%\fr_...\workspace`.
3. **Pytest Gate Integrity:** Guards `ran_pytest = True` so missing venv / path errors or exit code 4/127 do not count as a valid pytest run before `submit_patch`.
4. **Un-truncated Trace Logging:** Preserves full `fpath_arg:start-end` line ranges in trace logs without 54-char truncation.
5. **New First-Class Candidates:**
   - `E4B_F3_v2`: Compact 497-tok Copilot Sonnet prompt + 4 Engineering Failure-Trap Laws designed specifically for E4B's 512-token sliding window attention.
   - `B5_Lean_31B`: Lean fast-fix prompt designed for 31B fast convergence (under 8-10 turns).

## 📋 Included Files
- `win_frontier_6harness_overnight.py`: Master overnight tournament harness (F1..F9, E4B_F3_v2, B5_Lean_31B).
- `win_local_sandbox.py`: Pure-Python Windows POSIX emulator & test execution sandbox.
- `win_harness_triage_parallel.py`: Parallel batched harness triage matrix.
- `win_phase2_tournament.py`: AST code graph indexer and Gemma engine helpers.
- `regrade_overnight_patches.py`: 0-GPU re-grader for saved patches.
- `README.md`: This document.

## ⚡ Quick Start Commands (Run inside `gemma-4-developer-agent\`):

### 1. Canary Validation on 1 task (Canary 1 — requests_7433)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2 --task_mode val20 --smoke1
```

### 2. Run E4B_F3_v2 vs F3 vs F4 vs F6 on Canary 8
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2,F3,F4,F6 --task_mode val20 --workers 2 --batch_size 2
```

### 3. Re-grade overnight patches without loading GPU (0 GPU time, ~2 min)
```powershell
python -u regrade_overnight_patches.py --verify_gold
```

### 4. Export submission zips
```powershell
python win_frontier_6harness_overnight.py --export_candidate E4B_F3_v2
```
