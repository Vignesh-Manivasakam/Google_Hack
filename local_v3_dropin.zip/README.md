# Local v3 Drop-in Package (Python 3.12 + RTX 2000 Ada Remote GPU Machine)
**Release Date:** Nov 18, 2026 (v3.1 Production Hardened)

## 🚀 What is this?
Drop-in replacement for the local Windows SWE-gemma harness on your remote GPU machine (`gemma-4-developer-agent\`).
Fixes all VRAM fragmentation, WDDM paging, and edit_file loop issues observed during initial smoke tests, ensuring a bullet-proof 10-hour overnight run.

## 🛠️ Fixes Applied in v3 & v3.1:

### 1. GPU VRAM & WDDM Paging Elimination (0.0 GB Shared Memory)
- **Expandable Segments Allocator:** `os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"` initialized at line 1 before any `torch` import across all modules to eliminate CUDA memory fragmentation.
- **SDPA Native Attention:** Initialized `AutoModelForCausalLM.from_pretrained` with `attn_implementation="sdpa"` for flash-fused memory-efficient attention.
- **Token Ceiling Reduction:** Lowered max tokenization length from 14,336 / 13,312 down to **8,192** tokens.
- **Tighter History Compaction:** `keep_tail_msgs = 8`, `max_total_chars = 14000`, and tool observation truncation capped at **2,000 chars** (was 4,800 chars).
- **Proactive Memory Release:** Added `torch.cuda.empty_cache()` between agent turns and after every batch in `BatchedGemmaServer`.
- **Automatic 16GB GPU Batch Clamp:** Updated GPU-guard threshold from 11.5 GiB to **7.5 GiB** (`if used_gb > 7.5: server.max_batch_size = 1; args.workers = 1; args.batch_size = 1`), completely preventing multi-sample batching from exceeding 16 GiB on RTX 2000 Ada.

### 2. Ping-Pong Loop & 14 Malformed Call Bug Fix
- **Decoupled `edit_file` from Loop Detector:** The loop detector previously intercepted repeated `edit_file` calls in a 6-turn window as malformed and aborted them with a `read_file without start_line` error without writing edits to disk. Now only `read_file` without `start_line` triggers ping-pong protection. `edit_file` always executes cleanly.
- **Decisive Exit Rule in Prompts:** Updated `E4B_F3_v2` and `B5_Lean_31B` prompts with:
  > "DECISIVE EXIT: If tests pass, call submit_patch immediately. If a test continues to fail due to pre-existing suite breakages or if you have attempted fixes twice, CALL submit_patch IMMEDIATELY. An existing patch with partial fixes earns score; hitting max tool calls earns zero."
- **Max Steps Capped at 24:** Candidates default to `max_steps = 24` (historical data shows 0 tasks solve past step 27).
- **Budget Critical Warning:** When remaining tool calls `rem <= 3`, harness injects:
  `BUDGET CRITICAL: Only {rem} tool calls remaining. If you have edited files, call submit_patch NOW.`
- **Auto-Submit on Budget Expiration:** If an agent runs out of steps without explicitly calling `submit_patch`, but has created a non-empty patch on disk, the harness automatically marks it as submitted (`submitted = True`).

### 3. Harness Core Integrity (from v3 & v3.1)
- **Python >= 3.12 Startup Guard:** Prevents false-positive solves from `Protocol.__instancecheck__`.
- **Absolute Path Resolution (.resolve()):** Resolves `venv_root`, `gemma_dir`, `out_dir`, and `py_exe` so `%TEMP%` workdirs never break.
- **Pytest Gate Integrity:** Missing venv or exit codes 4/127 do not satisfy the pytest gate before submit.
- **Multi-Turn SFT Provenance Persistence:** Persists full multi-turn conversational `messages` history, thoughts (`<|channel>thought...<channel|>`), tool calls, and observations into `bstate` and `rec` saved to `tdir / f"{tid}.json"`.
- **Provenance Tags:** Embeds `"source_model": "gemma-4-e4b-it"` and `"rollout_mode": "on_policy_local"`.
- **Terminal submit_patch Guarantee:** Automatically synthesizes a closing `submit_patch` turn for any resolved trajectory if the agent didn't emit one before turn ceiling.
- **Automated SFT JSONL Exporter:** Automatically exports `passing_trajectories.jsonl` per candidate and `all_passing_trajectories.jsonl` at the root of `out_dir` for direct ingestion by `sft_dataset_builder.py`.

## 📋 Included Files
- `win_frontier_6harness_overnight.py`: Master overnight tournament harness (F1..F9, E4B_F3_v2, B5_Lean_31B).
- `win_local_sandbox.py`: Pure-Python Windows POSIX emulator & test execution sandbox.
- `win_harness_triage_parallel.py`: Batched harness triage matrix with expandable segments & SDPA.
- `win_phase2_tournament.py`: AST code graph indexer, 8192-tok SDPA Gemma engine helpers.
- `regrade_overnight_patches.py`: 0-GPU re-grader for saved patches.
- `README.md`: This document.

## ⚡ Quick Start Commands (Run inside `gemma-4-developer-agent\`):

### 1. Canary Validation on 1 task (Smoke Test)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2 --task_mode val20 --smoke1
```

### 2. Launch Full Overnight Tournament Run (~10 hours)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2,B5_Lean_31B,F3,F4,F6 --task_mode val20 --continuous --evolve_hours 9.5
```

### 3. Re-grade overnight patches without loading GPU (0 GPU time, ~2 min)
```powershell
python -u regrade_overnight_patches.py --verify_gold
```

### 4. Export submission zips
```powershell
python win_frontier_6harness_overnight.py --export_candidate E4B_F3_v2
```
