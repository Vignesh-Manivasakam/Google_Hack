# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-19 22:34:34 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`E4B_F3_v2`** | `0.0%` (0/8) | `5/8` | `78.49%` | `35` | `21.5` | `50.56m` | Compact 497-tok Copilot + 4 Trap Laws prompt for E4B |
