# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-19 20:29:27 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`E4B_F3_v2`** | `0.0%` (0/8) | `7/8` | `78.7%` | `32` | `21.12` | `64.08m` | Compact 497-tok Copilot + 4 Trap Laws prompt for E4B |
| 2 | **`F4_OpenCode_Gate`** | `0.0%` (0/8) | `5/8` | `80.34%` | `32` | `22.25` | `44.12m` | OpenCode milestones + anti-loop circuit breaker |
| 3 | **`F3_Copilot_Sonnet`** | `0.0%` (0/8) | `5/8` | `70.11%` | `36` | `21.75` | `62.5m` | GitHub Copilot Sonnet 7-step + 4 Trap Laws |
| 4 | **`B5_Lean_31B`** | `0.0%` (0/8) | `3/8` | `73.74%` | `33` | `22.38` | `62.65m` | Lean 31B fast-fix prompt under 8-10 turns |
