# Local RTX 2000 Ada Factory Drop-in Package (v9.0 — Patch (d) + E4B_LoRA_v1.5 Parity)
**Target PC:** `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent`
**Target Hardware:** RTX 2000 Ada Generation (16 GB VRAM, 8.42-8.67 GiB active)

## Key Changes in v9.0 (over local_v8_dropin)
1. **Patch (d) — Thinking Parity (`win_phase2_tournament.py` & `win_harness_triage_parallel.py`):** Passes `enable_thinking=True` in `apply_chat_template` and sets `top_p=0.90`, eliminating local `s02:<eos>` no-call loops.
2. **Patch (d) — Local Sandbox Parity (`win_local_sandbox.py`):** Removes `-p no:anyio` from `verify_single_task` and `run_posix_command_windows`, adds `NO_COLOR=1`/`PYTHONUTF8=1`, and adds `shadow_dev` (balanced 16 non-holdout tasks) and `holdout30` task selectors.
3. **E4B_LoRA_v1.5 (`2,048 B` LF Prompt, 0 braces, <=476 tok < 512W):** Replaces the falsified `2,656 B` prompt across `prompts/system.md`, `win_frontier_6harness_overnight.py`, and `submission_E4B_LoRA_v1_5/`. Drops `| tail -20`, full-file pytest, 2-attempt partial surrender, and `get_code_neighbors` from prompt while preserving 9-tool `agent.yaml` parity and `240/40/8/80` envelope.
4. **Parity Gate Instrumentation (`win_frontier_6harness_overnight.py`):** Adds `E4B_LoRA_v1_5`, `E4B_Base_v1_5` (safe `--adapter_dir none`), and `E4B_LoRA_v1_2149B` candidates, fixes `--factory --task_mode <subset>` filtering, and reports `no_call/task` and `no:anyio` bash emissions in `summary.json`.
