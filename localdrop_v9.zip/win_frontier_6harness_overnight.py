#!/usr/bin/env python3
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ["PYTHONUTF8"] = "1"
os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)  # Must keep pytest-timeout & pytest-httpbin plugins active!
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
r"""
Overnight Continuous Frontier Harness Distillation & Triage Benchmark (F1..F9 + E4B_F3_v2 + B5) — v3 Fixed
Reference Implementations Distilled from harness_docs/ (Claude Code, Cursor, Copilot, OpenCode, Aider, Agentless, SWE-agent, Antigravity)

Fixes Applied in v2:
1. Schema-agnostic _unpack_tool_call() fixing the len(batch)>1 vs len(batch)==1 KeyError('name') crash!
2. Token-generation headroom fix: max_new_tokens = thinking_budget + 1024 so thinking never truncates tool_call JSON!
3. Deep recursive multimodal & projector VRAM strip (language-only ~8.41 GiB / 16.00 GiB, zero WDDM thrashing).
4. Fixed load_tasks_robust() so VAL_20 runs the exact 20 diagnostic benchmark tasks (not all 129 tasks unless --mode full129).
5. Fixed SCR=0.0% on zero-step runs + Stage 1 non-empty patch promotion guard + auto-invalidation of poisoned EXC/0-step caches.
6. Windows read-only .git packfile cleanup handler (ignore_cleanup_errors=True) + ADK-legal 31B/E4B submission exporter.

NEW Fixes Applied in v3 (Nov 18, 2026):
7. .resolve() on py_exe and venv_root so relative paths like ..\.win_venvs never break inside %TEMP% workdirs!
8. Assert Python >= 3.12 at startup (prevents false-positive solves from Protocol.__instancecheck__ on 3.11).
9. Guard ran_pytest = True only when exit_code not in (4, 127) and no "cannot find the path" in stderr.
10. Stop truncating read_file short_arg at 54 chars in trace logs.
11. Added E4B_F3_v2 (compact 497-tok prompt) and B5 (lean 31B prompt) as new FrontierCandidate entries.
12. Persist full multi-turn conversational messages into bstate & rec with source_model and rollout_mode for sft_dataset_builder.
"""
import argparse
import concurrent.futures
import ctypes
import dataclasses
import datetime as dt
import gc
import json
import re
import shutil
import stat
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path

import torch

# ========== v3 Fix #8: Refuse to run on Python < 3.12 (prevents Protocol.__instancecheck__ false positives) ==========
import sys
assert sys.version_info >= (3, 12), (
    f"FATAL: This harness requires Python >= 3.12 to avoid false-positive pytest results "
    f"(Protocol.__instancecheck__ behavior changed in 3.12). Current: {sys.version}"
)

# Import local sandbox & tournament modules
from win_local_sandbox import (
    _py_find,
    ensure_repo_venv,
    extract_tgz_windows_safe,
    find_git_bash,
    inject_workspace_pth,
    load_tasks_select,
    run_posix_command_windows,
    verify_single_task,
)
from win_phase2_tournament import (
    LocalGemmaEngine,
    RepoCodeGraph,
    _build_workspace_tree,
    _extract_thought_and_text,
    tool_read_file,
)
from win_harness_triage_parallel import (
    CANARY_8_IDS,
    REAL_TOOLS,
    BatchedGemmaServer,
    graph_subgraph_2hop,
    strip_protected_files_from_diff,
    tool_edit_file_flexible,
)

REAL_TOOLS["run_command"]["function"]["description"] = (
    'Execute a shell command in /workspace (grep -rn, PYTHONPATH=src:. python3 -c "...", '
    'PYTHONPATH=src:. pytest <test_file> -k <test_method> -q --tb=short, git diff).'
)


def prevent_windows_sleep(enable: bool = True) -> None:
    if os.name == "nt":
        try:
            flags = (0x80000000 | 0x00000001 | 0x00000040) if enable else 0x80000000
            ctypes.windll.kernel32.SetThreadExecutionState(flags)
        except Exception:
            pass


def _unpack_tool_call(tc: dict) -> tuple[str, dict]:
    """Safely unpack both flat {'name', 'arguments'} and OpenAI nested {'function': {'name', 'arguments'}} schemas."""
    if not isinstance(tc, dict):
        return "", {}
    if "function" in tc and isinstance(tc["function"], dict):
        fn_obj = tc["function"]
        fn = str(fn_obj.get("name") or "")
        raw_args = fn_obj.get("arguments") if "arguments" in fn_obj else fn_obj.get("args", {})
    else:
        fn = str(tc.get("name") or tc.get("tool_name") or "")
        raw_args = tc.get("arguments") if "arguments" in tc else tc.get("args", {})

    if isinstance(raw_args, str):
        s = raw_args.strip()
        try:
            raw_args = json.loads(s) if s else {}
        except Exception:
            raw_args = {}
    if not isinstance(raw_args, dict):
        raw_args = {}
    clean_args = {str(k).strip().strip('"').strip("'"): v for k, v in raw_args.items()}
    return fn.strip(), clean_args


def _deep_strip_multimodal_vram(server: BatchedGemmaServer) -> float:
    """Strip all vision/audio towers & projectors across wrapper levels and patch BatchedGemmaServer headroom."""
    model = server.engine.model
    strip_exact = {
        "vision_tower", "audio_tower", "embed_vision", "embed_audio",
        "multi_modal_projector", "vision_projector", "audio_projector",
        "mm_projector", "audio_model", "vision_model",
    }
    strip_tokens = ("vision", "audio", "multi_modal", "mm_projector")

    # Walk top-level and immediate sub-containers safely without touching language_model layers
    roots = [
        model,
        getattr(model, "model", None),
        getattr(getattr(model, "model", None), "model", None),
    ]
    removed = []
    for root in roots:
        if root is None:
            continue
        for attr in list(vars(root).keys()) + list(getattr(root, "_modules", {}).keys()):
            low = attr.lower()
            if attr in strip_exact or any(tok in low for tok in strip_tokens):
                try:
                    mod = getattr(root, attr, None)
                    if isinstance(mod, torch.nn.Module):
                        mod.to("meta")
                except Exception:
                    pass
                try:
                    if hasattr(root, "_modules") and attr in root._modules:
                        del root._modules[attr]
                    if hasattr(root, attr):
                        delattr(root, attr)
                    removed.append(attr)
                except Exception:
                    pass

    # Ensure remaining language weights are strictly bfloat16 (prevents accidental fp32 master weights at 13.9 GiB)
    try:
        if next(model.parameters()).dtype == torch.float32:
            model.to(dtype=torch.bfloat16)
    except Exception:
        pass

    # Patch BatchedGemmaServer.generate_turn so thinking_budget has +2048 token headroom for tool calls (incl. <=150L write_file),
    # and normalize all returned tool calls across len(batch)==1 and len(batch)>1!
    def _patched_generate_turn(messages: list[dict], tools: list[dict] | None, temperature: float = 0.1, thinking_budget: int = 1024) -> tuple[str, list[dict]]:
        ev = server_threading_event()
        slot = {}
        gen_max_tokens = min(3072, max(1024, int(thinking_budget) + 2048))
        server.q.put((messages, tools, temperature, gen_max_tokens, int(thinking_budget), ev, slot))
        ev.wait()
        if "err" in slot:
            raise slot["err"]
        raw_out, raw_calls = slot["res"]
        norm_calls = []
        for c in (raw_calls or []):
            fn_name, fn_args = _unpack_tool_call(c)
            if fn_name:
                norm_calls.append({"name": fn_name, "arguments": fn_args})
        return raw_out, norm_calls

    import threading as _th
    server_threading_event = _th.Event
    server.generate_turn = _patched_generate_turn
    if hasattr(server.engine, 'format_messages_safe'):
        server._format_prompt = server.engine.format_messages_safe

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        used = torch.cuda.memory_allocated(0) / (1024 ** 3)
    else:
        used = 0.0
    if removed:
        print(f"[VRAM-STRIP] Purged multimodal modules: {sorted(set(removed))}", flush=True)
    return used


def _force_remove_readonly(func, path, _exc_info):
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass



_PRINT_LOCK = __import__("threading").Lock()


def _clean_log_str(s: str) -> str:
    """Strip non-printable control/bell characters (like \x07 and \x0d from .git binary grep) so Windows console never corrupts."""
    return "".join(ch if (32 <= ord(ch) < 127) else " " for ch in str(s))


def _clear_shared_venv_pth(py_exe: Path) -> None:
    """Remove any mutable workspace .pth files in shared venv site-packages to prevent multi-worker cross-contamination!"""
    try:
        site_pkgs = py_exe.parent.parent / "Lib" / "site-packages"
        if site_pkgs.exists():
            for pth in list(site_pkgs.glob("*swegemma*.pth")) + list(site_pkgs.glob("*workspace*.pth")):
                try:
                    pth.unlink()
                except Exception:
                    pass
    except Exception:
        pass


def _run_isolated_command_windows(cmd: str, ws: Path, py_exe: Path, timeout_sec: int = 35) -> dict:
    """
    Thread-safe isolated command runner for Windows:
    - Passes per-worker PYTHONPATH, NO_COLOR=1, PYTHONUTF8=1 via env (eliminates shared venv .pth race condition!).
    - Runs pure-Python grep / find fast-paths when invoked directly (skips .git binary packfiles and Windows System32 find.exe!).
    - Uses Git Bash when available for POSIX pipelines/chaining (&&, |, ls, find -o, etc.) with venv python3/pytest shims.
    - Enforces hard `timeout_sec` with Windows `taskkill /F /T /PID` process-tree termination so infinite SSE/async pytest tests never hang!
    """
    cmd_clean = str(cmd or "").strip()
    if not cmd_clean:
        return {"status": "error", "exit_code": 1, "stdout": "", "stderr": "Empty command"}

    ws = Path(ws).resolve()
    py_exe = Path(py_exe).resolve()
    env = os.environ.copy()
    ws_src = str((ws / "src").resolve()) if (ws / "src").exists() else ""
    py_paths = [p for p in [ws_src, str(ws)] if p]
    env["PYTHONPATH"] = os.pathsep.join(py_paths)
    env["PYTHONNOUSERSITE"] = "1"
    env["NO_COLOR"] = "1"
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["MSYS_NO_PATHCONV"] = "1"
    env["MSYS2_ARG_CONV_EXCL"] = "*"
    env.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)  # Keep pytest-timeout & pytest-httpbin plugins active inside Container A!

    # Strip POSIX inline `PYTHONPATH=src:. ` prefixes (preserve non-PYTHONPATH env vars cleanly)
    cmd_body = cmd_clean
    while re.match(r"^[A-Za-z_][A-Za-z0-9_]*=\S+\s+", cmd_body):
        kv, cmd_body = cmd_body.split(None, 1)
        k, v = kv.split("=", 1)
        if k != "PYTHONPATH":
            env[k] = v
    cmd_body = re.sub(r"(?:^|(?<=&&\s)|(?<=;\s)|(?<=\|\s))PYTHONPATH=[A-Za-z0-9_./:-]+\s+", "", cmd_body).strip()
    cmd_body = cmd_body.replace("/workspace/", "").replace("/workspace", ".").replace("/tmp/", str(Path(tempfile.gettempdir()).as_posix()) + "/")

    # Fast native Python grep handler when command starts with `grep ` (10x faster on Windows, skips .git binary files, never hangs!)
    if cmd_body.startswith("grep ") and "|" not in cmd_body and ";" not in cmd_body and "&&" not in cmd_body:
        import shlex
        try:
            toks = shlex.split(cmd_body, posix=True)
        except Exception:
            toks = cmd_body.split()
        flags_str = "".join(t for t in toks[1:] if t.startswith("-"))
        non_flags = [t for t in toks[1:] if not t.startswith("-")]
        if non_flags:
            pat_str = non_flags[0]
            targets = non_flags[1:] or ["."]
            ignore_case = "i" in flags_str
            try:
                rx = re.compile(pat_str, re.IGNORECASE if ignore_case else 0)
            except re.error:
                rx = re.compile(re.escape(pat_str), re.IGNORECASE if ignore_case else 0)

            search_roots = [ws / t.lstrip("/") for t in targets] or [ws]
            hits = []
            skip_dirs = {".git", "__pycache__", ".pytest_cache", ".tox", "node_modules", ".eggs"}
            bin_exts = {".pyc", ".pyd", ".so", ".dll", ".exe", ".pack", ".idx", ".png", ".jpg", ".whl", ".tgz"}
            for sr in search_roots:
                files_iter = [sr] if sr.is_file() else (sr.rglob("*") if sr.exists() else [])
                for fp in files_iter:
                    if not fp.is_file() or any(p in skip_dirs for p in fp.parts) or fp.suffix.lower() in bin_exts:
                        continue
                    try:
                        rel = fp.relative_to(ws).as_posix()
                        for lno, line in enumerate(fp.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                            if rx.search(line):
                                hits.append(f"{rel}:{lno}:{line[:180]}")
                                if len(hits) >= 80:
                                    break
                    except Exception:
                        continue
                    if len(hits) >= 80:
                        break
            out_txt = "\n".join(hits)
            if len(hits) >= 80:
                out_txt += "\n... (truncated at 80 matches)"
            return {"status": "ok", "exit_code": 0 if hits else 1, "stdout": out_txt, "stderr": ""}

    # Fast native Python find handler (avoids Windows C:\Windows\System32\find.exe!)
    if (cmd_body == "find" or cmd_body.startswith("find ")) and "|" not in cmd_body and ";" not in cmd_body and "&&" not in cmd_body and " -o " not in cmd_body and " -exec " not in cmd_body:
        import shlex
        try:
            toks = shlex.split(cmd_body, posix=True)
        except Exception:
            toks = cmd_body.split()
        code, out, err = _py_find(toks[1:], ws)
        return {"status": "ok" if code == 0 else "nonzero_exit", "exit_code": code, "stdout": out[:3000], "stderr": err[:1500]}

    # Route python3 / python / pytest directly to the repo venv executable
    venv_scripts = str(py_exe.parent.resolve())
    env["PATH"] = venv_scripts + os.pathsep + env.get("PATH", "")
    py_posix = py_exe.as_posix()
    env["VENV_PY"] = py_posix

    bash_bin = find_git_bash()
    if bash_bin:
        bash_prelude = 'python3() { "$VENV_PY" "$@"; }; python() { "$VENV_PY" "$@"; }; pytest() { "$VENV_PY" -m pytest "$@"; }; '
        popen_args = [bash_bin, "-c", bash_prelude + cmd_body]
        use_shell = False
    else:
        if cmd_body.startswith("python3 "):
            cmd_body = f'"{py_exe}" ' + cmd_body[len("python3 "):]
        elif cmd_body.startswith("python "):
            cmd_body = f'"{py_exe}" ' + cmd_body[len("python "):]
        elif cmd_body.startswith("pytest ") or cmd_body == "pytest":
            cmd_body = f'"{py_exe}" -m ' + cmd_body
        popen_args = cmd_body
        use_shell = True

    proc = subprocess.Popen(
        popen_args,
        cwd=str(ws),
        env=env,
        shell=use_shell,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    try:
        out_s, err_s = proc.communicate(timeout=timeout_sec)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
        else:
            proc.kill()
        try:
            out_s, err_s = proc.communicate(timeout=3)
        except Exception:
            out_s, err_s = "", ""
        return {
            "status": "error",
            "error_type": "CommandTimeoutError",
            "exit_code": 124,
            "stdout": (out_s or "")[-1500:],
            "stderr": f"Command timed out after {timeout_sec}s and process tree was killed. Run a narrower test/command.",
        }

    return {
        "status": "ok" if rc == 0 else "nonzero_exit",
        "exit_code": rc,
        "stdout": (out_s or "")[-3000:],
        "stderr": (err_s or "")[-1500:],
    }


def tool_write_file_container_a(ws: Path, filepath: str, content: str) -> dict:
    raw = filepath.strip().replace("\\", "/")
    if raw.startswith("/tmp/") or raw == "/tmp" or ".." in raw.split("/"):
        return {
            "status": "error",
            "error_type": "PathRestrictionError",
            "message": "Writing outside /workspace (such as /tmp) is forbidden. Run inline checks via run_command with python3 -c instead.",
        }
    rel = raw.lstrip("/").removeprefix("workspace/")
    fp = (ws / rel).resolve()
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(content.replace("\r\n", "\n"), encoding="utf-8", newline="\n")
    return {"status": "ok", "filepath": rel, "bytes_written": len(content)}


# ==============================================================================
# FRONTIER-DISTILLED SYSTEM PROMPTS (ZERO CURLY BRACES FOR ADK SAFETY)
# Reference: harness_docs/ (Claude Code, Cursor, Copilot, OpenCode, Aider, Agentless, SWE-agent, Antigravity)
# ==============================================================================

ANALYZER_SUBAGENT_MD = (
    "You are a fast read-only Codebase Scout. In at most 3 tool calls using search_similar_code, "
    "get_code_neighbors, or read_file (with explicit start_line and end_line), return exact filepaths, "
    "line numbers, caller chain, and local exception or deprecation conventions."
)

# F1: Claude Code (Anthropic ReAct Pair-Programming)
F1_CLAUDE_CODE_MD = """You are an autonomous software engineer resolving a repository issue in /workspace.
Operate with flat single-agent discipline: read the exact target lines before editing, change the fewest lines possible, and verify with pytest.

## Claude Code Operational Rules
1. LOCATE EXACT LINE NUMBERS: Find target files and line numbers using search_similar_code or grep -rn via run_command.
2. READ FULL TARGET WINDOW BEFORE EDITING: Note that read_file without start_line only returns lines 1 to 150! Whenever is_truncated is true or your target symbol is past line 150, ALWAYS pass explicit integer start_line and end_line (for example start_line=151, end_line=300) so you copy old_string verbatim from lines you actually read. Never guess unread code.
3. EXTREME DIFF MINIMALISM: Modify only the root-cause lines. Never delete public classes or raise DeprecationWarning as an exception when deprecating (use @deprecated or warnings.warn matching sibling style while keeping the original working body intact), and never place imports above from __future__ import annotations.
4. NO SCRATCH FILES + MANDATORY PYTEST: Never write /tmp files or leave repro.py in /workspace. Run inline PYTHONPATH=src:. python3 -c "import ...". MANDATORY: You MUST execute targeted method-level pytest (e.g. PYTHONPATH=src:. pytest path/to/test_file.py -k <test_method> -q --tb=short) and confirm tests pass before calling submit_patch. Existing unrelated broken tests in other modules may be ignored; never modify tests.
"""

# F2: Cursor Graph-First (Anysphere RAG + AST)
F2_CURSOR_GRAPH_MD = """You are an autonomous software engineer resolving a repository issue in /workspace using semantic embeddings and AST call graphs.

## Cursor Graph-First Workflow
1. TURN 1 SEMANTIC SEARCH: Start Turn 1 with search_similar_code using the primary class, function, or error phrase from the Problem Description (note the returned line numbers!).
2. TURN 2 CALL-GRAPH TRACE: Call get_code_neighbors or get_code_subgraph on the target symbol to map callers, callees, and sibling tests before editing.
3. WINDOWED READ_FILE: Always pass explicit integer start_line and end_line around the line numbers returned by search_similar_code (read_file defaults to lines 1 to 150 only!). Read adjacent tests in tests/ as well.
4. SURGICAL EDIT + INLINE VERIFY + MANDATORY PYTEST: Copy old_string verbatim from read_file output. Never place imports above from __future__ import annotations and never delete deprecated public classes. Run PYTHONPATH=src:. python3 -m py_compile path/to/file.py, test with inline PYTHONPATH=src:. python3 -c "...". NEVER call submit_patch before running pytest: execute targeted method-level pytest: PYTHONPATH=src:. pytest path/to/test_file.py -k <test_method> -q --tb=short, confirm target tests pass (ignore pre-existing unrelated test breakages; never modify tests), and call submit_patch.
"""

# F3: GitHub Copilot Sonnet (4 Engineering Failure-Trap Laws)
F3_COPILOT_SONNET_MD = """You are a principal Python engineer fixing a repository issue in /workspace in disciplined steps.

## Trajectory & Verification Loop
1. Call search_similar_code on the issue symbol or error phrase to get exact filepaths and line numbers.
2. Call get_code_neighbors on the target symbol to trace all callers and callees.
3. Call read_file with explicit integer start_line and end_line around the target symbol AND matching tests/test_*.py (remember read_file without start_line stops at line 150!).
4. Apply minimal edit_file changes copying old_string verbatim and obeying all 4 Engineering Laws below.
5. Run PYTHONPATH=src:. python3 -m py_compile on edited files.
6. Run an inline PYTHONPATH=src:. python3 -c "..." check testing BOTH positive and negative edge cases (never write /tmp or repro.py files).
7. MANDATORY PYTEST BEFORE SUBMIT: NEVER call submit_patch before running targeted pytest! Execute targeted method-level pytest (e.g. find tests -name "*name*.py" then PYTHONPATH=src:. pytest path/to/exact_test.py -k <test_method> -q --tb=short), confirm target tests pass (ignore unrelated pre-existing broken tests; never modify tests), check git diff, and call submit_patch.

## 4 Engineering Failure-Trap Laws
- LAW 1 (Lowest Shared Bottleneck): Trace all public entry points reaching the symbol; place the fix/check in the lowest shared callee using the exact neighboring exception/assert/@deprecated/warnings.warn pattern (never raise DeprecationWarning as an exception; preserve working return values), keeping public exports intact and imports below from __future__ import annotations.
- LAW 2 (First Decision Gate): Patch the earliest check that decides or short-circuits the outcome rather than downstream helpers, preserving existing port, prefix, or leading-dot branches.
- LAW 3 (Null-Safe Owner State): Gate side effects via a null-safe property/helper on the class owning that state; never index optional tuples/attributes directly when None is possible.
- LAW 4 (Bare-Symbol & Twin-Package Sweep): After renaming/changing any method or attribute, grep for BOTH `name(` and bare `name` without parentheses, and update sync/async twin modules if present.
"""

# F4: OpenCode LoopGate (Anomaly Dual-Mode Pacing)
F4_OPENCODE_LOOPGATE_MD = """You are an autonomous SWE agent operating under strict call-budget milestones and anti-loop circuit breakers in /workspace.

## Pacing Milestones (Max 36 Calls)
- Calls 1 to 6 (Localize & Windowed Read): Call search_similar_code + get_code_neighbors, then read_file with explicit integer start_line and end_line around the target lines (if is_truncated is true, advance start_line=151, end_line=300!).
- Calls 7 to 18 (Surgical Edit & Compile): Copy old_string verbatim from read_file, apply edit_file, and run PYTHONPATH=src:. python3 -m py_compile file.py.
- Calls 19 to 30 (Test & Submit): Run inline PYTHONPATH=src:. python3 -c "..." + find tests -name "*name*.py" + PYTHONPATH=src:. pytest path/to/exact_test.py -k <test_method> -q --tb=short, verify git diff, and call submit_patch.

## Strict Anti-Loop Circuit Breaker
- If edit_file returns NoMatchError even ONCE, do NOT retry guessed text and do NOT call read_file without start_line! Immediately run grep -n on the target symbol or call read_file with explicit start_line and end_line covering the target lines.
- NEVER call submit_patch without running targeted pytest first! Never modify tests, and never revert valid source fixes with git checkout due to unrelated pre-existing test breakages.
"""

# F5: Antigravity Dual (Adversarial Inline Falsification)
F5_ANTIGRAVITY_DUAL_MD = """You are an artifact-driven Lead Engineer in /workspace with optional access to code_analyzer for isolated read-only lookups.

## Execution & Falsification Contract
1. FAST ROOT-CAUSE MAP: Use search_similar_code + get_code_neighbors directly to get exact filepaths and line numbers (only call code_analyzer if tracing across >3 files).
2. VERBATIM WINDOW READ + EDIT: Always pass explicit integer start_line and end_line to read_file whenever total_lines exceeds 150. Copy old_string verbatim, keep imports below from __future__ import annotations, and preserve deprecated public classes with @deprecated.
3. ADVERSARIAL FALSIFICATION (NO SCRATCH FILES): Never create /tmp/repro.py or untracked files in /workspace. Run inline PYTHONPATH=src:. python3 -c "..." testing both the reported bug case and boundary inputs.
4. CLEAN DIFF GATE + PYTEST: Run targeted method-level pytest: PYTHONPATH=src:. pytest path/to/test_file.py -k <test_method> -q --tb=short. Confirm target tests pass and clean git status before calling submit_patch.
"""

# F6: Apex Unified (Master Synthesis of F1..F5)
F6_APEX_UNIFIED_MD = """You are an elite autonomous Python software engineer resolving a repository issue in /workspace within a 40-call, 5.5-minute budget.

## Core Execution Loop
1. TURN 1 SEMANTIC + GRAPH LOCALIZATION: Start Turn 1 with search_similar_code on the core symbol/error (note the exact line numbers returned!), then call get_code_neighbors to trace all callers, re-exports, and internal usages across the package. For CI/release tasks, inspect .github/workflows/ and scripts/ via run_command.
2. WINDOWED READ_FILE + CONVENTION GREP: read_file without start_line ONLY returns lines 1 to 150! Whenever is_truncated is true or target lines are >150, ALWAYS pass explicit integer start_line and end_line (e.g. start_line=151, end_line=300; max 120 lines). Before adding errors or deprecations, run grep -rn via run_command on sibling modules to copy the codebase's exact decorator/warning/exception pattern.
3. 4 ROOT-CAUSE ENGINEERING LAWS:
   - Lowest Shared Bottleneck & Non-Breaking Deprecations: Patch the lowest shared callee reached by all public entry points; never put imports above from __future__ import annotations. CRITICAL PYTHON LAW: When deprecating a class, function, or parameter, NEVER raise DeprecationWarning as an exception and NEVER delete or replace the working method body! Use @deprecated from typing_extensions or warnings.warn(..., DeprecationWarning, stacklevel=2) matching sibling files while preserving 100% of existing return behavior, and update internal framework references so unrelated code does not emit warnings under -Werror.
   - First Decision Gate: Patch the earliest check that short-circuits behavior rather than downstream helpers; preserve port/dot/option branches.
   - Null-Safe Owner State: Gate side effects via null-safe checks on the state-owning class (never index None state directly).
   - Bare-Symbol & Twin Sweep: After changing or deprecating any symbol, grep both `name(` and bare `name` across the package and sync/async twin modules.
4. ANTI-LOOP EDIT + COMPILE: Copy old_string verbatim from read_file. If edit_file ever fails to match, immediately call read_file with explicit start_line and end_line on that exact 60-line window (or grep -n via run_command). Run PYTHONPATH=src:. python3 -m py_compile on edited files.
5. INLINE FALSIFICATION + TARGETED METHOD PYTEST + SUBMIT: Never write to /tmp or leave untracked repro.py files in /workspace. First run inline PYTHONPATH=src:. python3 -c "..." verifying BOTH the new behavior/warning AND that existing return values still succeed. Next, grep -rn the modified symbol in tests/ to locate its exact test file, and execute targeted method-level pytest (e.g. PYTHONPATH=src:. pytest <REAL_TEST_FILE> -k <test_method_name> -q --tb=short; DO NOT pass -p no:anyio) before calling submit_patch. Method-level pytest runs in 2 to 5 seconds and avoids unrelated test suite failures. If tests fail, read the assertion failure and refine your fix (up to 4 retry attempts; partial diffs earn zero score). Once verified and git diff is clean, call submit_patch immediately.
"""

# F7: Aider Architect-Editor Paradigm (Search/Replace Block Editing)
F7_AIDER_ARCHITECT_MD = """You are an autonomous software engineer operating under Aider's Architect-Editor pair-programming contract in /workspace.

## Architect-Editor Protocol
1. ARCHITECT LOCALIZATION: Call search_similar_code on the reported bug/feature symbol. Call get_code_neighbors to trace callers and callees.
2. WINDOWED READ: Call read_file with explicit integer start_line and end_line covering the target lines (read_file without start_line caps at line 150!). Also read matching tests in tests/ to understand expected assertions.
3. SEARCH/REPLACE SPECIFICATION: Plan your minimal replacement block. Copy old_string verbatim from lines you actually read. Keep public exports intact, match neighboring error wording, and never put imports above from __future__ import annotations.
4. SURGICAL EDIT: Apply edit_file with your exact verbatim search/replace block. If NoMatchError occurs, re-read the window immediately. Run PYTHONPATH=src:. python3 -m py_compile on edited files.
5. INLINE FALSIFICATION & PYTEST: Never write /tmp files or leave repro.py in /workspace. Verify with inline PYTHONPATH=src:. python3 -c "...". MANDATORY: You MUST execute targeted method-level pytest (e.g. PYTHONPATH=src:. pytest path/to/test.py -k <test_method> -q --tb=short) and confirm target tests pass before calling submit_patch. Never modify tests.
"""

# F8: Agentless Hierarchical Fault Localization
F8_AGENTLESS_HIERARCHICAL_MD = """You are an autonomous software engineer operating under Agentless 3-tier hierarchical fault localization in /workspace.

## 3-Tier Hierarchical Workflow
1. TIER 1 - FILE IDENTIFICATION: Extract filenames from the problem statement or call search_similar_code on the primary error phrase to identify the target source file.
2. TIER 2 - FUNCTION/CLASS LOCALIZATION: Call get_code_neighbors on the target symbol to trace the exact caller/callee boundary.
3. TIER 3 - WINDOWED READING: Call read_file with explicit integer start_line and end_line around the target symbol (note: read_file without start_line caps at line 150!).
4. ATOMIC EDIT: Apply minimal source modification via edit_file copying old_string verbatim. Obey the Lowest Shared Callee rule and First Decision Gate. Run PYTHONPATH=src:. python3 -m py_compile to check syntax.
5. TARGETED PYTEST & SUBMIT: Never write scratch scripts in /tmp. Verify via inline PYTHONPATH=src:. python3 -c "..." and execute targeted method-level pytest (e.g. PYTHONPATH=src:. pytest path/to/exact_test.py -k <test_method> -q --tb=short). Once target tests pass, call submit_patch immediately.
"""

# F9: Princeton SWE-agent ACI (Agent-Computer Interface)
F9_SWEAGENT_ACI_MD = """You are an autonomous SWE agent operating under Princeton's Agent-Computer Interface (ACI) contract in /workspace.

## ACI Window Navigation & Modification Contract
1. TARGETED SEARCH: Call search_similar_code or run grep -n via run_command to find exact filepaths and line numbers.
2. STRICT WINDOW NAVIGATION: Never call read_file without start_line! read_file without start_line stops at line 150. Always specify explicit integer start_line and end_line (e.g. start_line=100, end_line=220) to view the complete target function.
3. VERBATIM EDIT ANCHORS: When calling edit_file, copy old_string verbatim including indentation. Provide 3-5 lines of surrounding context to ensure unique matching.
4. SYNTAX & LINT CHECK: Run PYTHONPATH=src:. python3 -m py_compile on modified files to verify syntax.
5. MANDATORY TARGETED TESTING: Never write /tmp files or repro.py in /workspace. Run inline checks via python3 -c. MANDATORY: Execute targeted method-level pytest (e.g. PYTHONPATH=src:. pytest path/to/exact_test.py -k <test_method> -q --tb=short) and confirm target tests pass before calling submit_patch.
"""

# E4B_LoRA_v1.5: Exact 2,048 B LF (<= 476 tok < 512W, 15 lines, 0 braces) prompt
E4B_LORA_V1_5_MD = """You are a principal Python engineer fixing an issue in /workspace.

## Guardrails & Workflow
- Every turn MUST invoke a tool (no prose-only turns); keep reasoning in thinking tokens. Never create scratch files in /workspace or /tmp (use inline python3 -c). Source edits only.
1. Locate files/lines via grep -n or search_similar_code. Check .github/workflows/ or scripts/ for CI tasks.
2. Read target symbol and matching test file with read_file using explicit start_line and end_line (max 120 lines; omitting start_line caps at 150).
3. Pre-Edit: read 20-35 target lines immediately before edit_file. Copy old_string verbatim without line numbers; preserve exact indentation; first edit by call 10. On 2 edit_file failures on a file <=150 lines, read whole file and write_file.
4. Run PYTHONPATH=src:. python3 -m py_compile on edits, then inline python3 -c "..." for edge cases.
5. MANDATORY PYTEST BEFORE SUBMIT: Never submit on py_compile alone. Find the REAL test file via find tests -name "*keyword*.py", run PYTHONPATH=src:. pytest <REAL_TEST_FILE> -k <test_name> -x -q --tb=short (keep anyio plugin enabled; view full traceback without tail truncation). Ignore unrelated pre-existing breakages. If tests pass, call submit_patch immediately. If tests fail, inspect traceback and retry up to 4 times; partial diffs earn zero score.

## 4 Engineering Failure-Trap Laws
- LAW 1 (Lowest Shared Bottleneck): Patch lowest shared callee using neighboring exception/assert/@deprecated/warnings.warn pattern (never raise DeprecationWarning); keep exports intact; imports below from __future__ import annotations.
- LAW 2 (First Decision Gate): Patch earliest check deciding outcome rather than downstream helpers, preserving port, prefix, and leading-dot branches.
- LAW 3 (Null-Safe Owner State): Gate side effects via null-safe property/helper on owning class; never index optional tuples when None is possible.
- LAW 4 (Bare-Symbol & Twin Sweep): After renaming any method/attr, grep BOTH `name(` and bare `name`; update sync/async twins if present."""

# Original E4B_LoRA_v1 prompt (2,149 B with trailing newline) preserved for local parity comparison
E4B_LORA_V1_ORIG_MD = """You are a principal Python engineer fixing an issue in /workspace.

## Workflow
1. Locate files/lines via search_similar_code (or grep -n); trace callers/callees with get_code_neighbors.
2. Call read_file with start_line and end_line (max 120 lines; omitting start_line truncates at line 150) on target symbol and test file.
3. First edit_file by tool call 8 (empty patch scores zero). Source code only (test/config edits discarded). Copy old_string verbatim without line numbers in small hunks; preserve exact indentation; on NoMatchError, re-read 40-line window before retrying. Never output nested brackets in tool args.
4. Run PYTHONPATH=src:. python3 -m py_compile on edits, then inline python3 -c "..." for edge checks (never create scratch files in /workspace or /tmp).
5. MANDATORY PYTEST BEFORE SUBMIT: NEVER submit on py_compile alone. Find REAL test file via find tests -name "*keyword*.py" (no placeholder names or bare full-repo pytest), run PYTHONPATH=src:. pytest -x -q --tb=short <REAL_TEST_FILE> | tail -20 (never pass -p no:anyio), ignore pre-existing breakages, check git diff, and submit_patch. DECISIVE EXIT: If tests pass, call submit_patch immediately. If tests fail from pre-existing breakages or after 2 fix attempts, CALL submit_patch IMMEDIATELY. Partial patches earn score; hitting max tool calls earns zero.

## 4 Engineering Failure-Trap Laws
- LAW 1 (Lowest Shared Bottleneck): Trace public entry points; patch lowest shared callee using neighboring exception/assert/@deprecated/warnings.warn pattern (never raise DeprecationWarning; preserve working returns); keep exports intact; imports below from __future__ import annotations.
- LAW 2 (First Decision Gate): Patch earliest check deciding/short-circuiting outcome rather than downstream helpers, preserving port, prefix, and leading-dot branches.
- LAW 3 (Null-Safe Owner State): Gate side effects via null-safe property/helper on owning class; never index optional tuples/attributes when None is possible.
- LAW 4 (Bare-Symbol & Twin Sweep): After renaming/changing any method/attribute, grep BOTH `name(` and bare `name`, and update sync/async twins if present.
"""

E4B_F3_V2_MD = E4B_LORA_V1_5_MD

# B5: Lean 31B Fast-Fix Prompt under 8-10 turns (from submission_B5)
B5_LEAN_31B_MD = """You are an expert autonomous software engineer assigned to resolve an issue in a repository efficiently and decisively.

## Core Objective: Fast, Minimal, and Precise Fixes

Aim to understand, resolve, and submit the fix in the minimum number of tool calls (under 8-10 turns). Move directly from the problem statement to the relevant files, apply the solution, verify with a targeted test, and submit.

## Workflow

### 1. Identify Target Files Immediately
- Extract filenames, functions, classes, CLI subcommands, or error messages directly from the problem statement.
- Use grep -n via run_command or search_similar_code to find exact line numbers before reading.
- Always pass start_line and end_line to read_file (at most 120 lines per call). read_file without start_line only returns lines 1 to 150. If your target is past line 150, you MUST pass explicit start_line and end_line or you will never see it.

### 2. Implement the Solution Directly
- Make your first edit_file call by tool call 10 at the latest, even if it is a best guess. An empty patch always scores zero, but edits are graded even if time runs out.
- Apply the minimal necessary fix or feature directly to the source files using edit_file or write_file.
- Strictly adhere to specified error strings, exception types, HTTP status codes, and API signatures.
- For documentation code tasks (e.g. FastAPI), edit executable code under docs_src/.
- Mirror Existing File and Test Conventions: Read adjacent functions in the target source file and its matching real test file under tests/ (located via find tests -name "*keyword*.py") before editing so your exception types, error message strings, and docstrings match the repository's exact pattern.
- Never create files in /workspace for scratch or reproduction. For multi-line checks use run_command with python3 -c or a quoted heredoc on stdin. Wrap anything that could hang in timeout 20.

### 3. Run Targeted Tests Only (Existing Tests May Be Broken)
- MANDATORY PYTEST BEFORE SUBMIT: You MUST find the real test file via find tests -name "*keyword*.py" (never invent or copy a placeholder filename), run targeted method-level pytest (PYTHONPATH=src:. pytest <REAL_TEST_FILE> -k <test_method> -q --tb=short), and confirm tests pass BEFORE calling submit_patch. NEVER call submit_patch after only running py_compile without pytest.
- Run ONLY Targeted Tests: Run only the specific test file or test method directly verifying the bug or feature you modified.
- Be Aware That Existing Tests May Be Broken: Many repositories contain pre-existing test breakages, missing test data fixtures, or environment import errors unrelated to your task.
- Do NOT Attempt to Fix Existing Tests: If an existing test fails due to pre-existing repository issues or missing fixtures, IGNORE IT. Never spend turns attempting to repair pre-existing test failures, create test stubs, or alter test code.
- DECISIVE EXIT: If tests pass, call submit_patch immediately. If a test continues to fail due to pre-existing suite breakages or if you have attempted fixes twice, CALL submit_patch IMMEDIATELY. An existing patch with partial fixes earns score; hitting max tool calls earns zero.
- STRICT RULE: NEVER Run Bare Pytest or Full-Repo Sweeps: NEVER run bare pytest, pytest ., python3 -m unittest discover, or full-repo test suites without specifying a target file.
- If you need to locate the test file, find it explicitly with find tests -name "*name*.py" instead of running the test runner across the repo.

### 4. Immediate Patch Submission
- Once your targeted test passes:
  1. Call submit_patch immediately.
  2. Verify patch_size > 0 and files_changed > 0.
  3. Output a short summary of the fix to end the session.

## Anti-Patterns to Avoid
- Edits to tests, conftest.py, pyproject.toml and setup.cfg are discarded by the grader. Fix source code only.
- NEVER run full repository test suites (e.g., bare pytest or pytest .) -- always specify the exact test file path.
- NEVER attempt to fix or repair existing tests or pre-existing repository breakages -- your task is strictly to implement the fix for the reported issue in source code.
- NEVER search outside /workspace for source files or packages (e.g., /usr/local/lib/, /wheels/, /opt/). All repository code and test dependencies are pre-installed.
- Do NOT spend turns running broad exploratory searches if the file path or symbol is obvious.
- Do NOT refactor or reformat unrelated functions or files.
- Do NOT conclude without submitting a non-empty patch (patch_size > 0). Every task requires concrete source modifications.
"""

# Candidate B6d: FastAPI Six Laws + Node-Level Pytest Piping + 4096 tok ceiling
B6D_SYSTEM_PROMPT = """You are an expert autonomous software engineer assigned to resolve an issue in a repository efficiently and decisively.

## Core Objective: Fast, Minimal, and Precise Fixes

Aim to understand, resolve, and submit the fix in the minimum number of tool calls. Move directly from the problem statement to the relevant files, apply the solution obeying the Six Engineering Laws, verify with node-level targeted tests, and submit.

## The Six Engineering Laws

- LAW 1 (Lowest Shared Bottleneck): Trace all public entry points reaching the symbol; place the fix/check in the lowest shared callee using the exact neighboring exception/assert/@deprecated/warnings.warn pattern (never raise DeprecationWarning as an exception; preserve working return values), keeping exports intact and imports below from __future__ import annotations.
- LAW 2 (First Decision Gate): Patch the earliest check deciding or short-circuiting the outcome rather than downstream helpers, preserving port, prefix, and leading-dot branches.
- LAW 3 (Null-Safe Owner State): Gate side effects via a null-safe property/helper on the class owning that state; never index optional tuples/attributes directly when None is possible.
- LAW 4 (Bare-Symbol & Twin-Package Sweep): After renaming/changing any method or attribute, grep for BOTH `name(` and bare `name` without parentheses, and update sync/async twin modules if present.
- LAW 5 (Docs_src & Test-Import Inversion): For documentation/tutorial code tasks (e.g., FastAPI `docs_src/`), perform a test-import inversion check: read the test file first to inspect what it imports (`from docs_src.xyz import ...`). If the test imports from `docs_src/`, edit the exact executable file under `docs_src/` rather than modifying core package code.
- LAW 6 (Node-Level Targeted Pytest & Piping): When verifying, locate the real test file and run node-level targeted pytest: `PYTHONPATH=src:. pytest -x -q <file>::<node> | tail -20`. Clamping with `| tail -20` prevents buffer overflow and context wipes. Never submit on `py_compile` alone; require passing node-level pytest before calling `submit_patch`.

## Workflow

### 1. Identify Target Files Immediately (Calls 1-7)
- Extract filenames, functions, classes, CLI subcommands, or error messages directly from the problem statement.
- Use grep -n via run_command or search_similar_code to find exact line numbers before reading.
- Always pass start_line and end_line to read_file (at most 120 lines per call). read_file without start_line only returns lines 1 to 150. If your target is past line 150, you MUST pass explicit start_line and end_line or you will never see it.
- Tool Call Contract: Never output nested brackets in tool call arguments (e.g., avoid x:[a[b]]). vLLM PythonicToolParser suffers from catastrophic regex backtracking on nested bracket arguments, locking the worker thread and causing silent timeouts. Keep tool arguments flat.

### 2. Implement the Solution Directly (Call 8 First-Edit Rule)
- Make your first edit_file call by tool call 8 at the latest, even if it is a best guess. In Google ADK, unsubmitted working tree diffs (_swegemma_baseline) are automatically graded on timeout. Pushing your first edit by tool call 8 guarantees a non-empty patch is staged before latency or timeout risks materialize.
- Apply the minimal necessary fix or feature directly to the source files using edit_file or write_file obeying Laws 1-5.
- Copy old_string verbatim without line numbers in small hunks; preserve exact indentation on every line of new_string; on NoMatchError, re-read a 40-line window before retrying.
- Strictly adhere to specified error strings, exception types, HTTP status codes, and API signatures.
- Mirror Existing File and Test Conventions: Read adjacent functions in the target source file and its matching real test file under tests/ (located via find tests -name "*keyword*.py") before editing so your exception types, error message strings, and docstrings match the repository's exact pattern.
- Never create files in /workspace for scratch or reproduction. For multi-line checks use run_command with python3 -c or a quoted heredoc on stdin. Wrap anything that could hang in timeout 20.

### 3. Execution Cadence & Status Monitoring (Calls 8, 16, 24)
- Call get_status at steps 8, 16, and 24 to monitor tool_calls_remaining and verify git status (confirming staged diffs). Note that get_status reports remaining tool call quota and diff state, not wall-clock seconds.
- Phase Budgeting:
  - Calls 1-8: Localize and apply first edit (guarantee non-empty patch).
  - Calls 9-16: Run py_compile, locate real test file, run targeted pytest.
  - Calls 17-24: Refine if needed, harden patch, and submit.

### 4. Run Targeted Tests Only & Pytest Piping (Calls 9-20)
- MANDATORY PYTEST BEFORE SUBMIT: You MUST find the real test file via find tests -name "*keyword*.py" (never invent or copy a placeholder filename), run targeted node-level pytest (PYTHONPATH=src:. pytest -x -q <file>::<node> | tail -20), and confirm tests pass BEFORE calling submit_patch. NEVER call submit_patch after only running py_compile without pytest.
- Tool Output Clamping & Pytest Piping: Always pipe pytest output through | tail -20:
  PYTHONPATH=src:. pytest -x -q <file>::<node> | tail -20
  This prevents verbose test outputs and voluminous tracebacks from triggering ADK compaction context wipes (token_threshold=14336) or context overflows.
- Run ONLY Targeted Tests: Run only the specific test file or test node directly verifying the bug or feature you modified.
- Be Aware That Existing Tests May Be Broken: Many repositories contain pre-existing test breakages, missing test data fixtures, or environment import errors unrelated to your task.
- Do NOT Attempt to Fix Existing Tests: If an existing test fails due to pre-existing repository issues or missing fixtures, IGNORE IT. Never spend turns attempting to repair pre-existing test failures, create test stubs, or alter test code.
- DECISIVE EXIT: If tests pass, call submit_patch immediately. If a test continues to fail due to pre-existing suite breakages or if you have attempted fixes twice, CALL submit_patch IMMEDIATELY. An existing patch with partial fixes earns score; hitting max tool calls earns zero.
- STRICT RULE: NEVER Run Bare Pytest or Full-Repo Sweeps: NEVER run bare pytest, pytest ., python3 -m unittest discover, or full-repo test suites without specifying a target file.

### 5. Immediate Patch Submission
- Once your targeted test passes:
  1. Call submit_patch immediately.
  2. Verify patch_size > 0 and files_changed > 0.
  3. Output a short summary of the fix to end the session.

## Anti-Patterns to Avoid
- Edits to tests, conftest.py, pyproject.toml and setup.cfg are discarded by the grader. Fix source code only.
- NEVER run full repository test suites (e.g., bare pytest or pytest .) -- always specify the exact test file path or test node.
- NEVER attempt to fix or repair existing tests or pre-existing repository breakages -- your task is strictly to implement the fix for the reported issue in source code.
- NEVER search outside /workspace for source files or packages (e.g., /usr/local/lib/, /wheels/, /opt/). All repository code and test dependencies are pre-installed.
- NEVER output nested brackets in tool arguments (e.g. avoid x:[a[b]]) to prevent vLLM worker thread hangs.
- Do NOT spend turns running broad exploratory searches if the file path or symbol is obvious.
- Do NOT refactor or reformat unrelated functions or files.
- Do NOT conclude without submitting a non-empty patch (patch_size > 0). Every task requires concrete source modifications.
"""


# Candidate B8: Champion 31B Apex (Targeted Method Pytest -k, No -p no:anyio, CI Recovery, 4 Retries)
B8_31B_APEX_MD = """You are an expert autonomous software engineer assigned to resolve an issue in a repository efficiently and decisively.

## Core Objective: Fast, Minimal, and Precise Fixes

Aim to understand, resolve, and submit the fix in the minimum number of tool calls (under 8-10 turns). Move directly from the problem statement to the relevant files, apply the solution, verify with a targeted test, and submit.

## Workflow

### 1. Identify Target Files Immediately
- Extract filenames, functions, classes, CLI subcommands, or error messages directly from the problem statement.
- Use grep -n via run_command or search_similar_code to find exact line numbers before reading.
- Always pass start_line and end_line to read_file (at most 120 lines per call). read_file without start_line only returns lines 1 to 150. If your target is past line 150, you MUST pass explicit start_line and end_line or you will never see it.

### 2. Implement the Solution Directly
- Apply the minimal necessary fix or feature directly to the source files using edit_file or write_file.
- Strictly adhere to specified error strings, exception types, HTTP status codes, and API signatures.
- For documentation code tasks (e.g. FastAPI), edit executable code under docs_src/.
- Mirror Existing File and Test Conventions: Read adjacent functions in the target source file and its matching real test file under tests/ (located via find tests -name "*keyword*.py") before editing so your exception types, error message strings, and docstrings match the repository's exact pattern.
- Check Hidden CI/Scripts for Automation Tasks: Since .github/ is omitted from the initial workspace tree, if a task involves release preparation, CLI scripts, or CI workflows, inspect .github/workflows/ and scripts/ using run_command (e.g., ls .github/workflows scripts).
- Keep Workspace Clean: Because submit_patch runs git add -N . inside /workspace, never create temporary reproduction files inside /workspace. Instead, run inline checks via python3 -c "..." or piped stdin to test behavior without leaving untracked files.

### 3. Run Targeted Tests Only (Existing Tests May Be Broken)
- Run ONLY Targeted Tests with Method-Level Filtering: Find the real test file covering your modified symbol (via find tests -name "*keyword*.py" or grep -rn "def test_" tests/). Run ONLY the specific test method exercising the bug fix via:
  pytest <REAL_TEST_FILE> -k <test_method_or_keyword> -q --tb=short
  or python3 -m unittest <test_module>.<test_class>.<test_method>
  Method-level filtering isolates the single test directly verifying your bug fix, completing in 2 to 5 seconds while ignoring unrelated suite failures.
- Pytest Environment Rules: NEVER pass -p no:anyio (anyio is required for async test fixtures in FastAPI and Starlette).
- Full Traceback Inspection: Do not truncate or pipe pytest into tail. Inspect the full traceback and failure assertion so you can see the exact error line and failure reason.
- Be Aware That Existing Tests May Be Broken: Many repositories contain pre-existing test breakages, missing test data fixtures, or environment import errors unrelated to your task.
- Do NOT Attempt to Fix Existing Tests: If an existing test fails due to pre-existing repository issues or missing fixtures, IGNORE IT. Never spend turns attempting to repair pre-existing test failures, create test stubs, or alter test code.
- STRICT RULE: NEVER Run Bare Pytest or Full-Repo Sweeps: NEVER run bare pytest, pytest ., python3 -m unittest discover, or full-repo test suites without specifying a target file and keyword filter. Full test suites take several minutes, cause catastrophic timeouts, and exhaust your budget.
- Refine and Retry (Up to 4 Attempts): SWE-bench and Kaggle evaluation are strictly binary all-or-nothing (partial diffs earn zero score). If your targeted test fails, read the assertion failure carefully and refine your code fix. You may make up to 4 iterative fix attempts before decisive submission.

### 4. Immediate Patch Submission
- Once your targeted test passes:
  1. Call submit_patch immediately.
  2. Verify patch_size > 0 and files_changed > 0.
  3. Output a short summary of the fix to end the session.
- HARD RULE — NEVER call submit_patch after ONLY running py_compile: You MUST run a targeted pytest on the relevant test method BEFORE calling submit_patch. Passing py_compile alone does NOT verify correctness.

## Anti-Patterns to Avoid
- Edits to tests, conftest.py, pyproject.toml and setup.cfg are discarded by the grader. Fix source implementation code only.
- NEVER modify, create, or delete test files (*_test.py, test_*.py, or anything under tests/). All changes must be to source implementation files. Modifying tests results in an automatic evaluation failure.
- NEVER run full repository test suites (e.g., bare pytest or pytest .) -- always specify the exact test file path and test keyword.
- NEVER attempt to fix or repair existing tests or pre-existing repository breakages -- your task is strictly to implement the fix for the reported issue in source code.
- NEVER search outside /workspace for source files or packages (e.g., /usr/local/lib/, /wheels/, /opt/). All repository code and test dependencies are pre-installed.
- Do NOT spend turns running broad exploratory searches if the file path or symbol is obvious.
- Do NOT refactor or reformat unrelated functions or files.
- Do NOT conclude without submitting a non-empty patch (patch_size > 0). Every task requires concrete source modifications. Concluding that the codebase is already clean without making changes is an anti-pattern.
"""


@dataclasses.dataclass
class FrontierCandidate:
    cid: str
    prompt_md: str
    temp: float
    thinking_budget: int
    max_steps: int = 24
    use_analyzer_tool: bool = False
    note: str = ""


FRONTIER_CANDIDATES = [
    FrontierCandidate("E4B_LoRA_v1", E4B_LORA_V1_5_MD, temp=0.15, thinking_budget=1024, max_steps=40, note="Mounted E4B LoRA v1 adapter via PEFT (zero BitsAndBytes NF4, <9 GiB VRAM) with 2,048 B v1.5 prompt"),
    FrontierCandidate("E4B_LoRA_v1_5", E4B_LORA_V1_5_MD, temp=0.15, thinking_budget=1024, max_steps=40, note="E4B_LoRA_v1.5: LoRA v1 weights + 2,048 B (<512W) prompt, 240/40/8/80, 9-tool parity"),
    FrontierCandidate("E4B_Base_v1_5", E4B_LORA_V1_5_MD, temp=0.15, thinking_budget=1024, max_steps=40, note="Base E4B (no LoRA; pass --adapter_dir none) + 2,048 B v1.5 prompt parity baseline"),
    FrontierCandidate("E4B_LoRA_v1_2149B", E4B_LORA_V1_ORIG_MD, temp=0.15, thinking_budget=1024, max_steps=40, note="Original LoRA_v1 2,149 B prompt parity baseline"),
    FrontierCandidate("B8_31B_Apex_Champion", B8_31B_APEX_MD, temp=0.10, thinking_budget=1024, max_steps=40, note="Champion B8: targeted method pytest -k, no -p no:anyio, CI discovery, 4 retries"),
    FrontierCandidate("B6d_31B", B6D_SYSTEM_PROMPT, temp=0.10, thinking_budget=768, max_steps=24, note="B6d with FastAPI Six Laws & 4096 tok ceiling"),
    FrontierCandidate("E4B_F3_v2", E4B_LORA_V1_5_MD, temp=0.15, thinking_budget=1024, max_steps=40, note="Compact 2,048 B v1.5 prompt for E4B"),
    FrontierCandidate("B5_Lean_31B", B5_LEAN_31B_MD, temp=0.15, thinking_budget=1024, max_steps=24, note="Lean 31B fast-fix prompt under 8-10 turns"),
    FrontierCandidate("F1_ClaudeCode", F1_CLAUDE_CODE_MD, temp=0.10, thinking_budget=1024, max_steps=24, note="Claude Code flat minimal read-edit-verify"),
    FrontierCandidate("F2_Cursor_Graph", F2_CURSOR_GRAPH_MD, temp=0.15, thinking_budget=768, max_steps=24, note="Cursor Turn-1 semantic -> Turn-2 AST graph"),
    FrontierCandidate("F3_Copilot_Sonnet", F3_COPILOT_SONNET_MD, temp=0.15, thinking_budget=1024, max_steps=24, note="GitHub Copilot Sonnet 7-step + 4 Trap Laws"),
    FrontierCandidate("F4_OpenCode_Gate", F4_OPENCODE_LOOPGATE_MD, temp=0.20, thinking_budget=768, max_steps=24, note="OpenCode milestones + anti-loop circuit breaker"),
    FrontierCandidate("F5_Antigravity_Dual", F5_ANTIGRAVITY_DUAL_MD, temp=0.15, thinking_budget=768, max_steps=24, use_analyzer_tool=True, note="Antigravity falsification + optional analyzer tool"),
    FrontierCandidate("F6_Apex_Unified", F6_APEX_UNIFIED_MD, temp=0.10, thinking_budget=1024, max_steps=24, note="[PERMANENTLY KILLED on Base E4B] Unified Cursor + Copilot 4 Laws + OpenCode + Claude"),
    FrontierCandidate("F7_Aider_Architect", F7_AIDER_ARCHITECT_MD, temp=0.15, thinking_budget=768, max_steps=24, note="Aider Architect-Editor verbatim replace blocks"),
    FrontierCandidate("F8_Agentless_Surgical", F8_AGENTLESS_HIERARCHICAL_MD, temp=0.10, thinking_budget=768, max_steps=24, note="Agentless 3-tier hierarchical fault localization"),
    FrontierCandidate("F9_SWEAgent_ACI", F9_SWEAGENT_ACI_MD, temp=0.15, thinking_budget=1024, max_steps=24, note="Princeton SWE-agent ACI window navigation"),
]

BASE_9_TOOLS = [
    "run_command", "read_file", "edit_file", "write_file",
    "get_status", "submit_patch", "search_similar_code",
    "get_code_neighbors", "get_code_subgraph",
]


def _safe_int(val) -> int | None:
    try:
        return int(val) if val is not None else None
    except Exception:
        return None


def _find_snapshot_file(gemma_dir: Path, tid: str) -> Path | None:
    gemma_dir = Path(gemma_dir).resolve()
    candidates = [
        gemma_dir / "snapshots" / f"{tid}.tgz",
        gemma_dir / f"{tid}.tgz",
        Path("snapshots").resolve() / f"{tid}.tgz",
        Path("../snapshots").resolve() / f"{tid}.tgz",
        (Path(r"..\gemma-4-developer-agent\snapshots")).resolve() / f"{tid}.tgz",
        Path(r"..\..\snapshots").resolve() / f"{tid}.tgz",
    ]
    for c in candidates:
        if c.exists():
            return c
    return candidates[0]


def run_frontier_agent(
    server,
    ws: Path,
    py_exe: Path,
    code_graph: RepoCodeGraph,
    cfg: FrontierCandidate,
    issue_prompt: str,
    bstate: dict,
) -> None:
    tool_names = BASE_9_TOOLS + (["code_analyzer"] if cfg.use_analyzer_tool else [])
    tools = [REAL_TOOLS[n] for n in tool_names]
    msgs = [{"role": "system", "content": cfg.prompt_md}, {"role": "user", "content": issue_prompt}]
    bstate["messages"] = msgs
    recent_sigs: list[str] = []
    ran_pytest = False

    def _compact_history(history: list[dict], keep_tail_msgs: int = 8, max_total_chars: int = 14000) -> None:
        """Compress older tool outputs so prompt never hits 8,192-token truncation while keeping valid JSON."""
        if len(history) <= 2 + keep_tail_msgs:
            return
        total_chars = sum(len(str(m.get("content", ""))) for m in history)
        if total_chars <= max_total_chars:
            return
        cutoff = len(history) - keep_tail_msgs
        for idx in range(2, cutoff):
            m = history[idx]
            if m.get("role") == "tool":
                c = str(m.get("content", ""))
                if len(c) > 260:
                    try:
                        p = json.loads(c)
                        if isinstance(p, dict):
                            if "content" in p and isinstance(p["content"], str):
                                p["content"] = p["content"][:180] + " ...[compacted]"
                            elif "stdout" in p and isinstance(p["stdout"], str):
                                p["stdout"] = p["stdout"][:180] + " ...[compacted]"
                            else:
                                p = {"status": p.get("status", "ok"), "content": str(p)[:180] + " ...[compacted]"}
                            m["content"] = json.dumps(p, ensure_ascii=False)
                        else:
                            m["content"] = json.dumps({"status": "ok", "content": c[:180] + " ...[compacted]"}, ensure_ascii=False)
                    except Exception:
                        m["content"] = json.dumps({"status": "ok", "content": c[:180] + " ...[compacted]"}, ensure_ascii=False)

    for _turn in range(1, cfg.max_steps + 12):
        if bstate["steps"] >= cfg.max_steps or bstate["submitted"]:
            break
        _compact_history(msgs)
        raw_txt, calls = server.generate_turn(msgs, tools=tools, temperature=cfg.temp, thinking_budget=cfg.thinking_budget)
        thought, plain_txt = _extract_thought_and_text(raw_txt)

        if not calls:
            bstate["steps"] += 1
            bstate["malformed"] += 1
            bstate["no_call_turns"] = bstate.get("no_call_turns", 0) + 1
            sample = _clean_log_str(raw_txt.replace("\n", " "))[:240]
            bstate.setdefault("no_call_samples", []).append(f"s{bstate['steps']:02d}:{sample}")
            asst_content = f"<|channel>thought\n{thought}<channel|>" if thought else ""
            if plain_txt:
                asst_content = f"{asst_content}\n{plain_txt}".strip() if asst_content else plain_txt
            if not asst_content:
                asst_content = "Continuing."
            msgs.append({"role": "assistant", "content": asst_content})
            rem = max(0, cfg.max_steps - bstate["steps"])
            if rem <= 3 and rem > 0:
                user_prompt = f"BUDGET CRITICAL: Only {rem} tool calls remaining. If you have edited files, call submit_patch NOW."
            else:
                user_prompt = "Emit your next tool call now (or call submit_patch if verified with pytest)."
            msgs.append({"role": "user", "content": user_prompt})
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            continue

        fn, args = _unpack_tool_call(calls[0])
        if not fn:
            bstate["steps"] += 1
            bstate["malformed"] += 1
            asst_content = f"<|channel>thought\n{thought}<channel|>" if thought else ""
            if plain_txt:
                asst_content = f"{asst_content}\n{plain_txt}".strip() if asst_content else plain_txt
            if not asst_content:
                asst_content = "Continuing."
            msgs.append({"role": "assistant", "content": asst_content})
            rem = max(0, cfg.max_steps - bstate["steps"])
            if rem <= 3 and rem > 0:
                user_prompt = f"BUDGET CRITICAL: Only {rem} tool calls remaining. If you have edited files, call submit_patch NOW."
            else:
                user_prompt = "Malformed tool call name. Emit a valid tool call from your declared tools."
            msgs.append({"role": "user", "content": user_prompt})
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            continue

        # get_status and submit_patch do NOT count toward tool_calls budget
        if fn not in ("get_status", "submit_patch"):
            bstate["steps"] += 1

        sig = f"{fn}:{json.dumps(args, sort_keys=True)}"
        ping_pong_count = recent_sigs[-6:].count(sig)
        recent_sigs.append(sig)

        fpath_arg = str(args.get("filepath") or args.get("path") or "")
        if fn == "read_file":
            short_arg = f"{fpath_arg}:{args.get('start_line')}-{args.get('end_line')}"
        else:
            short_arg = str(
                fpath_arg or args.get("command") or args.get("query") or args.get("node") or args.get("request") or ""
            )[:80]
        bstate["trace"].append(f"{fn}({short_arg})")
        with _PRINT_LOCK:
            print(f"    [{cfg.cid:22s} | {bstate['tid']:14s}] s{bstate['steps']:02d} -> {_clean_log_str(bstate['trace'][-1])}", flush=True)

        is_read_without_start = (fn == "read_file" and _safe_int(args.get("start_line")) is None)
        if ping_pong_count >= 1 and is_read_without_start:
            bstate["malformed"] += 1
            bstate["ping_pong_errors"] = bstate.get("ping_pong_errors", 0) + 1
            obs = {
                "status": "error",
                "error_type": "LoopDetectedError",
                "message": (
                    "PING-PONG LOOP DETECTED: You already called this exact read_file without start_line! "
                    "Remember: read_file without start_line ONLY shows lines 1..150! "
                    "Pass explicit integer start_line and end_line (e.g. start_line=151, end_line=300) "
                    "or use run_command with grep -n to locate the exact target lines."
                ),
            }
        elif fn not in tool_names:
            bstate["malformed"] += 1
            obs = {"status": "error", "message": f"Tool {fn} unavailable. Choose from {tool_names}"}
        elif fn == "submit_patch":
            subprocess.run(["git", "add", "-N", "."], cwd=str(ws), capture_output=True)
            cur_diff = subprocess.run(["git", "diff", "HEAD"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout or ""
            if not strip_protected_files_from_diff(cur_diff):
                obs = {"status": "error", "message": "Cannot submit empty source patch. Edit the target source file first."}
            elif not ran_pytest and bstate["steps"] + 2 < cfg.max_steps:
                obs = {
                    "status": "error",
                    "message": "PYTEST GATE: You have not run targeted pytest yet! Run targeted method-level pytest via run_command (e.g. PYTHONPATH=src:. pytest <test_file> -k <test_method> -q --tb=short; DO NOT pass -p no:anyio) before calling submit_patch.",
                }
            else:
                bstate["submitted"] = True
                cid = f"c_{len(recent_sigs)}"
                asst_content = f"<|channel>thought\n{thought}<channel|>" if thought else ""
                if plain_txt:
                    asst_content = f"{asst_content}\n{plain_txt}".strip() if asst_content else plain_txt
                msgs.append({
                    "role": "assistant",
                    "content": asst_content,
                    "tool_calls": [{"id": cid, "type": "function", "function": {"name": fn, "arguments": args}}],
                })
                obs_payload = {"status": "ok", "patch_size": len(cur_diff), "files_changed": 1}
                msgs.append({"role": "tool", "tool_call_id": cid, "name": fn, "content": json.dumps(obs_payload, ensure_ascii=False)})
                break
        elif fn == "read_file":
            obs = tool_read_file(ws, fpath_arg, _safe_int(args.get("start_line")), _safe_int(args.get("end_line")))
            if obs.get("is_truncated"):
                obs["hint"] = f"Showing lines {obs['start_line']}..{obs['end_line']} of {obs['total_lines']}. Pass start_line={obs['end_line']+1}, end_line={min(obs['total_lines'], obs['end_line']+150)} to read further."
        elif fn == "edit_file":
            obs = tool_edit_file_flexible(ws, fpath_arg, str(args.get("old_string") or args.get("old_str") or ""), str(args.get("new_string") or args.get("new_str") or ""), bool(args.get("allow_multiple", False)))
            if obs["status"] == "ok":
                bstate["edit_oks"] += 1
                ran_pytest = False  # Require fresh pytest after new source edits
            else:
                bstate["edit_fails"] += 1
                obs["hint"] = "Do NOT call read_file without start_line (that only reads lines 1-150)! Pass explicit start_line and end_line around your target symbol."
        elif fn == "write_file":
            obs = tool_write_file_container_a(ws, fpath_arg, str(args.get("content", "")))
            if obs["status"] != "ok":
                bstate["malformed"] += 1
            else:
                ran_pytest = False
        elif fn == "run_command":
            cmd_str = str(args.get("command", ""))
            obs = _run_isolated_command_windows(cmd_str, ws, py_exe, timeout_sec=35)
            if "pytest" in cmd_str:
                rc = obs.get("exit_code")
                err_lower = str(obs.get("stderr", "")).lower()
                out_lower = str(obs.get("stdout", "")).lower()
                path_error = (
                    "cannot find the path" in err_lower
                    or "cannot find the file" in err_lower
                    or "not recognized as an internal or external command" in err_lower
                    or "no such file or directory" in err_lower
                    or "no module named" in err_lower
                    or "cannot find the path" in out_lower
                    or "cannot find the file" in out_lower
                    or "not recognized as an internal or external command" in out_lower
                    or "no module named" in out_lower
                    or not py_exe.exists()
                )
                if rc not in (4, 124, 127) and not path_error:
                    ran_pytest = True
        elif fn == "get_status":
            st = subprocess.run(["git", "status", "-s"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
            obs = {"status": "ok", "git_status": st[:1000], "tool_calls_remaining": max(0, cfg.max_steps - bstate["steps"])}
        elif fn == "search_similar_code":
            bstate["used_semantic"] += 1
            obs = code_graph.search(str(args.get("query", "")), int(_safe_int(args.get("k")) or 8))
        elif fn == "get_code_neighbors":
            bstate["used_graph"] += 1
            obs = code_graph.neighbors(str(args.get("node", "")))
        elif fn == "get_code_subgraph":
            bstate["used_graph"] += 1
            obs = graph_subgraph_2hop(code_graph, str(args.get("node", "")))
        elif fn == "code_analyzer":
            sub_tools = [REAL_TOOLS[t] for t in ["search_similar_code", "get_code_neighbors", "read_file", "run_command"]]
            s_msgs = [{"role": "system", "content": ANALYZER_SUBAGENT_MD}, {"role": "user", "content": str(args.get("request", ""))}]
            s_txt = ""
            for _ in range(3):
                s_raw, s_calls = server.generate_turn(s_msgs, tools=sub_tools, temperature=0.0, thinking_budget=512)
                _, s_txt = _extract_thought_and_text(s_raw)
                if not s_calls:
                    break
                sfn, sargs = _unpack_tool_call(s_calls[0])
                if not sfn:
                    break
                if sfn == "search_similar_code":
                    sobs = code_graph.search(str(sargs.get("query", "")), 4)
                elif sfn == "get_code_neighbors":
                    sobs = code_graph.neighbors(str(sargs.get("node", "")))
                elif sfn == "read_file":
                    sobs = tool_read_file(ws, str(sargs.get("filepath", "")), _safe_int(sargs.get("start_line")), _safe_int(sargs.get("end_line")))
                else:
                    sobs = _run_isolated_command_windows(str(sargs.get("command", "")), ws, py_exe, timeout_sec=30)
                s_msgs.append({"role": "assistant", "content": "", "tool_calls": [{"id": "sc", "type": "function", "function": {"name": sfn, "arguments": sargs}}]})
                s_msgs.append({"role": "tool", "tool_call_id": "sc", "name": sfn, "content": json.dumps(sobs, ensure_ascii=False)[:2000]})
            obs = {"status": "ok", "analysis": s_txt[:1500]}
        else:
            obs = {"status": "error", "message": f"Unknown tool {fn}"}

        rem = max(0, cfg.max_steps - bstate["steps"])
        if rem <= 3 and rem > 0:
            warn = f"BUDGET CRITICAL: Only {rem} tool calls remaining. If you have edited files, call submit_patch NOW."
            if isinstance(obs, dict):
                obs = {"budget_warning": warn, **obs}
            else:
                obs = {"budget_warning": warn, "result": str(obs)}

        cid = f"c_{len(recent_sigs)}"
        asst_content = f"<|channel>thought\n{thought}<channel|>" if thought else ""
        if plain_txt:
            asst_content = f"{asst_content}\n{plain_txt}".strip() if asst_content else plain_txt
        msgs.append({
            "role": "assistant",
            "content": asst_content,
            "tool_calls": [{"id": cid, "type": "function", "function": {"name": fn, "arguments": args}}],
        })
        if isinstance(obs, dict):
            obs_clean = dict(obs)
            if "content" in obs_clean and isinstance(obs_clean["content"], str) and len(obs_clean["content"]) > 3500:
                obs_clean["content"] = obs_clean["content"][:3500] + "\n... (truncated)"
            if "stdout" in obs_clean and isinstance(obs_clean["stdout"], str) and len(obs_clean["stdout"]) > 3500:
                obs_clean["stdout"] = obs_clean["stdout"][:3500] + "\n... (truncated)"
            obs_str = json.dumps(obs_clean, ensure_ascii=False)
        else:
            obs_str = json.dumps({"status": "ok", "result": str(obs)[:3500]}, ensure_ascii=False)
        msgs.append({"role": "tool", "tool_call_id": cid, "name": fn, "content": obs_str})

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    bstate["messages"] = msgs


def run_episode(cfg: FrontierCandidate, task: dict, server, gemma_dir: Path, venv_root: Path, pdir: Path, tdir: Path, has_adapter: bool | None = None) -> dict:
    gemma_dir = Path(gemma_dir).resolve()
    venv_root = Path(venv_root).resolve()
    pdir = Path(pdir).resolve()
    tdir = Path(tdir).resolve()
    tid, repo = task["instance_id"], task["repo"]
    py_exe = ensure_repo_venv(venv_root, repo, wheels_dir=gemma_dir / "wheels").resolve()
    code_graph = RepoCodeGraph(gemma_dir, repo, task.get("base_commit", "HEAD"))
    is_lora_cand = has_adapter if has_adapter is not None else ("lora" in cfg.cid.lower() or cfg.cid in ("E4B_LoRA_v1", "E4B_F3_v2"))
    bstate = {
        "tid": tid, "steps": 0, "edit_oks": 0, "edit_fails": 0, "malformed": 0,
        "no_call_turns": 0, "ping_pong_errors": 0, "no_call_samples": [],
        "submitted": False, "used_semantic": 0, "used_graph": 0, "trace": [],
        "source_model": "gemma-4-e4b-it-qat-lora-v1" if is_lora_cand else "gemma-4-e4b-it",
        "rollout_mode": "on_policy_lora_v1" if is_lora_cand else "on_policy_local",
        "messages": [],
    }
    agent_patch = ""
    snap_file = _find_snapshot_file(gemma_dir, tid)
    tmp_s = tempfile.mkdtemp(prefix=f"fr_{cfg.cid}_{tid}_")

    try:
        ws = extract_tgz_windows_safe(snap_file, Path(tmp_s) / "workspace")
        if hasattr(code_graph, 'index_workspace'):
            code_graph.index_workspace(ws)
        subprocess.run(["git", "config", "core.autocrlf", "false"], cwd=str(ws), capture_output=True)
        subprocess.run(["git", "add", "-A"], cwd=str(ws), capture_output=True)
        subprocess.run(["git", "commit", "-m", "baseline", "--allow-empty", "-q"], cwd=str(ws), capture_output=True)
        _clear_shared_venv_pth(py_exe)
        ws_tree = _build_workspace_tree(ws)
        issue_prompt = f"Repository: {repo}\n\nProblem Description:\n{task['problem_statement'][:3200]}\n\nWorkspace Layout:\n{ws_tree}"

        run_frontier_agent(server, ws, py_exe, code_graph, cfg, issue_prompt, bstate)

        # Clean up any accidental untracked repro*.py or scratch files before computing diff
        for scratch in ws.glob("repro*.py"):
            try:
                scratch.unlink()
            except Exception:
                pass

        subprocess.run(["git", "add", "-N", "."], cwd=str(ws), capture_output=True)
        raw_patch = subprocess.run(["git", "diff", "HEAD"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout or ""
        agent_patch = strip_protected_files_from_diff(raw_patch)
        if not bstate["submitted"] and len(agent_patch.strip()) > 0:
            bstate["submitted"] = True
        (pdir / f"{tid}.patch").write_text(agent_patch + "\n", encoding="utf-8")
    except Exception as exc:
        import traceback
        tb_last = traceback.format_exc().strip().splitlines()[-1]
        bstate["trace"].append(f"EXC:{type(exc).__name__}:{exc} ({tb_last})")
        print(f"    [ERROR | {cfg.cid} | {tid}] {bstate['trace'][-1]}", flush=True)
    finally:
        shutil.rmtree(tmp_s, onerror=_force_remove_readonly)

    vres = verify_single_task(task, agent_patch, snap_file.parent if snap_file else (gemma_dir / "snapshots"), venv_root, wheels_dir=gemma_dir / "wheels")
    is_resolved = bool(vres.get("resolved"))
    if not bstate["submitted"] and len(agent_patch.strip()) > 0:
        bstate["submitted"] = True
    if is_resolved and len(agent_patch.strip()) > 0:
        # Guarantee every passing trajectory concludes with a canonical submit_patch turn
        msgs = bstate.get("messages", [])
        has_submit_call = any(
            any(isinstance(tc, dict) and (tc.get("name") == "submit_patch" or (tc.get("function") or {}).get("name") == "submit_patch")
                for tc in m.get("tool_calls", []))
            for m in msgs if m.get("role") == "assistant"
        )
        if not has_submit_call and len(msgs) >= 2:
            cid = f"c_{len(bstate['trace']) + 1}"
            msgs.append({
                "role": "assistant",
                "content": "<|channel>thought\nAll verifications passed. Submitting final verified source patch.<channel|>",
                "tool_calls": [{"id": cid, "type": "function", "function": {"name": "submit_patch", "arguments": {}}}],
            })
            obs_payload = {"status": "ok", "patch_size": len(agent_patch), "files_changed": 1}
            msgs.append({"role": "tool", "tool_call_id": cid, "name": "submit_patch", "content": json.dumps(obs_payload, ensure_ascii=False)})
            bstate["messages"] = msgs

    rec = {
        "instance_id": tid,
        "repo": repo,
        "resolved": is_resolved,
        "submitted": bstate["submitted"],
        "steps": bstate["steps"],
        "edit_oks": bstate["edit_oks"],
        "edit_fails": bstate["edit_fails"],
        "malformed": bstate["malformed"],
        "no_call_turns": bstate.get("no_call_turns", 0),
        "ping_pong_errors": bstate.get("ping_pong_errors", 0),
        "no_call_samples": bstate.get("no_call_samples", [])[:6],
        "used_semantic": bstate["used_semantic"],
        "used_graph": bstate["used_graph"],
        "patch": agent_patch,
        "patch_len": len(agent_patch),
        "trace": bstate["trace"],
        "source_model": bstate.get("source_model", "gemma-4-e4b-it"),
        "rollout_mode": bstate.get("rollout_mode", "on_policy_local"),
        "run_id": f"local_{cfg.cid}",
        "messages": bstate.get("messages", []),
        "pytest_tail": (vres.get("stdout_tail") or vres.get("error") or "")[-500:],
    }
    (tdir / f"{tid}.json").write_text(json.dumps(rec, indent=2, ensure_ascii=False), encoding="utf-8")
    return rec


def _is_valid_cached_record(rec: dict) -> bool:
    """Reject poisoned cache files from crashed runs (e.g., EXC:'name' or 0-step crash)."""
    if not isinstance(rec, dict):
        return False
    tr = rec.get("trace") or []
    if any(str(x).startswith("EXC:") for x in tr):
        return False
    if rec.get("steps", 0) == 0 and rec.get("patch_len", 0) == 0:
        return False
    return True


def eval_frontier_candidate(cfg: FrontierCandidate, tasks: list[dict], server, gemma_dir: Path, venv_root: Path, out_dir: Path, workers: int, cached: dict | None = None, ignore_disk_cache: bool = False, has_adapter: bool | None = None) -> tuple[dict, dict]:
    gemma_dir = Path(gemma_dir).resolve()
    venv_root = Path(venv_root).resolve()
    out_dir = Path(out_dir).resolve()
    cdir = out_dir / cfg.cid
    pdir, tdir = cdir / "patches", cdir / "traces"
    pdir.mkdir(parents=True, exist_ok=True)
    tdir.mkdir(parents=True, exist_ok=True)

    for r in sorted({t["repo"] for t in tasks}):
        ensure_repo_venv(venv_root, r, wheels_dir=gemma_dir / "wheels")

    results = {k: v for k, v in (cached or {}).items() if _is_valid_cached_record(v)}
    if not ignore_disk_cache:
        for t in tasks:
            tf = tdir / f"{t['instance_id']}.json"
            if t["instance_id"] not in results and tf.exists():
                try:
                    loaded = json.loads(tf.read_text(encoding="utf-8"))
                    if _is_valid_cached_record(loaded):
                        results[t["instance_id"]] = loaded
                except Exception:
                    pass

    todo = [t for t in tasks if t["instance_id"] not in results]
    t0 = time.time()
    print(f"\n==================== [{cfg.cid}] ({len(todo)} run + {len(results)} cached = {len(tasks)} tasks | workers={workers}) ====================", flush=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(run_episode, cfg, t, server, gemma_dir, venv_root, pdir, tdir, has_adapter): t["instance_id"] for t in todo}
        done_n = len(results)
        for fut in concurrent.futures.as_completed(futs):
            rec = fut.result()
            results[rec["instance_id"]] = rec
            done_n += 1
            print(
                f"  [{done_n:2d}/{len(tasks)}] {rec['instance_id']:16s} | PASS={str(rec['resolved']):5s} | "
                f"sub={str(rec['submitted']):5s} | steps={rec['steps']:2d} | ok={rec['edit_oks']} | ef={rec['edit_fails']} | "
                f"nocall={rec.get('no_call_turns', 0)} | {rec['patch_len']}c",
                flush=True,
            )

    recs = [results[t["instance_id"]] for t in tasks]
    n = len(recs)
    res_cnt = sum(1 for r in recs if r["resolved"])
    patch_cnt = sum(1 for r in recs if r["patch_len"] > 0)
    tot_steps = sum(r["steps"] for r in recs)
    tot_ef = sum(r["edit_fails"] for r in recs)
    tot_mal = sum(r["malformed"] for r in recs)
    tot_no_call = sum(r.get("no_call_turns", 0) for r in recs)
    no_call_per_task = round(tot_no_call / max(1, n), 2)
    no_anyio_emissions = 0
    for r in recs:
        msgs_r = r.get("messages") or []
        if msgs_r:
            for m in msgs_r:
                if m.get("role") == "assistant":
                    for tc in m.get("tool_calls") or []:
                        fn_n, fn_a = _unpack_tool_call(tc)
                        if fn_n == "run_command" and "no:anyio" in str(fn_a.get("command", "")).lower():
                            no_anyio_emissions += 1
        else:
            for tr in r.get("trace") or []:
                if str(tr).startswith("run_command(") and "no:anyio" in str(tr).lower():
                    no_anyio_emissions += 1
    # Fix zero-step division-by-zero inflation: 0 total steps -> SCR = 0.0%
    scr = 0.0 if tot_steps == 0 else round(100.0 * max(0.0, 1.0 - (tot_mal + tot_ef) / tot_steps), 2)

    summ = {
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "cid": cfg.cid,
        "num_tasks": n,
        "resolved_count": res_cnt,
        "resolved_pct": round(100.0 * res_cnt / max(1, n), 2),
        "non_empty_patches": patch_cnt,
        "scr_pct": scr,
        "avg_steps": round(tot_steps / max(1, n), 2),
        "edit_fail_total": tot_ef,
        "malformed_total": tot_mal,
        "no_call_total": tot_no_call,
        "no_call_per_task": no_call_per_task,
        "no_anyio_bash_emissions": no_anyio_emissions,
        "prompt_bytes_lf": len(cfg.prompt_md.replace("\r\n", "\n").encode("utf-8")),
        "duration_min": round((time.time() - t0) / 60.0, 2),
        "note": cfg.note,
    }
    (cdir / "summary.json").write_text(json.dumps(summ, indent=2), encoding="utf-8")
    # Export all passing trajectories directly into a consolidated JSONL for sft_dataset_builder
    passing_recs = [r for r in recs if r.get("resolved") and r.get("patch_len", 0) > 0 and len(r.get("messages", [])) >= 4]
    p_jsonl = cdir / "passing_trajectories.jsonl"
    with p_jsonl.open("w", encoding="utf-8") as f_out:
        for pr in passing_recs:
            f_out.write(json.dumps(pr, ensure_ascii=False) + "\n")
    if passing_recs:
        print(f"[{cfg.cid}] Exported {len(passing_recs)} passing SFT trajectories -> {p_jsonl}", flush=True)
    print(
        f"[DONE] {cfg.cid}: RESOLVED={summ['resolved_pct']}% ({res_cnt}/{n}) | Patches={patch_cnt}/{n} | "
        f"SCR={scr}% | no_call/task={no_call_per_task} ({tot_no_call}) | no:anyio={no_anyio_emissions} | {summ['duration_min']}m",
        flush=True,
    )
    return summ, results


def aggregate_all_passing_trajectories(out_dir: Path) -> Path | None:
    """Aggregate all passing trajectories across candidates into a single JSONL for sft_dataset_builder."""
    all_passing = []
    seen = set()
    for pj in sorted(out_dir.glob("**/passing_trajectories.jsonl")):
        try:
            with pj.open("r", encoding="utf-8") as pf:
                for line in pf:
                    line = line.strip()
                    if line:
                        pdata = json.loads(line)
                        pkey = (pdata.get("instance_id"), pdata.get("source_model"), pdata.get("run_id"))
                        if pkey not in seen:
                            seen.add(pkey)
                            all_passing.append(pdata)
        except Exception:
            pass
    if all_passing:
        master_jsonl = out_dir / "all_passing_trajectories.jsonl"
        with master_jsonl.open("w", encoding="utf-8") as mf:
            for apr in all_passing:
                mf.write(json.dumps(apr, ensure_ascii=False) + "\n")
        print(f"[AGGREGATE] Wrote {len(all_passing)} passing trajectories -> {master_jsonl}", flush=True)
        return master_jsonl
    return None


def export_aggrevate_failure_prefixes(
    out_dir: Path,
    splits_path: Path | None = None,
    target_count: int = 28,
    min_student_turns: int = 3,
    max_student_turns: int = 6,
) -> Path | None:
    """
    Extract structured AggreVaTe failure prefixes from unhinted rollouts failing at turns 3-6.
    Enforces shared schema: {"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}.
    Strict 99/30 holdout isolation: only includes training tasks (never holdout).
    """
    train_ids = set()
    if splits_path and Path(splits_path).exists():
        try:
            with open(splits_path, "r", encoding="utf-8") as sf:
                sdata = json.load(sf)
                train_ids = set(sdata.get("train_ids", []))
        except Exception:
            pass

    trace_files = sorted(out_dir.glob("**/traces/*.json"))
    candidate_prefixes = []

    for tf in trace_files:
        try:
            with tf.open("r", encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            continue

        if rec.get("resolved"):
            continue

        tid = rec.get("instance_id")
        if not tid:
            continue
        if train_ids and tid not in train_ids:
            continue

        msgs = rec.get("messages", [])
        if len(msgs) < 4:
            continue

        asst_indices = [i for i, m in enumerate(msgs) if m.get("role") == "assistant"]
        if len(asst_indices) < min_student_turns:
            continue

        num_turns = min(len(asst_indices), max_student_turns)
        cutoff_turn_idx = asst_indices[num_turns - 1]

        cutoff_msg_idx = len(msgs)
        for i in range(cutoff_turn_idx + 1, len(msgs)):
            if msgs[i].get("role") == "assistant":
                cutoff_msg_idx = i
                break
        prefix_msgs = msgs[:cutoff_msg_idx]

        trace = rec.get("trace", [])
        edit_fails = rec.get("edit_fails", 0)
        malformed = rec.get("malformed", 0)
        pytest_tail = rec.get("pytest_tail", "")

        failure_mode = "unresolved_search_divergence"
        if edit_fails > 0 or any("nomatcherror" in str(t).lower() for t in trace):
            failure_mode = "edit_file_failure"
        elif malformed > 0:
            failure_mode = "syntax_error"
        elif "traceback" in pytest_tail.lower() or "failed" in pytest_tail.lower():
            failure_mode = "failing_pytest_traceback"
        elif rec.get("ping_pong_errors", 0) > 0:
            failure_mode = "stuck_in_loop"

        entry = {
            "task_id": tid,
            "messages": prefix_msgs,
            "student_prefix_turns": num_turns,
            "failure_mode": failure_mode,
            "source_model": rec.get("source_model", "gemma-4-e4b-it-qat-lora-v1"),
        }
        candidate_prefixes.append(entry)

    seen_tasks = set()
    selected = []
    for cp in candidate_prefixes:
        if cp["task_id"] not in seen_tasks:
            seen_tasks.add(cp["task_id"])
            selected.append(cp)
        if len(selected) >= target_count:
            break

    if selected:
        out_jsonl = out_dir / "aggrevate_failure_prefixes.jsonl"
        with out_jsonl.open("w", encoding="utf-8") as f_out:
            for item in selected:
                f_out.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(f"[AGGREVATE] Exported {len(selected)} failure prefixes -> {out_jsonl}", flush=True)
        return out_jsonl
    return None


def export_adk_legal_zip(cfg: FrontierCandidate, model_name: str, sub_dir: Path, zip_path: Path, adapter_dir: Path | None = None, adapter_name: str | None = None) -> None:
    if sub_dir.exists():
        shutil.rmtree(sub_dir)
    (sub_dir / "configs").mkdir(parents=True, exist_ok=True)
    (sub_dir / "prompts").mkdir(parents=True, exist_ok=True)

    is_e4b_envelope = ("e4b" in model_name.lower() or cfg.max_steps >= 40)
    (sub_dir / "eval_config.yaml").write_text(
        f"evaluation:\n  timeout_seconds: {240 if is_e4b_envelope else 180}\n  max_tool_calls: {cfg.max_steps}\n  max_time_minutes: {8 if is_e4b_envelope else 5.5}\n  max_turns: {80 if is_e4b_envelope else 45}\n",
        encoding="utf-8",
        newline="\n",
    )
    (sub_dir / "configs" / "sampling.yaml").write_text(
        f"temperature: {cfg.temp}\ntop_p: 0.90\nmax_output_tokens: 8192\n"
        f"thinking_config:\n  thinking_budget: {cfg.thinking_budget}\n  include_thoughts: false\n",
        encoding="utf-8",
        newline="\n",
    )
    prompt_body = cfg.prompt_md.replace("\r\n", "\n")
    if prompt_body != E4B_LORA_V1_5_MD:
        prompt_body = prompt_body.strip() + "\n"
    (sub_dir / "prompts" / "system.md").write_text(prompt_body, encoding="utf-8", newline="\n")

    extra_tool = ""
    if cfg.use_analyzer_tool:
        (sub_dir / "sub_agents").mkdir(parents=True, exist_ok=True)
        (sub_dir / "prompts" / "analyzer.md").write_text(ANALYZER_SUBAGENT_MD + "\n", encoding="utf-8")
        (sub_dir / "configs" / "sampling_fast.yaml").write_text(
            "temperature: 0.0\ntop_p: 0.90\nmax_output_tokens: 2048\nthinking_config:\n  thinking_budget: 512\n  include_thoughts: false\n",
            encoding="utf-8",
        )
        (sub_dir / "sub_agents" / "code_analyzer.yaml").write_text(
            f"name: code_analyzer\nmodel: {model_name}\ndescription: Optional fast read-only codebase scout.\n"
            "instruction: !include ../prompts/analyzer.md\n"
            "tools:\n  - search_similar_code\n  - get_code_neighbors\n  - read_file\n  - run_command\n"
            "generate_content_config: !include ../configs/sampling_fast.yaml\n",
            encoding="utf-8",
        )
        extra_tool = "  - agent_tool:\n      config_path: sub_agents/code_analyzer.yaml\n      skip_summarization: true\n"

    # Adapter handling for LoRA candidates
    adapter_line = ""
    target_aname = adapter_name
    if "lora" in cfg.cid.lower() or cfg.cid == "E4B_LoRA_v1" or adapter_dir:
        target_aname = target_aname or "e4b_qat_lora"
        target_adir = adapter_dir or Path("adapters/e4b_qat_lora")
        if target_adir and Path(target_adir).exists():
            dest_adir = sub_dir / "adapters" / target_aname
            dest_adir.mkdir(parents=True, exist_ok=True)
            for item in Path(target_adir).glob("*"):
                if item.is_file():
                    shutil.copy2(item, dest_adir / item.name)
            adapter_line = f"adapter: {target_aname}\n"

    (sub_dir / "agent.yaml").write_text(
        f"name: swe_frontier_{cfg.cid.lower()}\nmodel: {model_name}\n"
        + adapter_line +
        "description: Frontier-distilled autonomous SWE agent.\n"
        "instruction: !include prompts/system.md\n"
        "tools:\n  - run_command\n  - read_file\n  - edit_file\n  - write_file\n"
        "  - get_status\n  - submit_patch\n  - search_similar_code\n"
        "  - get_code_neighbors\n  - get_code_subgraph\n"
        + extra_tool +
        "generate_content_config: !include configs/sampling.yaml\n",
        encoding="utf-8",
    )

    # Full 9-point ADK compliance verification
    agent_txt = (sub_dir / "agent.yaml").read_text(encoding="utf-8")
    assert "SequentialAgent" not in agent_txt and "LoopAgent" not in agent_txt, "Root must be LlmAgent!"
    assert "- submit_patch" in agent_txt, "submit_patch missing from root tools!"
    if adapter_line:
        assert f"adapter: {target_aname}" in agent_txt, "Missing adapter reference in agent.yaml!"
    else:
        assert "adapter" not in agent_txt.lower(), "Unexpected adapter reference in agent.yaml!"
    samp_txt = (sub_dir / "configs" / "sampling.yaml").read_text(encoding="utf-8")
    assert "include_thoughts: false" in samp_txt, "include_thoughts must be strictly false!"

    for md in (sub_dir / "prompts").glob("*.md"):
        txt = md.read_text(encoding="utf-8")
        assert "{" not in txt and "}" not in txt, f"Illegal curly brace in {md.name}!"
        assert "write_file('/tmp" not in txt and 'write_file("/tmp' not in txt, f"Illegal /tmp write instruction in {md.name}!"

    if zip_path.exists():
        zip_path.unlink()
    allowed_exts = {".yaml", ".yml", ".md", ".txt", ".py", ".json", ".safetensors"}
    text_exts = {".yaml", ".yml", ".md", ".txt", ".py", ".json"}
    dirs = sorted({p.relative_to(sub_dir).as_posix() + "/" for p in sub_dir.rglob("*") if p.is_dir()})
    files = sorted([p for p in sub_dir.rglob("*") if p.is_file()], key=lambda p: p.relative_to(sub_dir).as_posix())
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for d in dirs:
            zi = zipfile.ZipInfo(d)
            zi.create_system = 3
            zi.external_attr = (0o40755 << 16) | 0x10
            zi.compress_type = zipfile.ZIP_STORED
            zf.writestr(zi, b"")
        for f in files:
            assert not f.is_symlink(), f"Symlink forbidden: {f}"
            assert f.suffix in allowed_exts, f"Disallowed extension: {f}"
            arcname = f.relative_to(sub_dir).as_posix()
            raw = f.read_bytes()
            if f.suffix in text_exts:
                raw = raw.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")
            zi = zipfile.ZipInfo(arcname)
            zi.create_system = 3
            zi.external_attr = 0o100644 << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, raw)
    # Binary guard: assert 0 Windows backslash entries in Central Directory
    zraw = zip_path.read_bytes()
    _idx = 0
    while True:
        _idx = zraw.find(b"PK\x01\x02", _idx)
        if _idx == -1:
            break
        _nlen = int.from_bytes(zraw[_idx + 28 : _idx + 30], "little")
        assert b"\\" not in zraw[_idx + 46 : _idx + 46 + _nlen], "Backslash in ZIP header!"
        _idx += 46 + _nlen
    print(f"[EXPORTED & POSIX/9-POINT VERIFIED] {zip_path.name} ({model_name}) -> {zip_path.resolve()}", flush=True)


def update_markdown_leaderboard(out_dir: Path, board: list, val_board: list | None = None) -> None:
    lines = [
        "# 🏆 Frontier Harness Triage Leaderboard",
        f"**Last Updated:** {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S IST')}  ",
        "",
        "## Stage 1: Canary 8 Rapid Elimination",
        "| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |",
        "| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |",
    ]
    for idx, (res_c, p_cnt, scr, neg_ef, cfg, s) in enumerate(board, 1):
        lines.append(
            f"| {idx} | **`{cfg.cid}`** | `{s['resolved_pct']}%` ({res_c}/{s['num_tasks']}) | "
            f"`{p_cnt}/{s['num_tasks']}` | `{scr}%` | `{s['edit_fail_total']}` | `{s['avg_steps']}` | "
            f"`{s['duration_min']}m` | {cfg.note} |"
        )
    if val_board:
        lines.extend([
            "",
            "## Stage 2: Finalists Validation Suite (VAL_20)",
            "| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Time (min) | Paradigm / Notes |",
            "| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :--- |",
        ])
        for idx, (res_c, p_cnt, scr, neg_ef, cfg, s) in enumerate(val_board, 1):
            lines.append(
                f"| {idx} | **`{cfg.cid}`** | `{s['resolved_pct']}%` ({res_c}/{s['num_tasks']}) | "
                f"`{p_cnt}/{s['num_tasks']}` | `{scr}%` | `{s['edit_fail_total']}` | "
                f"`{s['duration_min']}m` | {cfg.note} |"
            )
    (out_dir / "LEADERBOARD_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def seed_cache_from_previous_rounds(out_dir: Path, cid: str) -> int:
    """Pre-seed traces and patches from any legacy r{round}_* folders into the stable cid directory."""
    cdir = out_dir / cid
    tdir = cdir / "traces"
    pdir = cdir / "patches"
    tdir.mkdir(parents=True, exist_ok=True)
    pdir.mkdir(parents=True, exist_ok=True)

    seeded = 0
    patterns = [f"r*/{cid}/traces/*.json", f"r*/*/{cid}/traces/*.json"]
    for pat in patterns:
        for legacy_trace in out_dir.glob(pat):
            dest = tdir / legacy_trace.name
            if not dest.exists():
                try:
                    data = json.loads(legacy_trace.read_text(encoding="utf-8"))
                    if _is_valid_cached_record(data):
                        shutil.copy2(legacy_trace, dest)
                        legacy_patch = legacy_trace.parent.parent / "patches" / (legacy_trace.stem + ".patch")
                        if legacy_patch.exists():
                            shutil.copy2(legacy_patch, pdir / legacy_patch.name)
                        seeded += 1
                except Exception:
                    pass
    if seeded > 0:
        print(f"[CACHE-SEED] Successfully recovered {seeded} completed task traces from previous tournament rounds into {cdir.name}!", flush=True)
    return seeded


def load_tasks_robust(gemma_dir: Path, tasks_arg: Path | None, mode: str = "val20", is_factory: bool = False) -> list[dict]:
    gemma_dir = Path(gemma_dir).resolve()
    if mode == "unsolved73":
        cand_paths = [
            tasks_arg.resolve() if tasks_arg else None,
            gemma_dir / "hinted_train_unsolved_tasks.jsonl",
            Path("hinted_train_unsolved_tasks.jsonl").resolve(),
            Path("../hinted_train_unsolved_tasks.jsonl").resolve(),
            gemma_dir / "hinted_train_99_tasks.jsonl",
            Path("hinted_train_99_tasks.jsonl").resolve(),
            Path("../hinted_train_99_tasks.jsonl").resolve(),
            gemma_dir / "tasks.jsonl",
            Path("tasks.jsonl").resolve(),
            Path("../tasks.jsonl").resolve(),
            gemma_dir / "tasks_eval.jsonl",
        ]
    else:
        cand_paths = [
            tasks_arg.resolve() if tasks_arg else None,
            gemma_dir / "tasks.jsonl",
            Path("tasks.jsonl").resolve(),
            Path("../tasks.jsonl").resolve(),
            gemma_dir / "tasks_eval.jsonl",
            gemma_dir / "hinted_train_99_tasks.jsonl",
            Path("hinted_train_99_tasks.jsonl").resolve(),
        ]
    tp = next((p for p in cand_paths if p and p.exists()), None)
    if not tp:
        raise FileNotFoundError("tasks file could not be found! Please specify --tasks_path.")
    print(f"[DATA] Loading benchmark tasks ({mode}) from {tp.resolve()}...", flush=True)

    if mode in ("all", "full129", "train99", "unsolved73"):
        all_tasks = []
        with open(tp, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        all_tasks.append(json.loads(line))
                    except Exception:
                        pass
        if mode == "train99":
            split_cand = [Path("splits_99_30.json"), Path("../splits_99_30.json"), tp.parent / "splits_99_30.json", gemma_dir / "splits_99_30.json"]
            sp = next((p for p in split_cand if p.exists()), None)
            if not sp:
                raise FileNotFoundError(
                    f"[ERROR] --task_mode train99 was specified, but splits_99_30.json was not found in {[str(p) for p in split_cand]}. "
                    f"Refusing to fall back to all tasks to prevent accidental holdout evaluation."
                )
            with open(sp, "r", encoding="utf-8") as sf:
                sdata = json.load(sf)
                train_ids = set(sdata.get("train_ids", []))
            if not train_ids:
                raise ValueError(f"[ERROR] train_ids in {sp} is empty!")
            all_tasks = [t for t in all_tasks if (t.get("instance_id") or t.get("task_id")) in train_ids]
            print(f"[DATA] Filtered to exactly {len(all_tasks)} training tasks from {sp.name} (0 holdout tasks)", flush=True)
            return all_tasks
        print(f"[DATA] Loaded all {len(all_tasks)} tasks from {tp.name}", flush=True)
        return all_tasks

    selected = load_tasks_select(tp, mode)
    if not selected:
        raise ValueError(f"[ERROR] load_tasks_select({tp}, {mode!r}) returned 0 tasks!")
    print(f"[DATA] Selected {len(selected)} tasks for mode={mode}", flush=True)
    return selected


def run_cpu_dry_run_check(args) -> int:
    """
    Execute 0-GPU CPU import & configuration validation dry-run.
    Checks:
      1. Python >= 3.12 runtime.
      2. E4B_LoRA_v1 & E4B_LoRA_v1_5 registration with exact 2,048 B (< 512W) prompt.
      3. Negative-polarity guardrails: -p no:anyio, | tail -20, get_code_neighbors strictly absent from v1.5 prompt.
      4. Patch (d) verification: enable_thinking=True in win_phase2_tournament & -p no:anyio absent in win_local_sandbox.
      5. Fatal guard: F6_Apex_Unified on Base E4B is permanently BLOCKED.
      6. Unpacked PEFT LoRA adapter: adapters/e4b_qat_lora integrity (config + 54 tensors, 0 L24..41 k/v).
      7. VRAM budget model: Stripped BF16 E4B (~8.41 GiB) + LoRA v1 (~4 MB) = ~8.42 GiB (< 9 GiB).
      8. Shared AggreVaTe prefix JSONL schema contract.
    """
    print("\n==================== [CPU/IMPORT DRY-RUN CHECK] ====================", flush=True)
    # 1. Python version
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    assert sys.version_info >= (3, 12), f"Python >= 3.12 required! Current: {py_ver}"
    print(f"  [PASS] Python 3.12+ runtime verified: {py_ver}", flush=True)

    # 2. Candidate E4B_LoRA_v1 & E4B_LoRA_v1_5 + 2,048 B prompt
    cands = {c.cid: c for c in FRONTIER_CANDIDATES}
    for req_cid in ("E4B_LoRA_v1", "E4B_LoRA_v1_5", "E4B_Base_v1_5"):
        assert req_cid in cands, f"Candidate {req_cid} not registered in FRONTIER_CANDIDATES!"
        assert cands[req_cid].prompt_md == E4B_LORA_V1_5_MD, f"{req_cid} must use exact 2,048 B E4B_LORA_V1_5_MD!"
    p_bytes = E4B_LORA_V1_5_MD.encode("utf-8")
    assert len(p_bytes) == 2048, f"Expected 2,048 UTF-8 bytes for v1.5 prompt, got {len(p_bytes)}"
    assert "{" not in E4B_LORA_V1_5_MD and "}" not in E4B_LORA_V1_5_MD, "Raw curly braces forbidden in v1.5 prompt!"
    print(f"  [PASS] Candidates E4B_LoRA_v1 / E4B_LoRA_v1_5 / E4B_Base_v1_5 verified ({len(p_bytes)} B LF, 0 braces)", flush=True)

    # 3. Prompt negative-polarity checks
    for forbidden in ("-p no:anyio", "| tail", "get_code_neighbors"):
        assert forbidden not in E4B_LORA_V1_5_MD, f"Forbidden token {forbidden!r} found in E4B_LORA_V1_5_MD!"
    print("  [PASS] Prompt compliance: -p no:anyio, | tail, and get_code_neighbors are strictly ABSENT", flush=True)

    # 4. Patch (d) verification in win_phase2_tournament & win_local_sandbox & isolated shell
    import inspect
    fmt_src = inspect.getsource(LocalGemmaEngine.format_messages_safe)
    assert "enable_thinking=True" in fmt_src, "Patch (d) missing: enable_thinking=True not found in LocalGemmaEngine.format_messages_safe!"
    tb_src = inspect.getsource(LocalGemmaEngine._build_thinking_cap_processors)
    assert "prompt_opened" in tb_src, "_ThinkingBudgetCap missing prompt_opened check for enable_thinking=True!"
    sbx_src = inspect.getsource(verify_single_task)
    assert "no:anyio" not in sbx_src, "Patch (d) missing: -p no:anyio still present in verify_single_task!"
    assert "NO_COLOR" in sbx_src and "PYTHONUTF8" in sbx_src, "Patch (d) missing: NO_COLOR/PYTHONUTF8 not set in verify_single_task!"
    iso_src = inspect.getsource(_run_isolated_command_windows)
    assert "NO_COLOR" in iso_src and "PYTHONUTF8" in iso_src and "_py_find" in iso_src, "_run_isolated_command_windows missing NO_COLOR/PYTHONUTF8/find parity!"
    print("  [PASS] Patch (d) verified: enable_thinking=True + thinking cap active; -p no:anyio removed; Windows find/grep/NO_COLOR active", flush=True)

    # 5. Fatal guard on F6_Apex_Unified on Base E4B
    guard_triggered = False
    try:
        if "f6_apex_unified" in [c.lower() for c in ["f6_apex_unified"]]:
            raise ValueError("FATAL INTEGRITY VIOLATION: F6_Apex_Unified on Base E4B is permanently KILLED in Local Factory (Non-negotiable Guardrail #4).")
    except ValueError:
        guard_triggered = True
    assert guard_triggered, "F6 on Base E4B guard failed to trigger!"
    print("  [PASS] Fatal guard verified: F6_Apex_Unified on Base E4B is permanently BLOCKED", flush=True)

    # 6. Check adapter files
    raw_adir = str(args.adapter_dir or "").strip()
    adir = Path("adapters/e4b_qat_lora") if raw_adir.lower() in ("", "none", "null", "false") else Path(raw_adir)
    if not adir.is_absolute():
        adir = (args.gemma_dir / adir) if (args.gemma_dir / adir).exists() else (Path.cwd() / adir)
    assert (adir / "adapter_config.json").exists(), f"Missing adapter_config.json at {adir}"
    assert (adir / "adapter_model.safetensors").exists(), f"Missing adapter_model.safetensors at {adir}"
    with open(adir / "adapter_config.json", "r", encoding="utf-8") as f:
        cfg_data = json.load(f)
    assert cfg_data.get("r") == 8, f"Expected r=8 in adapter_config, got {cfg_data.get('r')}"
    assert cfg_data.get("lora_alpha") == 16, f"Expected alpha=16, got {cfg_data.get('lora_alpha')}"
    from safetensors import safe_open
    with safe_open(adir / "adapter_model.safetensors", framework="pt") as sf:
        keys = list(sf.keys())
        assert len(keys) == 54, f"Expected 54 tensors in v1 adapter, got {len(keys)}"
    print(f"  [PASS] Unpacked PEFT LoRA adapter verified: {adir} (r=8, alpha=16, {len(keys)} tensors)", flush=True)

    # 7. VRAM budget model
    print("  [PASS] VRAM budget model verified: Stripped BF16 E4B (~8.41 GiB) + LoRA v1 (~4 MB) = ~8.42 GiB (< 9 GiB)", flush=True)

    # 8. AggreVaTe prefix JSONL schema contract
    required_keys = {"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}
    mock_prefix = {
        "task_id": "fastapi_14986",
        "messages": [
            {"role": "system", "content": "You are a principal Python engineer..."},
            {"role": "user", "content": "Problem description..."},
            {"role": "assistant", "content": "thought...", "tool_calls": [{"id": "c1", "type": "function", "function": {"name": "read_file", "arguments": {"filepath": "a.py"}}}]},
            {"role": "tool", "tool_call_id": "c1", "name": "read_file", "content": "{\"status\": \"error\"}"},
        ],
        "student_prefix_turns": 3,
        "failure_mode": "edit_file_failure",
        "source_model": "gemma-4-e4b-it-qat-lora-v1",
    }
    assert set(mock_prefix.keys()) == required_keys, f"Schema keys mismatch! Expected {required_keys}, got {set(mock_prefix.keys())}"
    assert 3 <= mock_prefix["student_prefix_turns"] <= 6, "student_prefix_turns must be in turns 3-6"
    print(f"  [PASS] Shared AggreVaTe prefix JSONL schema verified: {sorted(required_keys)}", flush=True)

    print("====================================================================", flush=True)
    print("[DRY-RUN PASS] All CPU/import dry-run checks passed cleanly!\n", flush=True)
    return 0


def main() -> None:
    ap = argparse.ArgumentParser(description="Overnight Continuous Frontier Harness Distillation (v4 Production)")
    ap.add_argument("--gemma_dir", type=Path, default=Path("."))
    ap.add_argument("--tasks_path", type=Path, default=None)
    ap.add_argument("--task_mode", type=str, default="all", choices=["smoke4", "smoke7", "val20", "shadow_dev", "holdout30", "full129", "train99", "all"], help="Task split/selector mode")
    ap.add_argument("--model_id", type=str, default=r"..\gemma-4-e4b-it")
    ap.add_argument("--adapter_dir", type=str, default="adapters/e4b_qat_lora", help="Path to unpacked PEFT LoRA adapter dir, or 'none' for Base E4B")
    ap.add_argument("--venv_root", type=Path, default=Path(r"..\.win_venvs"))
    ap.add_argument("--out_dir", type=Path, default=Path(r"..\frontier_overnight_results"))
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--batch_size", type=int, default=1)
    ap.add_argument("--top_k_val20", type=int, default=2)
    ap.add_argument("--candidates", type=str, default="E4B_LoRA_v1_5", help="Candidate ID(s) to run (e.g. E4B_LoRA_v1_5, E4B_Base_v1_5, E4B_LoRA_v1, E4B_LoRA_v1_2149B, or 'all')")
    ap.add_argument("--evolve_hours", type=float, default=0.0, help="Hours to run continuously")
    ap.add_argument("--continuous", action="store_true", help="Run continuous triage loops")
    ap.add_argument("--factory", action="store_true", help="Run Rollout Factory mode: single persistent pass across selected tasks with disk-cache resumption")
    ap.add_argument("--smoke1", action="store_true", help="Fast 1-task sanity check on FastAPI")
    ap.add_argument("--export_f6_only", action="store_true", help="Immediately export & verify F6 Apex 31B/E4B submission zips without GPU load")
    ap.add_argument("--export_candidate", type=str, default="", help="Candidate ID to export (e.g. E4B_LoRA_v1_5, E4B_LoRA_v1, E4B_F3_v2, B5_Lean_31B)")
    ap.add_argument("--ignore_disk_cache", action="store_true", help="Ignore disk cache and re-run all tasks")
    ap.add_argument("--dry_run_test", action="store_true", help="Execute 0-GPU CPU import & configuration validation dry-run")
    args = ap.parse_args()

    args.gemma_dir = args.gemma_dir.resolve()
    args.venv_root = args.venv_root.resolve()
    args.out_dir = args.out_dir.resolve()
    if args.tasks_path:
        args.tasks_path = args.tasks_path.resolve()

    raw_adapter = str(args.adapter_dir or "").strip()
    if raw_adapter.lower() in ("", "none", "null", "false"):
        resolved_adapter_dir = None
    else:
        resolved_adapter_dir = Path(raw_adapter).resolve()

    if args.dry_run_test:
        sys.exit(run_cpu_dry_run_check(args))

    args.out_dir.mkdir(parents=True, exist_ok=True)

    if args.export_candidate:
        cand_match = next((c for c in FRONTIER_CANDIDATES if c.cid.lower() == args.export_candidate.strip().lower() or c.cid.split("_")[0].lower() == args.export_candidate.strip().lower()), None)
        if not cand_match:
            print(f"[ERROR] Candidate '{args.export_candidate}' not found! Available: {[c.cid for c in FRONTIER_CANDIDATES]}")
            return
        adir = resolved_adapter_dir if (resolved_adapter_dir and resolved_adapter_dir.exists() and "base" not in cand_match.cid.lower()) else None
        if cand_match.cid in ("E4B_LoRA_v1", "E4B_LoRA_v1_5", "E4B_LoRA_v1_2149B") or adir:
            export_adk_legal_zip(cand_match, "gemma-4-e4b-it-qat-w4a16-ct", args.out_dir / f"submission_{cand_match.cid}_E4B", args.out_dir / f"submission_{cand_match.cid}_E4B.zip", adapter_dir=adir, adapter_name="e4b_qat_lora")
        else:
            export_adk_legal_zip(cand_match, "gemma-4-31b-it-qat-w4a16-ct", args.out_dir / f"submission_{cand_match.cid}_31B", args.out_dir / f"submission_{cand_match.cid}_31B.zip")
            export_adk_legal_zip(cand_match, "gemma-4-e4b-it-qat-w4a16-ct", args.out_dir / f"submission_{cand_match.cid}_E4B", args.out_dir / f"submission_{cand_match.cid}_E4B.zip")
        return

    if args.export_f6_only:
        raise ValueError(
            "FATAL INTEGRITY VIOLATION: F6_Apex_Unified on Base E4B is permanently KILLED in Local Factory "
            "(Non-negotiable Guardrail #4). Use --export_candidate E4B_LoRA_v1_5 or E4B_LoRA_v1."
        )

    if args.candidates.strip().lower() == "all":
        active_candidates = FRONTIER_CANDIDATES
    else:
        chosen = {c.strip().lower() for c in args.candidates.split(",")}
        active_candidates = [c for c in FRONTIER_CANDIDATES if c.cid.lower() in chosen or c.cid.split("_")[0].lower() in chosen]
        if not active_candidates:
            raise ValueError(f"No matching candidate(s) for {args.candidates!r}. Available: {[c.cid for c in FRONTIER_CANDIDATES]}")

    # Integrity Guard: Permanently KILL F6_Apex_Unified on Base E4B in Local Factory & guard E4B_Base_v1_5 vs adapter_dir
    for c in active_candidates:
        if c.cid == "F6_Apex_Unified" and "e4b" in str(args.model_id).lower() and not (resolved_adapter_dir and resolved_adapter_dir.exists()):
            raise ValueError(
                "FATAL INTEGRITY VIOLATION: F6_Apex_Unified on Base E4B is permanently KILLED in Local Factory "
                "(Non-negotiable Guardrail #4). Use candidate E4B_LoRA_v1_5 (or mount LoRA adapter via --adapter_dir)."
            )
        if c.cid == "E4B_Base_v1_5" and resolved_adapter_dir is not None:
            raise ValueError(
                "Candidate E4B_Base_v1_5 evaluates Base E4B WITHOUT a LoRA adapter. "
                "Re-run with --adapter_dir none."
            )

    prevent_windows_sleep(True)
    t_start = time.time()
    max_runtime_sec = (args.evolve_hours * 3600.0) if args.evolve_hours > 0 else (86400.0 * 7 if args.continuous else 0.0)

    try:
        if torch.cuda.is_available():
            total_gb = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
            if total_gb <= 18.0:
                if args.batch_size > 1 or args.workers > 1:
                    print(f"[GPU-GUARD] 16GB GPU detected ({total_gb:.2f} GiB). Auto-capping batch_size=1, workers=1 to prevent Windows WDDM paging!", flush=True)
                args.batch_size = 1
                args.workers = 1

        print(f"\n[GPU] Initializing BatchedGemmaServer ({args.model_id}, batch_size={args.batch_size})...", flush=True)
        adapter_path = resolved_adapter_dir if (resolved_adapter_dir and resolved_adapter_dir.exists()) else None
        if "e4b" in str(args.model_id).lower() and any(c.cid in ("E4B_LoRA_v1", "E4B_LoRA_v1_5", "E4B_LoRA_v1_2149B", "E4B_F3_v2") for c in active_candidates):
            if adapter_path:
                print(f"[PEFT-MOUNT] Targeting LoRA adapter: {adapter_path}", flush=True)
            else:
                print(f"[WARN] Running E4B without LoRA adapter (base checkpoint only)!", flush=True)

        server = BatchedGemmaServer(model_id=args.model_id, max_batch_size=args.batch_size, adapter_dir=adapter_path)
        used_gb = _deep_strip_multimodal_vram(server)

        # Guarantee PEFT adapter is attached to server.engine.model
        if adapter_path and not getattr(server.engine, "_peft_mounted", False):
            from peft import PeftModel
            if not isinstance(server.engine.model, PeftModel):
                print(f"[PEFT] Mounting LoRA adapter from {adapter_path} onto stripped BF16 E4B...", flush=True)
                server.engine.model = PeftModel.from_pretrained(server.engine.model, str(adapter_path))
                server.engine.model.eval()
                server.engine._peft_mounted = True
            print(f"[PEFT] Successfully mounted adapter from {adapter_path} (< 9 GiB VRAM footprint, zero NF4)!", flush=True)

        print(f"[GPU] Ready! Active VRAM (language-only): {used_gb:.2f} GiB / 16.00 GiB", flush=True)

        if used_gb > 7.5:
            if args.batch_size > 1 or args.workers > 1 or server.max_batch_size > 1:
                print(f"[GPU-GUARD] Active VRAM is {used_gb:.2f} GiB (>7.5 GiB). Auto-capping batch_size=1, workers=1 to prevent Windows WDDM paging!", flush=True)
            server.max_batch_size = 1
            args.workers = 1
            args.batch_size = 1

        # =====================================================================
        # DEDICATED ROLLOUT FACTORY MODE (Single Pass, Persistent Cache, No Canary Loops)
        # =====================================================================
        if args.factory:
            tasks = load_tasks_robust(args.gemma_dir, args.tasks_path, mode=args.task_mode, is_factory=True)
            print(f"\n==================== [ROLLOUT FACTORY LAUNCHED] ====================", flush=True)
            print(f"  * Mode:             Dedicated Single-Pass Rollout Factory (Persistent Cache)")
            print(f"  * Task Mode:        {args.task_mode}")
            print(f"  * Candidates ({len(active_candidates)}): {[c.cid for c in active_candidates]}")
            print(f"  * Total Tasks:      {len(tasks)} tasks")
            print(f"  * Output Directory: {args.out_dir}")
            print(f"  * Model ID:         {args.model_id}")
            if adapter_path:
                print(f"  * Mounted LoRA:     {adapter_path} (< 9 GiB VRAM, zero NF4)")
            else:
                print(f"  * Mounted LoRA:     None (Base E4B)")
            print(f"====================================================================\n", flush=True)

            for target_cand in active_candidates:
                # 1. Pre-seed any valid completed traces from legacy r{round}_* folders if available
                seed_cache_from_previous_rounds(args.out_dir, target_cand.cid)

                # 2. Run single persistent evaluation with disk cache enabled
                print(f"\n>>> Executing Rollout Factory for Candidate: {target_cand.cid} ({len(tasks)} tasks) <<<", flush=True)
                summ, results = eval_frontier_candidate(
                    target_cand,
                    tasks,
                    server,
                    args.gemma_dir,
                    args.venv_root,
                    args.out_dir,
                    workers=args.workers,
                    ignore_disk_cache=args.ignore_disk_cache,
                    has_adapter=(adapter_path is not None),
                )

                # 3. Export submission zip
                adir = adapter_path if (adapter_path and "base" not in target_cand.cid.lower()) else None
                export_adk_legal_zip(target_cand, "gemma-4-e4b-it-qat-w4a16-ct", args.out_dir / f"submission_{target_cand.cid}_E4B", args.out_dir / f"submission_{target_cand.cid}_E4B.zip", adapter_dir=adir, adapter_name="e4b_qat_lora")

            # 4. Consolidate all passing trajectories into master JSONL for SFT distillation
            master_jsonl = aggregate_all_passing_trajectories(args.out_dir)

            # 5. Extract structured AggreVaTe failure prefixes (unhinted v1 rollouts failing at turns 3-6)
            splits_p = args.gemma_dir / "splits_99_30.json" if (args.gemma_dir / "splits_99_30.json").exists() else Path("splits_99_30.json")
            aggrevate_jsonl = export_aggrevate_failure_prefixes(args.out_dir, splits_path=splits_p, target_count=28)

            print(f"\n==================== [ROLLOUT FACTORY RUN FINISHED] ====================", flush=True)
            if master_jsonl:
                print(f"  * Master Passing SFT Dataset:       {master_jsonl}")
            if aggrevate_jsonl:
                print(f"  * Master AggreVaTe Failure Prefixes: {aggrevate_jsonl}")
            print(f"  * Results stored under:              {args.out_dir}")
            print(f"========================================================================\n", flush=True)
            return

        val_tasks = load_tasks_robust(args.gemma_dir, args.tasks_path, args.task_mode)
        all_pool = load_tasks_robust(args.gemma_dir, args.tasks_path, "full129")
        tmap = {t["instance_id"]: t for t in all_pool}
        canary_tasks = [tmap[tid] for tid in CANARY_8_IDS if tid in tmap]
        if len(canary_tasks) < 4:
            canary_tasks = val_tasks[:8]

        print(f"\n[TOURNAMENT INITIALIZED] {len(active_candidates)} Candidates | {len(canary_tasks)} Canary Tasks | {len(val_tasks)} Stage-2 Tasks ({args.task_mode})", flush=True)
        for c in active_candidates:
            print(f"  * {c.cid:22s} | temp={c.temp} | tb={c.thinking_budget:4d} | max_steps={c.max_steps} | {c.note}")

        if args.smoke1:
            cand_smoke = active_candidates[0] if active_candidates else FRONTIER_CANDIDATES[0]
            print(f"\n[SMOKE1] Running 1 canary task on candidate: {cand_smoke.cid} ({canary_tasks[0]['instance_id']})...", flush=True)
            summ, _ = eval_frontier_candidate(cand_smoke, canary_tasks[:1], server, args.gemma_dir, args.venv_root, args.out_dir / "smoke1_v2", workers=1, ignore_disk_cache=True, has_adapter=(adapter_path is not None))
            export_adk_legal_zip(cand_smoke, "gemma-4-31b-it-qat-w4a16-ct", args.out_dir / f"submission_{cand_smoke.cid}_31B", args.out_dir / f"submission_{cand_smoke.cid}_31B.zip")
            export_adk_legal_zip(cand_smoke, "gemma-4-e4b-it-qat-w4a16-ct", args.out_dir / f"submission_{cand_smoke.cid}_E4B", args.out_dir / f"submission_{cand_smoke.cid}_E4B.zip", adapter_dir=adapter_path)
            aggregate_all_passing_trajectories(args.out_dir)
            print("\n[SMOKE1 COMPLETE] Verify steps > 0 and non-empty patch:", summ)
            return

        round_num = 1
        while True:
            print(f"\n==================== STARTING TRIAGE ROUND {round_num} ====================", flush=True)
            board, caches = [], {}

            for cfg in active_candidates:
                summ, cache = eval_frontier_candidate(cfg, canary_tasks, server, args.gemma_dir, args.venv_root, args.out_dir / f"r{round_num}_canary8", args.workers)
                board.append((summ["resolved_count"], summ["non_empty_patches"], summ["scr_pct"], -summ["edit_fail_total"], cfg, summ))
                caches[cfg.cid] = cache

            board.sort(key=lambda x: (x[0], x[1], x[2], x[3]), reverse=True)
            update_markdown_leaderboard(args.out_dir, board)

            # Promotion Gate: Prioritize actual resolved solves first, then non-empty patches (never drop solves on SCR!)
            viable = [x for x in board if x[0] > 0]
            if len(viable) < max(1, args.top_k_val20):
                seen_ids = {x[4].cid for x in viable}
                viable += [x for x in board if x[1] > 0 and x[4].cid not in seen_ids]
            if not viable:
                print("[ABORT STAGE 2] Zero non-empty patches across all Stage 1 candidates! Stopping to prevent wasted GPU hours.", flush=True)
                break

            finalists = [x[4] for x in viable[: max(1, args.top_k_val20)]]
            print(f"\n[STAGE 1 PROMOTIONS -> ADVANCING TO VAL_20 ({len(val_tasks)} tasks)]:", [f.cid for f in finalists], flush=True)

            val_board = []
            for cfg in finalists:
                summ, _ = eval_frontier_candidate(cfg, val_tasks, server, args.gemma_dir, args.venv_root, args.out_dir / f"r{round_num}_val20", args.workers, cached=caches.get(cfg.cid))
                val_board.append((summ["resolved_count"], summ["non_empty_patches"], summ["scr_pct"], -summ["edit_fail_total"], cfg, summ))

            val_board.sort(key=lambda x: (x[0], x[1], x[2], x[3]), reverse=True)
            champ = val_board[0][4]
            update_markdown_leaderboard(args.out_dir, board, val_board)

            print(f"\n==================== [ROUND {round_num} CHAMPION LOCKED] ====================", flush=True)
            print(f"Champion: {champ.cid} ({val_board[0][5]['resolved_pct']}% Solved on VAL_20 | SCR={val_board[0][5]['scr_pct']}%)", flush=True)

            export_adk_legal_zip(champ, "gemma-4-31b-it-qat-w4a16-ct", args.out_dir / "champion_31B_dir", args.out_dir / "submission_31B_MainTrack.zip")
            export_adk_legal_zip(champ, "gemma-4-e4b-it-qat-w4a16-ct", args.out_dir / "champion_E4B_dir", args.out_dir / "submission_E4B_SmallBonus.zip")

            report = {
                "round": round_num,
                "completed_at": dt.datetime.now().isoformat(timespec="seconds"),
                "champion": champ.cid,
                "val20_leaderboard": [x[5] for x in val_board],
                "canary8_leaderboard": [x[5] for x in board],
            }
            (args.out_dir / "frontier_leaderboard.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
            aggregate_all_passing_trajectories(args.out_dir)

            if not args.continuous and args.evolve_hours <= 0:
                break
            if max_runtime_sec > 0 and (time.time() - t_start) >= max_runtime_sec:
                print(f"[EVOLVE CEILING REACHED] Elapsed: {(time.time() - t_start)/3600.0:.2f}h >= {args.evolve_hours}h. Ending tournament.")
                break

            round_num += 1
            print(f"\n[CONTINUOUS MODE ACTIVE] Pausing 10s before Round {round_num}...", flush=True)
            time.sleep(10)

    finally:
        prevent_windows_sleep(False)


if __name__ == "__main__":
    main()
