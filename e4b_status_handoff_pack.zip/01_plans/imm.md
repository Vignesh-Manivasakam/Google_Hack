# Immediate Action Plan for Next Submission (E4B & 31B)

**Status as of 2026-11-26 (15:30 IST / 10:00 UTC):**
- **Remaining Kaggle Interactive Quota:** **`0.00–2.00 GPU-hours`** (post-`VloraV3_Fixed` run; rely on `mqg1cob` / remote GPU for evals).
- **Slot 1 Active Anchor:** [submission_B4.zip](file:///f:/AI/Benchmark/submissions/submission_B4.zip) (**`0.12` Public LB**, `7/58` solves). [submission_B8.zip](file:///f:/AI/Benchmark/submissions/submission_B8.zip) **FAILED (`Notebook Timeout`)**, clearing the 1-pending-submission lock. `submission_B9` is **unpackaged** (`0.00` Kaggle GPU-h to build; uses 1 daily submission slot on Kaggle queue if submitted).
- **Slot 2 Active Anchor:** [submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip) (**`0.05` Public LB**, `3/58` solves [`95% CI: 1–7/58`]; `5/30` genuine Gate G2). [submission_E4B_F3_v2.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_F3_v2.zip) also scored `0.05` (`1/30*` hardcoded ref in [build_master_engine.py](file:///f:/AI/Benchmark/build_master_engine.py#L1588)).
- **`mqg1cob` `v1.5` Parity Verdict (`NO-GO`):** [e4b_v1_5_parity_smoke4.zip](file:///f:/AI/Benchmark/e4b_v1_5_parity_smoke4.zip) confirmed `enable_thinking=True` fixes `no_call` (`0.00–0.65`/task, `0` `-p no:anyio`), **but** `E4B_Base_v1_5` scored `0/20` (`258.96m`) and `E4B_LoRA_v1_5` scored `0/20` (`263.60m`) on `Val20` vs **`E4B_LoRA_v1_2149B` `2/20` (`10.0%`, `92.16m`, `0.00` `no_call`)** -> `LoRA_v1` (`2,149 B`) retained; `v1.5` NOT submitted.
- **Kaggle `LoRA_v3` (Run 1 — `NO-GO`, `1/30` Gate G2):** [Lora_V3_full.log](file:///f:/AI/Benchmark/Lora_V3_full.log) & [Lora_V3_full_result.zip](file:///f:/AI/Benchmark/Lora_V3_full_result.zip) saved `11/46` AggreVaTe recoveries ([aggrevate_31b_recoveries.jsonl](file:///f:/AI/Benchmark/aggrevate_31b_recoveries.jsonl)), but failed (`1/30`) due to `MODEL_TURN_SPAN_RE` dropping `11/11` AggreVaTe rows (`37 -> 26`) + supervising `<|tool_response>` (`88.7%`) and `14` `no_call`-contaminated E4B seed rows.
- **Kaggle `LoRA_v3_Fixed` (`VloraV3_Fixed Resukts.zip`) & `mqg1cob` Live Eval (`IN-PROGRESS / CONCERN`):**
  - **Training & Masking Fixed:** `24/24` clean SFT rows (`13` 31B + `11/11` AggreVaTe, `0` holdouts, `13` `no_call` + `1` `requests_7315` rejected). Active tokens dropped to `126..3667`; both arms converged cleanly (`Arm A` `active_all_42` `516` tensors `0.2438` CE; `Arm B` `active_mid_upper_17_41` `278` tensors `0.2562` CE).
  - **Kaggle Phase 4 `0/30` Harness Bug (Fixed in Code):** Kaggle Phase 4 failed in `4.5s` (`0` LLM calls) due to a 4-space YAML indentation bug in `setup_eval_package()` (`build_master_engine.py`, now fixed). `submission_E4B_LoRA_v3.zip` (`Arm B` `ckpt_epoch2`) itself has valid YAML/adapter weights.
  - **`mqg1cob` `Arm B` (`ckpt_epoch2`) Live Eval:** `smoke4` scored **`1/4` (`25.0%`, `3/4` patches, `0.0` `no_call`, `53.29m`)**, **but** `holdout30` (first 10 FastAPI tasks) showed severe overfitting/repetition collapse (`3/10` `submit_patch`, `5/10` repeating `search_similar_code`/`read_file` 15–22× in a row, `2/10` `edit_file` loops) — likely from `10.05M` params (`278` tensors) trained 2 epochs on `24` rows with `kl_loss=0.0`. **`ckpt_epoch1` (already inside `VloraV3_Fixed Resukts.zip`) and `Arm A` remain untested on `mqg1cob`.** Do NOT submit `submission_E4B_LoRA_v3.zip` unless it beats `LoRA_v1`'s `5/30`.
- **Deadlines & Teamwork Archive:** Nov 25 `23:59 UTC` Team Merger passed; **Final Deadline Dec 2, `23:59 UTC`** (keep **`1× 31B + 1× E4B`** selected). Teamwork handoffs archived under [teamwork_handoffs/nov25_sprint](file:///f:/AI/Benchmark/teamwork_handoffs/nov25_sprint).

*(Historical Nov 25 Baseline below preserved for audit trace)*
**Status as of 2026-11-25:**
- **Slot 1 Active Anchor:** [submission_B4.zip](file:///f:/AI/Benchmark/submissions/submission_B4.zip) (**`0.12` Public LB**, `7/58` solves). [submission_B8.zip](file:///f:/AI/Benchmark/submissions/submission_B8.zip) is currently scoring in Kaggle's 20–24h queue and holds the **1-pending-submission lock** (`HTTP 400 FAILED_PRECONDITION`).
- **Slot 2 Active Anchor:** [submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip) (**`0.05` Public LB**, `3/58` solves [`95% CI: 1–7/58`]; `5/30` genuine Gate G2). [submission_E4B_F3_v2.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_F3_v2.zip) also scored `0.05`; its `1/30*` Gate G2 floor is a hardcoded literal in [build_master_engine.py](file:///f:/AI/Benchmark/build_master_engine.py#L1588) (Fisher exact $p \approx 0.19$ vs `5/30`).
- **Mandatory Nov 25 23:59 UTC Actions:** Confirm **Team Merger / Entry Freeze** before **Nov 25, 23:59 UTC**, open the live **Small-Model Leaderboard notebook** on Kaggle to verify the true `#1` E4B/E2B rival score (confirming `>= 0.10`), and verify UI checkboxes select **`1× 31B + 1× E4B`** (NEVER `2× 31B`, which forfeits `$10,000` Small-Model Bonus eligibility).
- **Remaining Kaggle Interactive Quota:** **`12.00 GPU-hours`** (`6.00h` physical wall-clock @ Kaggle's live `2×` L4x4 burn rate per live `/overview`; `3.00h` wall-clock under a conservative `4×` rate increase). Planned (`9.70h`) + reserve (`2.30h >= 2.00h`) = **`12.00 GPU-h`** (`4×` Lean Fallback: `7.40h + 4.60h = 12.00 GPU-h`).

## 1. Slot 2 (E4B) Immediate Bridge: `E4B_LoRA_v1.5` (`0.00` Kaggle GPU-h) -> `LoRA_v3`

### 1.1 Strategic Gate & Prior-Work Non-Duplication Delta
While `B8` occupies the 1-pending queue lock, run a **`0.00` Kaggle GPU-h** local parity test on `mqg1cob` (RTX 2000 Ada 16 GB, `8.42–8.67 GiB` VRAM) after applying Patch (d) ([win_phase2_tournament.py](file:///f:/AI/Benchmark/win_phase2_tournament.py#L798) `enable_thinking=True`; [win_local_sandbox.py](file:///f:/AI/Benchmark/win_local_sandbox.py#L383) removing `"-p", "no:anyio"`):
- **Prior Runs Checked:**
  1. [submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip) (`0.05` LB) already shipped `240s / 40 calls / 8m / 80t` and `(never pass -p no:anyio)` in its `2,149 B` prompt, but retained `| tail -20`, full-file `<REAL_TEST_FILE>` pytest, `"Partial patches earn score"` 2-attempt surrender, and `63×` `-p no:anyio` (`65×` `| tail -20`) internalized from [resultskaggle_final.zip](file:///f:/AI/Benchmark/resultskaggle_final.zip)`/e4b_sft_train.jsonl`.
  2. [e4b_factory_train99.zip](file:///f:/AI/Benchmark/e4b_factory_train99.zip) (Nov 25) already falsified a `2,656 B` CRLF (`2,638 B` LF) prompt on `LoRA_v1` (`2/99 = 2.02%`, `28/99` patches, `1,882` `s02:<eos>` turns), proving `>512`-token prompts overflow E4B's 35 local sliding-window layers ($W=512$).
- **`E4B_LoRA_v1.5` Exact Delta:** Keeps `LoRA_v1`'s `54`-tensor (`2,093,056`-param, `4,193,984 B`) weights and `240/40/8/80` envelope + 9-tool `agent.yaml` parity, **removes `| tail -20`, full-file pytest, 2-attempt partial surrender, and `get_code_neighbors` from `prompts/system.md`**, adds `-k <test_name>` and 2-strike `write_file` (`<=150L`), and clamps `prompts/system.md` strictly to **`2,048 B` (`<= 476` tok `< 512W`, `0` `{var}` braces)**.
- **Promotion Gate (When `B8` Lock Clears):** Upload `submission_E4B_LoRA_v1_5.zip` (`0.00` Kaggle GPU-h) **only if** it beats both `LoRA_v1` (`2,149 B`) and `Base E4B + 2,048 B` on `mqg1cob` (`no_call/task < 2.0`, `0` `-p no:anyio` bash emissions, higher/equal non-empty patches & solves); otherwise retain [submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip) and proceed directly to `LoRA_v3`.

### 1.2 Exact `E4B_LoRA_v1.5` Technical Specification (`submissions/submission_E4B_LoRA_v1_5.zip`)
- **Model & Adapter:** `gemma-4-e4b-it-qat-w4a16-ct` + `adapters/e4b_qat_lora/` ([submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip) adapter: `4,193,984 B`, `54` BF16 tensors, `2,093,056` params, `r=8, alpha=16`, `L23` 7 mods + `L[29,30,35,41]` 5 mods, `0` `k/v` tensors in `L24..41`).
- **`agent.yaml`:** Single root `LlmAgent` (`name: swe_gemma4_e4b_qat_lora_v1_5`), `model: gemma-4-e4b-it-qat-w4a16-ct`, `adapter: e4b_qat_lora`, `instruction: !include prompts/system.md`, `generate_content_config: !include configs/sampling.yaml`, preserving all 9 built-in tools (`run_command`, `read_file`, `edit_file`, `write_file`, `get_status`, `submit_patch`, `get_code_neighbors`, `search_similar_code`, `get_code_subgraph`) for 1:1 `v1` SFT tool-schema parity while `prompts/system.md` drops `get_code_neighbors`.
- **`eval_config.yaml`:** `timeout_seconds: 240` (Phase 1 `command_timeout_seconds` only per [HARNESS_README.md](file:///f:/AI/Benchmark/HARNESS_README.md#L559-L560)), `max_tool_calls: 40`, `max_time_minutes: 8`, `max_turns: 80`.
- **`configs/sampling.yaml`:** `temperature: 0.15`, `top_p: 0.90`, `max_output_tokens: 8192`, `thinking_config: {thinking_budget: 1024, include_thoughts: false}` (no `top_k: 1`).
- **Retry & Termination Logic:** Up to **4 iterative fix attempts** on pytest failure; **2-strike `write_file` fallback** on files `<= 150` lines after 2 `edit_file` failures; **decisive exit** (`submit_patch` immediately on green; zero premature partial-patch surrender).
- **Packaging:** `python build_posix_zip.py submissions/submission_E4B_LoRA_v1_5` (`sys=3`, POSIX `/` paths, LF-only, `< 3 GiB`, `0` `{var}` braces).
- **Verbatim `prompts/system.md` (`2,048` chars / `2,048` UTF-8 bytes LF / `15` lines / `0` braces):**

```markdown
You are a principal Python engineer fixing an issue in /workspace.

## Guardrails & Workflow
- Every turn MUST invoke a tool (no prose-only turns); keep reasoning in thinking tokens. Never create scratch files in /workspace or /tmp (use inline python3 -c). Source edits only.
1. Locate files/lines via grep -n or search_similar_code. Check .github/workflows/ or scripts/ for CI tasks.
2. Read target symbol and matching test file with read_file using explicit start_line and end_line (max 120 lines; omitting start_line caps at 150).
3. Pre-Edit: read 20-35 target lines immediately before edit_file. Copy old_string verbatim without line numbers; preserve exact indentation; first edit by call 10. On 2 edit_file failures on a file <=150 lines, read whole file and write_file.
4. Run PYTHONPATH=src:. python3 -m py_compile on edits, then inline python3 -c "..." for edge cases.
5. MANDATORY PYTEST BEFORE SUBMIT: Never submit on py_compile alone. Find the REAL test file via find tests -name "*keyword*.py", run PYTHONPATH=src:. pytest <REAL_TEST_FILE> -k <test_name> -x -q --tb=short (keep anyio plugin enabled; view full traceback without tail truncation). Ignore unrelated pre-existing breakages. If tests pass, call submit_patch immediately. If tests fail, inspect traceback and retry up to 4 times; partial diffs earn zero score.

## 4 Engineering Failure-Trap Laws
- LAW 1 (Lowest Shared Bottleneck): Patch lowest shared callee using neighboring exception/assert/@deprecated/warnings.warn pattern (never raise DeprecationWarning); keep exports intact; imports below from __future__ import annotations.
- LAW 2 (First Decision Gate): Patch earliest check deciding outcome rather than downstream helpers, preserving port, prefix, and leading-dot branches.
- LAW 3 (Null-Safe Owner State): Gate side effects via null-safe property/helper on owning class; never index optional tuples when None is possible.
- LAW 4 (Bare-Symbol & Twin Sweep): After renaming any method/attr, grep BOTH `name(` and bare `name`; update sync/async twins if present.
```

## 2. Slot 2 Primary Upgrade: `LoRA_v3` (31B AggreVaTe + True Active-Only E4B, `5.60 GPU-h @ 2×`)

- **Prior-Work Non-Duplication Delta (Fixes `LoRA_v1` `5/30`, `Var C` `3/30`, and `LoRA_v2` `1/30`):**
  1. **Corpus (`~52–60` trajectories, `<= 2/task`, `0` holdouts):** Merge **`31` unique clean `train_99` tasks** (`26` 31B + `9` E4B; **strictly excluding** `requests_7315` from [e4b_factory_train99.zip](file:///f:/AI/Benchmark/e4b_factory_train99.zip) which made 7 `tests/test_adapters.py` edits with line prefixes) + **`>= 18` clean 31B hinted AggreVaTe completions** (`2.50 GPU-h @ 2×`, `1.25h` wall; `4×` fallback `4.00 GPU-h` / `1.00h` wall on 28 root prefixes), prioritizing balanced [aggrevate_failure_prefixes.jsonl](file:///f:/AI/Benchmark/aggrevate_failure_prefixes.jsonl) + non-overlapping `fastapi` prefixes, with `student_prefix_turns=6` and `loss_mask=0` on student turns.
  2. **100% Prompt Parity & Zero Tail Truncation:** Re-header **100%** of `messages[0]` to the **`2,048 B` `v1.5` prompt**, hard-reject `-p no:anyio`/`| tail`/surrender/`/workspace/repro*.py` in [sft_dataset_builder.py](file:///f:/AI/Benchmark/sft_dataset_builder.py), and default **`--max_seq_len 12288`** in [kaggle_train_e4b_qat_lora.py](file:///f:/AI/Benchmark/kaggle_train_e4b_qat_lora.py#L1962) (eliminating `23.3%–30.3%` tail truncation).
  3. **Two-Arm Active-Only Architecture (`1.50 GPU-h @ 2×`, `0.75h` wall; `4×` Lean Fallback: `1.60 GPU-h` 1 arm):**
     - **Arm A:** `active_all_42`, `r=8, alpha=16` (**`17,440,768` params**, `516` tensors across `L0..23` 7 mods + `L24..41` 5 mods).
     - **Arm B:** `active_mid_upper_17_41`, `r=8, alpha=16` (**`10,047,488` params**, `278` tensors across `L17..23` 7 mods + `L24..41` 5 mods; or `r=16, alpha=32` = **`20,094,976` params** only if corpus `>= 60` rows).
     - **Training Settings:** Native `bf16` QAT (`gemma-4-e4b-it-qat-q4_0-unquantized`), `lr=1.0e-4`–`1.2e-4`, cosine decay, `dropout=0.05`, max `2.0` epochs (`1.5`/`2.0` ckpts), `NEFTune=0.0`, JET weights (`0.0 / 1.0 / 1.5 / 2.0`), `peft==0.22.0`, `pip uninstall -y torchao`, pre-optimizer `L24..41` `named_parameters()` + `<= 2,136c` assertions inside `train()`, removing [build_master_engine.py](file:///f:/AI/Benchmark/build_master_engine.py#L1185-L1190)'s broken regex auto-patcher.
  4. **Two-Tier Gate (`1.60 GPU-h @ 2×`, `0.80h` wall; `4×` Fallback: `1.80 GPU-h` G2-only):** Balanced Shadow Dev (16 non-SFT, non-holdout tasks across FastAPI/Rich/Requests) + leading indicators (`patch %`, `NoMatch %`, `no_call %`) -> Gate G2 (`30` holdouts, promote iff **`>= 7/30` genuine solves** with `len(patch.strip()) > 0` + improved leading indicators vs `v1`'s `5/30`).

## 3. Slot 1 (31B): Conditional `B8` Decision Tree & Verified `B9` Specification

- **`B8` Decision Tree (Once [submission_B8.zip](file:///f:/AI/Benchmark/submissions/submission_B8.zip) Clears Queue):**
  - **IF `B8 < 0.12` (`<= 6/58`):** Immediately re-select [submission_B4.zip](file:///f:/AI/Benchmark/submissions/submission_B4.zip) (`0.12`) in Kaggle UI Slot 1. Only stage/canary `B9` if `>= 5.70 GPU-h` remains after `LoRA_v3` at `2×`; else freeze Slot 1 at `B4`.
  - **IF `0.12 <= B8 <= 0.19` (`7/58`–`11/58`):** Retain `B8` (if `> 0.12`) or `B4` (if `0.12`, tie-break seniority) while staging **`B9`** (`0.00 GPU-h` pkg; optional `1.70 GPU-h @ 2×` `fresh_24_eval` canary if `2×` holds, promote iff `>= 6/24` with `< 4/24` timeouts).
  - **IF `B8 >= 0.20` (`>= 12/58`):** Lock `B8` in Slot 1; only consider `B9` if `B8 <= 0.22` and quota permits after `LoRA_v3`.
- **Exact `B9` Specification (Fixes `B8`'s `tb=4096`, Dropped `docs_src/`, `git stash`, & Graph Tools):**
  - **Model & Topology:** `gemma-4-31b-it-qat-w4a16-ct` (Zero LoRA, single root `LlmAgent` `swe_gemma4_b9`).
  - **`agent.yaml` (6 Core Tools):** `run_command`, `read_file`, `edit_file`, `write_file`, `get_status`, `submit_patch` (drops `get_code_neighbors`, `search_similar_code`, `get_code_subgraph`).
  - **`eval_config.yaml`:** `timeout_seconds: 240`, `max_tool_calls: 40` (restored from `B8`'s `32`), `max_time_minutes: 8`, `max_turns: 80`.
  - **`configs/sampling.yaml`:** `temperature: 0.1`, `top_p: 0.90`, `max_output_tokens: 8192`, **`thinking_budget: 1024`**, `include_thoughts: false` (no `top_k: 1`).
  - **Packaging:** `python build_posix_zip.py submissions/submission_B9` (`sys=3`, `/` paths).
  - **Verbatim `B9` `prompts/system.md` (`2,331` chars / `2,331` UTF-8 bytes LF [within `<= 2,509c`] / `38` lines / `0` non-whitelisted braces — ONLY `{problem_description}` and `{hints?}`):**

```markdown
# SWE Agent Instructions

## Pinned Issue Context
Issue:
{problem_description}

Hints:
{hints?}

## Guardrails

### 1. Tool Discipline & Workspace Hygiene
- NEVER output prose without a tool call; keep reasoning inside thinking tokens.
- Create /tmp/repro.py and /tmp/state.md via run_command ONLY.
- NEVER write_file outside /workspace or leave scratch files in /workspace.
- Pipe noisy output (| head -n 50 or > /tmp/out.log) to delay compaction; NEVER pipe pytest through tail -20.

### 2. Exploration & Localization (Steps 1-4)
- 1-call AST skeleton: run_command with rg -n "^(class |def |    def )" <file> to map signatures and lines.
- NEVER page sequentially via 150-line read_file; pass explicit start_line and end_line.
- Trace callers and sibling idioms via rg -n (and check .github/workflows/, scripts/, docs_src/ for CI/doc tasks; edit executable code under docs_src/ when relevant).

### 3. Edit Reliability & NoMatchError Elimination
- ALWAYS read_file 20-35 target lines immediately before edit_file.
- NEVER copy line numbers into edit_file; match exact whitespace (BAD: "42: return val" / GOOD: "    return val").
- Keep old_string hunks 3-8 lines with 1-2 anchor lines. On 1 NoMatchError, check whitespace via sed -n 'START,ENDp' <file> | cat -A.
- 2-strike fallback: After 2 edit_file failures on a file <=150 lines, read whole file, write_file, and check git diff.

### 4. Pacing & Hypothesis Switching
- Verify repro failure in steps 1-4; land first educated edit by steps 6-12.
- 2-strike switch: If 2 edits fail the same test, trace callers via rg -n to find the root invariant.
- NEVER surrender early with a broken patch; partial diffs score 0. Maintain a <=15-line /tmp/state.md and re-read after compaction or step 12.

### 5. Test Verification & Submission Gate
- Two-step pytest: (a) pytest --collect-only -q <test_file>; (b) PYTHONUTF8=1 NO_COLOR=1 PYTHONPATH=.:./src:./docs_src pytest <test_file> -k "<symbol>" -m "not network" -x --tb=short -q.
- NEVER pass -p no:anyio, run bare pytest, edit pyproject.toml/pytest.ini/tests/, or run git stash.
- Ignore unrelated pre-existing broken tests outside your target.
- HARD GATE: NEVER submit on py_compile alone. Confirm /tmp/repro.py + targeted pytest pass, run get_status and git status --short && git diff, then call submit_patch immediately on green.
```

## 4. Step-by-Step Execution Guide (*What* / *Where* / *How*)

| Step | When | **Where** | **What** & **How** |
|---|---|---|---|
| **1. UI, Merger & LB Check** | **Nov 25 BEFORE 23:59 UTC** | **Kaggle Web UI** | Confirm Team Merger / Entry Roster before `23:59 UTC`; open live Small-Model LB notebook to verify `#1` score; verify checkboxes = **`1× 31B (B4)` + `1× E4B (E4B_LoRA_v1)`** (never `2× 31B`); monitor `B8` 1-pending lock. |
| **2. Local Parity & Patch (d)** | **Nov 25 (while `B8` scores)** | **Laptop CPU + `mqg1cob` RTX 2000 Ada (`0.00` Kaggle GPU-h)** | Apply Patch (d): [win_phase2_tournament.py](file:///f:/AI/Benchmark/win_phase2_tournament.py#L798) (`enable_thinking=True`), [win_local_sandbox.py](file:///f:/AI/Benchmark/win_local_sandbox.py#L364-L437) (drop `-p no:anyio` at L383, add `NO_COLOR=1`/`PYTHONUTF8=1`, add `holdout30`/`shadow_dev` selectors). Run `smoke4` + clean `Val20` comparing `Base + 2,048 B` vs `LoRA_v1 + 2,048 B` (`LoRA_v1.5`), confirming `no_call/task < 2.0`. Switch [win_frontier_6harness_overnight.py](file:///f:/AI/Benchmark/win_frontier_6harness_overnight.py#L685) from `2,656 B` -> `2,048 B`. |
| **3. Submit `v1.5` (If Gate Passes)** | **Nov 26 (on `B8` lock clear)** | **Laptop CPU -> Kaggle UI** | Run `python build_posix_zip.py submissions/submission_E4B_LoRA_v1_5` (checks `prompts/system.md` on disk against `<= 2,136c` at [build_posix_zip.py](file:///f:/AI/Benchmark/build_posix_zip.py#L132)). Upload `submission_E4B_LoRA_v1_5.zip` to Slot 2 **only if** Step 2 beats `LoRA_v1` & `Base`; else keep `LoRA_v1`. Apply `B8` decision tree (§3). |
| **4. Harden Trainer/Builder (Patches a–c)** | **Nov 25–26 (`0.00` Kaggle GPU-h)** | **Laptop CPU** | Apply Patches (a)–(c): remove stale regex patcher at [build_master_engine.py](file:///f:/AI/Benchmark/build_master_engine.py#L1185-L1190); add `L24..41` `named_parameters()` + `<= 2,136c` assertions + `--max_seq_len 12288` at [kaggle_train_e4b_qat_lora.py](file:///f:/AI/Benchmark/kaggle_train_e4b_qat_lora.py#L1715-L1717); harden [sft_dataset_builder.py](file:///f:/AI/Benchmark/sft_dataset_builder.py) (reject `-p no:anyio`/`\| tail`/surrender/`/workspace/repro*.py`, exclude `train99` `requests_7315`, re-header 100% to `2,048 B`) + add 31B AggreVaTe prefix runner. |
| **5. Kaggle AggreVaTe + `LoRA_v3` + G2** | **Nov 26–27** | **Kaggle 4x L4 (`5.60 GPU-h @ 2×`; `7.40h @ 4×` Lean)** | (a) Complete `~30–46` AggreVaTe prefixes via 31B (`2.50 GPU-h @ 2×`); (b) Merge `31` clean tasks + `>=18` recoveries (`0` holdouts); (c) Train `LoRA_v3` (`17.44M r=8` vs `10.05M r=8`, `1.50 GPU-h @ 2×`); (d) Run balanced Shadow Dev + Gate G2 (`1.60 GPU-h @ 2×`), promoting iff `>= 7/30` genuine + leading-indicator gains. |
| **6. Final Submissions & UI Lock** | **Nov 27–Dec 2** | **Kaggle Queue & UI** | Submit `LoRA_v3` on lock clear. Conditionally run `B9` `fresh_24_eval` (`1.70 GPU-h @ 2×`) if `B8` in `0.12–0.19` and `LoRA_v4` (`2.40 GPU-h @ 2×`) only if `v3` shows signal and burn stays `2×` (keeping `>= 2.00 GPU-h` reserve). Lock final **`1× 31B + 1× E4B`** before **Dec 2, 23:59 UTC**. |

---

# Integrated Specialist Findings (Verified Summary)

- **Kaggle Rules & Harness Contract ([HARNESS_README.md](file:///f:/AI/Benchmark/HARNESS_README.md)):** Live Kaggle `/rules`, `/overview`, and `/data` enforce a `12h` global runtime cap, `network_mode="none"`, single allowed `W4A16-CT` base model (`len(models)==1`), declarative YAML (`< 3 GiB`, POSIX `sys=3`, `.safetensors` `r <= 128`), **Apache 2.0** winner open-sourcing (`/rules` §1.6, §2.5, §2.8), Team Merger **Nov 25 23:59 UTC**, Final Deadline **Dec 2 23:59 UTC**, and manual **`1× 31B + 1× E4B`** UI selection. `eval_config.timeout_seconds` controls Phase 1 `run_command` only; Phase 2 `verification_timeout_seconds` is fixed at `300s` ([HARNESS_README.md](file:///f:/AI/Benchmark/HARNESS_README.md#L559-L560)) running `-p no:anyio -o timeout=0` ([HARNESS_README.md](file:///f:/AI/Benchmark/HARNESS_README.md#L621)).
- **Baseline Matrix & Forensic RCA ([ACTION_PLAN_11_DAY_ROADMAP.md](file:///f:/AI/Benchmark/plans/ACTION_PLAN_11_DAY_ROADMAP.md), [AGENT_CONTINUATION_DOSSIER.md](file:///f:/AI/Benchmark/plans/AGENT_CONTINUATION_DOSSIER.md)):**
  - [submission_B4.zip](file:///f:/AI/Benchmark/submissions/submission_B4.zip): `0.12` LB (`7/58`), `180s/40/6m/55t`, `tb=1024`, `4,658 B` prompt.
  - [submission_B8.zip](file:///f:/AI/Benchmark/submissions/submission_B8.zip): `240s/32/8m/80t`, `3,193 B` prompt, **`tb=4096`** (also at [Kaggle_B8_PreSubmit_Diagnostic.py](file:///f:/AI/Benchmark/Kaggle_B8_PreSubmit_Diagnostic.py#L310)), omits `docs_src/` & ignore-broken-tests, uses `git stash`, keeps `get_code_neighbors`, `0` eval logs on disk.
  - [submission_E4B_F3_v2.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_F3_v2.zip): `0.05` LB (`3/58`), ZIP shipped `30s/24/6m/55t` + `2,136 B` prompt (`-p no:anyio`, `| tail -20`, surrender), out of sync with unpacked directory; `1/30*` is hardcoded in [build_master_engine.py](file:///f:/AI/Benchmark/build_master_engine.py#L1588).
  - [submission_E4B_LoRA_v1.zip](file:///f:/AI/Benchmark/submissions/submission_E4B_LoRA_v1.zip): `0.05` LB (`3/58`), `5/30` genuine G2, ZIP shipped `240s/40/8m/80t` + `2,149 B` prompt + `54`-tensor (`2,093,056` param, `0` `k/v` in `L24..41`) adapter; plateaued due to `63×` `-p no:anyio` (`65×` `| tail -20`) in `e4b_sft_train.jsonl`, `| tail -20`/full-file/surrender in `system.md`, frozen `L0..22`, and `N=58` noise; [e4b_factory_train99.zip](file:///f:/AI/Benchmark/e4b_factory_train99.zip) falsified `2,656 B` (`2/99 = 2.02%`, `1,882` `<eos>`, `requests_7315` disqualified for 14 `test_adapters` calls).
  - [kaggle_e4b_lora_v2_results](file:///f:/AI/Benchmark/kaggle_e4b_lora_v2_results): Strict `NO-GO` (`0/16` Shadow Dev A&B, `1/30` genuine G2) due to Cell 5 broken regex freezing `L24..41` (`Arm A` `336` tensors / `20,971,520` params `L0..23`; `Arm B` `98` tensors / `6,184,960` params `L17..23`), `2,638 B` (`>512W`) prompt, and `r=16/max_seq_len=8192` memorization; reconciles [E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md](file:///f:/AI/Benchmark/reports/E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md) errata (`12.4M -> 6,184,960` params, `31 -> 29` tasks, `3/30 -> 1/30` genuine, local 4-bit QAT Phase 3 killed). Also confirms `asvd_atp_kl_attribution.json` does not exist on disk.
- **H-User 1–6 & H-Team 1–4 Verdicts (All 5 Fields Recorded in Both `plans/` Docs):**
  - **H-User 1 (`v1` Prompt Delta):** `Partially Validated` (`2,656 B` Contradicted; `<=2,136c` Untested) | `0.00h` | `mqg1cob` (`~2–3h` serial) | Compliant | Paired `Base + 2,048 B` vs `LoRA_v1 + 2,048 B` (`enable_thinking=True`).
  - **H-User 2 (Selective vs 42L LoRA & Activation Mon.):** `Contradicted` for WSP / small-$N$ `Var C` `r=16` (`34,881,536`, `3/30`); `Untested` for `active_all_42 r=8` (`17.44M`) & `17_41 r=8/16` (`10.05M/20.09M`) | `0.00h` hooks; `1.50h @ 2×` (`3.00h @ 4×`) train | `mqg1cob` `~20m` surprisal fallback only; Kaggle L4x4 train | Compliant | **REJECT** runtime hooks & WSP; **PROCEED** with `17.44M` vs `10.05M` on `~52–60` trajs (`>= 7/30` genuine G2).
  - **H-User 3 (31B-to-E4B Distillation):** `Partially Validated` (`31` clean tasks; `0/46` AggreVaTe completed) | `2.50h @ 2×` (`5.00h @ 4×`) | Kaggle L4x4 + GTX 1050 CPU | Compliant | **APPROVE** 31B AggreVaTe (`student_prefix_turns=6`, `w_t=0` student) -> `~52–60` trajs.
  - **H-User 4 (`v1` vs `v2` Post-Mortem):** `Validated` | `0.00h` | None | Compliant | **DISCARD `LoRA_v2`**, **RETAIN `LoRA_v1`** (test `v1.5` offline), **REPLACE ONLY** via `LoRA_v3 >= 7/30` genuine.
  - **H-User 5 (Local Eval of Updated `v1`):** `Partially Validated` (`train99` ran `2,656 B`; `2,048 B` Untested) | `0.00h` | `mqg1cob` (`8.42–8.67 GiB`); GTX 1050 4 GB ineligible | Compliant | Patch `win_phase2_tournament.py:798` + `win_local_sandbox.py:383`; verify `no_call/task < 2.0`.
  - **H-User 6 (Offload Activation Logging):** `Contradicted` (`mqg1cob` IS factory GPU; GTX 1050 cannot load E4B) | `0.00h` | `mqg1cob` serial `~20m` fallback only | Compliant | Reject concurrent hooks (`8.42 + 8.42 > 14.8 GiB` OOM).
  - **Emergent Hypotheses (`H-Team 1–4`):** `enable_thinking=True` local parity fix (`win_phase2_tournament.py:798`), `--max_seq_len 12288` + live `L24..41` assertion (`kaggle_train_e4b_qat_lora.py:1715-1717`), `B8 -> B9` fixes, and the `<= 2,136c` `512W` ceiling law.
- **12.00h Quota Ledger, Core Docs, `research_briefs/`, & `others/`:** All 5 core files ([ACTION_PLAN_11_DAY_ROADMAP.md](file:///f:/AI/Benchmark/plans/ACTION_PLAN_11_DAY_ROADMAP.md), [AGENT_CONTINUATION_DOSSIER.md](file:///f:/AI/Benchmark/plans/AGENT_CONTINUATION_DOSSIER.md), [E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md](file:///f:/AI/Benchmark/reports/E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md), [MASTER_OVERVIEW.md](file:///f:/AI/Benchmark/MASTER_OVERVIEW.md), [MASTERPLAN.md](file:///f:/AI/Benchmark/plans/MASTERPLAN.md)), all 6 briefs under [research_briefs](file:///f:/AI/Benchmark/research_briefs), and all 14 files under [Others](file:///f:/AI/Benchmark/Others) (line-by-line `KEEP`/`MODIFY`/`DROP` for [E4B Small-Model Track Diagnosis and Next Steps.md](file:///f:/AI/Benchmark/Others/E4B%20Small-Model%20Track%20Diagnosis%20and%20Next%20Steps.md), [strategic_audit_and_execution_summary.md](file:///f:/AI/Benchmark/Others/strategic_audit_and_execution_summary.md), and [WINNING_STRATEGY_SLOT2_OFFENSIVE.md](file:///f:/AI/Benchmark/Others/WINNING_STRATEGY_SLOT2_OFFENSIVE.md)) are reconciled into the `12.00 GPU-h` ledger (`9.70h` planned + `2.30h` reserve = `12.00h` @ `2×`; `4×` Lean Fallback `7.40h + 4.60h = 12.00h`).

<!-- GOAL_COMPLETE -->