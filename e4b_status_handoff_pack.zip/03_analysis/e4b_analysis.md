# E4B Model Quantitative & Forensic Statistical Analysis

**Analyst:** E4B Model Data Analysis Agent  
**Date (UTC):** 2026-11-25  
**Scope:** Exhaustive empirical audit of ALL `gemma-4-e4b-it-qat-w4a16-ct` (E4B) runs across Kaggle 4x L4 (`vLLM` + ATIF-v1.7) and Local RTX 2000 Ada (`win_frontier_6harness_overnight.py` / `win_local_sandbox.py`), verifying raw `.jsonl`, `.json`, `.patch`, `.log`, `.yaml`, `.md`, and `.safetensors` binary headers.

---

## Executive Summary (2-Sentence Synthesis)

Across **14 distinct E4B cohorts** (Kaggle Public LB `B0`/`B1`/`B2`/`E4B_F3_v2`/`E4B_LoRA_v1`, Kaggle Gate G2 & Shadow Dev `LoRA v1 Var A/B/C` and `LoRA v2 Arm A/B`, Local R1–R12 `Val20`/`Canary8` [316 episodes], Local `E4B_F3_v2` 99-task factory, Local `E4B_LoRA_v1` 129-task factory, and Nov 25 `e4b_factory_train99.zip`), **un-tuned and LoRA-v1 E4B both hit a hard `0.05` (3/58) Public LB ceiling** because **86%–100% of localization-capable episodes fail in the last mile**: `edit_file` exact-match failures (`70.7%–85.3%` failure rate on Kaggle; `68.8%–77.6%` locally), `no_call` turn dropouts (`39.0%–48.7%` locally; `1.3–2.0/task` on Kaggle), and right-file logic errors (`53%–67%` of Gate G2 tasks). Crucially, we uncovered three previously undocumented empirical facts: **(1)** Local `E4B_F3_v2` (`4/99`) was run on **hinted** (`[LOCALIZATION_HINT]`) prompts (`97/99` flagged, `100%` gold-file read) yet still failed `95/99` (`95.96%`); **(2)** `Base E4B_F3_v2 Floor: 1/30` in `build_master_engine.py:1588` is a hardcoded reference constant rather than an executed Gate G2 log; and **(3)** the Nov 25 `e4b_factory_train99.zip` run **already evaluated** `E4B_LoRA_v1` with the updated `2,656 B` (`2,638c` LF) prompt across all 99 training tasks, regressing from `3/99` (`45/99` patches) to **`2/99` (`28/99` patches)** due to 512-token sliding-window eviction and `Strict Pre-Edit Rule` read paralysis.

---

## 1. Master Inventory of Verified E4B Trials & Configurations

### 1.1. Kaggle Submissions, Gate G2, Shadow Dev & Diagnostic Runs

| Run / Sub ID | Adapter & Binary `.safetensors` Proof | Prompt & Harness Config (Verified) | Eval Suite ($N$) | Raw Solve | **Genuine Solve** | Non-Empty Patches | Public LB ($N=58$) | Primary Artifact / Proof Path |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **`B0`** | None (Zero LoRA) | `system.md` **5,396 B** (`5,390c`, 44L); `25` calls, `120s`, `4m`, `40` turns; `temp=0.1, tb=2048, include_thoughts=false`; optional `code_analyzer` | `DIAG_20 (C0)` | `2/20` | **`2/20 (10.0%)`** | `19/20` (95.0%) | **`0.05`** (3/58) | `submissions/submission_b0/`, `02_Harness_Benchmarks_and_Leaderboard_Log.txt:6,22` |
| **`B1`** | `surgical_lora`: BnB NF4, **18 tensors**, **921,600 params** (1.85 MB), `L[24..32]`, `down_proj` only, `r=8, alpha=2` | `system.md` **3,742 B** (`3,730c`, 26L); `25` calls, `120s`, `4m`; `temp=0.2, tb=3584, max_out=12288, include_thoughts=true` | `DIAG_20 (C3)` | `1/20` | **`1/20 (5.0%)`** | `15/20` (75.0%) | **`0.03`** (2/58) | `submissions/submission_B1.zip`, `02_Harness_Benchmarks_and_Leaderboard_Log.txt:7,25` |
| **`B2`** | None (Zero LoRA) | `system.md` **1,356 B** (12L); `42` calls, `180s`, `6m`, `60` turns; mandatory `code_analyzer` + `patch_verifier` + `git checkout --` | `DIAG_20 (H9)` | `0/20` | **`0/20 (0.0%)`** | `3/20` (15.0%) | **`0.03`** (2/58) | `submissions/submission_B2.zip`, `02_Harness_Benchmarks_and_Leaderboard_Log.txt:8`, `EXPERIMENT_VALIDATION_REPORT.md:87` |
| **`DIAG_20: C1_B0_budget40`** | None (Zero LoRA) | `B0` prompt, `40` calls, `6m` | `DIAG_20` | `3/20` | **`3/20 (15.0%)`** | `18/20` (90.0%) | *Not sub.* | `02_Harness_Benchmarks_and_Leaderboard_Log.txt:23` |
| **`DIAG_20: C2_B0_plus_3rules`** | None (Zero LoRA) | `B0` + 3 rules, `40` calls, `6m`, `tb=2048` | `DIAG_20` | `3/20` | **`3/20 (15.0%)`** | `17/20` (85.0%) | *Not sub.* | `02_Harness_Benchmarks_and_Leaderboard_Log.txt:24` |
| **`E4B_F3`** | None (Zero LoRA) | `system.md` **2,649 B** (23L, `-p no:anyio`); `40` calls, `30s`, `6m`, `55` turns; `temp=0.15, tb=1024` | *Predecessor* | — | — | — | *Not sub.* | `submissions/submission_E4B_F3.zip` |
| **`E4B_F3_v2`** | None (Zero LoRA) | `system.md` **2,136 B** (14L, ~497 tok; `-p no:anyio`, `tail -20`, partial surrender); `24` calls, `30s`, `6m`, `55` turns; `temp=0.15, tb=1024` | Gate G2 Floor *(hardcoded ref)* | `1/30`* | **`1/30`*** *(imputed)* | — | **`0.05`** (3/58) | `submissions/submission_E4B_F3_v2.zip`, `build_master_engine.py:1588`, `resultskaggle_final.log:1434` |
| **`Gate G2 v1: Var A`** | `e4b_few_23_29_30_ep2`: **24 tensors**, **1,064,960 params** (2.13 MB), `L[23,29,30]` (`o,gate,up,down`), `r=8, a=8` | `system.md` **2,136 B** (14L); `40` calls, `240s`, `8m`, `80` turns; `temp=0.15, tb=1024` | Gate G2 (`splits_99_30`) | `4/30` (13.3%) | **`3/30 (10.0%)`** (`14077`=1 B) | `26/30` (86.7%) | *Not sub.* | `resultskaggle_final.zip/results_phase4_Variant_A_few_23_29_30/` |
| **`E4B_LoRA_v1` (Var B)** | `e4b_global_upper_ep2`: **54 tensors**, **2,093,056 params** (4.19 MB), `L23` (all 7), `L[29,30,35,41]` (`q,o,gate,up,down`; 0 `k/v`), `r=8, a=16` | `submissions/` zip: `system.md` **2,149 B** (`-p no:anyio`, `tail -20`, partial); `40` calls, `240s`, `8m`, `80` turns (`eval_cand_variant_B`: `2,136 B`) | Gate G2 (`splits_99_30`) | `5/30` | **`5/30 (16.67%)`** | `26/30` (86.7%) | **`0.05`** (3/58) | `submissions/submission_E4B_LoRA_v1.zip`, `resultskaggle_final.zip/results_phase4_Variant_B_global_upper/` |
| **`Gate G2 v1: Var C`** | `e4b_all_linear_ep2`: **516 tensors**, **34,881,536 params** (69.84 MB), `L[0..23]` (all 7) + `L[24..41]` (5 projs), `r=16, a=32` | `system.md` **2,136 B** (14L); `40` calls, `240s`, `8m`, `80` turns; `temp=0.15, tb=1024` | Gate G2 (`splits_99_30`) | `3/30` | **`3/30 (10.0%)`** | `26/30` (86.7%) | *Not sub.* | `resultskaggle_final.zip/results_phase4_Variant_C_all_linear/` |
| **`LoRA v2: Arm A`** | `e4b_active_all_42_ep2`: **336 tensors**, **20,971,520 params** (41.99 MB), **`L[0..23]` ONLY** (Cell 5 bug froze `L24..41`!), `r=16, a=32` | `system.md` **2,638 B** (18L, ~615 tok > 512W; `Strict Pre-Edit`, no `-p no:anyio`, 4 attempts); `40` calls, `240s`, `8m`, `80` turns | Shadow Dev (`16` train tasks) | `0/16` | **`0/16 (0.0%)`** | `11/16` (68.8%) | *Not sub.* | `kaggle_e4b_lora_v2_results/results_phase4_shadow_dev_Arm_A_active_all_42/` |
| **`LoRA v2: Arm B`** | `e4b_active_mid_upper_17_41_ep2`: **98 tensors**, **6,184,960 params** (12.38 MB), **`L[17..23]` ONLY** (Cell 5 bug froze `L24..41`!), `r=16, a=32` | Same `system.md` **2,638 B** (~615 tok); `40` calls, `240s`, `8m`, `80` turns (packaged as `submission_E4B_LoRA_v2.zip`) | Shadow Dev (`16`) & Gate G2 (`30`) | Shadow: `0/16`<br>G2: `3/30` | Shadow: **`0/16 (0.0%)`**<br>G2: **`1/30 (3.33%)`** (`14077`=1 B, `14851`=1 B) | Shadow: `9/16` (56.2%)<br>G2: `23/30` (76.7%) | *NO-GO* | `kaggle_e4b_lora_v2_results/results_phase4_gate_g2_holdout_Arm_B_active_mid_upper_17_41/` |

*\*Note on `E4B_F3_v2` Gate G2 `1/30`: No `task_results.jsonl` for `E4B_F3_v2` on the 30 Gate G2 tasks exists in `resultskaggle_final.zip` or `resultskaggle_final.log`; `build_master_engine.py:1588` prints `Base E4B_F3_v2 Floor: 1/30 (0.05 LB)` as a hardcoded baseline constant.*

### 1.2. Local Workstation (RTX 2000 Ada 16 GB) Runs

| Run ID | Model & Prompt (`messages[0]` Verified) | Suite ($N$) | Genuine Solve | Non-Empty Patches | SCR % | Avg Steps | Runtime | Artifact Path |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **Local v1/v2 `F1,F3,F4,F6` (69 E4B traces)** | Zero LoRA (`win_frontier_6harness_overnight.py`, Py 3.11.17 -> Py 3.12 fix) | `Canary8` + `Val20` (`69` E4B traces) | **`3/69 (4.35%)`** (`requests_7433, 7502, 7505`) | `28/69` (40.58%) | — | — | — | `reports/E4B_69_TRACE_ROLLOUT_FORENSICS.md:4-19`, `reports/EPISODES_78_STATISTICAL_ANALYSIS.md` |
| **Local `E4B_F3_v2` R1–R12 (`Canary8`)** | Zero LoRA, compact `E4B_F3_v2` | `12 × 8 = 96` | **`0/96 (0.0%)`** | `57/96` (59.4%, 3–6/8) | `42.2%–57.5%` | ~23.8 | `39.1m–54.3m`/rd | `frontier_overnight_results/r{1..12}_canary8/E4B_F3_v2/summary.json` |
| **Local `E4B_F3_v2` R1–R11 (`Val20`)** | Zero LoRA, compact `E4B_F3_v2` | `11 × 20 = 220` | **`2/220 (0.91%)`** (1/20 R5, 1/20 R11) | `118/220` (53.6%, 7–14/20) | `48.5%–54.9%` | ~23.5 | `44.8m–60.4m`/rd | `frontier_overnight_results/r{1..11}_val20/E4B_F3_v2/summary.json` |
| **Local `E4B_F3_v2` Factory (HINTED)** | Zero LoRA; **`messages[0]` = `2,476c`** (14L, `-p no:anyio`, Call-10, partial ok); **`97/99` `[LOCALIZATION_HINT]`** | `99` train (`hinted_train_99_tasks.jsonl`) | **`4/99 (4.04%)`** (`fastapi_14303, 14463, requests_7315, rich_2725`) | `46/99` (46.5%) | `50.56%` | `23.45` | `83.32m` (0.84m/task) | `frontier_overnight_results/E4B_F3_v2/summary.json`, `traces/*.json` |
| **Local `E4B_LoRA_v1` Factory (Old Prompt)** | PEFT `E4B_LoRA_v1`; **`messages[0]` = `2,513c`** (14L, **no `-p no:anyio`**, no `tail -20`, 4 attempts, partial=0); **Unhinted** | `129` all<br>(`99` train / `30` holdout) | All: **`6/129 (4.65%)`**<br>Train: **`3/99 (3.03%)`**<br>Hold: **`3/30 (10.0%)`** | All: `60/129` (46.5%)<br>Train: `45/99` (45.5%)<br>Hold: `15/30` (50.0%) | `52.19%` | `37.84` | `191.66m` (1.49m/task) | `e4b_lora_v1_factory/E4B_LoRA_v1/summary.json`, `traces/*.json` |
| **Local `E4B_LoRA_v1` `train99` (Nov 25)** | PEFT `E4B_LoRA_v1`; **`messages[0]` = `2,638c` LF** (`2,656 B` CRLF `system.md` == **LoRA v2 prompt**!); **Unhinted** | `99` train (`splits_99_30.json`) | **`2/99 (2.02%)`** (`fastapi_14303, requests_7315`) | `28/99` (28.3%) | `46.71%` | `38.63` | **`589.38m`** (5.95m/task) | `e4b_factory_train99.zip` (`summary.json`, `traces/*.json`, `prompts/system.md`) |

---

## 2. Verification of Prompts, Patch Validity, Tool Syntax & Anomalies

### 2.1. Prompt Drift & 512-Token Sliding Window Violations
E4B has 35/42 local sliding-window layers with $W = 512$ tokens (`ML_RESEARCH_MODEL_DYNAMICS.md` §9). Directly comparing `prompts/system.md` and trace `messages[0]` reveals:
- **Kaggle `E4B_F3_v2` (`2,136 B`, 14 lines)** and **Kaggle `E4B_LoRA_v1` (`2,149 B`, 14 lines)**: Both fit inside the ~500-token ceiling, **but** both still contain `-p no:anyio`, `| tail -20`, and `"Partial patches earn score"`.
- **Local `E4B_F3_v2` (`2,476c` in `messages[0]`)** and **Local `E4B_LoRA_v1` old (`2,513c` in `messages[0]`)**: Slightly expanded wording (~575–585 tokens); `2,513c` removed `-p no:anyio` and `| tail -20`, introduced 4 iterative fix attempts, and changed to `"partial diffs earn zero score"`.
- **Kaggle `LoRA v2` (`2,638 B`) & Local `train99` (`2,638c` LF / `2,656 B` CRLF)**: **Byte-identical** (ignoring CRLF vs LF) across all 18 lines! Added `## Critical Guardrails`, `Strict Pre-Edit Rule` (*"ALWAYS call read_file on 20-35 target lines immediately before every edit_file"*), and kept `"allow up to 4 iterative fix attempts; partial diffs earn zero score"`. At ~615 tokens, it **exceeds $W=512$ on Turn 0**.

### 2.2. Patch Artifact Hygiene (`0 B` / `1 B` Empty Diffs vs. Genuine Patches)
In ATIF-v1.7 Kaggle outputs, empty `.patch` files contain a single newline (`1 B` = `"\n"`), which `resolved=True` reports must NEVER conflate with real fixes:
- **`Gate G2 v1 Var A`:** Raw `4/30` includes **`fastapi_14077` (`1 B` empty diff)** (`3 passed in 0.39s` at repo baseline) -> **3/30 genuine**.
- **`Gate G2 v1 Var B (LoRA v1)`:** Raw `5/30`, **all 5 genuine** (`404 B – 825 B`).
- **`Gate G2 v1 Var C`:** Raw `3/30`, **all 3 genuine** (`404 B – 1,930 B`).
- **`LoRA v2 Arm B Gate G2`:** Raw `3/30` includes **`fastapi_14077` (`1 B`)** and **`fastapi_14851` (`1 B`)** -> **1/30 genuine (`fastapi_14786`, `404 B`)**! Trace inspection proves on `fastapi_14077` Arm B edited `pyproject.toml` (discarded config edit), and on `fastapi_14851` Arm B made two edits to `fastapi/applications.py` that cancelled out to a `1 B` diff—both triggering baseline test suites that passed untouched!
- **Container B Patch Apply Rate:** Across ALL 6 Kaggle ATIF runs (`26 + 26 + 26 + 11 + 9 + 23 = 121` non-empty patches), **`git apply` failures in Container B = `0 / 121` (`100.0%` clean apply)**. Every failure after patch emission is a **localization or code-logic failure**, not a `git apply` corruption issue.
- **Local Discarded/Self-Reverted Edits:** In `train99`, `34/99` tasks had $\ge 1$ `edit_file` succeed, yet only `28/99` emitted a non-empty patch (`6` lost edits: `rich_3469`, `rich_4075` edited `tests/` only; `fastapi_15589`, `requests_7505`, `rich_3935`, `rich_4076` reverted/produced 0 B).

### 2.3. Tool-Call Distribution, Edit Failures (`NoMatchError` / `FileEditError`), & Turn Anomalies

| Cohort ($N$) | Calls / Task | Tool Distribution (`read` / `edit` / `cmd` / `search` / `submit` / `graph`) | Unwindowed `read_file` | `edit_file` OK / Fail (**OK %**) | `NoMatch` / `old_string not found` Share of Edit Fails | `no_call` / Malformed Turns |
| :--- | :---: | :--- | :---: | :---: | :---: | :--- |
| **Kaggle `v1 Var A` (30)** | `25.0` (749) | `270 / 319 / 108 / 31 / 20 / 1` | `58 / 270` (21.5%) | `47 / 272` (**14.7%**) | `216 / 272` (`79.4%`) + 49 MultiMatch + 10 NoChange | `42` no_call (19 prose, 23 code leak), `2` mal, `15` TO |
| **Kaggle `v1 Var B` (30)** | `22.4` (672) | `275 / 248 / 89 / 41 / 15 / 4` | `75 / 275` (27.3%) | `42 / 206` (**16.9%**) | `193 / 206` (`93.7%`) + 10 MultiMatch + 2 NoChange | `45` no_call (29 prose, 14 code, 2 raw token), `2` mal, `16` TO |
| **Kaggle `v1 Var C` (30)** | `21.8` (654) | `233 / 254 / 100 / 36 / 29 / 2` | `65 / 233` (27.9%) | `57 / 197` (**22.4%**) | `177 / 197` (`89.8%`) + 13 MultiMatch + 7 NoChange | `55` no_call (30 prose, 25 code leak), `1` mal, `11` TO |
| **Kaggle `v2 Arm A` SD (16)** | `31.8` (508) | `280 / 89* / 81 / 45 / 12 / 1` | `32 / 280` (11.4%) | `14 / 75` (**15.7%**) | `53 / 75` (`70.7%`) + 17 MultiMatch + 2 Budget | `23` no_call (11 prose, 8 code, 4 raw token), `19` mal, `8` TO |
| **Kaggle `v2 Arm B` SD (16)** | `40.1` (642) | `342 / 79 / 111 / 42 / 53 / 5` (+10 `get_status`) | `35 / 342` (10.2%) | `13 / 66` (**16.5%**) | `39 / 66` (`59.1%`) + 7 MultiMatch + 19 Budget | `13` no_call (8 prose, 4 code, 1 raw token), `0` mal, `11` TO |
| **Kaggle `v2 Arm B` G2 (30)** | `29.9` (897) | `477 / 181 / 151 / 42 / 41 / 5` | `59 / 477` (12.4%) | `53 / 128` (**29.3%**) | `88 / 128` (`68.8%`) + 29 MultiMatch + 8 NoChange | `40` no_call (15 prose, 23 code, 2 raw token), `4` mal, `12` TO |
| **Local `E4B_F3_v2` (99, Hinted)** | `14.5` (1,433) | `715 / 241 / 138 / 206 / 83 / 50` | `0 / 715` (`0.0%`) | `65 / 176` (**27.0%**) | `157 / 176` (`89.2%`) + 15 MultiMatch + 4 Empty | `972` no_call (`40.4%` of turns: `925` Continuing, `45` prose, `2` leak) |
| **Local `LoRA_v1` Old (129)** | `23.9` (3,080) | `1405 / 439* / 475 / 385 / 193 / 183` | `0 / 1,405` (`0.0%`) | `100 / 339` (**22.8%**) | `317 / 339` (`93.5%`) + 17 MultiMatch + 5 Empty | `1,995` no_call (`39.3%` of turns: `1897` Cont, `87` prose, `11` leak) |
| **Local `LoRA_v1` `train99` (99)** | `20.0` (1,979) | `848 / 207 / 499 / 235 / 36 / 153` (+1 `get_status`) | `0 / 848` (`0.0%`) | `51 / 156` (**24.6%**) | `133 / 156` (`85.3%`) + 6 MultiMatch + 17 Empty | **`1,882` no_call (`48.7%` of turns**: `1879` Cont, `1` prose, `2` leak) |

*\*Note: `v2 Arm A` includes 2 `write_file` calls; `LoRA_v1` old includes 2 `write_file` calls. In local `train99`, `read_file` also recorded **45 inverted-range calls** (`end_line < start_line`, e.g., `rich_3905`: `read_file(rich/progress.py:1150-120)`) and **16 pytest file-not-found / zero-tests-ran errors** (e.g., `fastapi_14463`: hallucinated `tests/test_openapi_utils.py`).*

---

## 3. E4B Quantitative Failure Funnel (Exact $N$ Across Cohorts)

| Cohort ($N$) | Task Start ($N$) | Stage 1: Gold-File Read | Stage 2: Edit Attempted | Stage 3: Gold-File Edit Hit | Stage 4: Edit Succeeded ($\ge 1$ `ok`) | Stage 5: Non-Empty Valid Patch | Stage 6: Container B Apply (`git apply`) | Stage 7: **Genuine Test Pass** (Raw) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Kaggle `v1 Var A` (G2)** | `30` | `26 (86.7%)` | `30 (100.0%)` | `22 (73.3%)` | `27 (90.0%)` | `26 (86.7%)` | `26 / 26 (100%)` | **`3 (10.0%)`** (`4` raw) |
| **Kaggle `v1 Var B` (`LoRA_v1`)** | `30` | `28 (93.3%)` | `30 (100.0%)` | `24 (80.0%)` | `26 (86.7%)` | `26 (86.7%)` | `26 / 26 (100%)` | **`5 (16.7%)`** (`5` raw) |
| **Kaggle `v1 Var C` (`all_lin`)** | `30` | `27 (90.0%)` | `29 (96.7%)` | `25 (83.3%)` | `26 (86.7%)` | `26 (86.7%)` | `26 / 26 (100%)` | **`3 (10.0%)`** (`3` raw) |
| **Kaggle `v2 Arm A` (Shadow16)** | `16` | `12 (75.0%)` | `11 (68.8%)` | `7 (43.8%)` | `11 (68.8%)` | `11 (68.8%)` | `11 / 11 (100%)` | **`0 (0.0%)`** |
| **Kaggle `v2 Arm B` (Shadow16)** | `16` | `10 (62.5%)` | `13 (81.2%)` | `7 (43.8%)` | `9 (56.2%)` | `9 (56.2%)` | `9 / 9 (100%)` | **`0 (0.0%)`** |
| **Kaggle `v2 Arm B` (G2)** | `30` | `24 (80.0%)` | `26 (86.7%)` | `19 (63.3%)` | `25 (83.3%)` | `23 (76.7%)` | `23 / 23 (100%)` | **`1 (3.3%)`** (`3` raw) |
| **Local `E4B_F3_v2` (Hinted)** | `99` | `99 (100.0%)` | `64 (64.6%)` | `62 (62.6%)` | `46 (46.5%)` | `46 (46.5%)` | `46 / 46 (100%)*` | **`4 (4.0%)`** |
| **Local `LoRA_v1` Old (129)** | `129` | `85 (65.9%)` | `86 (66.7%)` | `62 (48.1%)` | `62 (48.1%)` | `60 (46.5%)` | `60 / 60 (100%)*` | **`6 (4.7%)`** |
| **Local `LoRA_v1` Old (99 Train)** | `99` | `64 (64.6%)` | `67 (67.7%)` | `46 (46.5%)` | `47 (47.5%)` | `45 (45.5%)` | `45 / 45 (100%)*` | **`3 (3.0%)`** |
| **Local `LoRA_v1` Old (30 Hold)** | `30` | `21 (70.0%)` | `19 (63.3%)` | `16 (53.3%)` | `15 (50.0%)` | `15 (50.0%)` | `15 / 15 (100%)*` | **`3 (10.0%)`** |
| **Local `LoRA_v1` `train99` (Nov25)** | `99` | `60 (60.6%)` | `54 (54.5%)` | `41 (41.4%)` | `34 (34.3%)` | `28 (28.3%)` | `28 / 28 (100%)*` | **`2 (2.0%)`** |

*\*Local factory evaluates directly in the sandboxed git working tree (all non-empty diffs tested via `pytest`).*

**Funnel Bottleneck Verdict:** On Kaggle Gate G2, `LoRA v1 Var B` reached **gold-file read on 93.3% (28/30)**, **gold-file edit on 80.0% (24/30)**, and **clean patch application on 86.7% (26/30)**, yet only **16.7% (5/30)** passed tests (`17/26` non-empty patches hit the exact gold file with flawed logic). Even when `E4B_F3_v2` was given `[LOCALIZATION_HINT]` (`100%` gold read), **35.4% (35/99) never even attempted an edit**, **18.2% (18/99) failed all edit attempts via `NoMatchError`**, and **40.4% (40/99) edited the right file with failing logic**.

---

## 4. Error Categorization Table (Exact Counts, %, & Trace Citations)

| Error / Outcome Bucket | Kaggle `v1 Var B` (N=30) | Kaggle `v2 Arm B` G2 (N=30) | Local `E4B_F3_v2` (N=99) | Local `LoRA_v1` Old (N=99) | Local `train99` (N=99) | Representative Verified Trace Citations |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **1. `RIGHT_FILE_LOGIC_FAIL`** *(Non-empty patch hits gold file, pytest fails)* | **`17 (56.7%)`** | **`18 (60.0%)`** | **`40 (40.4%)`** | **`30 (30.3%)`** | **`22 (22.2%)`** | `resultskaggle_final.zip/.../trace_fastapi_14077.json` (`555 B`); `train99/.../rich_3518.json` (failed `test_columns_highlight_added_by_add_row`); `train99/.../fastapi_14463.json` (`NameError: http`) |
| **2. `NO_EDIT_TIMEOUT_OR_EMPTY`** *(0 B / 1 B patch; turn/read/no-call stall or test-only edit)* | `0 (0.0%)` | `4 (13.3%)` | **`36 (36.4%)`** | **`34 (34.3%)`** | **`51 (51.5%)`** | `v2/.../trace_fastapi_9753.json` (`1 B`); `train99/.../fastapi_15589.json` (`4 edit_oks`, `0 B` final); `train99/.../rich_3469.json` (edited `tests/` only) |
| **3. `EDIT_NOMATCH_STALL`** *(Attempted edits, 0 succeeded due to `NoMatchError`/`FileEditError` -> empty patch)* | `4 (13.3%)` | `1 (3.3%)` | `17 (17.2%)` | `20 (20.2%)` | `20 (20.2%)` | `resultskaggle_final.zip/.../trace_fastapi_13713.json` (`FileEditError` ×4+, `0 B`); `v2/.../trace_fastapi_14258.json`; `E4B_F3_v2/traces/rich_4076.json` |
| **4. `WRONG_FILE_LOCALIZATION`** *(Non-empty patch, misses gold files completely)* | `4 (13.3%)` | `4 (13.3%)` | `2 (2.0%)` | `12 (12.1%)` | `4 (4.0%)` | `VarB/.../trace_fastapi_14487.json`; `v2/.../trace_fastapi_14459.json` (`959 B`); `train99/.../requests_6757.json` |
| **5. `EMPTY_PATCH_FALSE_PASS`** *(`resolved=True` with `1 B` `"\n"` diff artifact)* | `0 (0.0%)` | **`2 (6.7%)`** | `0 (0.0%)` | `0 (0.0%)` | `0 (0.0%)` | `v2/.../test_outputs/fastapi_14077.log` (`1 B`, `3 passed`); `v2/.../test_outputs/fastapi_14851.log` (`1 B`, `9 passed`); `VarA/.../fastapi_14077.log` (`1 B`) |
| **6. `GENUINE_PASS`** *(`resolved=True` with genuine non-empty source patch)* | **`5 (16.7%)`** | **`1 (3.3%)`** | **`4 (4.0%)`** | **`3 (3.0%)`** | **`2 (2.0%)`** | `VarB`: `fastapi_14459, 14786, 9753, 14616, rich_3772`; `v2`: `fastapi_14786`; `train99`: `fastapi_14303, requests_7315` |

---

## 5. Cross-Cohort Comparison & Task-by-Task Overlap / Regression Matrix

### 5.1. Gate G2 (30 Holdout Tasks): `Var A` vs `Var B (LoRA v1)` vs `Var C` vs `LoRA v2 Arm B` vs `Local LoRA v1`

Every task resolved in **at least one** of the 5 evaluations across the 30 frozen holdouts (`splits_99_30.json`):

| Holdout Task ID | `v1 Var A` (`few_23_29_30`) | `v1 Var B` (`E4B_LoRA_v1`) | `v1 Var C` (`all_linear`) | `v2 Arm B` (`L17..23` bug) | `Local LoRA_v1` (30h slice) | Forensic Note |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| `fastapi_14786` | **PASS** (404 B) | **PASS** (404 B) | **PASS** (404 B) | **PASS** (404 B) | **PASS** (411 B) | Universal trivial anchor solved by all 5 cohorts |
| `fastapi_14459` | FAIL (751 B) | **PASS** (562 B) | **PASS** (562 B) | FAIL (959 B) | FAIL (0 B) | Regressed in `v2 Arm B` (missed gold file!) |
| `fastapi_14616` | **PASS** (516 B) | **PASS** (825 B) | FAIL (783 B) | FAIL (916 B) | FAIL (974 B) | Regressed in `v1 Var C` & `v2 Arm B` |
| `fastapi_9753` | FAIL (791 B) | **PASS** (765 B) | FAIL (838 B) | FAIL (1 B) | FAIL (614 B) | Unique to `Var B` |
| `rich_3772` | FAIL (1,273 B) | **PASS** (683 B) | FAIL (703 B) | FAIL (560 B) | FAIL (1,879 B) | Unique to `Var B` |
| `rich_3882` | **PASS** (503 B) | FAIL (599 B) | FAIL (621 B) | FAIL (501 B) | **PASS** (502 B) | Quarantined in `e4b_sft_holdout_quarantine.jsonl` |
| `requests_7205` | FAIL (540 B) | FAIL (608 B) | FAIL (1,078 B) | FAIL (1 B) | **PASS** (500 B) | Quarantined in `e4b_sft_holdout_quarantine.jsonl` |
| `fastapi_14077` | *FALSE PASS (1 B)* | FAIL (555 B) | **PASS** (1,930 B) | *FALSE PASS (1 B)* | FAIL (0 B) | Only `Var C` produced a genuine `1,930 B` solve |
| `fastapi_14851` | FAIL (764 B) | FAIL (1 B) | FAIL (1,494 B) | *FALSE PASS (1 B)* | FAIL (0 B) | Reverted two edits to `1 B` in `v2 Arm B` |
| **Total Genuine** | **3 / 30 (10.0%)** | **5 / 30 (16.7%)** | **3 / 30 (10.0%)** | **1 / 30 (3.3%)** | **3 / 30 (10.0%)** | **Union = 8 distinct tasks across 5 runs** |

### 5.2. 99 Train Tasks: `E4B_F3_v2` (Hinted) vs `LoRA_v1 Old Prompt` vs `LoRA_v1 train99` (Updated Prompt)

| Train Task ID | `Local E4B_F3_v2` (Hinted) | `Local LoRA_v1` Old (Unhinted) | `Local LoRA_v1` `train99` (2,656 B) | Transition Analysis |
| :--- | :---: | :---: | :---: | :--- |
| `fastapi_14303` | **PASS** (740 B) | **PASS** (740 B) | **PASS** (740 B) | Universal solve across all 3 runs |
| `fastapi_14463` | **PASS** (931 B) | FAIL (662 B) | FAIL (782 B) | `train99` introduced `NameError: http` + hallucinated `test_openapi_utils.py` |
| `requests_7315` | **PASS** (521 B) | FAIL (546 B) | **PASS** (478 B) | Gained in `train99` |
| `rich_2725` | **PASS** (1,098 B) | FAIL (0 B) | FAIL (0 B) | Only solved when `[LOCALIZATION_HINT]` was given |
| `rich_3518` | FAIL (0 B) | **PASS** (528 B) | FAIL (542 B) | **REGRESSED in `train99`**: 10+ `read_file` turns before edit; assertion failed |
| `rich_3905` | FAIL (0 B) | **PASS** (767 B) | FAIL (451 B) | **REGRESSED in `train99`**: inverted `read_file` ranges (`1150-120`, `290-150`); failed `test_wrap_file` |
| **Total Genuine** | **4 / 99 (4.04%)** | **3 / 99 (3.03%)** | **2 / 99 (2.02%)** | **Patch transition (`Old -> train99`): 19 kept, 26 lost, 9 gained, 45 neither** |

### 5.3. Shadow Dev 16 (`LoRA v2 Arm A` & `Arm B`) vs Local 99-Train Runs
All 16 `SHADOW_DEV_IDS` (`fastapi_11355` through `fastapi_14430`) are in `splits_99_30.json["train_ids"]` (16/16 overlap, 0 holdouts) and are FastAPI tasks:
- **`LoRA v2 Arm A` (`L[0..23]`):** **0 / 16 (0.0%)**, 11/16 non-empty patches (`fastapi_14186` bloated to `12,013 B`), 8 timeouts.
- **`LoRA v2 Arm B` (`L[17..23]`):** **0 / 16 (0.0%)**, 9/16 non-empty patches, 11 timeouts, **`53` `submit_patch` calls** (budget-exhaustion/loop artifacts).
- **Local Benchmarks on the same 16 tasks:** `E4B_F3_v2 (hinted)` emitted `8/16` non-empty patches (`0/16` solves); `LoRA_v1 old` emitted `7/16` non-empty patches (`0/16` solves); `train99` emitted only `3/16` non-empty patches (`0/16` solves). These 16 tasks are genuinely hard FastAPI tasks (`0/16` across all 5 E4B runs).

---

## 6. Evidence Adjudication for H-User 1, H-User 4, & H-User 5

1. **H-User 1 (LoRA V1 Prompt Delta Optimization): CONTRADICTED for the `2,656 B` updated prompt; UNTESTED within `<= 2,136c`.**  
   - **Empirical Proof:** The updated `2,656 B` (`2,638c` LF) prompt from `local_v8_dropin/prompts/system.md` (which removed `-p no:anyio`, removed `| tail -20`, added `## Critical Guardrails`, `Strict Pre-Edit Rule`, and 4 fix attempts) was **already tested on `E4B_LoRA_v1`** in `e4b_factory_train99.zip` and **severely regressed**: solves fell `3/99 -> 2/99`, non-empty patches collapsed `45/99 -> 28/99` (losing 26 patched tasks), `no_call` turns surged `39.0% -> 48.7%`, and runtime tripled (`1.49m -> 5.95m/task`). A 615-token prompt breaks E4B's 512-token sliding window, and the mandatory pre-edit read rule triggers read-loop paralysis. Only a **strictly `<= 2,136c` (~497 tok)** prompt removing `-p no:anyio` and `| tail -20` remains untested.
2. **H-User 4 (LoRA V1 vs. V2 Post-Mortem & Next-Step Trajectory): VALIDATED (Discard V2; Lock V1; Replace only with repaired V3).**  
   - **LoRA V2 failed from 3 verified causes:** (a) Cell 5 regex bug froze `L[24..41]` completely (binary `.safetensors` proves Arm A = `L[0..23]` only, Arm B = `L[17..23]` only with **6,184,960 params / 12.38 MB**, correcting `E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md` §3 which mistook 12.38 MB for 12.4M params); (b) `2,638c` prompt exceeded $W=512$; (c) SFT data starvation (`e4b_sft_train.jsonl` has **33 rows across only 29 unique tasks**, not 31) caused Ep2 CE drop to `0.47–0.50` memorization.  
   - **Definitive Status of LoRA V1:** `E4B_LoRA_v1` (54 tensors on `L[23,29,30,35,41]`, 2.09M params, 4.19 MB) genuinely improved Gate G2 (`5/30`) and unhinted local 30-holdout (`3/30`) capability, making it the **mandatory Slot 2 incumbent lock** over `v2` (`1/30` genuine). Do **not** merge `v1` + `v2` (TIES/DARE is banned in `MASTERPLAN.md` §23.8 and `v2` weights are corrupted). Replace `v1` only via a repaired V3 (fixed `kaggle_train_e4b_qat_lora.py` line 118 regex covering `L24..41`, expanded SFT corpus $\ge 60\text{–}100$ unique tasks, and `<= 2,136c` prompt).
3. **H-User 5 (Local PC Evaluation of Updated LoRA V1): ALREADY COMPLETED (`e4b_factory_train99.zip`, Nov 25 08:49).**  
   - **Empirical Proof:** `e4b_factory_train99.zip` executed PEFT `E4B_LoRA_v1` + the updated `2,656 B` prompt on all 99 train tasks on the RTX 2000 Ada workstation (`589.38 min`, `2/99` solved, `28/99` patches, `46.71% SCR`). Do **not** re-run the `2,656 B` prompt locally. Any new local PC eval must test a **re-trimmed `<= 2,136c` prompt** on the 30 holdout tasks (`splits_99_30["holdout_ids"]`, ~45–90m).
