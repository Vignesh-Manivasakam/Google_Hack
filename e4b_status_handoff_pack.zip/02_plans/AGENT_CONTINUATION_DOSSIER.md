# Turnkey Agent Continuation Dossier: Engineering Handbook, Execution Commands & Invariants

**Target System:** Google Gemma 4 Developer Agent Benchmark & Continuous Experimentation Platform  
**Target Repository:** `f:\AI\Benchmark`  
**Classification:** Authoritative Operational Handbook, Turnkey Engineering Guide & System State  
**Audience:** Incoming AI Engineering Agents & Human ML Competitors  
**Version:** 7.1 (Updated 2026-11-26: Post-`B8` Timeout, `mqg1cob` `v1.5` NO-GO, `LoRA_v3` `1/30` NO-GO RCA, `2.00 GPU-h` Remaining)  
**Date:** November 26, 2026  
**Live Status Delta (2026-11-26 09:30 IST):** Remaining Kaggle GPU quota = **`2.00 GPU-h`** (`1.00h` wall @ `2×`). `B8` timed out (lock cleared; `B4` `0.12` remains Slot 1 anchor). `mqg1cob` `v1.5` (`0/20`) & `Base_v1_5` (`0/20`) lost to `LoRA_v1_2149B` (`2/20`, `92.16m`) -> `LoRA_v1` (`0.05` LB) retained. `LoRA_v3` saved `11/46` AggreVaTe recoveries (`aggrevate_31b_recoveries.jsonl`), but Gate G2 scored **`1/30` (`NO-GO`)** because `MODEL_TURN_SPAN_RE` broke on HF Gemma-4's native template (dropping all `11/11` AggreVaTe rows + supervising `<|tool_response>`) and `e4b_sft_train_seed.jsonl` contained `no_call` E4B turns. Teamwork handoffs archived in `teamwork_handoffs/nov25_sprint/`.  
**Authoritative Document Precedence:** `plans/MASTERPLAN.md` > `MASTER_OVERVIEW.md` > `plans/ACTION_PLAN_11_DAY_ROADMAP.md` > `plans/AGENT_CONTINUATION_DOSSIER.md` (per `REDUNDANCY_CLEANUP_LOG.md`)  

---

## 1. Executive Briefing, Rules Verification & ZIP-Verified Baseline Matrix

### 1.1. Core Mission, Competition Rules & Harness Contract (`rules_and_refs.md` & `HARNESS_README.md`)
You are inheriting the **Google Gemma 4 Developer Agent** benchmark and continuous experimentation platform (**$110,000 total prize pool**: `$65,000` Main Track + `$10,000` Small-Model Bonus + `$35,000` Paper Track [closed Nov 12]).
- **Deadlines & Submission Mechanics:** Team Merger / Entry freeze: **Nov 25, 2026 (23:59 UTC)**; Final submission deadline: **Dec 2, 2026 (23:59 UTC)**. Strict limit of **1 submission/day** (`00:00 UTC` reset), **1-pending lock** (`HTTP 400 FAILED_PRECONDITION`, 20–24h queue), and **2 final UI selections** (`$10,000` Small-Model Bonus requires **manual** selection of **`1× 31B + 1× E4B`** — NEVER `2× 31B`).
- **Runtime, Hardware & Isolation:** Submission global wall-clock limit **`12h`** (inclusive of Container A setup, exclusive of Container B verification). Kaggle 4x L4 (`96 GB` VRAM, `tp=4`, `gpu_mem_util=0.90`) currently burns interactive quota at **`2×`** (subject to Kaggle rate increase -> `4×` Lean Fallback). All L4 sessions are **internet-off** (`network_mode="none"`, `/wheels/`).
- **Licensing, Models & Data Rules:** Winners must release submission + training/inference/env code under **Open Source Apache 2.0** (`/rules` §1.6, §2.5, §2.8). Only 4 `W4A16-CT` models allowed (`31b`, `12b` [broken on vLLM 0.19.1], `e4b`, `e2b`), and every agent/subagent must share **1 base model** (`len(models) == 1`). External data/tools must satisfy the Host **Reasonableness Standard** (`/rules` §2.6). PEFT `.safetensors` LoRAs allowed (`r <= 128`, capped `r <= 16` by vLLM `#50059`); `.bin/.pt/.pth` rejected.
- **Scorer & Dataset Contract:** Public dev `tasks.jsonl` = `129` tasks (`67` FastAPI, `48` Rich, `13` Requests, `1` HTTPX; `~73/129` locally gradable). Hidden test set = `~120` private-repo tasks evenly split (`N=58` public split truncated to 2 decimals per Nov 23 intel; `0.16/0.19/0.21/0.23` impossible). `eval_config.timeout_seconds` controls Phase 1 `command_timeout_seconds` ONLY; Phase 2 `verification_timeout_seconds` is **fixed at `300s`** on scorer (`HARNESS_README.md:559-560`, running `pytest ... -p no:anyio -o timeout=0` at `:621`). Container A/B = `4 GiB` RAM, `2 vCPUs`, `5,000c` stdout cap, `150L/10,000c` unwindowed `read_file` cap. ADK `EventsCompactionConfig` (`token_threshold=14336`) wipes Turn-4 history if `include_thoughts: true`. Unsubmitted diffs recovered via `git add -N . && git diff --binary _swegemma_baseline`; protected files stripped before binary JUnit (`0.0` or `1.0`).

### 1.2. ZIP-Verified Baseline Matrix (`B4`, `E4B_F3_v2`, `E4B_LoRA_v1`, `LoRA_v2`, Active `B8`)

| Track / ID | Artifact & Adapter (`safetensors`) | ZIP `eval_config.yaml` & `sampling.yaml` | ZIP `prompts/system.md` | Local / G2 Eval | Public LB ($N=58$) | Current Status |
|---|---|---|---|---|---|---|
| **Slot 1: `B4`** *(Anchor)* | `submissions/submission_B4.zip`; Zero LoRA; Single `LlmAgent` | `180s / 40 / 6m / 55t`; `temp=0.1, top_p=0.90, tb=1024, out=8192, thoughts=false` | `4,650c` (`81L`); `docs_src/`, `.github/`, ignore broken tests; `0` `-p no:anyio` | `DIAG_20`: `5/20`; `Canary8`: `3/8` | **`0.12`** (`7/58`) | **SELECTED Slot 1 Champion** |
| **Slot 1: `B8`** *(Queue)* | `submissions/submission_B8.zip`; Zero LoRA; Single `LlmAgent` | `240s / 32 / 8m / 80t`; `temp=0.2, top_p=0.95, **`tb=4096`**`, `out=8192, thoughts=false` | `3,193 B` (`49L`); bans `-p no:anyio`/surrender; **drops `docs_src/` & ignore-broken-tests**; `git stash`; `get_code_neighbors` | **0 eval logs on disk** | **Scoring (Queue)** | **Pending (`1`-pending lock)** |
| **Slot 2: `E4B_F3_v2`** *(Floor)* | `submissions/submission_E4B_F3_v2.zip`; Zero LoRA *(unpacked disk desynced!)* | **`30s / 24 / 6m / 55t`** *(ZIP; disk says `240/40/8/80`)*; `temp=0.15, tb=1024` | **`2,136 B`** (`14L`, `497` tok); **has `-p no:anyio`, `\| tail -20`, partial surrender** | `Val20`: `1/20`; `train99` (Hinted): `4/99`; G2 ref: `1/30`* (`build_master_engine.py:1588`) | **`0.05`** (`3/58`) | Deselected Base Floor |
| **Slot 2: `E4B_LoRA_v1`** *(Active)* | `submissions/submission_E4B_LoRA_v1.zip`; `54` BF16 tensors (**`2,093,056`** params, `L23` 7 mods + `L[29,30,35,41]` 5 mods; **`0` `k/v` in `L29–41`**) | **`240s / 40 / 8m / 80t`** *(verified in ZIP)*; `temp=0.15, top_p=0.90, tb=1024` | **`2,149 B`** (`14L`, `~500` tok); has `(never pass -p no:anyio)`, **still has `\| tail -20`, full-file pytest, partial surrender** | Gate G2: **`5/30`** genuine (`p~0.19` vs `1/30*`); Local 129: `6/129`; `train99` (`2,656 B`): `2/99` | **`0.05`** (`3/58`, `95% CI: 1–7`) | **SELECTED Slot 2 Anchor** *(Test `v1.5` offline)* |
| **Slot 2: `LoRA_v2`** *(Failed)* | `kaggle_e4b_lora_v2_results/`; **Broken regex froze `L24..41`**: `Arm A` `20,971,520` (`L0..23`); `Arm B` `6,184,960` (`L17..23`) | `240s / 40 / 8m / 80t`; `temp=0.15, tb=1024`; `r=16, a=32, lr=1.2e-4` | **`2,638 B`** (`18L`, **`~618` tok > 512W**) | Shadow Dev: **`0/16`** (A&B); Gate G2 Arm B: `3/30` raw -> **`1/30` genuine** | **NO-GO (Not Sub.)** | **DISCARDED** *(Cell 5 regex + `>512W` + overfit)* |

*(Mandatory Nov 25 UI Actions: Confirm Team Merger / Entry freeze before `23:59 UTC`; open Small-Model LB notebook to verify exact `#1` rival score; verify UI checkboxes = `1× 31B (B4)` + `1× E4B (E4B_LoRA_v1)`.)*

### 1.3. Forensic Takeaways: Slot 1 (`B4` vs `B6` vs `B7` vs Active `B8`)
1. **Candidate `B4` (`0.12`, `7/58`):** Single `LlmAgent`, `180s/40/6m`, `tb=1024`, targeted `-k` pytest, `.github/workflows/` + `docs_src/` + ignore-broken-tests, `0` `-p no:anyio` / `tail -20` / surrender.
2. **Candidate `B6` (`0.08`, `5/58`):** Self-inflicted `30s/24 calls` throttle (`9/24` timeouts on `fresh_24_eval`), `-p no:anyio` (`11/24`), `| tail -20` (`12/24`), and 2-attempt surrender (`11/19` fails submitted broken code).
3. **Candidate `B7` (`0.10`, `6/58`):** Restored `180s/40/6m` and dropped `tail -20`, **but** trailed `B4` by `1` task due to `-p no:anyio` (`79/1,143` suites broken per `#757893`), full-file pytest, dropped `.github/` rule, and 2-attempt surrender.
4. **Candidate `B8` (Queue):** Cures `-p no:anyio`, `tail -20`, surrender, and `.github/`, **but** carries `tb=4096` (`4×` `B4`'s `1024`, contradicting notebook comments!), omits `docs_src/` (`11.6%` of tasks) and ignore-broken-tests, uses `git stash` (`0 B` diff loss risk on timeout), mandates `get_code_neighbors`, and has **0 eval logs on disk**.

### 1.4. Forensic Takeaways: Slot 2 `LoRA_v1` (`0.05`) vs Base `F3_v2` (`0.05`)
Submission `submission_E4B_LoRA_v1.zip` scored **`0.05` (`3/58`, `95% CI: 1–7/58`)**, tying `submission_E4B_F3_v2.zip` (`0.05`). Eight empirically verified mechanisms explain this plateau:
1. **`-p no:anyio` Weight Contamination (`63×` in Training JSONL / `78×` in `v2.jsonl`):** `resultskaggle_final.zip/e4b_sft_train.jsonl` (30 rows) baked **`63×` `-p no:anyio`** and **`65×` `| tail -20`** into `LoRA_v1`'s weights (`e4b_sft_train_v2.jsonl` had `78×` / `62×`; scrubbed to `0` in `v3.jsonl`).
2. **Frozen KV-Owners `L0–22` (Zero Dead KV Tensors in `L29–41`):** Binary `safetensors` (`4,193,984 B`, `54` tensors, `2,093,056` params) proves `L23` has 7 modules (`14` tensors) while `L29,30,35,41` have **5 modules (`q,o,gate,up,down` = `10` tensors each, 0 `k/v` tensors)**. The structural limit was adapting only 5/42 layers while freezing **all KV-owners `L0–22`**.
3. **Premature Surrender Trap (`system.md:8`):** `v1.zip` retained `"after 2 fix attempts, CALL submit_patch IMMEDIATELY. Partial patches earn score"`; binary grading awards `0.00`.
4. **Piped Pytest (`| tail -20`):** `v1.zip` still piped pytest through `| tail -20`, blinding root tracebacks.
5. **Full-File Pytest Execution:** Ran `<REAL_TEST_FILE>` without `-k`, hitting pre-existing failures.
6. **512-Token Local Sliding-Window Cliff:** `v1.zip`'s `2,149 B` (`~500` tok) left minimal Turn-0 headroom; later `2,638–2,656 B` (`~618` tok) prompts in `LoRA_v2` and `train99.zip` overflowed `512W` on Turn 0.
7. **Unhinted Domain Gap:** `LoRA_v1` trained on `27` hinted 31B + `3` E4B traces (`0` AggreVaTe student-failure-to-teacher-recovery traces).
8. **Small-Sample Variance (`N=58` & Fisher $p \approx 0.19$):** `5/30` Gate G2 vs hardcoded `1/30*` (`build_master_engine.py:1588`) has Fisher exact $p \approx 0.19$, and `0.31×–0.35×` private-repo transfer sits inside `3/58`'s `1–7/58` CI.

### 1.5. The 3-Minute Turnkey Execution Flow
To inspect, verify, and validate deliverables in less than 3 minutes:

```powershell
# Step 1: Navigate to repository root
cd F:\AI\Benchmark

# Step 2: Verify active submission champions & ZIP attributes
python -c "
import os, zipfile
for name in ['submission_B4.zip', 'submission_B7.zip', 'submission_B8.zip', 'submission_E4B_F3_v2.zip', 'submission_E4B_LoRA_v1.zip']:
    p = os.path.join('submissions', name)
    if os.path.exists(p):
        with zipfile.ZipFile(p) as z:
            print(f'{name}: size={os.path.getsize(p)} B, sys={set(i.create_system for i in z.infolist())}')
    else:
        print(f'{name}: NOT FOUND')
"

# Step 3: Run CPU dry-runs & prompt length check (<10 seconds, 0 GPU spend)
python scripts/check_e4b_len.py
python kaggle_train_e4b_qat_lora.py --dry_run_test
python sft_dataset_builder.py --self_test
python Kaggle_Master_Clubbed_Engine.py --dry_run_test
python build_posix_zip.py --help
```

---

## 2. Reconciled 12.00h Kaggle GPU Quota Ledger & Hardware Disambiguation

### 2.1. Master 12.00h Quota Ledger (`ORIGINAL_REQUEST.md:16`, Live `2×` & `4×` Fallback)
Authoritative starting balance as of **2026-11-25** is **`12.00 Kaggle GPU-hours`** (`6.00` physical wall-clock hours at Kaggle's live **`2×` L4x4 burn rate** per `/overview`, after Nov 24 `LoRA_v2` consumed `~6.28 GPU-h`). Mandatory contingency reserve floor: **`>= 2.00 GPU-hours`**.

| Cluster / Job | Dates | Planned Kaggle 4x L4 Activity (`0.00h` Local/Queue) | Wall (h) | **Burn @ 2× (GPU-h)** | **Rem. (2×)** | *4× Lean Fallback* |
|---|---|---|---:|---:|---:|---:|
| **Baseline** | Nov 25 | Starting Balance (`ORIGINAL_REQUEST.md:16`); `B8` in queue (`0.00h`); Team Merger `23:59 UTC` | `0.00h` | `0.00h` | **`12.00h`** | *`0.00h`* |
| **Job A (C1)** | Nov 25–26 | **Local (`0.00h`):** Patch (d) + `v1.5` gate + submit `v1.5` (if pass).<br>**Kaggle:** 31B Hinted AggreVaTe Completions (`~30–46` prefixes -> `>=18` clean) | `1.25h` | **`2.50h`** | **`9.50h`** | *`4.00h` (`1.00h`, 28 root)* |
| **Job B (C2)** | Nov 26 | **Kaggle:** `LoRA_v3` 2-Arm Train (`active_all_42 r=8` [`17.44M`] vs `17_41 r=8` [`10.05M`] or `r=16` [`20.09M`] if `>=60` rows, `max_seq_len=12288`, `2` ep) | `0.75h` | **`1.50h`** | **`8.00h`** | *`1.60h` (`0.40h`, 1 arm)* |
| **Job C (C3)** | Nov 26–27 | **Kaggle:** Balanced Shadow Dev + Gate G2 (`30` holdouts; promote iff `>=7/30` genuine + leading indicators) | `0.80h` | **`1.60h`** | **`6.40h`** | *`1.80h` (`0.45h`, G2 only)* |
| **Job D (C4)** | Nov 28–29 | **Queue:** Submit `LoRA_v3`. **Kaggle (Cond.):** `B9` `fresh_24_eval` Canary ONLY if `B8` in `0.12–0.19` | `0.85h` | **`1.70h`** | **`4.70h`** | *DROP if 4×* |
| **Job E (C5)** | Nov 29–30 | **Kaggle (Cond.):** `LoRA_v4` DAgger Round 2 ONLY if `v3` shows signal & rate stays `2×` | `1.20h` | **`2.40h`** | **`2.30h`** | *DROP if 4×* |
| **Reserve** | Contingency | Mandatory unspent reserve (`>= 2.00 GPU-h` hard floor); Dec 2 `23:59 UTC` UI lock **`1× 31B + 1× E4B`** | `1.15h` | **`2.30h`** | **`0.00h` net** | *`4.60h` (`>=2.00h`)* |
| **TOTAL** | **Nov 25–Dec 2** | **Planned `9.70h` + Reserve `2.30h` = `12.00 GPU-h` (`4×` Fallback: `7.40h + 4.60h = 12.00h`)** | **`6.00h`** | **`12.00h`** | **`12.00h`** | *`12.00h` exact* |

### 2.2. Hardware Role Disambiguation & Compute Discipline
*(Resolves `H-User 6` — no separate remote GPU exists to offload onto.)*

| Node / Environment | Verified Hardware & OS | Actual VRAM / Headroom | Permitted Roles (`0.00` vs Kaggle Quota) | Hard Prohibitions |
|---|---|---|---|---|
| **Remote GPU Workstation (`mqg1cob`)** | RTX 2000 Ada (`16 GB` VRAM), `64 GB` RAM, Win 11, Py `3.12.12` | `~14.5–14.8 GiB` WDDM usable (Stripped E4B + CPU PLE + LoRA = `8.42–8.67 GiB`) | `0.00h` serial E4B rollouts (`workers=1, bs=1`), `v1.5` local parity gate, `AggreVaTe` mining, optional `~20m` serial surprisal probe | **NO** local BF16/NF4 LoRA training (`~17 GB` OOM / NF4 banned); **NO** 31B; **NO** concurrent hooks (`8.42+8.42 > 14.8 GiB`) |
| **Local Laptop (`f:\AI\Benchmark`)** | GeForce GTX 1050 (`4 GB` VRAM), Windows, Py `3.12` | `4 GB` (Cannot load E4B `8.41 GiB`) | CPU scripts (`sft_dataset_builder.py`, `build_posix_zip.py`, `check_e4b_len.py`, `--dry_run_test`, `--inspect_template`) | **CANNOT** load E4B or 31B models |
| **Kaggle Interactive 4x L4** | `4× NVIDIA L4` (`96 GB` total, `~21.6 GB`/GPU), Linux | `96 GB` (`tp=4`) | **ONLY** 31B AggreVaTe completions (`Job A`), QAT `bf16` `LoRA_v3` training (`Job B`), Gate G2 (`Job C`), conditional `B9`/`v4` | **NEVER** burn interactive quota on runtime activation hooks or multi-hour un-hinted harvests |
| **Google Colab T4** | `1× T4` (`14.56 GiB`), Linux | `14.56 GiB` | POSIX ZIP / YAML / brace preflight checks | OOMs on E4B PLE + 262k logits |

---

## 3. Authoritative Master Document Hierarchy

Per the verified `REDUNDANCY_CLEANUP_LOG.md` (100% Zero Data Loss protocol), all sub-agents and engineers must consult documents according to the following strict hierarchy:

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   AUTHORITATIVE MASTER DOCUMENT HIERARCHY                              │
├─────┬────────────────────────────────────────┬─────────────┬───────────────────────────────────────────┤
│ Rank│ Canonical File Path                    │ Size / Lines│ Core Architectural Role                   │
├─────┼────────────────────────────────────────┼─────────────┼───────────────────────────────────────────┤
│ 1   │ plans/MASTERPLAN.md                    │ 175KB/1314L │ Master Architecture, ADK contracts,       │
│     │                                        │             │ chronological timeline Phases 0–16        │
│ 2   │ MASTER_OVERVIEW.md                     │ 95KB / 704L │ Complete repository inventory, trees,     │
│     │                                        │             │ historical experiment ledger B0–B7        │
│ 3   │ plans/ACTION_PLAN_11_DAY_ROADMAP.md    │ ~85KB       │ Master 11-day operational plan, daily     │
│     │                                        │             │ clusters, 12.00h quota ledger, H1–H25     │
│ 4   │ plans/AGENT_CONTINUATION_DOSSIER.md    │ v7.0        │ Turnkey engineering handbook, Phase 0–2   │
│     │                                        │             │ registries, H-User 1–6, v1.5/v3/B9 specs  │
│ 5   │ reports/EXPERIMENT_VALIDATION_REPORT.md│ 61KB / 554L │ Master validation scorecard, 78-episode   │
│     │                                        │             │ analytics, G2 shootout results            │
│ 6   │ reports/STRATEGIC_DEEP_DIVE_ANALYSIS.md│ 61KB / 453L │ Config audit, 18 tuning guardrails,       │
│     │                                        │             │ mechanical diffs (B4 vs B6 vs B7)         │
│ 7   │ reports/ML_RESEARCH_MODEL_DYNAMICS.md  │ 59KB / 501L │ Attention topology (5:1 window), errata,  │
│     │                                        │             │ QAT INT4 vs native bf16 LoRA dynamics     │
│ 8   │ reports/HARNESS_ENGINEERING_RESEARCH.md│ 48KB / 566L │ ADK container lifecycles, unsubmitted     │
│     │                                        │             │ diff fallback, sandbox defect shims       │
└─────┴────────────────────────────────────────┴─────────────┴───────────────────────────────────────────┘
```

### 3.1. Complete SFT, Trajectory & AggreVaTe Dataset Registry (`31b_analysis.md` §1.2)
All 13 JSONL datasets on disk + archive JSONLs audited directly (`0%` holdout contamination in every train/SFT/AggreVaTe file; all 3 holdout passes isolated in `e4b_sft_holdout_quarantine.jsonl`):

| Dataset Path | Size (B) | SHA-256 (12) | Rows / Unique Tasks | Repo (`F`/`R`/`Rq`) | `source_model` | Holdouts | `sys_chars` | Thoughts | 8-Guard Status |
|---|---|---|---|---|---|---|---|---|---|
| `raw_hinted_31b_passing.jsonl` | 1,099,009 | `f806a02807f8` | 27 / 27 | `13/13/1` | 31B: `27` | **0** | `6,002` | **0/27** | **23/27 pass** (2 test writes, 2 empty `old_string`) |
| `all_passing_trajectories.jsonl` (root) | 85,189 | `088b445d98b6` | 3 / 3 | `0/0/3` | E4B: `3` | **0** | `2,476; 4,572` | 3/3 | **3/3 pass** |
| `frontier_overnight_results/all_passing_trajectories.jsonl` | 172,557 | `4c0684a35568` | 5 / 5 | `2/1/2` | E4B: `5` | **0** | `2,476` | 2/5 | **5/5 pass** |
| `onpolicy_lora_v1_passing.jsonl` | 169,091 | `9fc4891ead1e` | 3 / 3 | `1/2/0` | E4B-v1: `3` | **0** | `2,513` | 0/3 | **3/3 pass** |
| `e4b_lora_v1_factory/all_passing_trajectories.jsonl` | 284,326 | `6b55d75125d1` | 6 / 6 | `2/3/1` | E4B-v1: `6` | **3** *(quarantined)* | `2,513` | 1/6 | **3/6 pass** (3 holdouts quarantined) |
| `e4b_sft_holdout_quarantine.jsonl` | 109,965 | `8090bf1b6d7d` | 3 / 3 | `1/1/1` | E4B-v1: `3` | **3** *(quar.)* | `2,513` | 1/3 | **0/3** (`holdout_task_excluded`) |
| `e4b_factory_train99.zip` (`all_passing`) | 77,892 | — | 2 / 2 | `1/0/1` | E4B-v1: `2` | **0** | `2,638` | — | **1/2 pass** (`fastapi_14303` OK; **`requests_7315` REJECTED** `tests/test_adapters.py` edit) |
| `e4b_sft_train_synthesized.jsonl` | 813,387 | `76bb2773db20` | 26 / 26 | `12/10/4` | 31B: `23`, E4B: `3` | **0** | `2,135` | 3/26 | Sanitized; `no:anyio=56, tail=58` |
| `resultskaggle_final.zip/e4b_sft_train.jsonl` *(v1)* | 995,541 | `ed60f016fd2a` | 30 / 30 | `13/13/4` | 31B: `27`, E4B: `3` | **0** | `2,136` | — | 26/27 31B pass (`14964` empty edit); `no:anyio=63, tail=65` |
| `e4b_sft_train_expanded.jsonl` | 863,212 | `68b92ab2a6de` | 28 / 28 | `13/10/5` | 31B: `23`, E4B: `5` | **0** | `2,135` | 4/28 | Sanitized |
| `e4b_sft_train_v2.jsonl` | 915,883 | `67be5ea61a15` | 30 / 28 | `14/11/5` | 31B: `23`, E4B: `7` | **0** | `2,135` | 4/30 | Sanitized; `no:anyio=78, tail=62` |
| `e4b_sft_train_v3.jsonl` & `e4b_sft_train.jsonl` *(v2)* | 1,105,099 | `3285e319ee04` | **33 / 29** | `15/13/5` | 31B: `23`, E4B: `7`, v1: `3` | **0** | **`2,637`** (`>512W`) | 4/33 | Byte-identical; `no:anyio=0, tail=0` |
| `aggrevate_failure_prefixes.jsonl` (root) | 410,013 | `9d26c6c4f3d3` | 28 / 28 | `10/9/9` | E4B-v1: `28` | **0** | `2,513` | 0/28 | Prefixes (`T=6`: `edit=13, stall=9, pytest=6`) |
| `e4b_lora_v1_factory/aggrevate_failure_prefixes.jsonl` | 398,972 | `2e9ae7f8e386` | 28 / 28 | `28/0/0` | E4B-v1: `28` | **0** | `2,513` | 0/28 | Prefixes (`T=6`: `syntax=22, edit=6`) |
| `e4b_factory_train99.zip` (`aggrevate`) | 424,293 | — | 28 / 28 | `28/0/0` | E4B-v1: `28` | **0** | `2,638` | — | Prefixes (`T=6`: `syntax=19, edit=9`) |

- **Deduplicated Clean Union (`train_99`):** **`61` clean sanitized records across `31` unique `train_99` tasks** (`26` 31B + `9` E4B, `4` overlap, `0` holdouts; `max_per_task=2, max_repo_share=0.50` -> `37` trajs). Across the 3 prefix files, **`46` unique `train_99` tasks** exist (`31` unsolved by 31B/E4B, `0` holdouts), currently **0/46 completed by 31B**. Three structural SFT flaws must be patched for `LoRA_v3`: (1) `0/27` thoughts in raw 31B traces; (2) `23.3%–30.3%` tail truncation past `max_seq_len=8192` (`kaggle_train_e4b_qat_lora.py:1962`); (3) `9/23` clean 31B traces write `/workspace/repro*.py`. (`archive/DO_NOT_TRAIN_distill_golden_trajectories.jsonl`, 129 rows, `source_model=None` remains excluded by Guard 1.)

### 3.2. E4B Quantitative Failure Funnel, Error Categorization & 31B Lifecycle Summary
- **E4B Quantitative Failure Funnel (`e4b_analysis.md` §3):**

| Cohort ($N$) | Task Start ($N$) | Gold-File Read | Edit Attempted | Gold-File Edit Hit | Edit OK ($\ge 1$) | Non-Empty Patch | Container B Apply | **Genuine Pass** (Raw) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Kaggle `v1 Var A` (G2)** | `30` | `26 (86.7%)` | `30 (100%)` | `22 (73.3%)` | `27 (90.0%)` | `26 (86.7%)` | `26/26 (100%)` | **`3 (10.0%)`** (`4` raw) |
| **Kaggle `v1 Var B` (`LoRA_v1`)** | `30` | `28 (93.3%)` | `30 (100%)` | `24 (80.0%)` | `26 (86.7%)` | `26 (86.7%)` | `26/26 (100%)` | **`5 (16.7%)`** (`5` raw) |
| **Kaggle `v1 Var C` (`all_lin`)** | `30` | `27 (90.0%)` | `29 (96.7%)` | `25 (83.3%)` | `26 (86.7%)` | `26 (86.7%)` | `26/26 (100%)` | **`3 (10.0%)`** (`3` raw) |
| **Kaggle `v2 Arm A` (Shadow16)** | `16` | `12 (75.0%)` | `11 (68.8%)` | `7 (43.8%)` | `11 (68.8%)` | `11 (68.8%)` | `11/11 (100%)` | **`0 (0.0%)`** |
| **Kaggle `v2 Arm B` (Shadow16)** | `16` | `10 (62.5%)` | `13 (81.2%)` | `7 (43.8%)` | `9 (56.2%)` | `9 (56.2%)` | `9/9 (100%)` | **`0 (0.0%)`** |
| **Kaggle `v2 Arm B` (G2)** | `30` | `24 (80.0%)` | `26 (86.7%)` | `19 (63.3%)` | `25 (83.3%)` | `23 (76.7%)` | `23/23 (100%)` | **`1 (3.3%)`** (`3` raw) |
| **Local `E4B_F3_v2` (Hinted)** | `99` | `99 (100%)` | `64 (64.6%)` | `62 (62.6%)` | `46 (46.5%)` | `46 (46.5%)` | `46/46 (100%)` | **`4 (4.0%)`** |
| **Local `LoRA_v1` Old (129)** | `129` | `85 (65.9%)` | `86 (66.7%)` | `62 (48.1%)` | `62 (48.1%)` | `60 (46.5%)` | `60/60 (100%)` | **`6 (4.7%)`** (`3` tr / `3` ho) |
| **Local `LoRA_v1` `train99` (Nov25)** | `99` | `60 (60.6%)` | `54 (54.5%)` | `41 (41.4%)` | `34 (34.3%)` | `28 (28.3%)` | `28/28 (100%)` | **`2 (2.0%)`** (`1,882` `<eos>`) |

- **E4B Error Categorization (`e4b_analysis.md` §4):**

| Error / Outcome Bucket | Kaggle `v1 Var B` (N=30) | Kaggle `v2 Arm B` G2 (N=30) | Local `E4B_F3_v2` (N=99) | Local `LoRA_v1` Old (N=99) | Local `train99` (N=99) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **1. `RIGHT_FILE_LOGIC_FAIL`** | **`17 (56.7%)`** | **`18 (60.0%)`** | **`40 (40.4%)`** | **`30 (30.3%)`** | **`22 (22.2%)`** |
| **2. `NO_EDIT_TIMEOUT_OR_EMPTY`** | `0 (0.0%)` | `4 (13.3%)` | **`36 (36.4%)`** | **`34 (34.3%)`** | **`51 (51.5%)`** |
| **3. `EDIT_NOMATCH_STALL`** (`69–94%` `NoMatchError`) | `4 (13.3%)` | `1 (3.3%)` | `17 (17.2%)` | `20 (20.2%)` | `20 (20.2%)` |
| **4. `WRONG_FILE_LOCALIZATION`** | `4 (13.3%)` | `4 (13.3%)` | `2 (2.0%)` | `12 (12.1%)` | `4 (4.0%)` |
| **5. `EMPTY_PATCH_FALSE_PASS`** (`1 B` `'\n'`) | `0 (0.0%)` | **`2 (6.7%)`** | `0 (0.0%)` | `0 (0.0%)` | `0 (0.0%)` |
| **6. `GENUINE_PASS`** | **`5 (16.7%)`** | **`1 (3.3%)`** | **`4 (4.0%)`** | **`3 (3.0%)`** | **`2 (2.0%)`** |

- **31B Lifecycle & Bottleneck Summary (`31b_analysis.md` §2):** Passing 31B trajectories (`B6 fresh_24` `5/24`, `B6d` `4/24`, `31B Hinted 99` `27/99`, `Clubbed P1` `8/73`) achieve **97.6%–100% `edit_file` accuracy**, make their first edit **3.1–7.8 calls earlier** (Call `5.3–10.3` vs `13.1–13.6`), finish **87–149s faster** (`120–174s` vs `260–303s`), and use **0–1 graph tool calls** across `2,867` total tool calls (`B6` `0/479`, `B6d` `1/493`, `Hinted99` `0/1895`). Failing 31B runs lose `20%–47.4%` to 6m timeouts.

### 3.3. Forensic RCA (`F3_v2` vs `v1` vs `v2`) & Exact `safetensors` Parameter Counts
- **Exact Verified `safetensors` Counts (`CR-02`–`CR-05`, `meta_strategy.md` §4.1):**
  - `LoRA_v1` (`v1.zip`): `54` tensors (`4,193,984 B`), **`2,093,056` params** (`r=8, a=16`: `L23` 7 mods + `L[29,30,35,41]` 5 active mods, **0** `k/v`).
  - `Gate G2 v1 Var A`: `24` tensors, **`1,064,960` params** (`L[23,29,30]`, 4 mods, `r=8, a=8`).
  - `Gate G2 v1 Var C`: `516` tensors (`69.84 MB`), **`34,881,536` params** (`r=16, a=32`, `L0..23` 7 mods + `L24..41` 5 mods).
  - `LoRA_v2 Arm A` (Cell 5 bug froze `L24..41`): `336` tensors (`41.99 MB`), **`20,971,520` params** (`L[0..23]` ONLY; Ep2 CE `0.4695`, `B_norm` `0.1525`).
  - `LoRA_v2 Arm B` (Cell 5 bug froze `L24..41`): `98` tensors (`12.38 MB` — NOT `12.4M` params!), **`6,184,960` params** (`L[17..23]` ONLY; Ep2 CE `0.4977`, `B_norm` `0.1850`).
  - **`LoRA_v3` Targets:** `active_all_42 r=8` (`516` tensors) = **`17,440,768` params** (`~87–97:1` on `55–60` trajs); `active_mid_upper_17_41 r=8` (`278` tensors) = **`10,047,488` params** (`~50–56:1`), `r=16` = **`20,094,976` params**.
- **Comparison Summary:** `E4B_F3_v2.zip` (`0.05` LB, `1/30*` ref) ran `30s/24/6m/55t` + `2,136 B` (`497` tok); `E4B_LoRA_v1.zip` (`0.05` LB, `5/30` G2) ran `240s/40/8m/80t` + `2,149 B` (`63×` `-p no:anyio` in weights); `LoRA_v2` (`0/16` SD, `1/30` genuine G2) failed from frozen `L24..41` + `2,638 B` (`+121` tok > `512W` on `fastapi_14786`) + `max_seq_len=8192` tail truncation + `r=16/lr=1.2e-4` memorization on `33` rows (`29` tasks).

### 3.4. Local Eval-to-LB Correlation Matrix (All 7 Suites, `meta_strategy.md` §1.2)

| Suite ($N$) | Contamination / Composition | Verified Candidate Scores | LB Mapping ($N=58$, $\sigma \approx 2$) | Confounders & Calibration Warnings |
|---|---|---|---|---|
| **`DIAG_20`** (`20`) | `10F/7R/3Rq` (`train_ids`) | E4B `B0=2, B1=1, B2=0, C1=3`; 31B `C1=4, B4=5` | `~0.45–0.50×` LB (zero-LoRA) | Inside `train_ids`; Py3.11 `Protocol` bugs fixed in Py3.12 |
| **`Canary8`** (`8`) | `canary_8_ids` (`train_ids`) | 31B `B4=3/8`; E4B `B0=1/8`, Local `F3_v2 R1–R12=0/96` | Binary smoke only ($\pm 12.5\%$/task) | Local R1–R12 ran `enable_thinking=False` |
| **`Val20`** (`20`) | `win_local_sandbox.py:428` | Local `F3_v2` `2/220` (`0.91%`) | Smoke only | Omitted `enable_thinking=True` + hardcoded `-p no:anyio` + `~73/129` wheels |
| **`fresh_24_eval`** (`24`) | `12F/9R/3Rq` (`holdout_ids`) | 31B `B6=5/24 (20.8%)`, `B6d=4/24 (16.7%)` | Best 31B proxy (`5/24 -> 0.08`) | `3/12` missing `dirty_equals`; `14851` baseline false pass |
| **`Shadow Dev 16`** (`16`) | `16/16` `train_ids`, `100%` FastAPI | **`0/16` across ALL 5 E4B runs** | **Zero discriminating power** | Severe FastAPI bias (`IA-04`); re-balance + add leading indicators |
| **`Gate G2 (30)`** (`30`) | `splits_99_30["holdout_ids"]` | `F3_v2=1/30*`, `Var A=3/30`, **`v1=5/30`**, `Var C=3/30`, `v2=1/30` | Best E4B proxy (`p ~ 0.19`) | Enforce `len(patch.strip()) > 0` (`14077`/`14851` `1 B`); require `>=7/30` |
| **`Local Factory (99/129)`** | `tasks.jsonl` / `train_ids` | `F3_v2` (Hinted) `4/99`; `v1` old `6/129`; `train99` `2/99` | Mining / falsification only | `train99` falsified `2,656 B` (`28/99` patches, `1,882` `<eos>`) |

### 3.5. Conflict Resolution Highlights (`CR-01`..`CR-16` & `IA-01`..`IA-05`)
- **CR-01/CR-02:** ZIP is truth: `E4B_F3_v2.zip` = `30s/24/6m`, `2,136 B`; `E4B_LoRA_v1.zip` = `240s/40/8m`, `2,149 B`, `0` dead `k/v` tensors in `L29–41`.
- **CR-03–CR-05:** Per `reports/E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md` (`:32,45,84-85` errata reconciled): `LoRA_v2` `Arm A` = `20,971,520` (`L0..23`), `Arm B` = **`6,184,960`** (`L17..23`, `12.38 MB` misread as `12.4M` params at `:45,85`), `e4b_sft_train_v3.jsonl` = `33` rows / **`29` unique tasks** (not `31` at `:45,84`), and `G2 Arm B` = **`1/30` genuine** (`:32` raw `3/30` included `1 B` `'\n'` artifacts on `14077`/`14851`). `Var C` = `r=16, a=32, 34,881,536`; `active_all_42 r=8` = `17,440,768`; `active_mid_upper_17_41 r=8` = `10,047,488` (`r=16` = `20,094,976`).
- **CR-06–CR-16 & IA-01–IA-05:** `B8.zip` ships `tb=4096`; `train99.zip` ran `2,656 B` (`2/99`) and its **`requests_7315` MUST be excluded** (Guard 6/7); **`asvd_atp_kl_attribution.json` does NOT exist on disk**; `Base E4B_F3_v2 Floor: 1/30*` is a hardcoded reference (`build_master_engine.py:1588`); `eval_config.timeout_seconds` controls Phase 1 only (`HARNESS_README.md:559-560`); **`CR-12`:** `TIES/DARE` and Phase 3 local 4-bit QAT LoRA training on RTX 2000 Ada (`reports/E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md:124`) are permanently **KILLED**; quota = `12.00 GPU-h` (`2×` live / `4×` fallback); `v1.5` uses `2,048 B` (no `get_code_neighbors`), `B9` uses `2,331 B` (`<= 2,509c`).

### 3.6. Research Audit Tiered Summary (`research_briefs/` — All 6 Briefs)
- **(1) Empirically Confirmed:** Negative guardrails > verbose prose; windowed `read_file` + line-number strip (`92.3%` `NoMatch`); `/tmp/` isolation; early edit by Step 10 (avoid Call-8 rush); $N=58$ lattice & `include_thoughts: false`; 31B LoRA `1.3×` decode tax; E4B KV-sharing (`L24–41` omit `k/v`) + `2.82B` frozen PLE + native `bf16` QAT LoRA; `-p no:anyio` Phase 1 ban (`B7 0.10`); `<= 2,136c` E4B `512W` cap (`train99` `2/99`); `r <= 16` + `peft==0.22.0` + no `torchao` + flat PEFT sanitizer.
- **(2) Contradicted / Dead End / Scorer-Blocked:** `get_code_neighbors` / `search_similar_code` (`21/21` empty, `resultskaggle_final.log:536`); `\| tail -20`; `12B` pivot (`KeyError`); `Var C` `r=16` (`34.88M`) on `N=30`; `3+` epochs / `NEFTune` / `DPO` / `TIES-DARE`; local 4-bit LoRA (`B1` `15%->5%`); `timeout_seconds` Phase 2 claim (`HARNESS_README:559-560`); `tool_choice="required"` / MTP+LoRA / custom vLLM CLI flags (blocked on Kaggle's immutable scorer `HARNESS_README:163-170`).
- **(3) Unverified Speculation (High-Leverage Next Tests):** **AggreVaTe failure-prefix completions (`w_t=0` student turns)** (`46` prefixes, `0` completed); true active-only `active_all_42 r=8` (`17.44M`) & `17_41 r=8` (`10.05M`) with `--max_seq_len 12288`; `X4` `~180`-tok prompt ablation; `B9` (`2,331 B`, `tb=1024`, `40` calls, `docs_src/`, no `git stash`, 6 core tools).

### 3.7. External AI Proposals Triage (`others/` — 3 Nov 25 Files + 11 Historical Files)
- **`E4B Small-Model Track Diagnosis and Next Steps.md`:** **KEEP** $N=58$ CI, Fisher $p \approx 0.19$, `HARNESS_README:621`, `v2` neutral evidence, WSP rejection, AggreVaTe 28-prefix distillation, leading-indicator G2, live Small-Model LB `#1` & Nov 25 team-merger check; **MODIFY** `v1.5` (`<=2,136c`), 2-arm `LoRA_v3`, fallback offline probe; **DROP** false claim (L17) that no E4B zip used `8m/240s` & stale `~7h` reserve (`18h`).
- **`strategic_audit_and_execution_summary.md`:** **KEEP** $N=58$, 75–80% Slot 2 pivot, 3-cause `v2` collapse, `B7`-vs-`B4`, `B8`, local 4-bit ban, 6 killed items; **MODIFY** `18.00h -> 12.00h`, `0` `k/v` in `L29–41`, remove `asvd_atp_kl_attribution.json`, add `v1.5` + `train99` `28` `fastapi` prefixes + `r=8` arm + `max_lora_rank=16`.
- **`WINNING_STRATEGY_SLOT2_OFFENSIVE.md`:** **KEEP** Slot 2 priority, `v1.5 -> v3 -> B8/B9`, WSP/hook rejection, seniority, `X4`, `sft_dataset_builder` hard-rejects; **MODIFY** `13.40h -> 12.00h`, downgrade `0.31×` transfer ratio, patch `win_local_sandbox.py` before local G2 (keep Kaggle G2 promotion), gate `X6` `LoRA_v4` on `v3` signal + `>= 2.00h` reserve.
- **11 Historical `others/` Files:** `Summary.md`, `Block_B_Master_Directive.md`, `Deepseek.md`, `Gemma4_Agent_Top3_Operational_Roadmap.md`, `GEMMA4_TOP3_OPERATIONAL_ROADMAP.md`, `STRATEGIC_DOSSIER_TOP3.md`, `TOP3_EXECUTION_PLAN.md`, `top_3_operational_roadmap_14_day_plan.md`, `GEMMA4_FINAL_SPRINT_KILLER_PLAN.md`, `UPdated Gemma final other AI_Nov22_Dec02.md` -> **`SUPERSEDED`** (valid invariants absorbed); `GEMMA4_TOP3_STRATEGY_PROMPT.md` -> **`ARCHIVE / NON-ACTIONABLE`**.

### 3.8. H-User 1–6 & H-Team 1–4 Complete Evaluation Matrix

| ID | Empirical Status | Kaggle Quota Cost | Local / Remote Compute | Rule Compliance | Falsification / Validation Test & Unambiguous Verdict |
|---|---|---|---|---|---|
| **H-User 1** (`v1` Prompt Delta) | **Partially Validated** (`2,656 B` **Contradicted** `2/99`; `<=2,136c` **Untested**) | `0.00h` | `mqg1cob` (`~2–3h` serial); GTX 1050 CPU | Compliant | Paired `Base + 2,048 B` vs `LoRA_v1 + 2,048 B` on `mqg1cob` (`enable_thinking=True`); reject `v1.5` if it fails to beat both. |
| **H-User 2** (Selective vs 42L & Activation Mon.) | **Contradicted** for WSP / 42L `r=16` (`Var C` `3/30`); **Untested** for `active_all_42 r=8` & `17_41 r=8/16` | `0.00h` hooks; `1.50h @ 2×` (`3.00h @ 4×`) train | `mqg1cob` `~20m` serial surprisal fallback ONLY; Kaggle 4x L4 train | Compliant | **REJECT** runtime activation hooks & WSP; **PROCEED** with `active_all_42 r=8` (`17.44M`) vs `17_41 r=8` (`10.05M`); gate `>=7/30` genuine + leading indicators. |
| **H-User 3** (31B-to-E4B Distillation) | **Partially Validated** (`31` clean tasks; `0/46` prefixes completed) | `2.50h @ 2×` (`5.00h @ 4×`) | Kaggle 4x L4 for 31B; GTX 1050 CPU builder | Compliant (`0%` leak) | **APPROVE AS PRIMARY LEVER:** complete `>=18` 31B AggreVaTe recoveries (`student_prefix_turns=6`), merge -> `~52–60` trajs; falsify if edit CE & G2 <= `5/30`. |
| **H-User 4** (`v1` vs `v2` Post-Mortem) | **Validated** | `0.00h` | None | Compliant (`TIES/DARE` killed) | **DISCARD `LoRA_v2` (`NO-GO`)**; **RETAIN `LoRA_v1`** (test `v1.5` offline); **REPLACE ONLY** via `LoRA_v3` `>=7/30` genuine G2. |
| **H-User 5** (Local Eval of Updated `v1`) | **Partially Validated** (`train99` ran `2,656 B` -> `2/99`; `<=2,136c` **Untested**) | `0.00h` | `mqg1cob` (`~1.5–2.5h`, `8.42–8.67 GiB`); GTX 1050 cannot load | Compliant | Patch `win_phase2_tournament.py:798` + `win_local_sandbox.py:383`; verify `no_call/task < 2.0` & beats `Base + 2,048 B`. |
| **H-User 6** (Offload Activation Logging) | **Contradicted** (`mqg1cob` IS factory GPU; GTX 1050 4GB cannot load E4B) | `0.00h` | `mqg1cob` serial `~20m` fallback ONLY | Compliant | Concurrent `8.42+8.42 > 14.8 GiB` OOMs; **REJECT** concurrent/runtime hooks. |
| **H-Team 1** (`enable_thinking=True`) | **Partially Validated** | `0.00h` | `mqg1cob` `~15m` `smoke4` | Compliant | Enable `enable_thinking=True` on `smoke4`; require `no_call/task` `19.01 -> <= 2.0`. |
| **H-Team 2** (`--max_seq_len 12288` & `train()` Assert) | **Validated (Defect)** | `0.00h` extra | CPU `--inspect_template` + Kaggle L4x4 | Compliant | Confirm `0` truncated `submit_patch` turns & assert `42` (or `25`) adapted layers pre-optimizer. |
| **H-Team 3** (`B8` Risks & `B9`) | **Validated (Config Defects)** / **Pending LB** | `0.00h` pkg; `1.70h @ 2×` cond. `fresh_24` | Queue (`B8`) + cond. 4x L4 | Compliant | Gate `B9` (`2,331 B`, `tb=1024`, `40` calls, `docs_src/`, no `git stash`, 6 tools) on `B8` LB; require `>=6/24` (`<4` TO). |
| **H-Team 4** (`<= 2,136c` `512W` Law) | **Validated** (`2/99`, `1/30`) | `0.00h` | CPU + `mqg1cob` cond. `X4` | Compliant | Enforce `len(system.md) <= 2136` in `build_posix_zip.py` & `train()`; optional `X4` `~180`-tok ablation. |

---

## 4. Locked Slot 1 Specs (`B8` Queue & Conditional `B9`)

### 4.1. Active Queue Candidate `B8` (`submissions/submission_B8.zip`) — Verified Risks
```yaml
# submissions/submission_B8.zip/eval_config.yaml
evaluation:
  timeout_seconds: 240      # Phase 1 command_timeout_seconds ONLY (Phase 2 fixed at 300s per HARNESS_README.md:559-560)
  max_tool_calls: 32        # Lowered from B4's 40
  max_time_minutes: 8       # 8-minute wall-clock cap
  max_turns: 80             # Turn ceiling
```
```yaml
# submissions/submission_B8.zip/configs/sampling.yaml
temperature: 0.2
top_p: 0.95
max_output_tokens: 8192
thinking_config:
  thinking_budget: 4096     # VERIFIED IN ZIP & Kaggle_B8_PreSubmit_Diagnostic.py:310 (contradicts 1024 comments!)
  include_thoughts: false   # INVARIANT: prevents Turn-4 14k compaction wipe
```
- **Prompt (`3,193 B`, `49L`, POSIX `sys=3`):** Whitelists `{problem_description}` and `{hints?}`, bans `-p no:anyio`, `| tail -20`, surrender, and `/workspace` scratch, **but** omits `docs_src/` (`11.6%` of tasks) & ignore-broken-tests, uses `git stash` (`0 B` diff risk on timeout), mandates `get_code_neighbors`, and has **0 pre-submit eval logs on disk**.

### 4.2. `B8` Conditional Decision Tree & Locked `B9` Specification
- **IF `B8 < 0.12` (`<= 6/58`):** Immediately re-select `submission_B4.zip` (`0.12`) in Kaggle UI Slot 1. Only build/canary `B9` if `>= 5.70 GPU-h` remains after `LoRA_v3`; else freeze Slot 1 at `B4`.
- **IF `0.12 <= B8 <= 0.19` (`7/58`–`11/58`):** Retain `B8` (if `> 0.12`) or `B4` (if `0.12`, timestamp seniority) while staging **`B9`** (`0.00 GPU-h` package; optional `1.70 GPU-h @ 2×` `fresh_24_eval` canary, promote iff `>= 6/24` with `< 4/24` timeouts).
- **IF `B8 >= 0.20` (`>= 12/58`):** Lock `B8` in Slot 1; only consider `B9` if `B8 <= 0.22` and quota permits after `LoRA_v3`.
- **Locked `B9` Spec (`swe_gemma4_b9`):** `gemma-4-31b-it-qat-w4a16-ct` (Zero LoRA); **6 core tools** in `agent.yaml` (drops `get_code_neighbors`, `search_similar_code`, `get_code_subgraph`); `eval_config.yaml` = `240s / 40 calls / 8m / 80t`; `sampling.yaml` = `temp=0.1, top_p=0.90, max_out=8192, tb=1024, include_thoughts=false`; `prompts/system.md` = **`2,331 B` / `38` lines (`<= 2,509c`, `0` non-whitelisted braces)** restoring `docs_src/`, ignore-broken-tests, `PYTHONUTF8=1 NO_COLOR=1`, `-m "not network"`, and **banning `git stash`**, validated via `python build_posix_zip.py submissions/submission_B9` before staging.

---

## 5. Locked Slot 2 Specs (`E4B_LoRA_v1.5` Bridge & `LoRA_v3`), Non-Duplication Delta & Pre-Execution Patches

### 5.1. Immediate Bridge: `E4B_LoRA_v1.5` (`0.00` Kaggle GPU-h, Gated Locally on `mqg1cob`)
- **Model & Adapter:** `gemma-4-e4b-it-qat-w4a16-ct` + `adapters/e4b_qat_lora/` (`54` BF16 tensors, **`2,093,056` params**, `4.19 MB`, `r=8, a=16`, `L23` 7 mods + `L[29,30,35,41]` 5 mods, `0` dead `k/v` tensors).
- **`agent.yaml` (9-Tool Parity):** Single root `LlmAgent` (`swe_gemma4_e4b_qat_lora_v1_5`), keeping all 9 built-in tools in `agent.yaml` for 1:1 `v1` SFT tool-schema parity while **dropping `get_code_neighbors` from `prompts/system.md`**.
- **`eval_config.yaml` & `sampling.yaml`:** `240s / 40 calls / 8m / 80t` (0 nulls); `temp=0.15, top_p=0.90, max_out=8192, tb=1024, include_thoughts=false` (no `top_k: 1`).
- **`prompts/system.md`:** Strictly clamped to **`2,048` chars / `2,048` UTF-8 bytes LF (`15` lines, `0` `{var}` braces, `~476` tok `< 512W`)** — removes `\| tail -20`, full-file pytest, 2-attempt partial surrender, and `get_code_neighbors`, adds `-k <test_name>` and 2-strike `write_file` (`<=150L`), and never repeats `train99.zip`'s `2,656 B` (`~618`-tok) overflow.
- **Promotion Gate:** Submit `submission_E4B_LoRA_v1_5.zip` (`python build_posix_zip.py submissions/submission_E4B_LoRA_v1_5`) once `B8` clears lock **ONLY IF** local `mqg1cob` parity (`enable_thinking=True` fixed) beats both `LoRA_v1` (`2,149 B`) and `Base E4B + 2,048 B` (`no_call/task < 2.0`, `0` `-p no:anyio` bash emissions).

### 5.2. Primary Upgrade: `LoRA_v3` (31B AggreVaTe + True Active-Only E4B)
- **Active-Only E4B Targeting (`L24..41` omit `k/v`):**
  - `L0–23` (KV Owners): all 7 projections (`q,k,v,o,gate,up,down`). `L24–41` (KV Shared): 5 active projections (`q,o,gate,up,down`); `check_attention_k_eq_v()` = `False`.
- **Two-Arm Gate G2 Shootout (`1.50 GPU-h @ 2×`, `4×` Lean Fallback: `1.60 GPU-h` 1-arm):**
  - **Arm A:** `active_all_42`, `r=8, alpha=16` (**`17,440,768` params**, `516` tensors across `L0..41`).
  - **Arm B:** `active_mid_upper_17_41`, `r=8, alpha=16` (**`10,047,488` params**, `278` tensors across `L17..41`; or `r=16, alpha=32` = **`20,094,976` params** ONLY if corpus `>= 60` clean trajectories).
- **Corpus (`~52–60` trajectories, `<= 2/task`, `0` holdouts):** `31` unique clean `train_99` tasks (**strictly excluding `train99.zip` `requests_7315`**) + **`>= 18` clean 31B hinted AggreVaTe recoveries** (`2.50 GPU-h @ 2×`, `student_prefix_turns=6`), 100% re-headered to **`2,048 B` (`<= 2,136c`)**, **`--max_seq_len 12288`** (no tail truncation).
- **Hyperparameters, JET & Safety Assertions:** Native `bf16` QAT, `lr=1.0e-4`–`1.2e-4`, cosine decay, `dropout=0.05`, max `2.0` epochs (`1.5`/`2.0` ckpts), `NEFTune=0.0`, PLE/ViT/USM frozen, JET loss ($w_t = 0.0$ user/obs/`turn < student_prefix_turns`; `1.0` routine; `1.5` edit/repair; `2.0` `submit_patch`), `peft==0.22.0`, `pip uninstall -y torchao`, `assert r <= 16`, `assert not (enable_lora and speculative_config)`, flat PEFT zip sanitizer.
- **Two-Tier Gate (`1.60 GPU-h @ 2×`):** Balanced Shadow Dev (16 non-SFT, non-holdout tasks) + leading indicators -> Gate G2 (`30` holdouts, promote iff **`>= 7/30` genuine solves** with `len(patch.strip()) > 0`).

### 5.3. Prior-Work Non-Duplication Verification Table

| Candidate | Prior Failed Configs Checked Against | Exact Documented Delta | Duplication Verdict |
|---|---|---|---|
| **`E4B_LoRA_v1.5`** | `submission_E4B_LoRA_v1.zip` (`0.05`, `2,149 B`), `e4b_factory_train99.zip` (`2/99`, `2,656 B`) | Keeps `v1` `2,093,056`-param weights + `240/40/8/80` + 9-tool `agent.yaml` parity; drops `\| tail -20`, full-file pytest, partial surrender, & `get_code_neighbors` from prompt; clamps to **`2,048 B`** (`0` braces); gated locally on `mqg1cob` | **NO DUPLICATION — PASS** |
| **`E4B_LoRA_v3`** | `LoRA_v1` (`30` rows, `63×` `no:anyio`, `5` layers), `Var C` (`34.88M` `r=16` overfit), `LoRA_v2` (`33` rows/`29` tasks, frozen `L24..41`, `2,638 B`, `8192`) | Fixed `pfx` + pre-optimizer `L24..41` assertion; `~52–60` trajs (`>=18` 31B AggreVaTe, **excluding** `requests_7315`); 100% `2,048 B` re-headering; `--max_seq_len 12288`; `active_all_42 r=8` (`17.44M`) vs `17_41 r=8` (`10.05M`) | **NO DUPLICATION — PASS** |
| **`B9` (Cond. 31B)** | `B4` (`0.12`), `B6` (`0.08`), `B7` (`0.10`), `B8` (`3,193c`, `tb=4096`, drops `docs_src/`, `git stash`, graph tools) | Restores `tb=1024`, `40` calls, `temp=0.1/0.90`, `docs_src/`, ignore-broken-tests; drops 3 graph tools (6 core tools); bans `git stash`; clamps prompt to **`2,331 B`** (`<= 2,509c`); gated on `B8` LB (`0.12–0.19`) | **NO DUPLICATION — CONDITIONAL** |

### 5.4. 4 Mandatory Pre-Execution Code Patches (a)–(d) (`conflict_resolution_log.md` §4 #6)
*(Do NOT execute during this analysis/synthesis sprint; apply immediately upon sprint handoff before running factory/training jobs.)*
1. **Patch (a) — `build_master_engine.py:1185-1190`:** Remove the stale `ts_code.replace(...)` regex patcher that left Branch 2 (`|layers\.(2[4-9]|3[0-9]|4[0-1])`) unprefixed in `LoRA_v2`.
2. **Patch (b) — `kaggle_train_e4b_qat_lora.py:1715-1717` & `--max_seq_len 12288`:** Add pre-optimizer `named_parameters()` `L24..41` coverage assertion (`516` / `278` tensors) + `len(messages[0]) <= 2136` prompt length assertion inside `train()`, and enforce `--max_seq_len 12288`.
3. **Patch (c) — `sft_dataset_builder.py`:** Hard-reject `-p no:anyio`, `| tail`, premature surrender text, and `/workspace/repro*.py` writes in `sanitize_trajectory()`; exclude `train99.zip` `requests_7315` (`tests/test_adapters.py` edit); re-header **100%** of trajectories to the `2,048 B` `v1.5` prompt.
4. **Patch (d) — `win_phase2_tournament.py:798` & `win_local_sandbox.py:383`:** Pass `enable_thinking=True` in `win_phase2_tournament.py:798`; remove `"-p", "no:anyio"` at `win_local_sandbox.py:383`, add `NO_COLOR=1`/`PYTHONUTF8=1` at `:364–368`, and add `holdout30`/`shadow_dev` selectors at `:423–437`; switch `win_frontier_6harness_overnight.py:685` from `2,656 B` to `2,048 B`.

---

## 6. Validated Safe Levers vs. Permanent Engineering Bans

### 6.1. The 10 Validated Safe Tuning Levers (Safe to Optimize)
1. **Active-Only LoRA Layer Targeting:** L0–23 all 7 projections; L24–41 5 projections (omitting non-existent `k_proj`/`v_proj`).
2. **JET Normalized Loss Weighting:** Turn-level weighting ($0.0 \to 1.0 \to 1.5 \to 2.0$) prioritizing repair turns and verified halting.
3. **AggreVaTe Prefix Masking:** Masking student failure turns ($loss\_mask = 0$) while training on teacher recovery turns ($loss\_mask = 1$).
4. **Phase 1 Command Timeout Envelope:** `timeout_seconds: 240` (Phase 1 `run_command` protection; Phase 2 `verification_timeout_seconds` is fixed at `300s` on scorer per `HARNESS_README.md:559-560`).
5. **Task Time Envelope:** `max_time_minutes: 8`. Captures fixes that 31B finds between minutes 4 and 8.
6. **Thought Budget Clamping:** `thinking_budget: 1024` with `include_thoughts: false` (proven anchor on both 31B `B4`/`B9` and E4B; `B8` tests `4096` in queue). Prevents ADK 14k event compaction amnesia.
7. **Prompt Brevity on Small Model (E4B):** Strictly preserve system prompt `<= 497` tokens (`<= 2,136` chars; `v1.5` = `2,048 B`) to fit E4B's 512-token sliding window across 35 layers.
8. **Targeted Pytest Selectors:** Method-level `-k <func>` or `file.py::<func>` with `-x --tb=short -q`. Slashes test duration from 45s to 2–5s.
9. **Windowed File Reads:** Mandatory `start_line` and `end_line` ($\le 120$ lines). Eliminates blind read loops.
10. **Early Edit Pacing Directive:** Stage first educated `edit_file` by Steps 6–12. Guarantees non-empty diffs before budget exhaustion.

### 6.2. The Permanent Engineering Bans (Strictly Prohibited — Fatal Integrity Violations)
1. **KILL TIES / DARE Adapter Merging:** Unprincipled weight-space merging produces non-deterministic activation drift on QAT weights.
2. **KILL 3+ Epoch LoRA Training:** Strictly cap training at 2.0 epochs (saving checkpoints at 1.5 and 2.0 epochs) to prevent catastrophic memorization of small trajectory sets.
3. **KILL `-p no:anyio` in Agent Prompts:** Deterministically breaks async test fixtures across 79 Python test suites (FastAPI, Starlette).
4. **KILL `F6_Apex_Unified` on Base E4B in Local Factory:** Unadapted base E4B has a 92.86% logic failure rate; rollouts must mount fine-tuned PEFT adapters.
5. **KILL Standalone DPO / KTO / GRPO / NEFTune / Day-7 Logit Steering:** High variance, unverified reward functions, and instability on small-N code tasks.
6. **KILL 31B LoRA:** Adds 15–20% decode latency penalty (~1.3× slower decode) that cancels out accuracy gains inside the 12-hour container limit. Zero-LoRA single agent is the validated champion.
7. **Banning Composite Root Agents:** NEVER wrap root agent in `SequentialAgent` or `LoopAgent`. `agent_runner.py` §5.3 fails to bind `submit_patch` and crashes immediately. Root must be declarative `LlmAgent`.
8. **Banning `include_thoughts: true`:** Setting `include_thoughts: true` causes thought tokens to enter session history, breaching ADK's 14,336-token event compaction limit at Turn 4 and wiping prior file observations.
9. **Banning BitsAndBytes NF4 LoRA:** Centroid mismatch between NF4 and linear QAT W4A16 base weights collapses holdout solve rate from 15% to 5% (LB = 0.03). Always dequantize QAT to native bf16 before training.
10. **Banning Dual 31B UI Selection:** Selecting two 31B submissions simultaneously completely forfeits eligibility for the $10,000 Small-Model Bonus Track. Exactly one 31B and one E4B must be selected.

---

## 7. Offline Local Plane Playbook (RTX 2000 Ada 16GB) & AggreVaTe Factory

The local workstation runs continuous background operations at **zero Kaggle GPU quota cost**:

### 7.1. Drop-in Package Specification: `local_v8_dropin.zip`
- **Path:** `F:\AI\Benchmark\local_v8_dropin.zip` (7.10 MB, POSIX sys=3, ZIP_DEFLATED, 0 backslashes).
- **Target Remote Path:** `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent`.
- **Contents:** Harnesses with PEFT LoRA v1 mounting, unpacked adapter `adapters/e4b_qat_lora/` (4.19 MB, 54 tensors), 497-token prompt configuration, `splits_99_30.json`, `hinted_train_99_tasks.jsonl`, `generate_onpolicy_passes.py`, `generate_aggrevate_prefixes.py`, `AGGREVATE_SCHEMA.md`.

### 7.2. Remote PC Execution Directives
```powershell
cd "C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent"
Expand-Archive -Path .\local_v8_dropin.zip -DestinationPath . -Force

# Step 1: Pre-flight dry-runs (<10 seconds, 0 GPU spend)
python win_frontier_6harness_overnight.py --dry_run_test
python generate_onpolicy_passes.py --dry_run_test
python generate_aggrevate_prefixes.py --dry_run_test

# Step 2: Canary 1-task smoke test (~2 min)
python -u win_frontier_6harness_overnight.py --candidates E4B_LoRA_v1 --model_id ..\gemma-4-e4b-it --adapter_dir adapters\e4b_qat_lora --task_mode val20 --smoke1

# Step 3: Launch Overnight Rollout Factory on 99 Training Tasks
python -u win_frontier_6harness_overnight.py --factory --candidates E4B_LoRA_v1 --model_id ..\gemma-4-e4b-it --adapter_dir adapters\e4b_qat_lora --tasks_path tasks.jsonl --task_mode train99 --workers 1 --batch_size 1 --out_dir ..\e4b_lora_v1_factory

# Step 4: Extract Training Artifacts upon completion
# 4a. On-policy passing trajectories (capped <= 2/task)
python generate_onpolicy_passes.py --results_dir ..\e4b_lora_v1_factory --out_jsonl onpolicy_lora_v1_passing.jsonl --max_per_task 2

# 4b. Structured AggreVaTe failure prefixes (turns 3-6, targeting ~25-30 prefixes)
python generate_aggrevate_prefixes.py --results_dir ..\e4b_lora_v1_factory --out_jsonl aggrevate_failure_prefixes.jsonl --target_count 28
```

### 7.3. Shared AggreVaTe Schema Contract (`AGGREVATE_SCHEMA.md`)
Every record in `aggrevate_failure_prefixes.jsonl` adheres strictly to:
```json
{
  "task_id": "fastapi_14986",
  "messages": [ ... ],
  "student_prefix_turns": 4,
  "failure_mode": "edit_file_failure",
  "source_model": "gemma-4-e4b-it-qat-lora-v1"
}
```
*Failure Modes:* `edit_file_failure`, `failing_pytest_traceback`, `syntax_error`, `stuck_in_loop`, `wrong_file_inspected`, `unresolved_search_divergence`.

### 7.4. Remote Workstation Live Execution Status (Session 13)
The remote workstation (NVIDIA RTX 2000 Ada 16GB, host `mqg1cob`) is actively executing offline rollout operations:
- **Deployment:** `local_v8_dropin.zip` (7.10 MB) successfully unpacked at `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent`.
- **Extraction Pass 1 Verified:**
  - `onpolicy_lora_v1_passing.jsonl`: 3 verified passing trajectories (`fastapi`: 1, `Textualize/rich`: 2) extracted via `generate_onpolicy_passes.py`.
  - `aggrevate_failure_prefixes.jsonl`: 28 structured student failure prefixes (`edit_file_failure`: 13, `stalling_no_call_turn`: 9, `failing_pytest_traceback`: 6) extracted at horizon turn 6 via `generate_aggrevate_prefixes.py`.
- **Active Rollout Factory Run:**
  - Command: `python -u win_frontier_6harness_overnight.py --factory --candidates E4B_LoRA_v1 --model_id ..\gemma-4-e4b-it --adapter_dir adapters\e4b_qat_lora --tasks_path tasks.jsonl --task_mode train99 --workers 1 --batch_size 1 --out_dir ..\e4b_lora_v1_factory`
  - VRAM Utilization: Active language-only footprint = 8.67 GiB / 16.00 GiB (zero NF4, hybrid CPU offload).
  - Scope: Rolling out candidate `E4B_LoRA_v1` across the 99 training tasks (`splits_99_30.json`) with persistent disk caching enabled.
  - Objective: Harvesting fresh on-policy passes and teacher-recovery prefixes for future SFT/AggreVaTe fine-tuning without consuming any Kaggle GPU hours.

### 7.5. Post-Nov 25 Factory Audit (`e4b_factory_train99.zip`) & Mandatory Patch (d)
- **`e4b_factory_train99.zip` (`2026-11-25T00:01:20`):** Ran `E4B_LoRA_v1` across `train_99` with `local_v8_dropin/prompts/system.md` (`2,656 B` CRLF / `2,638 B` LF, mislabeled `"497-tok"` in `summary.json`), collapsing to **`2/99 (2.02%)`**, `28/99` patches, **`1,882` `s02:<eos>` turns (`49.2%`)**, `589.38m`. Its `requests_7315` solve edited `tests/test_adapters.py` 7 times with line prefixes (`'    8 | ...'`) and is **rejected via Guard 6/7**.
- **Required Pre-Run Fixes:** Apply **Patch (d)** (`win_phase2_tournament.py:798` `enable_thinking=True`; `win_local_sandbox.py:383` remove `"-p", "no:anyio"`, add `NO_COLOR=1`/`PYTHONUTF8=1`, add `holdout30`/`shadow_dev` selectors) and switch `win_frontier_6harness_overnight.py:685` from `2,656 B` to the **`2,048 B` `v1.5` prompt** before running new `mqg1cob` rollouts.

---

## 8. Complete Project Artifact & Deliverables Index

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   CANONICAL PROJECT DELIVERABLES INDEX                                 │
├────────────────────────────────────────┬───────────────────────────────────────────────────────────────┤
│ DELIVERABLE DESCRIPTION                │ CANONICAL FILE PATH                                           │
├────────────────────────────────────────┼───────────────────────────────────────────────────────────────┤
│ Master Repository Overview & Index     │ MASTER_OVERVIEW.md                                            │
│ Comprehensive 11-Day Action Plan       │ plans/ACTION_PLAN_11_DAY_ROADMAP.md                           │
│ Turnkey Agent Continuation Dossier     │ plans/AGENT_CONTINUATION_DOSSIER.md                           │
│ Master Technical Architecture Blueprint│ plans/MASTERPLAN.md                                           │
│ Redundancy Cleanup Log & Audit         │ REDUNDANCY_CLEANUP_LOG.md                                     │
│ AggreVaTe Shared Schema & Contract     │ AGGREVATE_SCHEMA.md                                           │
│ Remote Workstation Drop-in Bundle v8   │ local_v8_dropin.zip (7.10 MB, POSIX sys=3, 0 backslashes)     │
│ Candidate B8 Kaggle Workbook           │ Kaggle_B8_PreSubmit_Diagnostic.ipynb / .py                    │
│ 31B Teacher Passing Trajectories Pack  │ passing_trajectories_pack.zip (239 KB)                         │
│ Experiment Validation Report (M2)      │ reports/EXPERIMENT_VALIDATION_REPORT.md                       │
│ Strategic Deep Dive & Guardrails (M3)  │ reports/STRATEGIC_DEEP_DIVE_ANALYSIS.md                       │
│ ML Research: Model Dynamics (M4A)      │ reports/ML_RESEARCH_MODEL_DYNAMICS.md                         │
│ Harness Engineering & Compliance (M4B) │ reports/HARNESS_ENGINEERING_RESEARCH.md                       │
│ Statistical Analysis of 78 Episodes    │ reports/EPISODES_78_STATISTICAL_ANALYSIS.md                   │
│ Fresh 24 Holdout Audit (B6 vs B6d)     │ reports/FRESH_24_HOLDOUT_AUDIT.md                             │
│ 31B Part B Teacher Harvest Report      │ reports/PART_B_31B_TEACHER_HARVEST.md                         │
│ Local 69 E4B Rollout Trace Forensics   │ reports/E4B_69_TRACE_ROLLOUT_FORENSICS.md                     │
│ LoRA v2 Forensic & Contingency Report  │ reports/E4B_LORA_V2_FORENSIC_AND_CONTINGENCY_REPORT.md (8,669 B / 129L, Nov 24; CR-03/CR-12 errata: 12.4M->6,184,960 Arm B params, 31->29 tasks, Phase 3 local 4-bit QAT on RTX 2000 Ada KILLED) │
│ Unified Kaggle Master Engine (Phase 1-5│ Kaggle_Master_Clubbed_Engine.ipynb / .py                      │
│ Master Engine Synchronizer Script      │ build_master_engine.py                                        │
│ Native QAT LoRA Training Script        │ kaggle_train_e4b_qat_lora.py                                  │
│ 8-Guard SFT Dataset Builder Script     │ sft_dataset_builder.py                                        │
│ Hermetic POSIX ZIP Packager Engine     │ build_posix_zip.py                                            │
│ Windows Local SWE-gemma Sandbox        │ win_local_sandbox.py                                          │
│ Multi-Agent Frontier Tournament Engine │ win_frontier_6harness_overnight.py                            │
│ On-Policy Passing Trajectory Generator │ generate_onpolicy_passes.py                                   │
│ AggreVaTe Failure Prefix Generator     │ generate_aggrevate_prefixes.py                                │
│ Zero-GPU Patch Re-grading Engine       │ regrade_overnight_patches.py                                  │
│ Production SFT Training Corpus (33 Tr) │ e4b_sft_train.jsonl (1,105,099 B, SHA 3285e319, 29 tasks, 2,637c)│
│ Reconciled SFT Corpus v2 (30 Tr)       │ e4b_sft_train_v2.jsonl (30 Tr, 28 Unique, 78x no:anyio, 2,135c)│
│ Expanded SFT Corpus v3 (33 Tr)         │ e4b_sft_train_v3.jsonl (33 Tr, 29 Unique, 0 no:anyio, 2,637c!)│
│ Quarantined Holdout Solves (3 Tr)      │ e4b_sft_holdout_quarantine.jsonl (Zero Leakage into SFT v3)   │
│ Reconciled SFT Provenance Log v2       │ e4b_sft_provenance_v2.json                                    │
│ Slot 1 Official Active Champion (0.12) │ submissions/submission_B4.zip                                 │
│ Slot 1 Staged Candidate B8 Champion    │ submissions/submission_B8.zip (tb=4096, 3,193 B, Queue)       │
│ Slot 2 Small-Model Baseline Floor      │ submissions/submission_E4B_F3_v2.zip (30s/24/6m, 2,136 B ZIP) │
│ Slot 2 Gate G2 Tournament Champion     │ submissions/submission_E4B_LoRA_v1.zip (240s/40/8m, 54 tensors)│
│ Gate G2 v1 Results & Log (L1295/1433)  │ resultskaggle_final.zip / resultskaggle_final.log             │
│ LoRA v2 Failed Results & ZIP (NO-GO)   │ kaggle_e4b_lora_v2_results/ (Arm A 20.97M, Arm B 6.18M)       │
│ Nov 25 Local Train99 Factory Archive   │ e4b_factory_train99.zip (2/99, 2,656 B, requests_7315 REJECT) │
│ Prompt Length Guard Script (<=2,136c)  │ scripts/check_e4b_len.py                                      │
│ 31B Hinted Passing Corpus (27/23)      │ raw_hinted_31b_passing.jsonl (0/27 thought blocks)            │
│ AggreVaTe Prefixes (46 Unique Tasks)   │ aggrevate_failure_prefixes.jsonl (root 28, v1_factory 28, train99 28)│
│ *Non-Existent File Warning (CR-08)*    │ *asvd_atp_kl_attribution.json DOES NOT EXIST on disk (never cite)*│
└────────────────────────────────────────┴───────────────────────────────────────────────────────────────┘
```

---

## 9. Session 13 Kaggle LoRA v2 Launch Forensics & Resolution

### 9.1. Observed Failure from `lora-e4b.log`
On executing `Kaggle_Master_Clubbed_Engine.ipynb` on Kaggle 4x L4 GPUs:
* **Cell 1 Warning:** Retried connecting to PyPI for `peft==0.22.0` on internet-disabled environment (~200s timeout delay).
* **Cell 2 Hard Crash:** Threw `AssertionError: Expected 73 unsolved tasks, got 70` at line 58.

### 9.2. Root Cause
* **Cell 2 Task Count:** `UNSOLVED_73_IDS` had hardcoded `assert len(UNSOLVED_73_IDS) == 73`. When using the sanitized dataset with 29 unique solved training instances, $99 - 29 = 70$ unsolved tasks remained. The static assertion failed despite zero holdout leakage and full `FAST_RESUME` readiness.
* **Phase 3A PEFT Target Modules:** PEFT's `inject_adapter` executes `re.fullmatch(target_modules, key)` against `model.language_model.model.layers.<i>.*`. The target regex lacked a leading `.*language_model.*` prefix, causing PEFT to reject target modules with `ValueError: Target modules ... not found in the base model`.

### 9.3. Applied Fixes
1. Changed Cell 2 task partitioning to dynamic count:
   `expected_unsolved = len(TRAIN_99_IDS) - len(set(existing_solved_ids) & set(TRAIN_99_IDS))`
   `assert len(UNSOLVED_TRAIN_IDS) == expected_unsolved`
   `assert written_count == len(UNSOLVED_TRAIN_IDS)`
2. Changed Cell 1 PEFT installation to use local wheelhouse `.whl` files (zero online PyPI queries).
3. Prefixed all target regexes in `kaggle_train_e4b_qat_lora.py` with `r".*language_model.*layers\."` to guarantee 100% `re.fullmatch` coverage across all 42 E4B transformer layers.
4. Added self-healing auto-patching in Cell 5 of `Kaggle_Master_Clubbed_Engine.ipynb` to dynamically heal any existing trainer scripts in `/kaggle/working`.
5. Regenerated `Kaggle_Master_Clubbed_Engine.ipynb` (113,216 bytes) & `Kaggle_Master_Clubbed_Engine.py` (97,383 bytes).
6. Rebuilt `swegemma_lora_bundle.zip` (608,987 bytes).

### 9.4. Post-Mortem Update on Cell 5 Auto-Patcher (`LoRA_v2`)
Although §9.3 item 3 fixed root `kaggle_train_e4b_qat_lora.py:118`, item 4's Cell 5 self-healing patcher (`build_master_engine.py:1185-1190`) left Branch 2 (`|layers\.(2[4-9]|3[0-9]|4[0-1])`) unprefixed on cached `kaggle_e4b_lora_v2_results/kaggle_train_e4b_qat_lora.py:135-156`, silently freezing `L24..41` in `LoRA_v2` (`Arm A` `20,971,520` `L0..23`; `Arm B` `6,184,960` `L17..23`). **Patches (a) & (b)** (§5.4) permanently eliminate this failure mode.

---
*End of Turnkey Agent Continuation Dossier (`plans/AGENT_CONTINUATION_DOSSIER.md`).*
