#!/usr/bin/env python3
"""
Real-Trajectory SFT Dataset Builder, Sanitizer & Provenance Logger (Slot 2: E4B QAT LoRA).

Enforces every competition & quality invariant from GEMMA4_BATTLE_PLAN_NOV18.md & HARNESS_README.md:
  1. Gemma-Only Provenance (Rule 4 & Rule 5): rejects non-Gemma sources; logs full run provenance & SHA-256.
  2. Strict 99/30 Holdout Isolation: hard-rejects any trajectory whose instance_id is in the 30-task holdout.
  3. Verified Pass Gate: keeps ONLY real trajectories with resolved==True (F2P & P2P passed) and patch_len > 0.
  4. Unhinted Prompt Swap + Hint-Leakage Filter: replaces hinted user prompt with exact unhinted problem_statement
     from tasks.jsonl and drops any trajectory whose assistant/thought text references the hint.
  5. Gemma-4 Tool & Thought Schema Validation:
       - System prompt normalized to deployment prompt (default: submission_E4B_F3_v2/prompts/system.md).
       - Every assistant tool call formatted in canonical {"type": "function", "function": {"name", "arguments"}}.
       - Every role=="tool" message MUST carry "name" matching the call and valid JSON content (rejects fake stubs!).
       - Rejects protected-file edits (tests/, conftest.py, pyproject.toml, setup.cfg, tox.ini).
       - Preserves <|channel>thought...<channel|> reasoning blocks, capped cleanly at <= max_thought_tokens (default 1024).
  6. Diversity Caps:
       - At most --max_per_task trajectories per task (default 2; prefers shortest clean passing runs + source diversity).
       - At most --max_repo_share fraction per repository (default 0.40, relaxed only if total < 10 with explicit warning).

Usage:
    # Run built-in unit test suite to verify every guard:
    python sft_dataset_builder.py --self_test

    # Build clean E4B SFT training corpus from real passing trajectory JSONL files:
    python sft_dataset_builder.py \
        --inputs hinted_31b_passing.jsonl onpolicy_e4b_passing.jsonl \
        --splits splits_99_30.json \
        --tasks tasks.jsonl \
        --system_prompt submission_E4B_F3_v2/prompts/system.md \
        --out_jsonl e4b_sft_train.jsonl \
        --out_provenance e4b_sft_provenance.json
"""
import argparse
import datetime as dt
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
import zipfile

ALLOWED_TOOLS = {
    "run_command", "read_file", "edit_file", "write_file",
    "get_status", "submit_patch", "search_similar_code",
    "get_code_neighbors", "get_code_subgraph",
}

EXCLUDED_CONTAMINATED_E4B_IDS = {"requests_7315"}

PROTECTED_FILE_PATTERNS = (
    re.compile(r"(^|/)tests?/"),
    re.compile(r"(^|/)test_[^/]+\.py$"),
    re.compile(r"(^|/)[^/]+_test\.py$"),
    re.compile(r"(^|/)conftest\.py$"),
    re.compile(r"(^|/)pyproject\.toml$"),
    re.compile(r"(^|/)setup\.cfg$"),
    re.compile(r"(^|/)pytest\.ini$"),
    re.compile(r"(^|/)tox\.ini$"),
)

HINT_LEAK_PATTERNS = [
    re.compile(r"\b(as|per|from|according to)\s+(the\s+)?hint\b", re.I),
    re.compile(r"\bhint(ed|s)?\s+(says|mentions|points|indicates|file|function|target)\b", re.I),
    re.compile(r"\bgold\s+(patch|file|function|target|diff)\b", re.I),
    re.compile(r"\byou\s+(told|gave|provided)\s+me\s+(the\s+)?(file|hint|function)\b", re.I),
    re.compile(r"\[LOCALIZATION_HINT\]", re.I),
    re.compile(r"ORACLE_HINT", re.I),
]

PRIVILEGE_LEAK_PATTERNS = [
    re.compile(r"\b(as|per|from|according to)\s+(the\s+)?(oracle\s+)?hint\b", re.I),
    re.compile(r"\bhint(ed|s)?\s+(says|mentions|points|indicates|file|function|target|identifies)\b", re.I),
    re.compile(r"\b(oracle|privileged)\s+(hint|information|knowledge|tutoring|trace|diff)\b", re.I),
    re.compile(r"\bgold\s+(patch|file|function|target|diff|solution|commit)\b", re.I),
    re.compile(r"\byou\s+(told|gave|provided)\s+me\s+(the\s+)?(file|hint|function|target)\b", re.I),
    re.compile(r"\[LOCALIZATION_HINT\]", re.I),
    re.compile(r"ORACLE_HINT", re.I),
    re.compile(r"\bcheat\s*sheet\b", re.I),
    re.compile(r"\bthe\s+solution\s+file\s+is\b", re.I),
    re.compile(r"\bground\s+truth\s+(fix|patch|file)\b", re.I),
]


def audit_and_strip_privilege_leak(content: str) -> tuple[str, bool, list[str]]:
    """
    Audits content for privilege/oracle leak phrases.
    If present inside reasoning/thought blocks, strips the offending sentences cleanly
    while keeping un-leaked reasoning steps.
    If no un-leaked sentences remain in the thought block, replaces with an unhinted
    diagnostic thought.
    Returns (sanitized_content, was_modified, remaining_leak_patterns).
    """
    matched: list[str] = [rx.pattern for rx in PRIVILEGE_LEAK_PATTERNS if rx.search(content)]
    if not matched:
        return content, False, []

    was_modified = False

    def _clean_thought_block(m: re.Match) -> str:
        nonlocal was_modified
        inner = m.group(1)
        lines = inner.split("\n")
        kept_lines = []
        for line in lines:
            line_has_leak = any(rx.search(line) for rx in PRIVILEGE_LEAK_PATTERNS)
            if not line_has_leak:
                kept_lines.append(line)
            else:
                was_modified = True

        cleaned_inner = "\n".join(kept_lines).strip()
        if not cleaned_inner:
            cleaned_inner = "Analyzing repository codebase and traceback for bug localization."
            was_modified = True
        return f"<|channel>thought\n{cleaned_inner}\n<channel|>"

    # Strip privilege leak from inside thought blocks
    if "<|channel>thought" in content:
        content = THOUGHT_BLOCK_RE.sub(_clean_thought_block, content)

    # After thought block stripping, check if any leak remains
    remaining_leaks = [rx.pattern for rx in PRIVILEGE_LEAK_PATTERNS if rx.search(content)]
    if remaining_leaks:
        lines = content.split("\n")
        kept_lines = []
        for line in lines:
            if not any(rx.search(line) for rx in PRIVILEGE_LEAK_PATTERNS):
                kept_lines.append(line)
            else:
                was_modified = True
        content = "\n".join(kept_lines).strip()

    remaining_leaks = [rx.pattern for rx in PRIVILEGE_LEAK_PATTERNS if rx.search(content)]
    return content, was_modified, remaining_leaks

FAKE_STUB_PATTERNS = [
    re.compile(r"^Showing lines \d+\.\.\d+ of "),
    re.compile(r"^# target$"),
]

ALLOWED_PROVENANCE_MODEL_SUBSTRINGS = (
    "gemma-4-31b", "gemma-4-12b", "gemma-4-e4b", "gemma-4-e2b",
    "gemma4", "gemma-4",
)

THOUGHT_BLOCK_RE = re.compile(r"<\|channel>thought\s*(.*?)<channel\|>", re.S)


def sha256_file(path: Path) -> str:
    path = Path(path)
    if path.is_dir():
        h = hashlib.sha256()
        for p in sorted(path.glob("**/*")):
            if p.is_file():
                h.update(p.name.encode("utf-8"))
                with p.open("rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
        return h.hexdigest()
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_raw_records(inp: Path) -> list[tuple[dict, Path]]:
    """
    Recursively collect raw trajectory dicts from a .jsonl file, .json file, or directory.
    Guarantees seamless ingestion of individual trace .json files from win_frontier_6harness_overnight
    as well as consolidated .jsonl files.
    """
    inp = Path(inp)
    records: list[tuple[dict, Path]] = []
    if inp.is_dir():
        for sub_p in sorted(inp.glob("**/*")):
            if sub_p.is_file() and sub_p.suffix.lower() in (".json", ".jsonl"):
                records.extend(collect_raw_records(sub_p))
        return records

    if not inp.is_file():
        return records

    # If file has .json extension, try full JSON load (single record or list of records)
    if inp.suffix.lower() == ".json":
        try:
            content = inp.read_text(encoding="utf-8").strip()
            if content:
                parsed = json.loads(content)
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict):
                            records.append((item, inp))
                    return records
                elif isinstance(parsed, dict):
                    records.append((parsed, inp))
                    return records
        except Exception:
            pass

    # Read line-by-line for .jsonl or fallback
    try:
        with inp.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    parsed = json.loads(line)
                    if isinstance(parsed, dict):
                        records.append((parsed, inp))
                except Exception:
                    pass
    except Exception:
        pass
    return records


def load_tasks_index(tasks_path: Path) -> dict[str, dict]:
    idx: dict[str, dict] = {}
    with tasks_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            idx[d["instance_id"]] = d
    return idx


def is_protected_path(filepath: str) -> bool:
    p = str(filepath or "").strip().replace("\\", "/").lstrip("/")
    p = re.sub(r"^workspace/", "", p)
    return any(rx.search(p) for rx in PROTECTED_FILE_PATTERNS)


def cap_thought_block(text: str, max_thought_tokens: int = 1024) -> tuple[str, int]:
    """
    Cap any <|channel>thought...<channel|> block at ~max_thought_tokens (~3.6 chars/token
    conservative bound) while preserving exact Gemma-4 delimiters.
    Returns (capped_text, num_thoughts_truncated).
    """
    if not text or "<|channel>thought" not in text:
        return text, 0
    max_chars = int(max_thought_tokens * 3.6)
    trunc_count = 0

    def _repl(m: re.Match) -> str:
        nonlocal trunc_count
        body = m.group(1)
        if len(body) <= max_chars:
            return m.group(0)
        trunc_count += 1
        cut = body[:max_chars].rsplit(" ", 1)[0].rstrip()
        return f"<|channel>thought\n{cut}\n...<channel|>"

    return THOUGHT_BLOCK_RE.sub(_repl, text), trunc_count


def normalize_tool_call(tc: dict, call_idx: int) -> tuple[dict | None, str | None]:
    """Normalize a tool call dict into canonical OpenAI/Gemma-4 function-call schema."""
    if not isinstance(tc, dict):
        return None, "tool_call_not_dict"
    if "function" in tc and isinstance(tc["function"], dict):
        fn_obj = tc["function"]
        name = str(fn_obj.get("name") or "").strip()
        raw_args = fn_obj.get("arguments", {})
    else:
        name = str(tc.get("name") or "").strip()
        raw_args = tc.get("arguments", tc.get("args", {}))

    if name not in ALLOWED_TOOLS:
        return None, f"unknown_tool:{name}"

    if isinstance(raw_args, str):
        try:
            args_dict = json.loads(raw_args) if raw_args.strip() else {}
        except Exception:
            return None, f"unparseable_tool_args:{name}"
    elif isinstance(raw_args, dict):
        args_dict = dict(raw_args)
    else:
        return None, f"invalid_tool_args_type:{name}"

    # Canonicalize alias 'path' -> 'filepath' for workspace tools (1:1 HARNESS_README.md §6 parity)
    if name in ("read_file", "edit_file", "write_file") and "filepath" not in args_dict and "path" in args_dict:
        args_dict["filepath"] = args_dict.pop("path")

    # Reject diff-header leakage, workspace repro scripts, or placeholder stubs inside edit/write/cmd
    if name == "edit_file":
        fp = str(args_dict.get("filepath") or "")
        if is_protected_path(fp):
            return None, f"protected_file_edit:{fp}"
        fp_norm = fp.strip().replace("\\", "/")
        if not fp_norm.startswith("/tmp/") and re.search(r"(^|/)repro[^/]*\.py$", fp_norm, re.I):
            return None, f"workspace_repro_write:{fp}"
        old_s = str(args_dict.get("old_string", ""))
        new_s = str(args_dict.get("new_string", ""))
        if not old_s.strip():
            return None, "empty_edit_old_string"
        if "-- a/" in old_s or "++ b/" in new_s:
            return None, "diff_header_leak_in_edit"
        if any(rx.match(old_s.strip()) for rx in FAKE_STUB_PATTERNS):
            return None, "fake_stub_edit"
    elif name == "write_file":
        fp = str(args_dict.get("filepath") or "")
        if is_protected_path(fp):
            return None, f"protected_file_write:{fp}"
        fp_norm = fp.strip().replace("\\", "/")
        if not fp_norm.startswith("/tmp/") and re.search(r"(^|/)repro[^/]*\.py$", fp_norm, re.I):
            return None, f"workspace_repro_write:{fp}"
    elif name == "run_command":
        cmd_s = str(args_dict.get("command") or "")
        if "no:anyio" in cmd_s.lower():
            return None, "forbidden_no_anyio"
        if re.search(r"\|\s*tail\b", cmd_s, re.I):
            return None, "forbidden_pipe_tail"

    norm = {
        "id": str(tc.get("id") or f"call_{call_idx}"),
        "type": "function",
        "function": {
            "name": name,
            "arguments": args_dict,
        },
    }
    return norm, None


def sanitize_trajectory(
    raw: dict,
    holdout_set: set[str],
    tasks_index: dict[str, dict],
    system_prompt: str,
    max_thought_tokens: int = 1024,
    require_thoughts: bool = False,
    strip_privilege_leaks: bool = False,
    accept_prebuilt_sft: bool = False,
) -> tuple[dict | None, str | None]:
    """
    Validate and sanitize a single raw rollout trajectory.
    Returns (sanitized_record, rejection_reason).
    """
    tid = str(raw.get("instance_id") or raw.get("task_id") or "").strip()
    if not tid or tid not in tasks_index:
        return None, "unknown_instance_id"

    if tid in holdout_set:
        return None, "holdout_task_excluded"

    is_prebuilt_sft = (
        accept_prebuilt_sft
        and all(k in raw for k in ("has_thoughts", "num_assistant_turns", "num_tool_calls", "run_id"))
        and "resolved" not in raw
    )
    if not raw.get("resolved", False) and not is_prebuilt_sft:
        return None, "not_resolved"

    patch_len = int(raw.get("patch_len", len(str(raw.get("patch", "")))) or 0)
    if patch_len < 10:
        return None, "empty_or_trivial_patch"

    # Rule 4 provenance guard: Gemma-generated only
    source_model = str(raw.get("source_model") or "").strip()
    if not source_model or not any(tok in source_model.lower() for tok in ALLOWED_PROVENANCE_MODEL_SUBSTRINGS):
        return None, f"disallowed_source_model:{source_model or 'missing'}"

    rollout_mode_raw = str(raw.get("rollout_mode") or "unknown").strip()
    if tid in EXCLUDED_CONTAMINATED_E4B_IDS and "31b" not in source_model.lower() and "aggrevate" not in rollout_mode_raw.lower():
        return None, "excluded_contaminated_train99_task"

    raw_msgs = raw.get("messages")
    if not isinstance(raw_msgs, list) or len(raw_msgs) < 4:
        return None, "too_few_messages"

    student_prefix_turns = int(raw.get("student_prefix_turns") or 0)
    failure_mode = str(raw.get("failure_mode") or "none")

    task_meta = tasks_index[tid]
    unhinted_problem = str(task_meta.get("problem_statement") or "").strip()
    if not unhinted_problem:
        return None, "missing_problem_statement"

    cleaned_msgs: list[dict] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": unhinted_problem},
    ]

    # Skip leading system/user messages from raw rollout (we always swap in canonical unhinted pair)
    start_idx = 0
    while start_idx < len(raw_msgs) and raw_msgs[start_idx].get("role") in ("system", "user"):
        start_idx += 1

    pending_calls: list[tuple[str, str]] = []  # (call_id, tool_name)
    call_counter = 0
    num_assistant_turns = 0
    num_edits = 0
    num_real_reads = 0
    has_any_thought = False
    thoughts_truncated = 0

    for m in raw_msgs[start_idx:]:
        role = str(m.get("role") or "").strip()
        content = str(m.get("content") or "")

        if role == "assistant":
            # Reject poisoned prompt behaviors in assistant messages (no:anyio / | tail / partial surrender)
            low_content = content.lower()
            if "no:anyio" in low_content:
                return None, "forbidden_no_anyio"
            if re.search(r"\|\s*tail\b", low_content):
                return None, "forbidden_pipe_tail"
            if "partial patches earn score" in low_content or "after 2 fix attempts, call submit_patch" in low_content:
                return None, "forbidden_surrender_text"

            # Check for hint leakage in assistant text OR separate reasoning_content field
            thought_field = str(m.get("reasoning_content") or m.get("thought") or "").strip()
            if thought_field and "<|channel>thought" not in content:
                content = f"<|channel>thought\n{thought_field}<channel|>\n{content}".strip()

            if strip_privilege_leaks:
                content, was_mod, rem_leaks = audit_and_strip_privilege_leak(content)
                if rem_leaks:
                    return None, f"hint_leak_detected:{rem_leaks[0][:32]}"
            else:
                for rx in HINT_LEAK_PATTERNS:
                    if rx.search(content):
                        return None, f"hint_leak_detected:{rx.pattern[:32]}"

            if "<|channel>thought" in content:
                has_any_thought = True
            content, t_trunc = cap_thought_block(content, max_thought_tokens=max_thought_tokens)
            thoughts_truncated += t_trunc

            raw_tcs = m.get("tool_calls") or []
            norm_tcs = []
            for tc in raw_tcs:
                call_counter += 1
                ntc, err = normalize_tool_call(tc, call_counter)
                if err:
                    return None, err
                norm_tcs.append(ntc)
                fn_name = ntc["function"]["name"]
                pending_calls.append((ntc["id"], fn_name))
                if fn_name in ("edit_file", "write_file"):
                    num_edits += 1

            loss_mask_val = 0 if num_assistant_turns < student_prefix_turns else 1
            msg_out: dict = {
                "role": "assistant",
                "content": content,
                "loss_mask": loss_mask_val,
            }
            if norm_tcs:
                msg_out["tool_calls"] = norm_tcs
            cleaned_msgs.append(msg_out)
            num_assistant_turns += 1

        elif role == "tool":
            t_name = str(m.get("name") or "").strip()
            t_cid = str(m.get("tool_call_id") or "").strip()
            if not t_name and pending_calls:
                t_cid_exp, t_name = pending_calls.pop(0)
                t_cid = t_cid or t_cid_exp
            elif pending_calls:
                t_cid_exp, exp_name = pending_calls.pop(0)
                if t_name != exp_name:
                    return None, f"tool_name_mismatch:{t_name}!={exp_name}"
                t_cid = t_cid or t_cid_exp

            if not t_name or t_name not in ALLOWED_TOOLS:
                return None, f"missing_or_invalid_tool_name:{t_name}"

            # Reject fake read stubs
            if any(rx.match(content.strip()) for rx in FAKE_STUB_PATTERNS):
                return None, "fake_tool_stub_response"

            # Verify tool response is valid JSON
            try:
                parsed_obs = json.loads(content)
                if not isinstance(parsed_obs, dict):
                    return None, "tool_response_not_json_object"
            except Exception:
                return None, "tool_response_not_json"

            if t_name == "read_file" and parsed_obs.get("status") == "ok" and len(str(parsed_obs.get("content", ""))) > 20:
                num_real_reads += 1

            cleaned_msgs.append({
                "role": "tool",
                "tool_call_id": t_cid or f"call_{call_counter}",
                "name": t_name,
                "content": content,
            })

        elif role == "user":
            if strip_privilege_leaks:
                content, was_mod, rem_leaks = audit_and_strip_privilege_leak(content)
                if rem_leaks:
                    return None, "hint_leak_in_user_turn"
            else:
                for rx in HINT_LEAK_PATTERNS:
                    if rx.search(content):
                        return None, "hint_leak_in_user_turn"
            cleaned_msgs.append({"role": "user", "content": content})

    if num_edits == 0:
        return None, "zero_edits"
    if num_real_reads == 0:
        return None, "zero_real_read_file_observations"
    if require_thoughts and not has_any_thought:
        return None, "missing_thought_blocks"

    # Reject trajectories with mid-trajectory tool-less `no_call` prose loops
    # (Allow at most 1 final summary assistant turn after submit_patch)
    asst_positions = [i for i, m in enumerate(cleaned_msgs) if m.get("role") == "assistant"]
    no_call_positions = [i for i in asst_positions if not cleaned_msgs[i].get("tool_calls")]
    if len(no_call_positions) > 1 or (
        len(no_call_positions) == 1 and no_call_positions[0] != asst_positions[-1]
    ):
        return None, "forbidden_no_call_prose_loop"

    sanitized = {
        "task_id": tid,
        "instance_id": tid,
        "messages": cleaned_msgs,
        "student_prefix_turns": student_prefix_turns,
        "failure_mode": failure_mode,
        "source_model": source_model,
        "repo": task_meta["repo"],
        "rollout_mode": str(raw.get("rollout_mode") or "unknown"),
        "run_id": str(raw.get("run_id") or "unspecified"),
        "num_assistant_turns": num_assistant_turns,
        "num_tool_calls": call_counter,
        "patch_len": patch_len,
        "has_thoughts": has_any_thought,
        "thoughts_truncated": thoughts_truncated,
    }
    return sanitized, None


def apply_diversity_caps(
    candidates: list[dict],
    max_per_task: int = 2,
    max_repo_share: float = 0.40,
) -> tuple[list[dict], dict]:
    """
    Apply per-task cap (strictly <= 2 per task instance, preferring shortest clean runs + diverse source_models)
    and per-repo cap (<= max_repo_share).
    """
    # Enforce strict <= 2 ceiling
    max_per_task = min(max(1, int(max_per_task)), 2)

    # Deduplicate identical trajectories before per-task capping
    deduped: list[dict] = []
    seen_sigs: set[tuple] = set()
    dropped_duplicates = 0
    for c in candidates:
        asst_sig = tuple(
            (
                m.get("content", "")[:200],
                tuple(tc.get("function", {}).get("name", "") for tc in (m.get("tool_calls") or [])),
            )
            for m in (c.get("messages") or [])
            if m.get("role") == "assistant"
        )
        sig = (c["instance_id"], c["source_model"], c["rollout_mode"], c["run_id"], asst_sig)
        if sig in seen_sigs:
            dropped_duplicates += 1
            continue
        seen_sigs.add(sig)
        deduped.append(c)

    by_task: dict[str, list[dict]] = defaultdict(list)
    for c in deduped:
        by_task[c["instance_id"]].append(c)

    after_task_cap: list[dict] = []
    dropped_task_cap = 0
    for tid in sorted(by_task.keys()):
        group = sorted(by_task[tid], key=lambda x: (x["num_tool_calls"], x["num_assistant_turns"], x["run_id"]))
        # Prefer diversity of source_model (e.g., 1 from 31B hinted + 1 from E4B on-policy) when >1 available
        picked: list[dict] = []
        seen_models = set()
        for item in group:
            if len(picked) >= max_per_task:
                break
            if item["source_model"] not in seen_models:
                picked.append(item)
                seen_models.add(item["source_model"])
        for item in group:
            if len(picked) >= max_per_task:
                break
            if item not in picked:
                picked.append(item)
        dropped_task_cap += max(0, len(group) - len(picked))
        after_task_cap.extend(picked)

    # Apply per-repo <= max_repo_share cap
    by_repo: dict[str, list[dict]] = defaultdict(list)
    for item in after_task_cap:
        by_repo[item["repo"]].append(item)
    for repo in by_repo:
        # Keep AggreVaTe recoveries and shortest/cleanest trajectories first per repo (.pop() trims from end)
        by_repo[repo].sort(key=lambda x: (0 if x.get("rollout_mode") == "aggrevate_31b_recovery" else 1, x["num_tool_calls"], x["instance_id"]))

    if len(by_repo) >= 3 and len(after_task_cap) >= 10:
        # Iteratively trim any repo exceeding max_repo_share until equilibrium
        while True:
            total = sum(len(v) for v in by_repo.values())
            if total == 0:
                break
            max_allowed = max(1, int(math.floor(total * max_repo_share)))
            over = [(r, len(v) - max_allowed) for r, v in by_repo.items() if len(v) > max_allowed]
            if not over:
                break
            # Trim 1 from the most over-represented repo per iteration
            over.sort(key=lambda x: (-x[1], x[0]))
            r_trim = over[0][0]
            by_repo[r_trim].pop()

    final_records: list[dict] = []
    for repo in sorted(by_repo.keys()):
        final_records.extend(by_repo[repo])
    final_records.sort(key=lambda x: (x["instance_id"], x["source_model"], x["run_id"]))

    # Enforce hard invariant: strictly <= 2 trajectories per task instance
    task_counts = Counter(r["task_id"] for r in final_records)
    for tid, count in task_counts.items():
        assert count <= 2, f"INVARIANT VIOLATION: task {tid} has {count} trajectories (> 2 max)!"

    dropped_repo_cap = len(after_task_cap) - len(final_records)
    cap_stats = {
        "after_sanitization": len(candidates),
        "dropped_duplicates": dropped_duplicates,
        "dropped_by_per_task_cap": dropped_task_cap,
        "dropped_by_repo_share_cap": dropped_repo_cap,
        "final_kept": len(final_records),
        "final_by_repo": dict(Counter(r["repo"] for r in final_records)),
        "final_by_source_model": dict(Counter(r["source_model"] for r in final_records)),
        "unique_tasks": len({r["instance_id"] for r in final_records}),
    }
    return final_records, cap_stats


def run_self_test() -> None:
    """Comprehensive unit tests verifying all 8 safety/quality guards."""
    print("Running sft_dataset_builder self-tests...")
    tasks_path = Path("tasks.jsonl")
    splits_path = Path("splits_99_30.json")
    assert tasks_path.exists() and splits_path.exists(), "Run build_splits.py first!"

    tasks_index = load_tasks_index(tasks_path)
    splits = json.loads(splits_path.read_text(encoding="utf-8"))
    holdout_set = set(splits["holdout_ids"])
    train_id = splits["train_ids"][0]
    holdout_id = splits["holdout_ids"][0]
    sys_cand = Path("submissions/submission_E4B_LoRA_v1_5/prompts/system.md")
    if not sys_cand.exists():
        sys_cand = Path("submission_E4B_LoRA_v1_5/prompts/system.md")
    if not sys_cand.exists():
        sys_cand = Path("submission_E4B_F3_v2/prompts/system.md")
    if not sys_cand.exists():
        sys_cand = Path("submissions/submission_E4B_F3_v2/prompts/system.md")
    sys_prompt = sys_cand.read_text(encoding="utf-8") if sys_cand.exists() else "You are an expert engineer."

    def make_valid(tid: str, model: str = "gemma-4-31b-it-qat-w4a16-ct", run_id: str = "r1", thought: str = "Inspecting target file.") -> dict:
        return {
            "instance_id": tid,
            "resolved": True,
            "patch_len": 350,
            "source_model": model,
            "rollout_mode": "hinted_31b",
            "run_id": run_id,
            "messages": [
                {"role": "system", "content": "old system"},
                {"role": "user", "content": "HINTED PROMPT: Look at foo.py\n" + tasks_index[tid]["problem_statement"]},
                {
                    "role": "assistant",
                    "content": f"<|channel>thought\n{thought}<channel|>",
                    "tool_calls": [{"name": "read_file", "arguments": {"filepath": "fastapi/responses.py", "start_line": 150, "end_line": 220}}],
                },
                {
                    "role": "tool",
                    "name": "read_file",
                    "content": json.dumps({"status": "ok", "filepath": "fastapi/responses.py", "content": "class ORJSONResponse(JSONResponse):\n    pass\n", "start_line": 150, "end_line": 220}),
                },
                {
                    "role": "assistant",
                    "content": "<|channel>thought\nApplying minimal fix.<channel|>",
                    "tool_calls": [{"name": "edit_file", "arguments": {"filepath": "fastapi/responses.py", "old_string": "class ORJSONResponse(JSONResponse):\n    pass", "new_string": "@deprecated('use JSONResponse')\nclass ORJSONResponse(JSONResponse):\n    pass"}}],
                },
                {
                    "role": "tool",
                    "name": "edit_file",
                    "content": json.dumps({"status": "ok", "filepath": "fastapi/responses.py", "occurrences": 1}),
                },
                {
                    "role": "assistant",
                    "content": "<|channel>thought\nSubmitting after pytest.<channel|>",
                    "tool_calls": [{"name": "submit_patch", "arguments": {}}],
                },
                {
                    "role": "tool",
                    "name": "submit_patch",
                    "content": json.dumps({"status": "ok", "patch_size": 350, "files_changed": 1}),
                },
            ],
        }

    # Test 1: Valid trajectory passes & swaps unhinted prompt + canonical system prompt (+ path -> filepath normalization)
    rec, err = sanitize_trajectory(make_valid(train_id), holdout_set, tasks_index, sys_prompt)
    assert err is None and rec is not None, f"Valid trajectory rejected: {err}"
    assert "HINTED PROMPT" not in rec["messages"][1]["content"]
    assert rec["messages"][0]["content"] == sys_prompt
    alias_tc, alias_err = normalize_tool_call({"name": "edit_file", "arguments": {"path": "src/a.py", "old_string": "x", "new_string": "y"}}, 99)
    assert alias_err is None and alias_tc["function"]["arguments"].get("filepath") == "src/a.py" and "path" not in alias_tc["function"]["arguments"]

    # Test 2: Holdout task strictly rejected
    rec, err = sanitize_trajectory(make_valid(holdout_id), holdout_set, tasks_index, sys_prompt)
    assert rec is None and err == "holdout_task_excluded", f"Expected holdout rejection, got {err}"

    # Test 3: Hint leak rejected
    leaked = make_valid(train_id, thought="As the hint says, I should edit fastapi/responses.py.")
    rec, err = sanitize_trajectory(leaked, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("hint_leak_detected"), f"Expected hint leak rejection, got {err}"

    # Test 4: Disallowed non-Gemma model (Rule 4) rejected
    paid = make_valid(train_id, model="claude-sonnet-4-5")
    rec, err = sanitize_trajectory(paid, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("disallowed_source_model"), f"Expected model rejection, got {err}"

    # Test 5: Protected test file edit rejected
    bad_edit = make_valid(train_id)
    bad_edit["messages"][4]["tool_calls"][0]["arguments"]["filepath"] = "tests/test_responses.py"
    rec, err = sanitize_trajectory(bad_edit, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err and err.startswith("protected_file_edit"), f"Expected protected edit rejection, got {err}"

    # Test 6: Fake read stub rejected
    fake_stub = make_valid(train_id)
    fake_stub["messages"][3]["content"] = "Showing lines 1..120 of fastapi/responses.py"
    rec, err = sanitize_trajectory(fake_stub, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err == "fake_tool_stub_response", f"Expected fake stub rejection, got {err}"

    # Test 7: Long thought block capped cleanly
    long_thought = make_valid(train_id, thought=("reasoning step " * 600))
    rec, err = sanitize_trajectory(long_thought, holdout_set, tasks_index, sys_prompt, max_thought_tokens=256)
    assert err is None and rec is not None and rec["thoughts_truncated"] == 1
    assert "<channel|>" in rec["messages"][2]["content"] and len(rec["messages"][2]["content"]) < 1100

    # Test 8: Per-task (<=2) and per-repo (<=40%) diversity caps
    pool = []
    # 3 trajectories for same fastapi task + 10 fastapi + 5 rich + 5 requests
    fa_ids = [t for t in splits["train_ids"] if t.startswith("fastapi_")][:10]
    ri_ids = [t for t in splits["train_ids"] if t.startswith("rich_")][:5]
    rq_ids = [t for t in splits["train_ids"] if t.startswith("requests_")][:5]
    for k in range(3):
        r, _ = sanitize_trajectory(make_valid(fa_ids[0], run_id=f"dup_{k}"), holdout_set, tasks_index, sys_prompt)
        pool.append(r)
    for tid in fa_ids[1:] + ri_ids + rq_ids:
        r, _ = sanitize_trajectory(make_valid(tid), holdout_set, tasks_index, sys_prompt)
        pool.append(r)
    kept, stats = apply_diversity_caps(pool, max_per_task=2, max_repo_share=0.40)
    assert stats["dropped_by_per_task_cap"] == 1
    fa_share = stats["final_by_repo"]["fastapi/fastapi"] / stats["final_kept"]
    assert fa_share <= 0.40 + 1e-9, f"Expected fastapi share <= 40%, got {fa_share:.2%}"

    # Test 9: Directory & indented JSON trace ingestion
    import tempfile, shutil
    tmp_test_dir = Path(tempfile.mkdtemp(prefix="sft_test_dir_"))
    try:
        t_json = tmp_test_dir / "trace1.json"
        t_json.write_text(json.dumps(make_valid(train_id, run_id="json_trace"), indent=2), encoding="utf-8")
        t_jsonl = tmp_test_dir / "trace2.jsonl"
        t_jsonl.write_text(json.dumps(make_valid(fa_ids[1], run_id="jsonl_trace")) + "\n", encoding="utf-8")
        dir_recs = collect_raw_records(tmp_test_dir)
        assert len(dir_recs) == 2, f"Expected 2 records collected from dir, got {len(dir_recs)}"
        for raw_r, src in dir_recs:
            r_san, r_err = sanitize_trajectory(raw_r, holdout_set, tasks_index, sys_prompt)
            assert r_err is None and r_san is not None
        dir_sha = sha256_file(tmp_test_dir)
        assert isinstance(dir_sha, str) and len(dir_sha) == 64
    finally:
        shutil.rmtree(tmp_test_dir, ignore_errors=True)

    # Test 10: 0% raw unrecovered failures (resolved=False strictly rejected)
    unresolved_raw = make_valid(train_id)
    unresolved_raw["resolved"] = False
    rec, err = sanitize_trajectory(unresolved_raw, holdout_set, tasks_index, sys_prompt)
    assert rec is None and err == "not_resolved", f"Expected not_resolved, got {err}"

    # Test 11: Privilege-leak CoT audit and stripper
    leaked_cot = make_valid(
        train_id,
        thought="Inspecting codebase for bug.\nAs per the oracle hint, line 150 of fastapi/responses.py is the gold patch location.\nLet's verify line 150.",
    )
    # With strip_privilege_leaks=False, must reject
    rec, err = sanitize_trajectory(leaked_cot, holdout_set, tasks_index, sys_prompt, strip_privilege_leaks=False)
    assert rec is None and err and err.startswith("hint_leak_detected")
    # With strip_privilege_leaks=True, must strip the leaked line cleanly and preserve valid reasoning
    rec, err = sanitize_trajectory(leaked_cot, holdout_set, tasks_index, sys_prompt, strip_privilege_leaks=True)
    assert err is None and rec is not None
    cot_text = rec["messages"][2]["content"]
    assert "oracle hint" not in cot_text.lower()
    assert "gold patch" not in cot_text.lower()
    assert "Inspecting codebase for bug" in cot_text

    # Test 12: AggreVaTe prefix masking metadata & shared schema keys
    agg_rec = make_valid(train_id)
    agg_rec["student_prefix_turns"] = 1
    agg_rec["failure_mode"] = "edit_file_failure"
    rec, err = sanitize_trajectory(agg_rec, holdout_set, tasks_index, sys_prompt)
    assert err is None and rec is not None
    assert rec["student_prefix_turns"] == 1
    assert rec["failure_mode"] == "edit_file_failure"
    assert rec["task_id"] == train_id
    asst_msgs = [m for m in rec["messages"] if m["role"] == "assistant"]
    assert asst_msgs[0]["loss_mask"] == 0, "Student prefix turn 0 must have loss_mask=0"
    assert asst_msgs[1]["loss_mask"] == 1, "Teacher recovery turn 1 must have loss_mask=1"
    assert asst_msgs[2]["loss_mask"] == 1, "Teacher recovery turn 2 must have loss_mask=1"
    required_keys = {"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}
    assert required_keys.issubset(rec.keys())

    # Test 13: Strict <= 2 trajectories per task instance hard cap
    pool_overflow = [sanitize_trajectory(make_valid(fa_ids[0], run_id=f"dup_{k}"), holdout_set, tasks_index, sys_prompt)[0] for k in range(5)]
    kept_overflow, stats_overflow = apply_diversity_caps(pool_overflow, max_per_task=5, max_repo_share=1.0)
    assert len(kept_overflow) <= 2, f"Expected <= 2 trajectories, got {len(kept_overflow)}"
    assert stats_overflow["dropped_by_per_task_cap"] == 3

    # Test 14: Patch (c) hard rejections (-p no:anyio, | tail, surrender, /workspace/repro*.py, 1-byte patch)
    bad_anyio = make_valid(train_id)
    bad_anyio["messages"].insert(4, {"role": "assistant", "content": "", "tool_calls": [{"name": "run_command", "arguments": {"command": "pytest -p no:anyio tests/test_a.py"}}]})
    assert sanitize_trajectory(bad_anyio, holdout_set, tasks_index, sys_prompt) == (None, "forbidden_no_anyio")

    bad_tail = make_valid(train_id)
    bad_tail["messages"].insert(4, {"role": "assistant", "content": "", "tool_calls": [{"name": "run_command", "arguments": {"command": "pytest tests/test_a.py | tail -20"}}]})
    assert sanitize_trajectory(bad_tail, holdout_set, tasks_index, sys_prompt) == (None, "forbidden_pipe_tail")

    bad_surr = make_valid(train_id)
    bad_surr["messages"][2]["content"] = "Partial patches earn score so submitting early."
    assert sanitize_trajectory(bad_surr, holdout_set, tasks_index, sys_prompt) == (None, "forbidden_surrender_text")

    bad_repro = make_valid(train_id)
    bad_repro["messages"].insert(4, {"role": "assistant", "content": "", "tool_calls": [{"name": "write_file", "arguments": {"filepath": "repro.py", "content": "print(1)"}}]})
    assert sanitize_trajectory(bad_repro, holdout_set, tasks_index, sys_prompt) == (None, "workspace_repro_write:repro.py")

    bad_1b = make_valid(train_id)
    bad_1b["patch_len"] = 1
    assert sanitize_trajectory(bad_1b, holdout_set, tasks_index, sys_prompt) == (None, "empty_or_trivial_patch")

    # Test 15: Prebuilt SFT record rejected by default, accepted when accept_prebuilt_sft=True (still enforces repro*.py guard)
    pb_rec = sanitize_trajectory(make_valid(train_id), holdout_set, tasks_index, sys_prompt)[0]
    assert "resolved" not in pb_rec
    assert sanitize_trajectory(pb_rec, holdout_set, tasks_index, sys_prompt) == (None, "not_resolved")
    pb_ok, pb_err = sanitize_trajectory(pb_rec, holdout_set, tasks_index, sys_prompt, accept_prebuilt_sft=True)
    assert pb_err is None and pb_ok is not None

    # Test 16: Mid-trajectory no_call prose loop rejected; single final summary after submit_patch allowed
    bad_nocall = make_valid(train_id)
    bad_nocall["messages"].insert(4, {"role": "assistant", "content": "Let me think in prose without calling a tool."})
    assert sanitize_trajectory(bad_nocall, holdout_set, tasks_index, sys_prompt) == (None, "forbidden_no_call_prose_loop")
    ok_final_summary = make_valid(train_id)
    ok_final_summary["messages"].append({"role": "assistant", "content": "Fixed and submitted."})
    ok_fs_rec, ok_fs_err = sanitize_trajectory(ok_final_summary, holdout_set, tasks_index, sys_prompt)
    assert ok_fs_err is None and ok_fs_rec is not None

    # Test 17: Contaminated requests_7315 from E4B train99 rejected, 31B AggreVaTe allowed, duplicates deduped
    bad_7315 = make_valid("requests_7315", model="gemma-4-e4b-it")
    bad_7315["rollout_mode"] = "on_policy_local"
    assert sanitize_trajectory(bad_7315, holdout_set, tasks_index, sys_prompt) == (None, "excluded_contaminated_train99_task")
    dup_a = sanitize_trajectory(make_valid(train_id, run_id="r_dup1"), holdout_set, tasks_index, sys_prompt)[0]
    dup_b = sanitize_trajectory(make_valid(train_id, run_id="r_dup1"), holdout_set, tasks_index, sys_prompt)[0]
    dedup_kept, dedup_stats = apply_diversity_caps([dup_a, dup_b], max_per_task=2, max_repo_share=1.0)
    assert len(dedup_kept) == 1 and dedup_stats["dropped_duplicates"] == 1

    print("[PASS] All 17 sft_dataset_builder guards & invariants verified 100%!")
    print("[PASS] Directory & indented JSON trace ingestion verified 100%!")


def main():
    parser = argparse.ArgumentParser(description="Real-Trajectory SFT Dataset Builder & Provenance Logger")
    parser.add_argument("--self_test", action="store_true", help="Run built-in verification suite")
    parser.add_argument("--inputs", nargs="*", default=[], help="Input raw passing trajectory JSONL files")
    parser.add_argument("--splits", default="splits_99_30.json", help="Path to 99/30 split JSON")
    parser.add_argument("--tasks", default="tasks.jsonl", help="Path to tasks.jsonl")
    parser.add_argument("--system_prompt", default="submissions/submission_E4B_LoRA_v1_5/prompts/system.md")
    parser.add_argument("--max_thought_tokens", type=int, default=1024)
    parser.add_argument("--max_per_task", type=int, default=2, help="Max trajectories per task (strictly <= 2)")
    parser.add_argument("--max_repo_share", type=float, default=0.40)
    parser.add_argument("--require_thoughts", action="store_true")
    parser.add_argument("--strip_privilege_leaks", action="store_true", default=True, help="Audit and strip privilege leak sentences from teacher CoT")
    parser.add_argument("--no_strip_privilege_leaks", dest="strip_privilege_leaks", action="store_false", help="Hard reject on any privilege leak")
    parser.add_argument("--accept_prebuilt_sft", action="store_true", help="Allow prebuilt verified SFT schema rows lacking explicit resolved=True while still applying all content/holdout guards")
    parser.add_argument("--out_jsonl", default="e4b_sft_train.jsonl")
    parser.add_argument("--out_provenance", default="e4b_sft_provenance.json")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return

    if not args.inputs:
        parser.print_help()
        sys.exit(1)

    splits = json.loads(Path(args.splits).read_text(encoding="utf-8"))
    holdout_set = set(splits["holdout_ids"])
    tasks_index = load_tasks_index(Path(args.tasks))
    sys_p = Path(args.system_prompt)
    if not sys_p.exists() and (Path("submissions") / args.system_prompt).exists():
        sys_p = Path("submissions") / args.system_prompt
    if sys_p.is_dir() and (sys_p / "prompts" / "system.md").exists():
        sys_p = sys_p / "prompts" / "system.md"
    if sys_p.suffix.lower() == ".zip":
        with zipfile.ZipFile(sys_p, "r") as zf:
            if "prompts/system.md" in zf.namelist():
                system_prompt = zf.read("prompts/system.md").decode("utf-8").strip()
            else:
                md_files = [n for n in zf.namelist() if n.endswith(".md")]
                assert md_files, f"No .md prompt found inside zip archive: {sys_p}"
                system_prompt = zf.read(md_files[0]).decode("utf-8").strip()
    else:
        system_prompt = sys_p.read_text(encoding="utf-8").strip()

    if "e4b" in args.out_jsonl.lower():
        assert len(system_prompt) <= 2136, (
            f"FATAL: E4B system_prompt length is {len(system_prompt)} chars (> 2,136c / 512W limit)! "
            "Use submissions/submission_E4B_LoRA_v1_5/prompts/system.md (2,048 B)."
        )
        assert "{" not in system_prompt and "}" not in system_prompt, "FATAL: Raw curly braces in E4B system_prompt!"

    accepted: list[dict] = []
    rejections: Counter = Counter()
    input_manifests: list[dict] = []

    for inp_str in args.inputs:
        inp = Path(inp_str)
        if not inp.exists():
            print(f"WARNING: input missing: {inp}")
            continue
        raw_records = collect_raw_records(inp)
        raw_count = len(raw_records)
        ok_count = 0
        for raw, src_path in raw_records:
            rec, err = sanitize_trajectory(
                raw,
                holdout_set=holdout_set,
                tasks_index=tasks_index,
                system_prompt=system_prompt,
                max_thought_tokens=args.max_thought_tokens,
                require_thoughts=args.require_thoughts,
                strip_privilege_leaks=args.strip_privilege_leaks,
                accept_prebuilt_sft=args.accept_prebuilt_sft,
            )
            if err:
                rejections[err] += 1
            else:
                accepted.append(rec)
                ok_count += 1
        input_manifests.append({
            "file": str(inp),
            "sha256": sha256_file(inp),
            "raw_rows": raw_count,
            "sanitized_rows": ok_count,
        })

    final_records, cap_stats = apply_diversity_caps(
        accepted,
        max_per_task=args.max_per_task,
        max_repo_share=args.max_repo_share,
    )

    out_jsonl = Path(args.out_jsonl)
    with out_jsonl.open("w", encoding="utf-8") as f:
        for r in final_records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    provenance = {
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "rule_compliance": {
            "gemma_generated_only": True,
            "zero_paid_frontier_outputs": True,
            "holdout_30_excluded": True,
            "holdout_overlap_count": len(holdout_set & {r["instance_id"] for r in final_records}),
        },
        "config": {
            "splits_file": args.splits,
            "system_prompt_file": args.system_prompt,
            "max_thought_tokens": args.max_thought_tokens,
            "max_per_task": args.max_per_task,
            "max_repo_share": args.max_repo_share,
            "require_thoughts": args.require_thoughts,
        },
        "inputs": input_manifests,
        "rejection_counts": dict(rejections.most_common()),
        "cap_stats": cap_stats,
        "output_file": str(out_jsonl),
        "output_sha256": sha256_file(out_jsonl),
    }
    assert provenance["rule_compliance"]["holdout_overlap_count"] == 0

    Path(args.out_provenance).write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print(f"Built {len(final_records)} sanitized trajectories -> {out_jsonl}")
    print(f"Provenance logged -> {args.out_provenance}")
    print("Repo balance:", cap_stats["final_by_repo"])
    if rejections:
        print("Rejections:", dict(rejections.most_common(8)))


if __name__ == "__main__":
    main()
