# E4B Complete Status Handoff — Exact Reading Order

Read in this exact order to understand the full E4B history, constraints, failed runs, and current bottleneck:

1. **`01_plans/imm.md`** — Live competition status, remaining Kaggle quota (2.00 GPU-h), Slot 1/2 anchors (`B4` 0.12, `LoRA_v1` 0.05), `v1.5` NO-GO verdict (`0/20` on Val20 vs `LoRA_v1` `2/20`), and all hypothesis verdicts.
2. **`02_plans/AGENT_CONTINUATION_DOSSIER.md`** — Full engineering handbook, baseline matrix, and invariants.
3. **`03_analysis/e4b_analysis.md`** — E4B failure funnel (`NoMatch`, logic, timeout across `LoRA_v1`, `v2`, `F3_v2`, `train99`).
4. **`03_analysis/meta_strategy.md`** — Eval-to-LB correlation and quota optimization.
5. **`04_latest_v3_fixed_telemetry/`** — Exact provenance, 24-row SFT corpus, and Arm A / Arm B training logs extracted from `VloraV3_Fixed Resukts.zip` (also attach your `mqg1cob` `smoke4` + `holdout30` console log, showing `1/4` `smoke4` and `holdout30` repetition loops on Arm B epoch 2).
6. **`05_code/kaggle_train_e4b_qat_lora.py`** & **`05_code/sft_dataset_builder.py`** — Active trainer (supports `e2_data_v1`, `sft_kl`, `ckpt_epoch1`) and corpus sanitizer.
7. **`06_baselines/submission_E4B_LoRA_v1_5/`** & **`06_baselines/submission_E4B_LoRA_v1.zip`** — Failed `v1.5` prompt (`2,048 B`, `0/20` Val20) vs incumbent Slot 2 champion (`LoRA_v1`, `2,149 B`, `5/30` Gate G2, `0.05` LB).
