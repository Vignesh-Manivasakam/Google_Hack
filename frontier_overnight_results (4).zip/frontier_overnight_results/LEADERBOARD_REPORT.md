# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-20 12:29:46 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F6_Apex_Unified`** | `0.0%` (0/8) | `5/8` | `48.96%` | `11` | `24.0` | `30.51m` | Unified Cursor + Copilot 4 Laws + OpenCode + Claude |
| 2 | **`E4B_F3_v2`** | `0.0%` (0/8) | `4/8` | `52.08%` | `18` | `24.0` | `36.64m` | Compact 497-tok Copilot + 4 Trap Laws prompt for E4B |
| 3 | **`B5_Lean_31B`** | `0.0%` (0/8) | `3/8` | `51.6%` | `18` | `23.5` | `28.04m` | Lean 31B fast-fix prompt under 8-10 turns |

## Stage 2: Finalists Validation Suite (VAL_20)
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F6_Apex_Unified`** | `0.0%` (0/20) | `10/20` | `51.59%` | `15` | `47.56m` | Unified Cursor + Copilot 4 Laws + OpenCode + Claude |
| 2 | **`E4B_F3_v2`** | `0.0%` (0/20) | `7/20` | `53.77%` | `19` | `36.99m` | Compact 497-tok Copilot + 4 Trap Laws prompt for E4B |
