# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-18 05:50:33 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F6_Apex_Unified`** | `0.0%` (0/8) | `6/8` | `42.76%` | `37` | `36.25` | `155.68m` | Unified Cursor + Copilot 4 Laws + OpenCode + Claude |
| 2 | **`F1_ClaudeCode`** | `0.0%` (0/8) | `5/8` | `53.52%` | `15` | `17.75` | `0.0m` | Claude Code flat minimal read-edit-verify |
| 3 | **`F3_Copilot_Sonnet`** | `0.0%` (0/8) | `5/8` | `46.58%` | `10` | `29.25` | `226.33m` | GitHub Copilot Sonnet 7-step + 4 Trap Laws |

## Stage 2: Finalists Validation Suite (VAL_20)
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F1_ClaudeCode`** | `0.0%` (0/20) | `9/20` | `62.45%` | `28` | `302.17m` | Claude Code flat minimal read-edit-verify |
