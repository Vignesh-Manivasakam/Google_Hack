#!/usr/bin/env python3
"""
On-Policy LoRA v1 Passing Trajectories Generator (Training-Only Artifact).

Collects, validates, deduplicates, and caps on-policy passing trajectories
from local RTX 2000 Ada factory rollouts.
Enforces:
  1. SWE-Gym small-N cap rule: strictly <= 2 passing trajectories per unique task instance.
  2. Strict 99/30 holdout isolation: hard-rejects any task in holdout_ids.
  3. Quality gate: resolved == True, patch_len > 0, valid multi-turn messages >= 4.
  4. Shortest-path preference: ranks by fewest steps when capping.
"""
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path


def load_train_holdout_split(splits_path: Path | None) -> tuple[set[str], set[str]]:
    train_ids = set()
    holdout_ids = set()
    if splits_path and Path(splits_path).exists():
        try:
            with open(splits_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                train_ids = set(data.get("train_ids", []))
                holdout_ids = set(data.get("holdout_ids", []))
        except Exception as exc:
            print(f"[WARN] Failed to parse splits from {splits_path}: {exc}", flush=True)
    return train_ids, holdout_ids


def collect_passing_trajectories(
    results_dir: Path,
    train_ids: set[str],
    holdout_ids: set[str],
    max_per_task: int = 2,
    source_model: str = "gemma-4-e4b-it-qat-lora-v1",
) -> list[dict]:
    results_dir = Path(results_dir).resolve()
    records_by_task = defaultdict(list)
    seen_hashes = set()

    # Search trace files and passing_trajectories.jsonl
    jsonl_files = sorted(results_dir.glob("**/passing_trajectories.jsonl"))
    trace_files = sorted(results_dir.glob("**/traces/*.json"))

    def process_record(rec: dict):
        if not rec.get("resolved"):
            return
        tid = rec.get("instance_id") or rec.get("task_id")
        if not tid:
            return
        # Strict holdout isolation
        if holdout_ids and tid in holdout_ids:
            return
        if train_ids and tid not in train_ids:
            return

        patch = rec.get("patch", "")
        if not patch or len(patch.strip()) == 0:
            return

        msgs = rec.get("messages", [])
        if len(msgs) < 4:
            return

        # Deduplicate identical message sequences
        sig = (tid, len(msgs), len(patch), rec.get("steps", 0))
        if sig in seen_hashes:
            return
        seen_hashes.add(sig)

        entry = {
            "task_id": tid,
            "instance_id": tid,
            "repo": rec.get("repo", ""),
            "messages": msgs,
            "patch": patch,
            "patch_len": len(patch),
            "steps": rec.get("steps", len(msgs) // 2),
            "source_model": source_model,
            "rollout_mode": "on_policy_lora_v1",
            "resolved": True,
        }
        records_by_task[tid].append(entry)

    # 1. Parse JSONL files
    for jf in jsonl_files:
        try:
            with open(jf, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            process_record(json.loads(line))
                        except Exception:
                            pass
        except Exception:
            pass

    # 2. Parse individual trace JSON files
    for tf in trace_files:
        try:
            with open(tf, "r", encoding="utf-8") as f:
                process_record(json.load(f))
        except Exception:
            pass

    # 3. Apply SWE-Gym small-N cap rule (<= max_per_task per task, sorted by fewest steps)
    capped_records = []
    for tid, trajs in sorted(records_by_task.items()):
        trajs.sort(key=lambda x: (x["steps"], x["patch_len"]))
        capped = trajs[:max_per_task]
        capped_records.extend(capped)

    return capped_records


def run_self_test() -> int:
    print("\n==================== [ON-POLICY PASSES GENERATOR SELF-TEST] ====================", flush=True)
    mock_train = {"task_1", "task_2", "task_3"}
    mock_holdout = {"task_holdout"}

    mock_trajectories = [
        {"instance_id": "task_1", "resolved": True, "patch": "diff --git a/a.py b/a.py", "patch_len": 30, "steps": 12, "messages": [{"role": "system"}, {"role": "user"}, {"role": "assistant"}, {"role": "tool"}]},
        {"instance_id": "task_1", "resolved": True, "patch": "diff --git a/a.py b/a.py", "patch_len": 35, "steps": 8, "messages": [{"role": "system"}, {"role": "user"}, {"role": "assistant"}, {"role": "tool"}]},
        {"instance_id": "task_1", "resolved": True, "patch": "diff --git a/a.py b/a.py", "patch_len": 40, "steps": 16, "messages": [{"role": "system"}, {"role": "user"}, {"role": "assistant"}, {"role": "tool"}]},
        {"instance_id": "task_holdout", "resolved": True, "patch": "diff --git a/h.py b/h.py", "patch_len": 20, "steps": 5, "messages": [{"role": "system"}, {"role": "user"}, {"role": "assistant"}, {"role": "tool"}]},
        {"instance_id": "task_2", "resolved": False, "patch": "", "steps": 24, "messages": [{"role": "system"}, {"role": "user"}, {"role": "assistant"}, {"role": "tool"}]},
    ]

    import tempfile
    with tempfile.TemporaryDirectory() as td:
        tpath = Path(td)
        tracedir = tpath / "traces"
        tracedir.mkdir()
        for idx, mt in enumerate(mock_trajectories):
            (tracedir / f"mock_{idx}.json").write_text(json.dumps(mt), encoding="utf-8")

        res = collect_passing_trajectories(tpath, mock_train, mock_holdout, max_per_task=2)

        # Verification 1: holdout rejected
        assert not any(r["task_id"] == "task_holdout" for r in res), "Holdout task leaked into passing trajectories!"
        print("  [PASS] Strict holdout isolation: 0 holdout tasks included.", flush=True)

        # Verification 2: failing task rejected
        assert not any(r["task_id"] == "task_2" for r in res), "Unresolved task included in passing trajectories!"
        print("  [PASS] Unresolved task rejection verified.", flush=True)

        # Verification 3: max_per_task cap enforced
        t1_count = sum(1 for r in res if r["task_id"] == "task_1")
        assert t1_count == 2, f"Expected 2 capped trajectories for task_1, got {t1_count}"
        print("  [PASS] SWE-Gym small-N cap <= 2 per task strictly enforced.", flush=True)

        # Verification 4: shortest path prioritized
        steps = [r["steps"] for r in res if r["task_id"] == "task_1"]
        assert steps == [8, 12], f"Expected steps [8, 12] sorted ascending, got {steps}"
        print("  [PASS] Shortest-step sorting verified: [8, 12] selected over 16.", flush=True)

    print("==================================================================================", flush=True)
    print("[PASS] generate_onpolicy_passes self-test passed with 100% success!\n", flush=True)
    return 0


def main():
    parser = argparse.ArgumentParser(description="Generate capped on-policy passing trajectories from factory rollouts")
    parser.add_argument("--results_dir", type=Path, default=Path("frontier_overnight_results"), help="Path to factory results directory")
    parser.add_argument("--out_jsonl", type=Path, default=Path("onpolicy_lora_v1_passing.jsonl"), help="Output path for passing JSONL")
    parser.add_argument("--splits", type=Path, default=Path("splits_99_30.json"), help="Path to splits_99_30.json for holdout isolation")
    parser.add_argument("--max_per_task", type=int, default=2, help="Maximum trajectories per task (SWE-Gym cap rule <= 2)")
    parser.add_argument("--source_model", type=str, default="gemma-4-e4b-it-qat-lora-v1", help="Source model tag")
    parser.add_argument("--dry_run_test", action="store_true", help="Run standalone CPU self-test")
    args = parser.parse_args()

    if args.dry_run_test:
        sys.exit(run_self_test())

    train_ids, holdout_ids = load_train_holdout_split(args.splits)
    if train_ids:
        print(f"[SPLITS] Loaded {len(train_ids)} train tasks and {len(holdout_ids)} holdout tasks from {args.splits}", flush=True)

    records = collect_passing_trajectories(
        args.results_dir,
        train_ids=train_ids,
        holdout_ids=holdout_ids,
        max_per_task=args.max_per_task,
        source_model=args.source_model,
    )

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_jsonl, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    repo_counts = defaultdict(int)
    for r in records:
        repo_counts[r.get("repo", "unknown")] += 1

    print("\n==================== [ON-POLICY PASSING EXPORT SUMMARY] ====================", flush=True)
    print(f"  * Results Scanned:       {args.results_dir}")
    print(f"  * Total Passing Output:  {len(records)} trajectories")
    print(f"  * Unique Tasks:          {len(set(r['task_id'] for r in records))}")
    print(f"  * Capped per Task:       <= {args.max_per_task}")
    print(f"  * Output Destination:    {args.out_jsonl}")
    print(f"  * Breakdown by Repo:     {dict(repo_counts)}")
    print("============================================================================\n", flush=True)


if __name__ == "__main__":
    main()
