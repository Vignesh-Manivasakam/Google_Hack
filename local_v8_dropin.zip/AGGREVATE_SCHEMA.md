# AggreVaTe / DAgger Shared Failure Prefix Specification

## 1. Overview & Objective
This document defines the exact shared schema and ingestion contract between:
- **Agent 4 (Local RTX 2000 Ada Factory Engineer):** Emits unhinted student rollout failure prefixes failing at turns 3–6.
- **Agent 3 (Slot 2 LoRA v2 & vLLM ML Engineer):** Ingests failure prefixes for Kaggle 31B teacher recovery completion and trains LoRA v2 via JET normalized weighted loss.

## 2. Exact Shared JSONL Schema Keys
Every line in `aggrevate_failure_prefixes.jsonl` is a valid UTF-8 JSON object containing strictly the following top-level keys:

```json
{
  "task_id": "fastapi_14986",
  "messages": [
    {
      "role": "system",
      "content": "You are a principal Python engineer fixing an issue in /workspace..."
    },
    {
      "role": "user",
      "content": "Repository: fastapi/fastapi\n\nProblem Description:\n..."
    },
    {
      "role": "assistant",
      "content": "<|channel>thought\nInitial exploration...\n<channel|>",
      "tool_calls": [
        {
          "id": "c_1",
          "type": "function",
          "function": {
            "name": "search_similar_code",
            "arguments": {"query": "get_swagger_ui_html"}
          }
        }
      ]
    },
    {
      "role": "tool",
      "tool_call_id": "c_1",
      "name": "search_similar_code",
      "content": "{\"status\": \"ok\", ...}"
    }
  ],
  "student_prefix_turns": 4,
  "failure_mode": "edit_file_failure",
  "source_model": "gemma-4-e4b-it-qat-lora-v1"
}
```

### Key Definitions:
| Key | Type | Description |
|---|---|---|
| `task_id` | `str` | Ground-truth SWE-bench instance ID (e.g. `fastapi_14986`). Must belong to `train_ids` from `splits_99_30.json` (0% holdout contamination). |
| `messages` | `list[dict]` | Full multi-turn conversational transcript up through turn `student_prefix_turns`. Contains `system`, `user`, and alternating `assistant` and `tool` turns. |
| `student_prefix_turns` | `int` | Exact integer count of student assistant turns executed before handover ($T \in [3, 6]$). |
| `failure_mode` | `str` | Categorical classification of the student failure state: `edit_file_failure`, `failing_pytest_traceback`, `syntax_error`, `stuck_in_loop`, `wrong_file_inspected`, or `unresolved_search_divergence`. |
| `source_model` | `str` | Model identifier that generated the failure prefix (`gemma-4-e4b-it-qat-lora-v1`). |

---

## 3. Failure Mode Categorization Taxonomy
1. **`edit_file_failure`**: Student attempted a source modification that failed with `NoMatchError`, invalid string substitution, or empty replacement.
2. **`failing_pytest_traceback`**: Student ran targeted pytest and received an active test failure / exception traceback (`exit_code != 0`).
3. **`syntax_error`**: Student introduced code that failed `py_compile` or raised a syntax / indentation error.
4. **`stuck_in_loop`**: Student repeatedly executed identical read/search operations or ping-ponged between files.
5. **`wrong_file_inspected`**: Student navigated into irrelevant directories (e.g., test fixtures, setup scripts) rather than root-cause source modules.
6. **`unresolved_search_divergence`**: Student failed to converge on the target fault after 3–6 exploratory search turns.

---

## 4. Kaggle 31B Teacher Completion Protocol
When the Kaggle 31B teacher ingests `aggrevate_failure_prefixes.jsonl`:
1. **Context Initialization**: The teacher ingests the existing `messages` array as the prior context.
2. **Golden Localization Conditioning**: The golden localization hint (file path and target symbol) is provided **strictly to the teacher's internal reasoning prompt**, NEVER injected into the student `messages` transcript.
3. **Recovery Execution**: The teacher resumes from the failure turn, diagnoses the student mistake (e.g., corrects the wrong file path or repairs the failing edit), implements the clean fix, verifies with pytest, and calls `submit_patch`.
4. **Export Format**: The teacher exports completed trajectories with metadata `student_prefix_turns` preserved.

---

## 5. JET Normalized Weighted Cross-Entropy Loss Contract
During LoRA v2 training in `kaggle_train_e4b_qat_lora.py`:
$$L(\theta) = - \frac{\sum_t w_t \log \pi_\theta(x_t \mid x_{<t})}{\sum_t w_t}$$

Where per-turn weights $w_t$ are allocated as:
- **$w_t = 0.0$ (`loss_mask = 0`)**: User turns, tool observation turns, and all student prefix assistant turns ($turn < student\_prefix\_turns$). Erroneous student exploration does NOT contribute to training loss.
- **$w_t = 1.0$ (`loss_mask = 1`)**: Routine teacher search, inspection, and read assistant turns.
- **$w_t = 1.5$ (`loss_mask = 1`)**: Post-traceback teacher self-correction turns and surgical `edit_file` calls.
- **$w_t = 2.0$ (`loss_mask = 1`)**: Final verified `submit_patch` halting turn.

This eliminates covariate shift and hinted-teacher shortcutting while preventing credit-assignment noise.
