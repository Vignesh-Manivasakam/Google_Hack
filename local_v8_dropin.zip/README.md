# Local RTX 2000 Ada Factory Drop-in Package (v8.0 Production)
**Target PC:** `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent`  
**Target Hardware:** RTX 2000 Ada Generation (16 GB VRAM)  
**Release Date:** November 23, 2026  

---

## 1. Executive Summary & Architectural Invariants
This package provides a completely self-contained deployment bundle for the local RTX 2000 Ada GPU machine to execute continuous 24/7 on-policy rollouts and AggreVaTe/DAgger failure prefix harvesting:
1. **Model & Adapter Serving:** Stripped BF16 Gemma 4 E4B base checkpoint with `submission_E4B_LoRA_v1` adapter mounted via `peft` (`adapters/e4b_qat_lora/`).
2. **Zero BitsAndBytes NF4:** Runs strictly in native `bfloat16` with CPU-pinned Per-Layer Embeddings (PLE) and purged vision/audio towers. Total VRAM footprint is **~8.42 GiB (< 9 GiB)** out of 16.00 GiB available, guaranteeing **0.00 GiB Windows WDDM paging thrashing**.
3. **497-Token Prompt Parity:** Uses compact Copilot prompt + 4 Engineering Failure-Trap Laws (`E4B_F3_v2`).
4. **Permanently KILLED Items Enforced:**
   - `F6_Apex_Unified` on Base E4B is permanently KILLED in Local Factory (hard assertion guard enforced).
   - `-p no:anyio` is permanently KILLED from all agent prompts (preserves AnyIO async test collection).
5. **Shared AggreVaTe Prefix Contract:** Emits structured student failure prefixes at turns 3–6 with shared JSONL schema:
   `{"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}` for Kaggle 31B teacher completion.
6. **SWE-Gym Small-N Cap:** Enforces `<= 2` passing trajectories per unique task instance to eliminate easy-task skew.

---

## 2. Package Contents
- `win_frontier_6harness_overnight.py`: Master rollout factory harness (mounting LoRA v1 via PEFT BF16, dry-run checks, disk-cache resumption).
- `win_harness_triage_parallel.py`: Batched server with PEFT `adapter_dir` loading support and VRAM guard.
- `win_local_sandbox.py`: Windows-safe POSIX emulator and test-runner.
- `win_phase2_tournament.py`: AST code graph indexer and hybrid PLE/SDPA Gemma engine.
- `adapters/e4b_qat_lora/`: Unpacked PEFT LoRA v1 adapter (`adapter_config.json`, `adapter_model.safetensors`, r=8, alpha=16, 54 tensors).
- `prompts/system.md`: 497-token invariant prompt (`E4B_F3_v2`, zero `-p no:anyio`).
- `configs/sampling.yaml`: Deployment sampling parameters (`temperature: 0.15`, `top_p: 0.95`, `thinking_budget: 1024`, `include_thoughts: false`).
- `eval_config.yaml`: Evaluator parameters (`max_time_minutes: 6.0`, `timeout_seconds: 180`, `max_tool_calls: 40`, `max_turns: 55`).
- `submission_E4B_LoRA_v1/`: Full ADK-compliant candidate directory ready for evaluation/submission.
- `generate_onpolicy_passes.py`: Training artifact script collecting passing trajectories (capped `<= 2/task`).
- `generate_aggrevate_prefixes.py`: Training artifact script extracting failure prefixes (turns 3–6, ~25–30 prefixes).
- `AGGREVATE_SCHEMA.md`: Interface contract documenting JSONL schema, failure modes, and JET loss weighting.
- `splits_99_30.json`: 99-train / 30-holdout split manifest (strict holdout isolation).
- `tasks.jsonl`: Unhinted 129 ground truth tasks.
- `hinted_train_99_tasks.jsonl`: 99 training tasks with golden localization hints.

---

## 3. Quick-Start Execution Commands (Remote RTX 2000 Ada)

Open PowerShell inside `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent`:

### Step 1: Instant Dry-Run Verification (0 GPU, ~2 seconds)
```powershell
python win_frontier_6harness_overnight.py --dry_run_test
python generate_onpolicy_passes.py --dry_run_test
python generate_aggrevate_prefixes.py --dry_run_test
```

### Step 2: Canary 1-Task Smoke Test (~2 minutes)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_LoRA_v1 --model_id ..\gemma-4-e4b-it --adapter_dir adapters\e4b_qat_lora --task_mode val20 --smoke1
```

### Step 3: Launch Master Rollout Factory (Overnight Run on 99 Train Tasks)
```powershell
python -u win_frontier_6harness_overnight.py --factory --candidates E4B_LoRA_v1 --model_id ..\gemma-4-e4b-it --adapter_dir adapters\e4b_qat_lora --tasks_path tasks.jsonl --task_mode train99 --workers 1 --batch_size 1 --out_dir ..\e4b_lora_v1_factory
```

### Step 4: Generate Training Artifacts (Post-Run)
```powershell
# 1. Collect on-policy passing trajectories (capped <= 2 per task)
python generate_onpolicy_passes.py --results_dir ..\e4b_lora_v1_factory --out_jsonl onpolicy_lora_v1_passing.jsonl --max_per_task 2

# 2. Extract structured AggreVaTe failure prefixes (turns 3-6, targeting ~25-30 prefixes)
python generate_aggrevate_prefixes.py --results_dir ..\e4b_lora_v1_factory --out_jsonl aggrevate_failure_prefixes.jsonl --target_count 28
```

### Step 5: Export ADK-Legal Submission Zip
```powershell
python win_frontier_6harness_overnight.py --export_candidate E4B_LoRA_v1 --adapter_dir adapters\e4b_qat_lora --out_dir ..\e4b_lora_v1_factory
```
