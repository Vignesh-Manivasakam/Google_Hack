#!/usr/bin/env python3
"""
Structured AggreVaTe Failure Prefixes Generator (Training-Only Artifact).

Extracts unhinted student rollout failure prefixes (failing at turns 3-6)
to be completed by the Kaggle 31B teacher model.
Enforces:
  1. Exact shared schema: {"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}
  2. Strict 99/30 holdout isolation: 0% holdout contamination.
  3. Failure mode categorization:
     - edit_file_failure: NoMatchError or failed string substitution.
     - failing_pytest_traceback: test execution traceback / exit_code failure.
     - syntax_error: py_compile error or invalid syntax.
     - stuck_in_loop: repeated identical calls or ping-ponging.
     - wrong_file_inspected: search/read diverted outside target bug scope.
     - unresolved_search_divergence: failure to locate or repair bug in turns 3-6.
  4. Target quantity: ~25-30 prefixes across distinct training tasks.
"""
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

REQUIRED_SCHEMA_KEYS = {"task_id", "messages", "student_prefix_turns", "failure_mode", "source_model"}


def load_train_holdout_split(splits_path: Path | None) -> tuple[set[str], set[str]]:
    train_ids = set()
    holdout_ids = set()
    if splits_path and Path(splits_path).exists():
        try:
            with open(splits_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                train_ids = set(data.get("train_ids", []))
                holdout_ids = set(data.get("holdout_ids", []))
        except Exception as exc:
            print(f"[WARN] Failed to parse splits from {splits_path}: {exc}", flush=True)
    return train_ids, holdout_ids


def classify_failure_mode(rec: dict, prefix_msgs: list[dict]) -> str:
    trace = rec.get("trace", [])
    edit_fails = rec.get("edit_fails", 0)
    malformed = rec.get("malformed", 0)
    pytest_tail = rec.get("pytest_tail", "")

    # 1. Edit failure
    if edit_fails > 0 or any("nomatcherror" in str(t).lower() for t in trace):
        return "edit_file_failure"
    for m in prefix_msgs:
        if m.get("role") == "tool" and "nomatcherror" in str(m.get("content", "")).lower():
            return "edit_file_failure"

    # 2. Syntax error
    if malformed > 0:
        return "syntax_error"
    for m in prefix_msgs:
        if m.get("role") == "tool" and "syntaxerror" in str(m.get("content", "")).lower():
            return "syntax_error"

    # 3. Failing pytest traceback
    if "traceback" in pytest_tail.lower() or "failed" in pytest_tail.lower():
        return "failing_pytest_traceback"
    for m in prefix_msgs:
        if m.get("role") == "tool" and ("traceback (most recent call last)" in str(m.get("content", "")).lower() or "=== fail" in str(m.get("content", "")).lower()):
            return "failing_pytest_traceback"

    # 4. Stuck in loop
    if rec.get("ping_pong_errors", 0) > 0:
        return "stuck_in_loop"
    tool_calls = [m.get("tool_calls", [{}])[0].get("function", {}).get("name") for m in prefix_msgs if m.get("role") == "assistant" and m.get("tool_calls")]
    if len(tool_calls) >= 3 and len(set(tool_calls)) == 1:
        return "stuck_in_loop"

    # 5. Wrong file inspected
    read_calls = [
        str(m.get("tool_calls", [{}])[0].get("function", {}).get("arguments", {}))
        for m in prefix_msgs if m.get("role") == "assistant" and m.get("tool_calls")
    ]
    if any("setup.py" in rc or "conftest.py" in rc or "test" in rc for rc in read_calls):
        return "wrong_file_inspected"

    return "unresolved_search_divergence"


def extract_aggrevate_prefixes(
    results_dir: Path,
    train_ids: set[str],
    holdout_ids: set[str],
    target_count: int = 28,
    min_turns: int = 3,
    max_turns: int = 6,
    source_model: str = "gemma-4-e4b-it-qat-lora-v1",
) -> list[dict]:
    results_dir = Path(results_dir).resolve()
    trace_files = sorted(results_dir.glob("**/traces/*.json"))

    candidate_records = []
    seen_tasks = set()

    for tf in trace_files:
        try:
            with open(tf, "r", encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            continue

        if rec.get("resolved"):
            continue

        tid = rec.get("instance_id") or rec.get("task_id")
        if not tid or tid in seen_tasks:
            continue

        # Strict holdout isolation
        if holdout_ids and tid in holdout_ids:
            continue
        if train_ids and tid not in train_ids:
            continue

        msgs = rec.get("messages", [])
        if len(msgs) < 4:
            continue

        # Locate assistant turn indices
        asst_indices = [i for i, m in enumerate(msgs) if m.get("role") == "assistant"]
        if len(asst_indices) < min_turns:
            continue

        # Cut at turn T in [min_turns, max_turns]
        num_turns = min(len(asst_indices), max_turns)
        cutoff_asst_idx = asst_indices[num_turns - 1]

        # Sice messages up to tool response of turn T
        cutoff_msg_idx = len(msgs)
        for i in range(cutoff_asst_idx + 1, len(msgs)):
            if msgs[i].get("role") == "assistant":
                cutoff_msg_idx = i
                break
        prefix_msgs = msgs[:cutoff_msg_idx]

        failure_mode = classify_failure_mode(rec, prefix_msgs)

        entry = {
            "task_id": tid,
            "messages": prefix_msgs,
            "student_prefix_turns": num_turns,
            "failure_mode": failure_mode,
            "source_model": source_model,
        }

        # Verify schema invariants
        assert set(entry.keys()) == REQUIRED_SCHEMA_KEYS, f"Schema mismatch for {tid}"
        assert min_turns <= entry["student_prefix_turns"] <= max_turns, f"Turn count out of range: {num_turns}"

        candidate_records.append(entry)
        seen_tasks.add(tid)
        if len(candidate_records) >= target_count:
            break

    return candidate_records


def run_self_test() -> int:
    print("\n==================== [AGGREVATE PREFIX GENERATOR SELF-TEST] ====================", flush=True)
    mock_train = {"task_1", "task_2", "task_3", "task_4"}
    mock_holdout = {"task_holdout"}

    def make_mock_msgs(turns: int, has_error: bool = False) -> list[dict]:
        msgs = [
            {"role": "system", "content": "You are a principal engineer."},
            {"role": "user", "content": "Fix repository issue #101."},
        ]
        for t in range(1, turns + 1):
            msgs.append({
                "role": "assistant",
                "content": f"Exploring turn {t}",
                "tool_calls": [{"id": f"c_{t}", "type": "function", "function": {"name": "read_file", "arguments": {"filepath": f"mod_{t}.py"}}}],
            })
            obs = {"status": "error", "message": "NoMatchError: string not found"} if (has_error and t == turns) else {"status": "ok", "content": "code..."}
            msgs.append({"role": "tool", "tool_call_id": f"c_{t}", "name": "read_file", "content": json.dumps(obs)})
        return msgs

    mock_traces = [
        {"instance_id": "task_1", "resolved": False, "edit_fails": 1, "messages": make_mock_msgs(5, has_error=True)},
        {"instance_id": "task_2", "resolved": False, "trace": ["run_command(pytest)"], "pytest_tail": "FAILED test_auth - Traceback (most recent call last):", "messages": make_mock_msgs(4)},
        {"instance_id": "task_3", "resolved": True, "patch": "fix", "messages": make_mock_msgs(4)},  # Resolved (must skip)
        {"instance_id": "task_holdout", "resolved": False, "messages": make_mock_msgs(4)},  # Holdout (must skip)
        {"instance_id": "task_4", "resolved": False, "messages": make_mock_msgs(8)},  # 8 turns (must cut to 6)
    ]

    import tempfile
    with tempfile.TemporaryDirectory() as td:
        tpath = Path(td)
        tracedir = tpath / "traces"
        tracedir.mkdir()
        for idx, mt in enumerate(mock_traces):
            (tracedir / f"mock_{idx}.json").write_text(json.dumps(mt), encoding="utf-8")

        res = extract_aggrevate_prefixes(tpath, mock_train, mock_holdout, target_count=10, min_turns=3, max_turns=6)

        # 1. Check count: task_1, task_2, task_4 (task_3 is resolved, task_holdout is holdout)
        assert len(res) == 3, f"Expected 3 extracted prefixes, got {len(res)}"
        print(f"  [PASS] Extracted {len(res)} prefixes (resolved and holdout filtered correctly).", flush=True)

        # 2. Check holdout rejection
        assert not any(r["task_id"] == "task_holdout" for r in res), "Holdout task leaked into prefixes!"
        print("  [PASS] Strict holdout isolation: 0% holdout leakage.", flush=True)

        # 3. Check schema keys
        for r in res:
            assert set(r.keys()) == REQUIRED_SCHEMA_KEYS, f"Keys mismatch: {set(r.keys())}"
            assert 3 <= r["student_prefix_turns"] <= 6, f"Turn out of bounds: {r['student_prefix_turns']}"
        print(f"  [PASS] Exact schema keys verified: {sorted(REQUIRED_SCHEMA_KEYS)}", flush=True)

        # 4. Check failure classification
        t1 = next(r for r in res if r["task_id"] == "task_1")
        assert t1["failure_mode"] == "edit_file_failure", f"Expected edit_file_failure, got {t1['failure_mode']}"
        t2 = next(r for r in res if r["task_id"] == "task_2")
        assert t2["failure_mode"] == "failing_pytest_traceback", f"Expected failing_pytest_traceback, got {t2['failure_mode']}"
        print("  [PASS] Failure mode classification verified: edit_file_failure & failing_pytest_traceback.", flush=True)

        # 5. Check turn cutoff at max_turns=6 for task_4
        t4 = next(r for r in res if r["task_id"] == "task_4")
        assert t4["student_prefix_turns"] == 6, f"Expected cutoff at 6, got {t4['student_prefix_turns']}"
        asst_count = sum(1 for m in t4["messages"] if m.get("role") == "assistant")
        assert asst_count == 6, f"Expected 6 assistant turns in messages, got {asst_count}"
        print("  [PASS] Turn-horizon boundary clamp verified: 8 turns cleanly cut to turns 3-6.", flush=True)

    print("==================================================================================", flush=True)
    print("[PASS] generate_aggrevate_prefixes self-test passed with 100% success!\n", flush=True)
    return 0


def main():
    parser = argparse.ArgumentParser(description="Extract structured AggreVaTe failure prefixes (turns 3-6) for 31B teacher completion")
    parser.add_argument("--results_dir", type=Path, default=Path("frontier_overnight_results"), help="Path to factory results directory")
    parser.add_argument("--out_jsonl", type=Path, default=Path("aggrevate_failure_prefixes.jsonl"), help="Output path for AggreVaTe prefix JSONL")
    parser.add_argument("--splits", type=Path, default=Path("splits_99_30.json"), help="Path to splits_99_30.json for holdout isolation")
    parser.add_argument("--target_count", type=int, default=28, help="Target number of prefixes (~25-30)")
    parser.add_argument("--min_turns", type=int, default=3, help="Minimum student prefix turns")
    parser.add_argument("--max_turns", type=int, default=6, help="Maximum student prefix turns")
    parser.add_argument("--source_model", type=str, default="gemma-4-e4b-it-qat-lora-v1", help="Student source model tag")
    parser.add_argument("--dry_run_test", action="store_true", help="Run standalone CPU self-test")
    args = parser.parse_args()

    if args.dry_run_test:
        sys.exit(run_self_test())

    train_ids, holdout_ids = load_train_holdout_split(args.splits)
    if train_ids:
        print(f"[SPLITS] Loaded {len(train_ids)} train tasks and {len(holdout_ids)} holdout tasks from {args.splits}", flush=True)

    prefixes = extract_aggrevate_prefixes(
        args.results_dir,
        train_ids=train_ids,
        holdout_ids=holdout_ids,
        target_count=args.target_count,
        min_turns=args.min_turns,
        max_turns=args.max_turns,
        source_model=args.source_model,
    )

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out_jsonl, "w", encoding="utf-8") as f:
        for p in prefixes:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    fmode_counts = defaultdict(int)
    turn_counts = defaultdict(int)
    for p in prefixes:
        fmode_counts[p["failure_mode"]] += 1
        turn_counts[p["student_prefix_turns"]] += 1

    print("\n==================== [AGGREVATE PREFIXES EXPORT SUMMARY] ====================", flush=True)
    print(f"  * Results Scanned:          {args.results_dir}")
    print(f"  * Total Prefixes Exported:  {len(prefixes)} (target ~25-30)")
    print(f"  * Student Turns Horizon:    turns {args.min_turns} to {args.max_turns}")
    print(f"  * Output Destination:       {args.out_jsonl}")
    print(f"  * Schema Keys:              {sorted(REQUIRED_SCHEMA_KEYS)}")
    print(f"  * Failure Mode Breakdown:   {dict(fmode_counts)}")
    print(f"  * Turns Distribution:       {dict(turn_counts)}")
    print("=============================================================================\n", flush=True)


if __name__ == "__main__":
    main()
