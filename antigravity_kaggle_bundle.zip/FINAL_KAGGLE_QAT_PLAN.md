# FINAL_KAGGLE_QAT_PLAN.md — Final 3-Option Kaggle QAT Verification Plan (Slot 2)

> **Date:** Saturday, Nov 28, 2026 | **Deadline:** Dec 2, 2026, 23:59 UTC (target final upload **Nov 28–30**; 1 Kaggle submission/day; 20–24h queue).
> **Current Incumbent (PROTECTED):** `submission_E4B_LoRA_v1.zip` (`0.05` Public LB, `5/30` Gate G2, `1/10` on Kaggle `key10`).
> **Hard Stop Rule:** Test **ONLY** the 3 Kaggle-native QAT options below. Promote **ONLY** if a candidate strictly beats `lora_v1` on Kaggle `holdout30` (`>= 7/30` genuine solves, `0` collapse loops). Otherwise **STOP cleanly** and keep `LoRA_v1` locked in Slot 2.

---

## 1. The #1 Root Cause (Why Every Laptop LoRA Failed `0/10` on Kaggle)

On Sat Nov 28, our 4-adapter Kaggle `key10` bake-off under real vLLM `gemma-4-e4b-it-qat-w4a16-ct` proved:

| Arm | Base Model Trained On | Kaggle `key10` Solved | `edit_ok / edit_fail` | Collapse |
|---|---|---|---|---|
| **`lora_v1`** | Kaggle **`gemma-4-e4b-it-qat-q4_0-unquantized`** | **`1/10`** (`fastapi_14786`) | `8 / 7` | `7/10` |
| `lora_v4` | Laptop vanilla BF16 `gemma-4-e4b-it` | `0/10` | `0 / 0` | `10/10` |
| `v6_ep075` | Laptop vanilla BF16 `gemma-4-e4b-it` | `0/10` *(even though it solved `2/4` locally!)* | `0 / 0` | `10/10` |
| `v6_ep10` | Laptop vanilla BF16 `gemma-4-e4b-it` | `0/10` | `0 / 0` | `10/10` |

**Mechanistic Cause (`Gemma E4B and 31B Verification.md`):**
Kaggle serves **`gemma-4-e4b-it-qat-w4a16-ct`**, which is quantized (static symmetric Q4_0, `group_size=32`, no zero points) from **`gemma-4-e4b-it-qat-q4_0-unquantized`** — *NOT* vanilla `gemma-4-e4b-it`. LoRA deltas trained on vanilla BF16 weights suffer severe weight-grid mismatch on QAT `w4a16-ct` and collapse `10/10` with `0` edits.

**Mandatory Fix:** ALL remaining training MUST run **directly on Kaggle** using **`gemma-4-e4b-it-qat-q4_0-unquantized`** (zero laptop training).

---

## 2. Complete Failure Graveyard & Hard Guardrails (DO NOT Skip Any Item)

1. **Base Weight Lineage:** Train ONLY on **`gemma-4-e4b-it-qat-q4_0-unquantized`** in native **BF16 + PyTorch SDPA** (NEVER NF4; NEVER FlashAttention-2 — breaks on `global_head_dim=512`).
2. **Exact E4B KV-Sharing Geometry (`num_layers=42`, `num_kv_shared_layers=18`, `sliding_window=512`):**
   - `L24–41` have **`q_proj/o_proj` + MLP ONLY** (no `k/v_proj`).
   - `L24, L26, L28, L30, L36` are `sliding_attention` and read **`L22`'s** K/V cache (NOT `L23`'s). `L23` (`global_attention`) feeds `L29, L35, L41`.
   - Keep PLE (2.82B), ViT, USM, `embed_tokens`, `lm_head`, `L0–21`, `L41` frozen.
3. **Train/Serve Format Parity (Already Fixed in `V6_Data`):**
   - `V6_Data/e4b_sft_v6_train.jsonl` (336 rows: 216 base + 120 A1 `FileEditError` recovery) & `e4b_sft_v6_val.jsonl` (36 rows) — `0` holdout30 overlap, `0` line-number gutters, `0` invalid JSON, `0` `-p no:anyio`.
   - Render with **`tools=KAGGLE_TOOLS`** (from `parity_common.py`).
   - **Zero loss (`0.0`)** on any assistant message with `"loss_mask": 0` (synthetic bad edits), system, user, and tool-response bodies; keep loss on `<|tool_response>` (ID `50`, assistant stop token).
   - **Loss weights:** `W_SUBMIT = 1.0` (NEVER `2.0` — caused `submit_patchx20` spam), `W_EDIT = 1.5`, other assistant `1.0`.
4. **vLLM `PEFTHelper` G0 Serving Rules (`vLLM Quantized LoRA Serving Brief.md`):**
   - `r = 8` (`<= 16`; `r >= 32` is non-deterministic on INT4 W4A16 `g32`).
   - `target_modules` MUST be an explicit `list[str]` (NEVER regex or `"all-linear"`).
   - `base_model_name_or_path == "google/gemma-4-e4b-it-qat-w4a16-ct"`, `modules_to_save: null`, `use_dora: false`, `bias: "none"`, empty `rank_pattern`/`alpha_pattern`, `0` `embed_tokens`/`lm_head` keys in `adapter_model.safetensors`.
   - Never disable thinking (`--reasoning-parser gemma4` grammar bypass bug): keep `thinking_budget: 1024`, `include_thoughts: false`, `frequency_penalty: 0.30`, `temperature: 0.15`.
5. **No Banned / Regressive Tricks:**
   - NO DPO (`<50` pairs → DPOP collapse), NO TIES/DARE adapter merging (drops HumanEval & PEFT `#4133` silently drops mismatched layers), NO Multi-LoRA/2-stage wrappers, NO `-p no:anyio`.
   - In `kaggle_bakeoff_e4b.ipynb`, keep **`DEDUP_ON = False`** (real Kaggle YAML submissions cannot run custom Python `before_tool_callback` hooks) and **`LEGACY_PROMPT_TOOLS = True`** (4 tools for `v6`/base, 6 tools for `lora_v1`).

---

## 3. The Only 3 Remaining Options (Run on Kaggle, Then STOP)

### Option 1 — Zero-LoRA Base Control (`base_qat_nolora`) [~15 min Kaggle GPU]
- **What:** Run unmodified Kaggle `gemma-4-e4b-it-qat-w4a16-ct` (no LoRA) with `prompts/system_v6_grep.md` (`836 B`) + 4 tools (`read_file`, `edit_file`, `run_command`, `submit_patch`), `T=0.15`, `frequency_penalty=0.30`, `thinking_budget=1024`, `include_thoughts=False`.
- **Why:** Fast 15-minute baseline proving what the clean QAT base achieves with zero adapter distortion.

### Option 2 — Train `LoRA_v6_QAT` on Kaggle `-qat-q4_0-unquantized` [~45–60 min train + ~15 min `key10`]
- **Base:** Kaggle `gemma-4-e4b-it-qat-q4_0-unquantized` (BF16 + SDPA, zero NF4/FA2).
- **Data:** `V6_Data` (`336` train / `36` val), `tools=KAGGLE_TOOLS`, `loss_mask=0` respected, `W_SUBMIT=1.0`, `W_EDIT=1.5`.
- **Layers (60 trainable tensors, `r=8, alpha=16, dropout=0.05`):**
  - `L22`: `q_proj, k_proj, v_proj, o_proj` (4 modules — sliding-KV owner)
  - `L23`: all 7 (`q/k/v/o` + `gate/up/down`)
  - `L24, L26`: `q_proj, o_proj` (2 each)
  - `L28, L30, L36`: `q_proj, o_proj, gate_proj, up_proj, down_proj` (5 each)
- **Schedule:** `lr=1e-4`, `kl_beta=0.10`, `epochs=1.0` (save `ckpt_ep0.75` and `ckpt_ep1.0`, pick lower `val_kl` within 3% `val_ce_w`).

### Option 3 — Warm-Start `LoRA_v1_QAT` on Kaggle `-qat-q4_0-unquantized` [~35–45 min train + ~15 min `key10`]
- **Base + Init:** Kaggle `gemma-4-e4b-it-qat-q4_0-unquantized` + initialize LoRA weights from shipped **`lora_v1`** (`54` tensors on `L[23, 29, 30, 35, 41]`).
- **Data:** Same `V6_Data` (`336` train / `36` val), `tools=KAGGLE_TOOLS`, `loss_mask=0` respected, `W_SUBMIT=1.0`, `W_EDIT=1.5`.
- **Schedule:** Gentle update `lr=5e-5`, `kl_beta=0.12`, `epochs=1.0` (save `ckpt_ep0.5` and `ckpt_ep1.0`). Preserves `lora_v1`'s proven QAT navigation while layering on `V6_Data`'s raw `read_file` + `FileEditError` recovery.

---

## 4. Strict Verification & Promotion Protocol (Anti-Skip Checklist for Antigravity / Hydrogen)

Before ANY Kaggle GPU run, the generated Kaggle training + eval notebook MUST pass every check below:
- [ ] **Check 1 (Model Lineage):** Training script loads Kaggle's **`gemma-4-e4b-it-qat-q4_0-unquantized`** (NOT vanilla `gemma-4-e4b-it`) in native BF16 + SDPA (NO NF4, NO FA2).
- [ ] **Check 2 (Pre-Flight Audit):** Prints `336` train / `36` val, `tools=KAGGLE_TOOLS` active, `loss_mask=0` assistant spans zeroed, `W_SUBMIT=1.0`, `0` holdout30 overlap, exact tensor count (`60` for Option 2, `54` for Option 3).
- [ ] **Check 3 (G0 Export Gate):** Every exported adapter passes `pack_kaggle_bakeoff.py` G0 assertions (`r=8`, explicit `target_modules` list, `base_model_name_or_path == "google/gemma-4-e4b-it-qat-w4a16-ct"`, `0` `embed_tokens`/`lm_head` keys, `modules_to_save: null`, `use_dora: false`, `bias: "none"`).
- [ ] **Check 4 (Kaggle `key10` Bake-Off):** Evaluates `lora_v1` (control) vs `Option 1 (base)` vs `Option 2 (v6_qat)` vs `Option 3 (v1_warm_qat)` with `DEDUP_ON = False`.
- [ ] **Check 5 (Final `holdout30` Gate & STOP):**
  - Run `holdout30` (~30 min on Kaggle) ONLY on the #1 `key10` winner if it beats `lora_v1` (`>= 2/10`).
  - **PROMOTE & SUBMIT TO SLOT 2** if and only if **`holdout30 >= 7/30` AND `0` collapse loops**.
  - **OTHERWISE STOP:** Keep `submission_E4B_LoRA_v1.zip` (`0.05` LB) safely locked in Slot 2. No V7/V8 iterations.
