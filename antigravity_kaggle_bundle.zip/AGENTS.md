# AGENTS.md — Gemma 4 E4B Small-Model Track ($10k Bonus, Slot 2)

> **Mission:** Push **Gemma 4 E4B** (`gemma-4-e4b-it-qat-w4a16-ct`) from **`0.05` Public LB (`3/58`, `5/30` holdout)** to **`0.10–0.12` Public LB (`6–7/58`, `>= 7–9/30` holdout)** before **Dec 2, 2026, 23:59 UTC**.
> **Queue Constraint:** Kaggle queue is **20–24h** with a **1-pending lock** → target final Slot 2 upload by **Nov 29–30** for tie-break seniority.

---

## 1. Hard Rules & Non-Negotiable Gates (NEVER Violate)
1. **Promotion Gate:** NEVER replace incumbent `submission_E4B_LoRA_v1.zip` (`5/30` Gate G2, `0.05` LB) unless a candidate **strictly beats `5/30`** (`>= 7/30` genuine solves on `holdout30`, **`0` collapse loops**). No moving goalposts.
2. **Zero Holdout Leakage:** `holdout_ids` (30 tasks in `V3 Data/splits_99_30.json`) are **strictly evaluation-only**. Never train, tune, or hand-label on them.
3. **Data Compliance (`Rules.md` §2.5, §2.6, §3.6.c):** External training data MUST be public, free, and permissively licensed (CC-BY-4.0 / MIT / Apache-2.0 / BSD). Prefer **open-weight** trajectories (e.g., `nvidia/SWE-Hero-openhands-trajectories` via `Qwen3-Coder-480B`). Do NOT distill proprietary frontier APIs.
4. **ADK Harness Rules (`HARNESS_README.md`):**
   - Root MUST be a single `LlmAgent` (never `SequentialAgent` at root). Use `AgentTool(skip_summarization=true, include_contents="none")` for fresh-context sub-agents.
   - Single base model: `gemma-4-e4b-it-qat-w4a16-ct`. Multi-LoRA under `adapters/` allowed (`r <= 16` for vLLM, `< 3 GiB` total).
   - Standard PEFT `adapter_config.json` ONLY (`"base_model_name_or_path": "google/gemma-4-e4b-it-qat-w4a16-ct"`, no local Windows paths, no PEFT 0.21.3-only keys).
   - Automatic Unsubmitted Patch Recovery (§8.1): harness runs `git add -N . && git diff HEAD` on budget exhaustion — never tell the model to call `submit_patch` on failing tests.
   - Use `thinking_config: {thinking_budget: 1024, include_thoughts: false}` (strips `<|channel>thought...<channel|>` from history) + `frequency_penalty: 0.25–0.35`.

---

## 2. Verified E4B Architecture & Layer Forensics (Attention vs. MLP)
- **Hardware:** Local Windows PC (`mqg1cob`, no admin, no Git Bash), **RTX 2000 Ada (16 GB VRAM)**, Conda env `GH` (`C:\Users\mqg1cob\.conda\envs\GH\python.exe`). Base checkpoint (read-only): `C:\Users\mqg1cob\Documents\Google Hack\gemma-4-e4b-it` (BF16).
- **Exact Config:** `num_layers=42`, `num_kv_shared_layers=18` (`L24–41` have **`q_proj/o_proj` + MLP ONLY, no `k/v_proj`**), `global_layers=[5, 11, 17, 23, 29, 35, 41]`, `sliding_window=512`, `global_head_dim=512`.
- **Interpretability (`viz_live_layers.py` + `check_affected_area.py`):**
  - **`L23`** = #1 Reasoning Bottleneck & highest global KV owner (`Attn_Act=0.666`). `L24–41` read `L23`'s KV cache.
  - **`L[24, 26, 28, 30, 36]`** = Top-5 Tool-Calling & `edit_file` layers:
    - **Attention-driven tool selection & schema:** `L36` Attn (`+0.0814`), `L26` Attn (`+0.0582`).
    - **MLP-driven exact code/string emission:** `L28` MLP (`+0.0420`).
  - **Frozen anchors:** `L0–16`, `L5, L11, L41`, PLE (2.82B), ViT (150M), USM (305M), `embed_tokens`, `lm_head`.
- **CUDA / Training Rules:** Native **BF16 + PyTorch SDPA** ONLY (NEVER NF4 — mismatches `w4a16-ct`; NEVER FlashAttention-2 — breaks on `global_head_dim=512`). Zero-spill 128-tok chunked `lm_head` + 2048-tok chunked MLP (`12.44 GiB` peak VRAM at 8,192 tokens). Single `<bos>`; stop on `<eos>` (`1`), `<|tool_response>` (`50`), `<turn|>` (`106`). Keep loss on ID `50` (tool-call stop); zero loss on tool-result body & ID `51`.

---

## 3. Failure Graveyard (675+ Trials — DO NOT Repeat These)
| Failure / Trap | Root Cause & Evidence | Verified Fix |
|---|---|---|
| **Right-file logic bugs (`56.7%`)** | E4B reads gold file `80–93%`, edits `63–80%`, but only had `21` train rows. | Scale to `240` clean rows (`V5_Data`: 19 local + 221 `SWE-Hero` Qwen3-480B, 65% first-shot / 35% recovery). |
| **`edit_file` `NoMatchError` (`69–85%`)** | Stale indentation/line numbers fall outside `sliding_window=512`. | ~100-tok 8-Law prompt + fresh 20–30 line `read_file` right before `edit_file` + `<=150`-tok pytest outputs. |
| **`512W` Prompt Cliff** | System prompt `> 2,136 B` overflows 35 local layers on Turn 0 (`2,656 B` → `2/99`; `v2` `2,638 B` → `1/30`). | Keep `messages[0]` strictly `<= 2,048 B` (ideally `~100` tokens / `~700 B`). |
| **Overfitting repetition loops** | Wide LoRA (`Arm B` 10.05M, `kl=0`; `Var C` `r=16` 34.88M → `3/30`) or `3` epochs on 21 rows (`v4_ep3` looped on `19/30`). | Surgical `r=8, alpha=16` (78 tensors), `kl_beta=0.05`, **`max 2.0 epochs`** (flag if `val_kl > 0.06`), `frequency_penalty: 0.30`. |
| **Data/prompt poisoning** | `-p no:anyio` (63× in `LoRA_v1`), `| tail -20`, `tests/` edits (`requests_7315`), premature `submit_patch` on `exit=1` (`fastapi_14492`). | Hard-sanitized in `V5_Data` (0 violations, 0 holdout overlap). |
| **`<|tool_response>` loss leak** | Regex masking trained on tool-result tokens (`88.7%`) → `LoRA_v3` Run 1 scored `1/30`. | Exact token-span masking: weight only assistant spans + stop ID `50`. |
| **Tail truncation (`8192`)** | Chopped final `edit_file`/`submit_patch` turns on 23–30% of long traces. | Head + tail preservation (drop middle exploration turns only). |
| **Windows CRLF diffs** | Default Windows `open(..., "w")` wrote `\r\n` → `366 KB` diffs. | Strict `newline="\n"` on write, `newline=""` on read (`404 B` clean diffs). |

---

## 4. Harness Architectures Tested So Far
1. **Single-Pass `LoRA_v1` (`r=8`, `L[23,29,30,35,41]`):** `5/30` Gate G2, `0.05` LB (`3/58`), `0` collapse loops (current Slot 2 incumbent).
2. **Single-Pass `LoRA_v4_Surgical` (`r=8`, `L[23,24,26,28,30,36]`, 3 ep on 21 rows):** `5/30` (`+3` gained, `-3` lost; `19/30` looped; **4 one-test near-misses**). Pass@2 union `LoRA_v1 ∪ LoRA_v4 = 8/30`.
3. **2-Stage Fresh-Context (`eval_2stage` on `v4_ep3`):** Stopped at `1/6` (CRLF bug + ignored `DUPLICATE CALL BLOCKED` + blind `submit_patch` on `exit=1`).
4. **Multi-LoRA (`lora_v4` S1 + `lora_v1` S2 fresh-context on `key10`):** `fastapi_14786` solved cleanly (`404 B`, `9.3 min`), but `fastapi_14616` regressed (`0/5` edits, `28.2 min`). Proved wrapper tricks on 21-row adapters cannot beat `5/30` alone.
5. **ACTIVE NOW:** `train_e4b_v5_local.py` running on RTX 2000 Ada (`216` train / `24` val, 78 tensors on `L[17,23,24,26,28,30,36]`, `r=8`, `2.0` ep, `kl_beta=0.05`, checkpoints at `ep1.0/1.5/2.0`).

---

## 5. Tier-2 On-Demand File Pointers (Open ONLY When Deeper Proof Is Needed)
- `E4B summary/E4B_Master_Trials_and_Forensics.xlsx` — 675+ trial master logs & per-task matrix.
- `HARNESS_README.md` & `Rules.md` — exact ADK, vLLM, and competition legal specs.
- `E4B summary/02_plans/AGENT_CONTINUATION_DOSSIER.md` — full historical continuity dossier.
- `V5_Data/e4b_sft_v5_audit.json` — `LoRA_v5` dataset audit (240 rows, 0 leaks).
- `v5_surgical/train_metrics.json` — live `LoRA_v5` checkpoint metrics (`val_ce`, `val_kl`, VRAM).
- `outputs/affected_area_check/affected_area_fastapi_14786.json` — layer-level Attn/MLP deltas.
