﻿#!/usr/bin/env python3
"""
Local Native-BF16 Surgical LoRA Trainer (LoRA_v6) - tuned for RTX 2000 Ada (16 GB).

Cloned from train_e4b_v5_local.py: native BF16, PyTorch SDPA, no FlashAttention-2, no NF4,
exact 128-token chunked lm_head CE/KL against the frozen base (adapter disabled) as reference.

v6 changes:
- Data: V6_Data train (336) + val (36), Kaggle-format tool results + failed-edit recovery rows.
- Sequences are rendered with tools=KAGGLE_TOOLS (the 4 declarations seen at inference).
- Per-token loss weights: edit_file 1.5x, submit_patch 1.0x, other assistant 1.0x; assistant messages with
  loss_mask 0 and everything else 0. Id 50 (<|tool_response>) stays supervised as the stop token.
- Exactly 60 trainable LoRA tensors (r=8, alpha=16, dropout 0.05): L22 q/k/v/o, L23 all 7, L24/L26 q/o,
  L28/L30/L36 q/o+MLP. L17 is dropped. All other LoRA tensors are frozen (zero-init B, so a no-op).
- lr 1e-4, kl_beta 0.10, 1.5 epochs, checkpoints at 0.75 / 1.0 / 1.5.
- Plan B: --init_adapter PATH --layer_profile v1 warm-starts LoRA_v1 (54 tensors, lr 5e-5, 1 epoch, v6b_v1warm).
- --dry_run: Pre-Flight Audit + 2 optimizer steps on the longest rows, asserts VRAM <= 13.5 GiB, zero NaNs.

Gemma 4 template note: a model turn holds many tool calls. A tool-calling assistant message therefore ends
with <|tool_response> (id 50, in generation_config eos_token_id) and only the final text answer ends with
<turn|> (id 106). Id 50 is kept supervised so the model learns to stop after a call; the tool result
block that follows it (content through <tool_response|>) carries zero weight.
"""
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ["PYTHONUTF8"] = "1"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

import argparse
import gc
import json
import math
import random
import re
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F

from parity_common import KAGGLE_TOOLS

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_GEMMA_DIR = Path(r"C:\Users\mqg1cob\Documents\Google Hack\gemma-4-developer-agent")
DEFAULT_MODEL_DIR = Path(r"C:\Users\mqg1cob\Documents\Google Hack\gemma-4-e4b-it")
DEFAULT_TRAIN_JSONL = SCRIPT_DIR / "V6_Data" / "e4b_sft_v6_train.jsonl"
DEFAULT_VAL_JSONL = SCRIPT_DIR / "V6_Data" / "e4b_sft_v6_val.jsonl"
DEFAULT_SPLITS_JSON = SCRIPT_DIR / "V3 Data" / "splits_99_30.json"
DEFAULT_OUT_DIR = SCRIPT_DIR / "v6_surgical"
DEFAULT_OUT_DIR_V1 = SCRIPT_DIR / "v6b_v1warm"

KAGGLE_BASE_MODEL = "google/gemma-4-e4b-it-qat-w4a16-ct"

TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
_QO = ["q_proj", "o_proj"]
_QO_MLP = _QO + ["gate_proj", "up_proj", "down_proj"]
# layer -> trainable modules; every other LoRA tensor is frozen
PROFILES = {
    "v6": {22: ["q_proj", "k_proj", "v_proj", "o_proj"], 23: TARGET_MODULES, 24: _QO, 26: _QO,
           28: _QO_MLP, 30: _QO_MLP, 36: _QO_MLP},
    "v1": {23: TARGET_MODULES, 29: _QO_MLP, 30: _QO_MLP, 35: _QO_MLP, 41: _QO_MLP},
}
PROFILE_EXPECTED_TENSORS = {"v6": 60, "v1": 54}
EXPECTED_TRAIN_ROWS, EXPECTED_VAL_ROWS = 336, 36

W_EDIT, W_SUBMIT, W_OTHER = 1.5, 1.0, 1.0
CKPT_EPOCHS = [0.75, 1.0, 1.5]

# Gemma 4 special token ids (asserted against the tokenizer in the Pre-Flight Audit)
TC_OPEN, TC_CLOSE, TR_OPEN, TR_CLOSE, TURN_OPEN, TURN_CLOSE, NL_ID = 48, 49, 50, 51, 105, 106, 107
EXPECTED_TOKENS = {48: "<|tool_call>", 49: "<tool_call|>", 50: "<|tool_response>",
                   51: "<tool_response|>", 105: "<|turn>", 106: "<turn|>", 107: "\n", 2: "<bos>"}
TC_SPAN_RE = re.compile(r"^(?:.*?)<\|tool_call>call:[A-Za-z_][A-Za-z0-9_]*\{.*\}<tool_call\|><\|tool_response>$", re.S)


# ----------------------------------------------------------------------------------------------
# Data / tokenization
# ----------------------------------------------------------------------------------------------
def load_jsonl(path: Path) -> list:
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def load_holdout_ids(splits_path: Path) -> set:
    if not splits_path or not splits_path.exists():
        return set()
    d = json.loads(splits_path.read_text(encoding="utf-8"))
    for key in ("holdout", "holdout_ids", "holdout_30", "val_ids"):
        if key in d and isinstance(d[key], list):
            return set(d[key])
    return set()


def clean_messages(messages):
    out = []
    for m in messages:
        c = {"role": m["role"], "content": m.get("content") or ""}
        if m.get("tool_calls"):
            c["tool_calls"] = m["tool_calls"]
        if m["role"] == "tool":
            c["tool_call_id"] = m.get("tool_call_id")
            c["name"] = m.get("name")
        out.append(c)
    return out


def render_ids(tokenizer, msgs) -> list:
    res = tokenizer.apply_chat_template(clean_messages(msgs), tools=KAGGLE_TOOLS, tokenize=True,
                                        add_generation_prompt=False)
    if hasattr(res, "keys") and "input_ids" in res:
        res = res["input_ids"]
    return list(res)


def build_msg_weights(row: dict) -> list:
    msgs = row["messages"]
    prefix = int(row.get("student_prefix_turns", 0))
    ws, a = [0.0] * len(msgs), 0
    for i, m in enumerate(msgs):
        if m["role"] != "assistant":
            continue
        keep = a >= prefix and m.get("loss_mask", 1) not in (0, "0", False)
        a += 1
        if not keep:
            continue
        names = [tc["function"]["name"] for tc in (m.get("tool_calls") or [])]
        ws[i] = W_SUBMIT if "submit_patch" in names else W_EDIT if "edit_file" in names else W_OTHER
    return ws


def scan_segments(ids: list, model_id: int) -> list:
    """Structural parse of a rendered Gemma 4 chat: (kind, start, end_exclusive) segments."""
    segs, n, i = [], len(ids), 0
    while i < n:
        if ids[i] != TURN_OPEN:
            i += 1
            continue
        if i + 2 < n and ids[i + 1] == model_id:
            p = i + 3
            while p < n and ids[p] != TURN_OPEN:
                if ids[p] == TURN_CLOSE:
                    segs.append(("close", p, p + 1))
                    p += 1
                    if p < n and ids[p] == NL_ID:
                        p += 1
                    continue
                s = q = p
                while q < n and ids[q] not in (TR_OPEN, TURN_CLOSE, TURN_OPEN):
                    q += 1
                if q < n and ids[q] == TR_OPEN:
                    r = q + 1
                    while r < n and ids[r] != TR_CLOSE:
                        r += 1
                    segs.append(("asst_tc", s, q + 1))
                    segs.append(("tool", q + 1, min(r + 1, n)))
                    p = r + 1
                    # the template renders a tool-calling message's text AFTER its tool response
                    if p < n and ids[p] not in (TC_OPEN, TURN_CLOSE, TURN_OPEN):
                        d = p
                        while d < n and ids[d] not in (TC_OPEN, TR_OPEN, TURN_CLOSE, TURN_OPEN):
                            d += 1
                        if d < n and ids[d] == TC_OPEN:
                            segs.append(("defer", p, d))
                            p = d
                elif q < n and ids[q] == TURN_CLOSE:
                    segs.append(("asst_text", s, q + 1))
                    p = q + 1
                    if p < n and ids[p] == NL_ID:
                        p += 1
                else:
                    segs.append(("asst_text", s, q))
                    p = q
            i = p
        else:
            i += 1
    return segs


def map_messages(ids: list, msgs: list, model_id: int):
    """Map rendered tokens back to messages.

    Returns (spans, zero_spans, msg_cost, first_model): spans = [(msg_idx, kind, s, e)] for assistant
    call/text spans; zero_spans = tool-response blocks, deferred assistant text and stray turn closes.
    """
    segs = scan_segments(ids, model_id)
    first_model = next(s for s in segs if s[0] != "close")[1]
    closes = [("close", s, e) for kind, s, e in segs if kind == "close"]
    segs = [s for s in segs if s[0] != "close"]
    spans, zero, cost, k = [], list(closes), [0] * len(msgs), 0
    for i, m in enumerate(msgs):
        if m["role"] == "assistant":
            kind, s, e = segs[k]
            k += 1
            if m.get("tool_calls"):
                assert kind == "asst_tc", f"message {i}: expected asst_tc, got {kind}"
            else:
                assert kind == "asst_text", f"message {i}: expected asst_text, got {kind}"
            spans.append((i, kind, s, e))
            cost[i] = e - s
        elif m["role"] == "tool":
            kind, s, e = segs[k]
            k += 1
            assert kind == "tool", f"message {i}: expected tool, got {kind}"
            zero.append(("tool", s, e))
            cost[i] = e - s
            owner = msgs[i - 1]
            if owner["role"] == "assistant" and owner.get("tool_calls") and (owner.get("content") or "").strip():
                nxt = msgs[i + 1]["role"] if i + 1 < len(msgs) else None
                assert k < len(segs), f"message {i}: deferred assistant text missing"
                kind, s, e = segs[k]
                if kind == "defer" or (kind == "asst_text" and nxt in (None, "user")):
                    zero.append(("defer", s, e))
                    cost[i] += e - s
                    k += 1
                else:
                    raise AssertionError(f"message {i}: ambiguous deferred assistant text ({kind}, next={nxt})")
    assert k == len(segs), f"{len(segs) - k} unmatched segments"
    return spans, zero, cost, first_model


def assign_weights(ids: list, msgs: list, ws: list, model_id: int):
    """Per-token loss weights aligned to ids; returns (weights, assistant spans, zero spans, first_model)."""
    spans, zero, _, first_model = map_messages(ids, msgs, model_id)
    weights = [0.0] * len(ids)
    out = []
    for i, kind, s, e in spans:
        out.append((i, kind, s, e, ws[i]))
        if ws[i] > 0:
            for pos in range(s, e):
                weights[pos] = ws[i]
    return weights, out, zero, first_model


def truncate_head_tail(tokenizer, msgs: list, ws: list, max_len: int, model_id: int):
    """Keep msgs[0] (system) + msgs[1] (problem) + the longest suffix that fits; drop middle turns only."""
    ids = render_ids(tokenizer, msgs)
    if len(ids) <= max_len:
        return msgs, ws, ids, 0
    _, _, cost, first_model = map_messages(ids, msgs, model_id)
    starts = [i for i in range(2, len(msgs)) if msgs[i]["role"] == "assistant"]
    suffix = [0] * (len(msgs) + 1)
    for i in range(len(msgs) - 1, -1, -1):
        suffix[i] = suffix[i + 1] + cost[i]
    cand = [k for k in starts if first_model + suffix[k] <= max_len - 8]
    if not cand:
        raise RuntimeError("Even the final turn does not fit max_seq_len after head preservation")
    ci = starts.index(cand[0])
    while ci < len(starts):
        k = starts[ci]
        new_msgs, new_ws = msgs[:2] + msgs[k:], ws[:2] + ws[k:]
        new_ids = render_ids(tokenizer, new_msgs)
        if len(new_ids) <= max_len and any(w > 0 for w in new_ws):
            return new_msgs, new_ws, new_ids, k - 2
        ci += 1
    raise RuntimeError("Head+tail truncation could not fit row")


def encode_row(row: dict, tokenizer, max_seq_len: int, model_id: int) -> dict:
    msgs, ws = row["messages"], build_msg_weights(row)
    orig_len = len(render_ids(tokenizer, msgs))
    msgs2, ws2, ids, dropped = truncate_head_tail(tokenizer, msgs, ws, max_seq_len, model_id)
    weights, spans, zero, first_model = assign_weights(ids, msgs2, ws2, model_id)
    labels = [ids[p] if weights[p] > 0 else -100 for p in range(len(ids))]
    return {
        "task_id": row.get("task_id", "unknown"), "repo": row.get("repo", "unknown"),
        "source": row.get("source", "unknown"), "tag": row.get("tag", ""),
        "prefix_turns": int(row.get("student_prefix_turns", 0)),
        "msgs": msgs2, "orig_msgs": msgs, "ids": ids, "zero": zero, "first_model": first_model, "spans": spans,
        "input_ids": torch.tensor([ids], dtype=torch.long),
        "labels": torch.tensor([labels], dtype=torch.long),
        "weights": torch.tensor([weights], dtype=torch.float32),
        "orig_len": orig_len, "seq_len": len(ids), "dropped_msgs": dropped,
        "unmasked_tokens": sum(1 for x in labels if x != -100),
    }


# ----------------------------------------------------------------------------------------------
# Pre-Flight Audit
# ----------------------------------------------------------------------------------------------
def tool_call_signature(row: dict) -> set:
    sig = set()
    for m in row["messages"]:
        if m["role"] != "assistant":
            continue
        for tc in m.get("tool_calls") or []:
            sig.add((tuple(sorted(set(m) - {"loss_mask"})), tuple(sorted(tc)),
                     tuple(sorted(tc["function"])), tc.get("type"), type(tc["function"]["arguments"]).__name__))
    return sig


def prefix_diff_crosscheck(tokenizer, row: dict, enc: dict, model_id: int):
    """Validate structural spans against the v4-style prefix-render diff on one (short) row."""
    msgs = enc["msgs"]
    spans = {i: (s, e) for i, kind, s, e, _ in enc["spans"]}
    for i, m in enumerate(msgs):
        if m["role"] != "assistant" or (m.get("tool_calls") and (m.get("content") or "").strip()):
            continue  # text-bearing calls render their text in a different slot per prefix; covered by map_messages
        a = len(render_ids(tokenizer, msgs[:i]))
        b = len(render_ids(tokenizer, msgs[: i + 1]))
        s, e = spans[i]
        # +3 = "<|turn>model\n" header; -2 = "<turn|>\n" the template appends when a prefix ends in a tool reply carrying deferred text
        assert (s - a) in (0, 3, -2) and e in (b, b - 1), f"{enc['task_id']} msg {i}: scan=({s},{e}) prefix=({a},{b})"


def preflight_audit(tokenizer, train_rows, val_rows, holdout_ids, max_seq_len):
    t0 = time.time()
    print("=" * 78 + "\n[PRE-FLIGHT] Real Gemma 4 tokenizer audit\n" + "=" * 78)
    assert len(train_rows) == EXPECTED_TRAIN_ROWS, f"train rows {len(train_rows)} != {EXPECTED_TRAIN_ROWS}"
    assert len(val_rows) == EXPECTED_VAL_ROWS, f"val rows {len(val_rows)} != {EXPECTED_VAL_ROWS}"
    for tid, tok_str in EXPECTED_TOKENS.items():
        got = tokenizer.convert_ids_to_tokens(tid)
        assert got == tok_str, f"token id {tid}: expected {tok_str!r}, got {got!r}"
    model_id = tokenizer.convert_tokens_to_ids("model")
    assert tokenizer.convert_ids_to_tokens(model_id) == "model"
    leaked = [r.get("task_id") for r in train_rows + val_rows if r.get("task_id") in holdout_ids]
    assert not leaked, f"holdout30 overlap: {leaked}"
    for r in train_rows + val_rows:
        asst_txt = "\n".join(str(m.get("content") or "") + str(m.get("tool_calls") or "")
                             for m in r["messages"] if m["role"] == "assistant")
        assert "no:anyio" not in asst_txt and "| tail" not in asst_txt, f"poisoned row {r.get('task_id')}"
    systems = {r["messages"][0]["content"] for r in train_rows + val_rows}
    assert len(systems) == 1, f"{len(systems)} distinct system prompts"
    print(f"[OK] ids {sorted(EXPECTED_TOKENS)} map to the expected Gemma 4 tokens | no holdout overlap | "
          f"single system prompt ({len(next(iter(systems)).encode())} B)")

    # 1. tool-call format parity (local vs external)
    loc = next(r for r in train_rows if r.get("source") == "local_train99")
    ext = next(r for r in train_rows if r.get("source") != "local_train99")
    s_loc, s_ext = tool_call_signature(loc), tool_call_signature(ext)
    assert s_loc == s_ext, f"tool-call signature differs:\n local={s_loc}\n ext={s_ext}"
    print(f"[OK] format parity: local={loc['task_id']} vs external={ext['task_id']} -> identical structure {sorted(s_loc)[0][1:]}")

    # 2. encode every row (head+tail truncation included) and run per-row assertions
    t_enc = time.time()
    enc_train = [encode_row(r, tokenizer, max_seq_len, model_id) for r in train_rows]
    enc_val = [encode_row(r, tokenizer, max_seq_len, model_id) for r in val_rows]
    allenc = enc_train + enc_val
    print(f"[OK] encoded {len(allenc)} rows in {time.time() - t_enc:.1f}s")

    n_trunc = n_asst = n_text_final = n_tc_spans = 0
    wcount = {"edit_file": 0, "submit_patch": 0, "other": 0}
    for e in allenc:
        ids = e["ids"]
        assert ids[0] == 2 and ids.count(2) == 1, f"{e['task_id']}: expected exactly one <bos> at position 0"
        assert e["seq_len"] <= max_seq_len, f"{e['task_id']}: seq {e['seq_len']} > {max_seq_len}"
        assert e["unmasked_tokens"] > 0, f"{e['task_id']}: zero supervised tokens"
        w = e["weights"][0].tolist()
        # 0% weight on system / user / tool-response content
        assert sum(w[: e["first_model"]]) == 0.0, f"{e['task_id']}: weight on system/user prefix"
        for kind, s, en in e["zero"]:
            assert sum(w[s:en]) == 0.0, f"{e['task_id']}: weight on {kind} segment"
        assert all(w[p] == 0.0 for p, t in enumerate(ids) if t == TR_CLOSE), f"{e['task_id']}: weight on <tool_response|>"
        # every assistant span ends with an EOS id (50 after a call, 106 after the final text)
        for i, kind, s, en, wt in e["spans"]:
            n_asst += 1
            last = ids[en - 1]
            if kind == "asst_tc":
                n_tc_spans += 1
                assert last == TR_OPEN, f"{e['task_id']} msg {i}: tool-call span must end with <|tool_response>"
                txt = tokenizer.decode(ids[s:en])
                assert TC_SPAN_RE.match(txt), f"{e['task_id']} msg {i}: malformed tool-call span {txt[:120]!r}"
            else:
                assert last == TURN_CLOSE, f"{e['task_id']} msg {i}: final text span must end with <turn|> (106)"
                n_text_final += 1
            if wt > 0:
                names = [tc["function"]["name"] for tc in (e["msgs"][i].get("tool_calls") or [])]
                wcount["submit_patch" if "submit_patch" in names else "edit_file" if "edit_file" in names else "other"] += 1
        # tail preservation: last message and head are untouched
        assert e["msgs"][-1] is e["orig_msgs"][-1], f"{e['task_id']}: tail chopped"
        assert e["msgs"][0] is e["orig_msgs"][0] and e["msgs"][1] is e["orig_msgs"][1]
        if e["dropped_msgs"]:
            n_trunc += 1
    print(f"[OK] single <bos> on {len(allenc)}/{len(allenc)} rows | every assistant span ends with EOS "
          f"({n_tc_spans} x <|tool_response>(50), {n_text_final} x <turn|>(106))")
    print("[OK] 0.0 weight on system, user, and tool-response blocks (<|tool_response> opener kept only as the "
          "assistant's stop token)")
    print(f"[OK] weights: edit_file x{W_EDIT}={wcount['edit_file']} spans | submit_patch x{W_SUBMIT}={wcount['submit_patch']} spans | "
          f"other x{W_OTHER}={wcount['other']} spans")
    long_rows = [e for e in allenc if e["orig_len"] > max_seq_len]
    print(f"[OK] head+tail truncation: {len(long_rows)} rows > {max_seq_len} tokens "
          f"({sum(1 for e in long_rows if e['source'] == 'local_train99')} local), 0 tails chopped")
    for e in long_rows:
        print(f"      {e['task_id']:<34} {e['orig_len']:>6} -> {e['seq_len']:>5} tokens, dropped {e['dropped_msgs']} middle msgs")

    # 3. cross-check structural spans vs. prefix-render diff on 1 short local (prefix) + 1 short external row
    cands = [e for e in enc_train if e["source"] == "local_train99" and e["prefix_turns"] > 0] or \
            [e for e in enc_train if e["source"] == "local_train99"]
    chk = [min(cands, key=lambda e: e["seq_len"]), min((e for e in enc_train if e["source"] != "local_train99"),
                                                        key=lambda e: e["seq_len"])]
    for e in chk:
        prefix_diff_crosscheck(tokenizer, None, e, model_id)
    print(f"[OK] span cross-check vs prefix-render diff: {[e['task_id'] for e in chk]}")
    print(f"[PRE-FLIGHT] PASSED in {time.time() - t0:.1f}s\n" + "=" * 78)
    summary = {
        "rows": len(allenc), "truncated_rows": n_trunc, "tails_chopped": 0, "assistant_spans": n_asst,
        "weighted_spans": dict(wcount),
        "elapsed_sec": round(time.time() - t0, 1), "system_prompt": next(iter(systems)),
    }
    return enc_train, enc_val, summary


# ----------------------------------------------------------------------------------------------
# Engine (cloned from v4, extended with per-token loss weights)
# ----------------------------------------------------------------------------------------------
def get_backbone_lm_head(peft_model):
    base = peft_model.get_base_model()
    backbone = base.model
    lm_head = base.get_output_embeddings()
    if lm_head is None:
        lm_head = getattr(base, "lm_head", None)
    cfg = base.config.get_text_config() if hasattr(base.config, "get_text_config") else base.config
    softcap = getattr(cfg, "final_logit_softcapping", None)
    return backbone, lm_head, softcap


def chunked_sft_kl_step(peft_model, batch, kl_beta: float, grad_accum: int, chunk_size: int = 128,
                        do_backward: bool = True):
    """Weighted CE (normalised by sum of weights) + beta * mean KL(base || adapter), exact chunked lm_head."""
    backbone, lm_head, softcap = get_backbone_lm_head(peft_model)
    device = next(p for p in peft_model.parameters() if p.requires_grad).device
    ids = batch["input_ids"].to(device)
    labels = batch["labels"].to(device)
    wts = batch["weights"].to(device)
    attn_mask = torch.ones_like(ids, device=device)

    shift_labels = labels[:, 1:]
    mask = shift_labels != -100
    active_targets = shift_labels[mask]
    active_w = wts[:, 1:][mask]
    n_active = int(active_targets.numel())
    if n_active == 0:
        return {"ce": 0.0, "ce_w": 0.0, "kl": 0.0}
    w_sum = float(active_w.sum().item())

    out = backbone(input_ids=ids, attention_mask=attn_mask, use_cache=False)
    hidden = out.last_hidden_state[:, :-1, :][mask]

    ref_hidden = None
    if kl_beta > 0.0:
        with torch.no_grad(), peft_model.disable_adapter():
            ref_out = backbone(input_ids=ids, attention_mask=attn_mask, use_cache=False)
            ref_hidden = ref_out.last_hidden_state[:, :-1, :][mask].detach()
            del ref_out

    h_leaf = hidden.detach().requires_grad_(True) if do_backward else hidden.detach()
    ce_total, ce_w_total, kl_total = 0.0, 0.0, 0.0

    for s in range(0, n_active, chunk_size):
        e = min(s + chunk_size, n_active)
        logits_c = lm_head(h_leaf[s:e]).float()
        if softcap is not None and softcap > 0:
            logits_c = softcap * torch.tanh(logits_c / softcap)

        ce_vec = F.cross_entropy(logits_c, active_targets[s:e], reduction="none")
        ce_w_sum = (ce_vec * active_w[s:e]).sum()
        ce_total += float(ce_vec.detach().sum().item())
        ce_w_total += float(ce_w_sum.detach().item())

        chunk_loss = ce_w_sum / (w_sum * grad_accum)
        kl_sum = None
        if kl_beta > 0.0 and ref_hidden is not None:
            with torch.no_grad():
                ref_logits_c = lm_head(ref_hidden[s:e]).float()
                if softcap is not None and softcap > 0:
                    ref_logits_c = softcap * torch.tanh(ref_logits_c / softcap)
                ref_probs_c = F.softmax(ref_logits_c, dim=-1)
            log_p_c = F.log_softmax(logits_c, dim=-1)
            kl_sum = F.kl_div(log_p_c, ref_probs_c, reduction="sum")
            kl_total += float(kl_sum.detach().item())
            chunk_loss = chunk_loss + kl_beta * kl_sum / (n_active * grad_accum)
            del ref_logits_c, ref_probs_c, log_p_c

        if do_backward:
            chunk_loss.backward()
        del logits_c, ce_vec, ce_w_sum, chunk_loss, kl_sum

    if do_backward:
        hidden.backward(h_leaf.grad)

    del out, hidden, h_leaf, ref_hidden
    return {"ce": ce_total / n_active, "ce_w": ce_w_total / w_sum, "kl": kl_total / n_active}


def chunk_mlps(base_model, chunk: int) -> int:
    """Run each decoder MLP over sequence chunks under checkpointing (position-wise, so numerically equivalent).

    Gemma 4 KV-shared layers have a double-wide MLP; at 8k tokens its backward transient costs ~1.1 GiB.
    """
    from torch.utils.checkpoint import checkpoint
    n = 0
    for name, mod in base_model.named_modules():
        if not re.search(r"layers\.\d+\.mlp$", name) or re.search(r"vision|audio", name):
            continue
        orig = mod.forward

        def make(orig):
            def fwd(x):
                if x.shape[1] <= chunk:
                    return orig(x)
                return torch.cat([checkpoint(orig, x[:, s:s + chunk], use_reentrant=False)
                                  for s in range(0, x.shape[1], chunk)], dim=1)
            return fwd

        mod.forward = make(orig)
        n += 1
    return n


@torch.no_grad()
def evaluate_val(peft_model, val_items, kl_beta: float, chunk_size: int = 128):
    peft_model.eval()
    res = [chunked_sft_kl_step(peft_model, it, kl_beta=kl_beta, grad_accum=1, chunk_size=chunk_size,
                               do_backward=False) for it in val_items]
    peft_model.train()
    gc.collect()
    torch.cuda.empty_cache()
    mean = lambda k: round(sum(r[k] for r in res) / max(1, len(res)), 4)
    return {"val_ce": mean("ce"), "val_ce_weighted": mean("ce_w"), "val_kl": mean("kl")}


# ----------------------------------------------------------------------------------------------
# Kaggle-safe adapter export
# ----------------------------------------------------------------------------------------------
def export_adapter(model, ckpt_dir: Path, layers: list, rank: int = 8, alpha: int = 16, dropout: float = 0.05):
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(ckpt_dir), safe_serialization=True)
    cfg = {
        "task_type": "CAUSAL_LM", "peft_type": "LORA", "auto_mapping": None,
        "base_model_name_or_path": KAGGLE_BASE_MODEL, "revision": None, "inference_mode": True,
        "r": rank, "target_modules": sorted(TARGET_MODULES), "lora_alpha": alpha, "lora_dropout": dropout,
        "fan_in_fan_out": False, "bias": "none", "use_rslora": False, "modules_to_save": None,
        "init_lora_weights": True, "layers_to_transform": layers, "layers_pattern": "layers",
        "rank_pattern": {}, "alpha_pattern": {}, "use_dora": False,
    }
    text = json.dumps(cfg, indent=2)
    assert "\\\\" not in text and ":/" not in text and "Users" not in text, "path leaked into adapter_config"
    (ckpt_dir / "adapter_config.json").write_text(text, encoding="utf-8")
    readme = ckpt_dir / "README.md"
    if readme.exists():
        readme.unlink()


# ----------------------------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Local Native-BF16 Surgical LoRA v6 Trainer")
    ap.add_argument("--gemma_dir", type=Path, default=DEFAULT_GEMMA_DIR)
    ap.add_argument("--model_id", type=str, default=str(DEFAULT_MODEL_DIR))
    ap.add_argument("--train_jsonl", type=Path, default=DEFAULT_TRAIN_JSONL)
    ap.add_argument("--val_jsonl", type=Path, default=DEFAULT_VAL_JSONL)
    ap.add_argument("--splits_json", type=Path, default=DEFAULT_SPLITS_JSON)
    ap.add_argument("--out_dir", type=Path, default=None, help="default v6_surgical (v6b_v1warm for --layer_profile v1)")
    ap.add_argument("--max_seq_len", type=int, default=8192)
    ap.add_argument("--chunk_size", type=int, default=128)
    ap.add_argument("--mlp_chunk", type=int, default=2048, help="sequence chunk for checkpointed MLP (VRAM)")
    ap.add_argument("--epochs", type=float, default=None, help="default 1.5 (1.0 for --layer_profile v1)")
    ap.add_argument("--lr", type=float, default=None, help="default 1e-4 (5e-5 for --layer_profile v1)")
    ap.add_argument("--warmup_frac", type=float, default=0.10)
    ap.add_argument("--kl_beta", type=float, default=0.10)
    ap.add_argument("--kl_warn", type=float, default=0.25)
    ap.add_argument("--grad_accum", type=int, default=4)
    ap.add_argument("--vram_limit_gib", type=float, default=13.5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--init_adapter", type=Path, default=None, help="warm-start from an existing LoRA folder (Plan B)")
    ap.add_argument("--layer_profile", choices=sorted(PROFILES), default="v6")
    ap.add_argument("--dry_run", action="store_true",
                    help="Pre-Flight Audit + 2 optimizer steps on the longest rows; assert VRAM and zero NaNs")
    args = ap.parse_args()

    profile = args.layer_profile
    layer_modules = PROFILES[profile]
    target_layers = sorted(layer_modules)
    if args.epochs is None:
        args.epochs = 1.0 if profile == "v1" else 1.5
    if args.lr is None:
        args.lr = 5e-5 if profile == "v1" else 1e-4
    if args.out_dir is None:
        args.out_dir = DEFAULT_OUT_DIR_V1 if profile == "v1" else DEFAULT_OUT_DIR
    assert 0 < args.epochs <= 2.0, "epochs must be <= 2.0 (3 epochs looped in earlier arms)"
    torch.manual_seed(args.seed)
    rng = random.Random(args.seed)
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Pre-Flight Audit (tokenizer only, no GPU)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model_id)
    train_rows = load_jsonl(args.train_jsonl)
    val_rows = load_jsonl(args.val_jsonl)
    enc_train, enc_val, pf_summary = preflight_audit(
        tokenizer, train_rows, val_rows, load_holdout_ids(args.splits_json), args.max_seq_len)
    sys_prompt = pf_summary.pop("system_prompt")
    if not args.dry_run:
        (out_dir / "prompts").mkdir(exist_ok=True)
        (out_dir / "prompts" / "system.md").write_text(sys_prompt, encoding="utf-8")
    print(f"[DATA] train={len(enc_train)} val={len(enc_val)} | avg_seq={sum(e['seq_len'] for e in enc_train)/len(enc_train):.0f} "
          f"| avg_supervised={sum(e['unmasked_tokens'] for e in enc_train)/len(enc_train):.0f}")

    # 2. Load base E4B in native BF16 (SDPA, no NF4, no FlashAttention-2)
    sys.path.insert(0, str(args.gemma_dir.resolve()))
    from win_harness_triage_parallel import BatchedGemmaServer
    from win_frontier_6harness_overnight import _deep_strip_multimodal_vram
    from peft import LoraConfig, get_peft_model

    server = BatchedGemmaServer(model_id=args.model_id, max_batch_size=1, adapter_dir=None)
    used_gb = _deep_strip_multimodal_vram(server)
    model = server.engine.model
    print(f"[GPU] Base E4B loaded in native BF16 ({used_gb:.2f} GiB VRAM, zero NF4)")

    # 3. Surgical LoRA
    model.config.use_cache = False
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()
    if args.init_adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, str(args.init_adapter.resolve()), is_trainable=True)
    else:
        lora_cfg = LoraConfig(r=8, lora_alpha=16, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM",
                              target_modules=TARGET_MODULES, layers_to_transform=target_layers, layers_pattern="layers")
        model = get_peft_model(model, lora_cfg)

    # Only the (layer, module) pairs in the profile train; every other LoRA tensor is frozen.
    site_re = re.compile(r"\.layers\.(\d+)\..*?\.(q_proj|k_proj|v_proj|o_proj|gate_proj|up_proj|down_proj)\.")
    for n, p in model.named_parameters():
        if "lora_" in n:
            m = site_re.search(n)
            p.requires_grad_(bool(m) and m.group(2) in layer_modules.get(int(m.group(1)), []))

    names = [n for n, p in model.named_parameters() if p.requires_grad]
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    layer_mods = {}
    for n in names:
        m = site_re.search(n)
        assert m, f"trainable tensor outside decoder layers: {n}"
        assert "lora_" in n and not re.search(r"embed|lm_head|vision|audio|per_layer", n), f"unexpected trainable: {n}"
        layer_mods.setdefault(int(m.group(1)), set()).add(m.group(2))
    assert layer_mods == {l: set(ms) for l, ms in layer_modules.items()}, \
        f"trainable map {({l: sorted(m) for l, m in sorted(layer_mods.items())})} != profile {profile}"
    assert len(names) == PROFILE_EXPECTED_TENSORS[profile], f"{len(names)} tensors != {PROFILE_EXPECTED_TENSORS[profile]}"
    print(f"[LORA] profile={profile} tensors={len(names)} params={n_params:,} | "
          + " ".join(f"L{l}:{len(ms)}mods" for l, ms in sorted(layer_mods.items()))
          + (f" | warm-start {args.init_adapter}" if args.init_adapter else "")
          + " | all other layers, PLE, ViT, USM, embed, lm_head frozen")
    print(f"[VRAM] sequence-chunked checkpointed MLP on {chunk_mlps(model.get_base_model(), args.mlp_chunk)} layers "
          f"(chunk={args.mlp_chunk} tokens)")

    # 4. Schedule
    n_train = len(enc_train)
    order = []
    for _ in range(math.ceil(args.epochs)):
        ep_items = list(enc_train)
        rng.shuffle(ep_items)
        order.extend(ep_items)
    total_rows = int(round(n_train * args.epochs))
    order = order[:total_rows]
    total_opt_steps = max(1, math.ceil(total_rows / args.grad_accum))
    warmup_steps = max(1, math.ceil(args.warmup_frac * total_opt_steps))
    ckpt_at = {int(round(n_train * e)): e for e in CKPT_EPOCHS if e <= args.epochs + 1e-9}
    if total_rows not in ckpt_at:
        ckpt_at[total_rows] = args.epochs
    max_opt_steps = None
    val_items = enc_val
    if args.dry_run:
        order = sorted(enc_train, key=lambda e: -e["seq_len"])[: 2 * args.grad_accum]
        ckpt_at = {}
        max_opt_steps = 2
        val_items = sorted(enc_val, key=lambda e: -e["seq_len"])[:2]
        print(f"[DRY-RUN] {len(order)} longest rows (seq {order[-1]['seq_len']}..{order[0]['seq_len']}), "
              f"2 optimizer steps, {len(val_items)} longest val rows")

    def lr_at(step: int) -> float:
        if step <= warmup_steps:
            return args.lr * step / warmup_steps
        prog = (step - warmup_steps) / max(1, total_opt_steps - warmup_steps)
        return args.lr * (0.1 + 0.45 * (1.0 + math.cos(math.pi * prog)))

    metrics = {
        "mode": "dry_run" if args.dry_run else "train", "layer_profile": profile, "target_layers": target_layers,
        "trainable_modules": {str(l): sorted(ms) for l, ms in sorted(layer_mods.items())},
        "init_adapter": str(args.init_adapter) if args.init_adapter else None,
        "trainable_tensors": len(names), "trainable_params": n_params,
        "lr": args.lr, "warmup_steps": warmup_steps, "total_opt_steps": total_opt_steps,
        "grad_accum": args.grad_accum, "kl_beta": args.kl_beta, "epochs": args.epochs,
        "max_seq_len": args.max_seq_len, "loss_weights": {"edit_file": W_EDIT, "submit_patch": W_SUBMIT, "other": W_OTHER},
        "num_train_rows": n_train, "num_val_rows": len(val_items), "preflight": pf_summary,
        "history": [], "epoch_evals": {}, "warnings": [], "nan_events": 0,
    }
    metrics_path = out_dir / ("dry_run_metrics.json" if args.dry_run else "train_metrics.json")

    def dump():
        metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    def check_val(tag, ev):
        ev = dict(ev, peak_vram_gib=round(torch.cuda.max_memory_allocated() / 1024 ** 3, 2))
        metrics["epoch_evals"][tag] = ev
        if ev["val_kl"] > args.kl_warn:
            msg = f"val_kl={ev['val_kl']} > {args.kl_warn} at {tag}: adapter drifting from base"
            metrics["warnings"].append(msg)
            print(f"[WARNING] {msg}")
        return ev

    # 5. Eval on start
    torch.cuda.reset_peak_memory_stats()
    ev0 = check_val("start", evaluate_val(model, val_items, args.kl_beta, args.chunk_size))
    print(f"[EVAL start] val_ce={ev0['val_ce']} (w={ev0['val_ce_weighted']}) | val_kl={ev0['val_kl']}")
    assert math.isfinite(ev0["val_ce"]) and math.isfinite(ev0["val_kl"]), "NaN in start eval"

    # 6. Train
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr, weight_decay=0.01)
    params = [p for p in model.parameters() if p.requires_grad]
    model.train()
    optimizer.zero_grad(set_to_none=True)
    opt_step, since_step, t0 = 0, 0, time.time()
    print(f"[TRAIN] rows={len(order)} opt_steps={total_opt_steps} warmup={warmup_steps} lr={args.lr} "
          f"ckpts@{sorted(ckpt_at.values())}")

    for gi, item in enumerate(order, 1):
        r = chunked_sft_kl_step(model, item, args.kl_beta, args.grad_accum, args.chunk_size, do_backward=True)
        since_step += 1
        peak = torch.cuda.max_memory_allocated() / 1024 ** 3
        if not (math.isfinite(r["ce"]) and math.isfinite(r["kl"])):
            metrics["nan_events"] += 1
            dump()
            raise RuntimeError(f"Non-finite loss at row {gi} ({item['task_id']}): {r}")
        print(f"  [{gi:03d}/{len(order)}] {item['task_id']:<34} seq={item['seq_len']:>5} ce={r['ce']:.4f} "
              f"ce_w={r['ce_w']:.4f} kl={r['kl']:.4f} peak={peak:.2f} GiB", flush=True)
        metrics["history"].append({"row": gi, "task_id": item["task_id"], "seq_len": item["seq_len"],
                                   "ce": round(r["ce"], 4), "ce_w": round(r["ce_w"], 4),
                                   "kl": round(r["kl"], 4), "peak_vram_gib": round(peak, 2)})

        at_ckpt = gi in ckpt_at
        if since_step == args.grad_accum or at_ckpt or gi == len(order):
            gnorm = torch.nn.utils.clip_grad_norm_(params, 1.0)
            if not torch.isfinite(gnorm):
                metrics["nan_events"] += 1
                dump()
                raise RuntimeError(f"Non-finite grad norm at row {gi}")
            opt_step += 1
            for pg in optimizer.param_groups:
                pg["lr"] = lr_at(opt_step)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            since_step = 0
            gc.collect()
            torch.cuda.empty_cache()
            print(f"  >> opt_step {opt_step}/{total_opt_steps} lr={lr_at(opt_step):.2e} grad_norm={float(gnorm):.3f}", flush=True)
            if max_opt_steps and opt_step >= max_opt_steps:
                break

        if at_ckpt:
            e_val = ckpt_at[gi]
            tag = "ep" + (f"{e_val:.2f}"[:-1] if f"{e_val:.2f}".endswith("0") else f"{e_val:.2f}")  # 0.75 -> ep0.75, 1.0 -> ep1.0
            ev = check_val(tag, evaluate_val(model, val_items, args.kl_beta, args.chunk_size))
            ckpt_dir = out_dir / f"ckpt_{tag}"
            export_adapter(model, ckpt_dir, target_layers)
            print(f"[CKPT {tag}] {ckpt_dir} | val_ce={ev['val_ce']} (w={ev['val_ce_weighted']}) | val_kl={ev['val_kl']} "
                  f"| peak={ev['peak_vram_gib']} GiB")
            dump()

    peak_alloc = torch.cuda.max_memory_allocated() / 1024 ** 3
    peak_resv = torch.cuda.max_memory_reserved() / 1024 ** 3
    metrics.update({"peak_vram_gib": round(peak_alloc, 2), "peak_vram_reserved_gib": round(peak_resv, 2),
                    "wall_time_sec": round(time.time() - t0, 1)})

    # 7. Dry-run verdict (+ export probe so the Kaggle-safe config is verified too)
    if args.dry_run:
        probe = out_dir / "dry_run" / "ckpt_probe"
        export_adapter(model, probe, target_layers)
        cfg = json.loads((probe / "adapter_config.json").read_text(encoding="utf-8"))
        cfg_text = json.dumps(cfg)
        checks = {
            f"{len(names)} trainable tensors == {PROFILE_EXPECTED_TENSORS[profile]}": len(names) == PROFILE_EXPECTED_TENSORS[profile],
            f"peak_vram_allocated {peak_alloc:.2f} <= {args.vram_limit_gib} GiB": peak_alloc <= args.vram_limit_gib,
            "zero NaN/inf events": metrics["nan_events"] == 0,
            "all losses finite": all(math.isfinite(h["ce"]) and math.isfinite(h["kl"]) for h in metrics["history"]),
            "2 optimizer steps completed": opt_step == 2,
            "adapter_config clean (Kaggle base, no local path, r<=16)": (
                cfg["base_model_name_or_path"] == KAGGLE_BASE_MODEL and cfg["layers_to_transform"] == target_layers
                and cfg["r"] <= 16 and "C:" not in cfg_text and "Users" not in cfg_text),
        }
        metrics["dry_run_checks"] = checks
        dump()
        print("\n[DRY-RUN VERDICT]")
        for k, v in checks.items():
            print(f"  {'PASS' if v else 'FAIL'}  {k}")
        print(f"  peak reserved={peak_resv:.2f} GiB | wall={metrics['wall_time_sec']}s | metrics -> {metrics_path}")
        sys.exit(0 if all(checks.values()) else 1)

    dump()
    print(f"\n[DONE] wall={metrics['wall_time_sec']}s peak_vram={metrics['peak_vram_gib']} GiB | warnings={metrics['warnings']} "
          f"| metrics -> {metrics_path}")


if __name__ == "__main__":
    main()
