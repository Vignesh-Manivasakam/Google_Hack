# Review.md — Surgical Coding & Review Protocol (Gemma 4 E4B)

Behavioral guidelines for executing `Plan_copilot.md` (`C0`–`C6`) cleanly with zero spec drift.

---

## 0. Role Split
- **Code Writer (Gemini Enterprise / Sonnet):** Implements ONLY new files (`C0`–`C6`) strictly from `Plan_copilot.md`. Never modifies existing baseline files (`eval_v4_local.py`, `train_e4b_v5_local.py`, `build_external_sft_v5.py`).
- **Reviewer (Sonnet):** Audits every new file against Section 5 (Hard Invariants) below. Fixes ONLY verified bugs or spec mismatches with minimal surgical diffs.

---

## 1. Think Before Coding
- State assumptions explicitly before implementing; if `Plan_copilot.md` leaves an edge case ambiguous, flag it instead of guessing silently.
- Do not invent extra CLI flags, wrappers, or abstractions not requested in `Plan_copilot.md`.

## 2. Simplicity First
- Minimum code that satisfies `Plan_copilot.md`. Nothing speculative.
- No abstractions for single-use code; no error handling for impossible scenarios.

## 3. Surgical Changes
- Never modify existing baseline files — only create/edit the new `v6` / `parity` files.
- Every changed line must trace directly to a spec requirement or a verified bug.

## 4. Goal-Driven Execution
- `C0/C1/C2` (`parity_common.py`, `v6_surgical/prompts/system.md`, `eval_parity_local.py`) → verify: `system.md <= 900 B`, raw `read_file` (no gutters), 3-tier `edit_file` with LF `newline="\n"`, serial `workers=1`, saves `traces/{tid}.json`.
- `C3` (`build_v6_from_v5.py`) → verify: `336` train / `36` val rows, `0` `holdout30` overlap, `0` gutter prefixes (`^\s*\d+\s*(:|\|)\s`), valid JSON tool results, `+120` failed-edit recovery rows.
- `C4` (`train_e4b_v6_local.py`) → verify: `--dry_run` passes with `60` trainable tensors (`L[22,23,24,26,28,30,36]`), `peak VRAM <= 13.5 GiB`, `0` NaNs, clean Kaggle `adapter_config.json`.

---

## 5. Mandatory Audit Checklist (Reject / Fix Immediately If Violated)
1. **No Existing Files Modified:** Only new files created (`parity_common.py`, `eval_parity_local.py`, `build_v6_from_v5.py`, `train_e4b_v6_local.py`, `v6_surgical/`).
2. **Kaggle Format Parity:** `kaggle_read_file` returns **raw text** (no `n: ` or `%5d | ` gutters); `kaggle_edit_file` uses 3-tier match + LF `newline="\n"` + exact `FileEditError`; `render_ids` passes `tools=KAGGLE_TOOLS`.
3. **Exact LoRA & Loss Spec:** `60` trainable tensors (`L22` `q/k/v/o`; `L23` all 7; `L24/26` `q/o`; `L28/30/36` `q/o`+MLP; `L17` dropped), `r=8, alpha=16`, `W_SUBMIT=1.0` (not `2.0`), `lr=1e-4`, `kl_beta=0.10`, `epochs=1.5`.
4. **Hardware & Rules Safety:** Native BF16 + PyTorch SDPA (NO NF4, NO FlashAttention-2); serial `workers=1` locally (16 GB VRAM); `-p no:anyio` stays banned; `0` `holdout30` leakage; `base_model_name_or_path == "google/gemma-4-e4b-it-qat-w4a16-ct"` with no Windows paths.
