#!/usr/bin/env python
# Packs the 4 bake-off adapters + prompts + splits into e4b_bakeoff_adapters.zip after strict vLLM PEFTHelper (G0) checks.
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

from safetensors import safe_open

ROOT = Path(__file__).resolve().parent
BASE_MODEL = "google/gemma-4-e4b-it-qat-w4a16-ct"
MAX_RANK = 16
MAX_ADAPTER_BYTES = 3 * 1024**3

ADAPTERS = {
    "lora_v1": ROOT / "submission_E4B_MultiLoRA" / "adapters" / "lora_v1",
    "v6_ep075": ROOT / "v6_surgical" / "ckpt_ep0.75",
    "v6_ep10": ROOT / "v6_surgical" / "ckpt_ep1.0",
    "lora_v4": ROOT / "submission_E4B_MultiLoRA" / "adapters" / "lora_v4",
}
LORA_V1_SHIPPED_ZIP = ROOT / "E4B summary" / "06_baselines" / "submission_E4B_LoRA_v1.zip"
PROMPTS = {
    "prompts/system_v6_grep.md": ROOT / "v6_surgical" / "prompts" / "system_v6_grep.md",
    "prompts/system_lora_v4.md": ROOT / "v4_surgical" / "prompts" / "system.md",
}
SPLITS = ROOT / "V3 Data" / "splits_99_30.json"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def g0_check(name: str, src: Path) -> list[str]:
    errs: list[str] = []
    cfg_path, w_path = src / "adapter_config.json", src / "adapter_model.safetensors"
    if not cfg_path.is_file() or not w_path.is_file():
        return [f"{name}: missing adapter_config.json or adapter_model.safetensors in {src}"]
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))

    r = cfg.get("r")
    if not isinstance(r, int) or isinstance(r, bool) or not 0 < r <= MAX_RANK:
        errs.append(f"r={r!r} (must be int in 1..{MAX_RANK})")
    tm = cfg.get("target_modules")
    if not (isinstance(tm, list) and tm and all(isinstance(m, str) and m for m in tm)):
        errs.append(f"target_modules must be a non-empty list[str] (got {type(tm).__name__})")
    elif any(set(m) & set("^$*+?()[]{}|\\") for m in tm):
        errs.append(f"target_modules contains regex metacharacters: {tm}")
    if cfg.get("base_model_name_or_path") != BASE_MODEL:
        errs.append(f"base_model_name_or_path={cfg.get('base_model_name_or_path')!r}")
    if cfg.get("modules_to_save") is not None:
        errs.append(f"modules_to_save={cfg.get('modules_to_save')!r} (must be null)")
    if cfg.get("use_dora") is not False:
        errs.append(f"use_dora={cfg.get('use_dora')!r} (must be false)")
    if cfg.get("bias") != "none":
        errs.append(f"bias={cfg.get('bias')!r} (must be 'none')")
    if cfg.get("peft_type") != "LORA":
        errs.append(f"peft_type={cfg.get('peft_type')!r}")

    with safe_open(str(w_path), framework="pt", device="cpu") as f:
        keys = list(f.keys())
        forbidden = [k for k in keys if "embed_tokens" in k or "lm_head" in k]
        if forbidden:
            errs.append(f"{len(forbidden)} embed_tokens/lm_head keys, e.g. {forbidden[0]}")
        non_lora = [k for k in keys if "lora_A" not in k and "lora_B" not in k]
        if non_lora:
            errs.append(f"{len(non_lora)} non-LoRA keys, e.g. {non_lora[0]}")
        if isinstance(r, int):
            bad = [k for k in keys if "lora_A" in k and f.get_slice(k).get_shape()[0] != r]
            if bad:
                errs.append(f"{len(bad)} lora_A tensors with rank != {r}, e.g. {bad[0]}")
    if not keys:
        errs.append("empty safetensors")
    return [f"{name}: {e}" for e in errs]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=ROOT / "e4b_bakeoff_adapters.zip")
    args = ap.parse_args()

    failures: list[str] = []
    for name, src in ADAPTERS.items():
        errs = g0_check(name, src)
        failures += errs
        print(f"[{'FAIL' if errs else 'G0 OK'}] {name:9s} <- {src.relative_to(ROOT)}")
    if failures:
        print("\nG0 FAILED:\n  " + "\n  ".join(failures))
        return 1

    with zipfile.ZipFile(LORA_V1_SHIPPED_ZIP) as z:
        lora_v1_prompt = z.read("prompts/system.md")
        shipped_w = sha256(z.read("adapters/e4b_qat_lora/adapter_model.safetensors"))
    if shipped_w != sha256((ADAPTERS["lora_v1"] / "adapter_model.safetensors").read_bytes()):
        print("FAIL: lora_v1 weights differ from the shipped submission_E4B_LoRA_v1.zip adapter")
        return 1

    for arc, p in PROMPTS.items():
        if not p.is_file():
            print(f"FAIL: missing prompt {p}")
            return 1
    splits = json.loads(SPLITS.read_text(encoding="utf-8"))
    if set(splits["train_ids"]) & set(splits["holdout_ids"]):
        print("FAIL: train/holdout overlap in splits")
        return 1

    files: dict[str, bytes] = {"prompts/system_lora_v1.md": lora_v1_prompt, "splits_99_30.json": SPLITS.read_bytes()}
    files.update({arc: p.read_bytes() for arc, p in PROMPTS.items()})
    for name, src in ADAPTERS.items():
        for fn in ("adapter_config.json", "adapter_model.safetensors"):
            files[f"{name}/{fn}"] = (src / fn).read_bytes()
    if sum(map(len, files.values())) >= MAX_ADAPTER_BYTES:
        print("FAIL: package >= 3 GiB")
        return 1
    files["manifest.json"] = json.dumps(
        {"base_model": BASE_MODEL, "adapters": list(ADAPTERS), "sha256": {k: sha256(v) for k, v in sorted(files.items())}},
        indent=2,
    ).encode("utf-8")

    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, data in sorted(files.items()):
            zf.writestr(arc, data)
    print(f"\n[DONE] {args.out.name}: {len(files)} files, {args.out.stat().st_size / 1e6:.1f} MB")
    for arc in sorted(files):
        print(f"  {arc}  ({len(files[arc])} B)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
