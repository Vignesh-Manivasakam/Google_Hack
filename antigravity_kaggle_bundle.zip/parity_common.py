#!/usr/bin/env python3
"""
Shared Kaggle-parity constants, tools and static checks for the v6 track (plan step C0).

- KAGGLE_TOOLS: the four tool schemas rendered in training and evaluation (verbatim from
  kaggle_train_e4b_qat_lora.py SWEGEMMA_TOOL_DECLARATIONS).
- kaggle_read_file / kaggle_edit_file / kaggle_run_command: Kaggle-format tool implementations
  (raw read_file text, 3-tier edit_file, ok/CommandError run_command).
- strip_gutter(), has_gutter(), GUTTER_RE: local `%5d | ` / `N: ` read_file prefix handling.
- check_prompt_bytes(): enforces the 2048 B prompt cap (plan G0).
"""
import difflib
import re
from pathlib import Path

PROMPT_HARD_LIMIT_BYTES = 2048
PROMPT_TARGET_BYTES = 900

READ_MAX_LINES = 150
READ_MAX_CHARS = 10_000
OUTPUT_MAX_CHARS = 5_000
DIFF_MAX_CHARS = 5_000
COMMAND_TIMEOUT_SEC = 120

EDIT_ERR_MSG = (
    "Failed to replace: old_string not found. Ensure you're not escaping content incorrectly "
    "and check whitespace, indentation, and context."
)

GUTTER_RE = re.compile(r"(?m)^\s*\d+\s*(:|\|)\s")

KAGGLE_TOOLS = [
    {"type": "function", "function": {"name": "run_command", "description": "Run a shell command in /bin/bash -c inside /workspace.", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
    {"type": "function", "function": {"name": "read_file", "description": "Read lines from a file in /workspace (1-indexed inclusive, capped at 150 lines / 10,000 chars).", "parameters": {"type": "object", "properties": {"filepath": {"type": "string"}, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}}, "required": ["filepath"]}}},
    {"type": "function", "function": {"name": "edit_file", "description": "Replace old_string with new_string in an existing non-empty file inside /workspace.", "parameters": {"type": "object", "properties": {"filepath": {"type": "string"}, "old_string": {"type": "string"}, "new_string": {"type": "string"}, "allow_multiple": {"type": "boolean"}}, "required": ["filepath", "old_string", "new_string"]}}},
    {"type": "function", "function": {"name": "submit_patch", "description": "Capture and submit the current /workspace git diff patch (does not count toward tool_calls).", "parameters": {"type": "object", "properties": {}}}},
]

# Local `%5d | text` (win_phase2_tournament) or external `N: text` (V5 rows) prefixes.
_GUTTER_PIPE = re.compile(r"^\s*\d+ \| ?")
_GUTTER_COLON = re.compile(r"^\d+: ")


def strip_gutter(text: str) -> str:
    """Remove one gutter prefix per line, leaving the raw file text."""
    out = []
    for line in text.split("\n"):
        line = _GUTTER_PIPE.sub("", line, count=1)
        line = _GUTTER_COLON.sub("", line, count=1)
        out.append(line)
    return "\n".join(out)


def has_gutter(text: str) -> bool:
    """True if any line starts with a local or external line-number prefix."""
    return any(_GUTTER_PIPE.match(l) or _GUTTER_COLON.match(l) for l in text.split("\n"))


def build_agent_prompt(repo: str, problem: str, hints: str = "", ws_tree: str = "") -> str:
    """Kaggle 7-section user prompt (HARNESS_README 5.2); code-intelligence section omitted."""
    parts = [f"You are evaluating a software engineering task for repository {repo}.\n\nProblem Statement:\n{problem}"]
    if hints:
        parts.append(f"## Hints:\n{hints}")
    parts.append(
        "## Task Budget (Session terminates when any budget is exhausted)\n"
        "- Time allowance: 8.0 minutes\n- Tool calls allowance: 40 calls\n- Max loop iterations: 80 turns"
    )
    parts.append(
        "## Execution Environment Rules\n"
        "- Single command timeout: 300 seconds (commands exceeding this fail without ending the session)\n"
        "- Command output limit: 5000 characters\n"
        "- File view limit: 150 lines per read_file call\n"
        "- File character limit: 10000 characters per read_file call\n"
        "- Environment is offline (no network/PyPI access). All repository and test dependencies are ALREADY "
        "pre-installed. Do NOT attempt to run pip install or download packages."
    )
    parts.append(
        "## Instructions\n"
        "0. Work strictly inside /workspace.\n"
        "1. Inspect the existing code and conventions before changing anything.\n"
        "2. Make the minimal source change that resolves the problem.\n"
        "3. Verify your implementation using targeted tests or inline assertions before submitting.\n"
        "4. Call submit_patch once complete.\n"
        "5. Then reply with a short final text response."
    )
    if ws_tree:
        parts.append(f"## Workspace Layout\n{ws_tree}")
    return "\n\n".join(parts)


class FileEditError(Exception):
    """edit_file failure; str(exc) is the Kaggle error_message."""

    def __init__(self, message: str = EDIT_ERR_MSG):
        super().__init__(message)


def _err(error_type: str, message: str) -> dict:
    return {"status": "error", "error_type": error_type, "error_message": message}


def _resolve(ws: Path, filepath: str):
    """Return (relative posix path, absolute path) for a path under the workspace, or (rel, None) if outside."""
    rel = str(filepath or "").strip().replace("\\", "/").lstrip("/")
    if rel == "workspace":
        rel = ""
    elif rel.startswith("workspace/"):
        rel = rel[len("workspace/"):]
    root = Path(ws).resolve()
    fp = (root / rel).resolve()
    if fp != root and root not in fp.parents:
        return rel, None
    return rel, fp


def _read_text_lf(fp: Path) -> str:
    with open(fp, "r", encoding="utf-8", errors="replace", newline="") as f:
        return f.read().replace("\r\n", "\n")


def kaggle_read_file(ws, filepath, start_line=None, end_line=None) -> dict:
    """Raw-text read_file (no line-number gutter), Kaggle key order, 150 lines / 10,000 chars cap."""
    rel, fp = _resolve(ws, filepath)
    if not rel or fp is None or not fp.is_file():
        return _err("FileNotFoundError", f"File not found: {rel}")
    text = _read_text_lf(fp)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    total = len(lines)
    try:
        s = max(1, int(start_line or 1))
        e = int(end_line) if end_line else s + READ_MAX_LINES - 1
    except (TypeError, ValueError):
        return _err("ValueError", "start_line and end_line must be integers.")
    e = min(e, total, s + READ_MAX_LINES - 1)
    if s > total:
        return {"status": "ok", "filepath": rel, "content": "", "start_line": s, "end_line": total,
                "total_lines": total, "is_truncated": False}
    picked, used = [], 0
    for ln in lines[s - 1:e]:
        cost = len(ln) + (1 if picked else 0)
        if used + cost > READ_MAX_CHARS:
            if not picked:
                picked.append(ln[:READ_MAX_CHARS])
            break
        picked.append(ln)
        used += cost
    last = s + len(picked) - 1
    return {"status": "ok", "filepath": rel, "content": "\n".join(picked), "start_line": s, "end_line": last,
            "total_lines": total, "is_truncated": last < total}


def _reindent(new_lines: list, old_first: str, file_first: str) -> list:
    old_ind = old_first[: len(old_first) - len(old_first.lstrip())]
    file_ind = file_first[: len(file_first) - len(file_first.lstrip())]
    if old_ind == file_ind:
        return new_lines
    out = []
    for ln in new_lines:
        if not ln.strip():
            out.append(ln)
        elif ln.startswith(old_ind):
            out.append(file_ind + ln[len(old_ind):])
        else:
            out.append(ln)
    return out


def _multi_match_error(n: int) -> FileEditError:
    return FileEditError(f"Failed to replace: old_string matched {n} times. "
                         "Add more surrounding context or set allow_multiple=true.")


def _apply_edit(text: str, old: str, new: str, allow_multiple: bool):
    """Return (new_text, occurrences, strategy) using exact -> flexible -> regex tiers."""
    if not old:
        raise FileEditError()
    # Tier 1: exact
    n = text.count(old)
    if n:
        if n > 1 and not allow_multiple:
            raise _multi_match_error(n)
        return text.replace(old, new, -1 if allow_multiple else 1), (n if allow_multiple else 1), "exact"

    # Tier 2: flexible (line-wise stripped comparison, re-indented new_string)
    lines = text.split("\n")
    old_lines = old.strip("\n").split("\n")
    key = [l.strip() for l in old_lines]
    k = len(key)
    if any(key):
        hits = [i for i in range(len(lines) - k + 1) if [l.strip() for l in lines[i:i + k]] == key]
        if hits:
            if len(hits) > 1 and not allow_multiple:
                raise _multi_match_error(len(hits))
            hits = hits if allow_multiple else hits[:1]
            new_lines = new.strip("\n").split("\n")
            for i in reversed(hits):
                lines[i:i + k] = _reindent(new_lines, old_lines[0], lines[i])
            return "\n".join(lines), len(hits), "flexible"

    # Tier 3: regex (whitespace-tolerant around punctuation tokens)
    toks = [t.strip() for t in re.split(r"([()\:\[\]{}>=<])", old) if t.strip()]
    if toks:
        spans = [m.span() for m in re.finditer(r"\s*".join(re.escape(t) for t in toks), text)]
        if spans:
            if len(spans) > 1 and not allow_multiple:
                raise _multi_match_error(len(spans))
            spans = spans if allow_multiple else spans[:1]
            for a, b in reversed(spans):
                text = text[:a] + new + text[b:]
            return text, len(spans), "regex"
    raise FileEditError()


def kaggle_edit_file(ws, filepath, old_string, new_string, allow_multiple=False) -> dict:
    """3-tier edit_file; writes LF (newline="\\n"); errors use the exact Kaggle FileEditError message."""
    rel, fp = _resolve(ws, filepath)
    if not rel or fp is None or not fp.is_file():
        return _err("FileNotFoundError", f"File not found: {rel}")
    text = _read_text_lf(fp)
    old = str(old_string if old_string is not None else "").replace("\r\n", "\n")
    new = str(new_string if new_string is not None else "").replace("\r\n", "\n")
    try:
        new_text, occ, strategy = _apply_edit(text, old, new, bool(allow_multiple))
    except FileEditError as exc:
        return _err("FileEditError", str(exc))
    with open(fp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_text)
    diff = "\n".join(difflib.unified_diff(text.split("\n"), new_text.split("\n"),
                                         f"a/{rel}", f"b/{rel}", lineterm=""))
    return {"status": "ok", "filepath": rel, "occurrences": occ, "strategy": strategy,
            "diff": diff[:DIFF_MAX_CHARS], "is_truncated": len(diff) > DIFF_MAX_CHARS}


def kaggle_run_command(ws, py_exe, command, timeout_sec: int = COMMAND_TIMEOUT_SEC) -> dict:
    """run_command in the Kaggle ok/CommandError format; needs gemma_dir on sys.path."""
    from win_frontier_6harness_overnight import _run_isolated_command_windows
    r = _run_isolated_command_windows(str(command or ""), Path(ws), Path(py_exe), timeout_sec=timeout_sec)
    out = str(r.get("stdout") or "")[:OUTPUT_MAX_CHARS]
    err = str(r.get("stderr") or "")[:OUTPUT_MAX_CHARS]
    rc = r.get("exit_code")
    if rc == 0:
        return {"status": "ok", "stdout": out, "stderr": err, "exit_code": 0}
    etype = "TimeoutExceeded" if rc == 124 else "CommandError"
    return {"status": "error", "error_type": etype, "error_message": err or out,
            "details": {"stdout": out, "stderr": err, "exit_code": rc}}


def check_prompt_bytes(prompt_md: str) -> tuple[bool, int]:
    """Return (within_hard_limit, byte_count)."""
    n = len(prompt_md.encode("utf-8"))
    return n <= PROMPT_HARD_LIMIT_BYTES, n


if __name__ == "__main__":
    import sys
    from pathlib import Path

    ok, n = check_prompt_bytes(Path(sys.argv[1]).read_text(encoding="utf-8"))
    print(f"prompt bytes={n} target<={PROMPT_TARGET_BYTES} hard<={PROMPT_HARD_LIMIT_BYTES} ok={ok}")
    sys.exit(0 if ok else 1)
