# Gemma 4 E4B and 31B Architectural Fact-Check for LoRA v2

Google DeepMind publicly released the **Gemma 4** model family (E2B, E4B, 12B, 26B-A4B, and 31B) in April 2026<sup>1</sup> (specifically April 2, 2026 per third-party launch trackers<sup>4</sup>), followed by Multi-Token Prediction (MTP) drafters on May 5, 2026<sup>6</sup>, Quantization-Aware Training (QAT) w4a16-ct checkpoints in June 2026<sup>2</sup>, and the Gemma 4 Technical Report (arXiv:2607.02770v1) on July 2, 2026<sup>9</sup>. Because Gemma 4 is public, no proxy mapping to Gemma 3n is required for Claims 1–9; every architectural claim is audited directly against primary Gemma 4 artifacts. For Question 10, prior-generation **Gemma 2** and **Gemma 3** interpretability findings are strictly segregated because no published Gemma 4 mechanistic-interpretability or Sparse Autoencoder (SAE) study exists yet.

Across your eight internal claims, **three are verified** (Claims 1, 2, and 3—with a critical LoRA-targeting caveat on Claim 3), **four require material corrections** (Claims 4, 5, 6, and 7), and **one is verified for vLLM memory and hybrid prefix-caching failure modes** (Claim 8). Four specific errors in your internal docs directly impact LoRA targeting, VRAM budgeting, and serving stability: (1) E4B's KV-shared layers (24–41) do not compute their own k_proj/v_proj, making KV LoRA on upper global layers \[29, 35, 41\] a dead target unless global KV owner **layer 23** is adapted<sup>10</sup>; (2) E4B's Per-Layer Embeddings (PLE) total **2.82B parameters**—not ~670M, which is actually the main tied embedding<sup>10</sup>; (3) Gemma 4 31B has **60 layers** and a strict **1,024-token** sliding window (not 64 layers or 2,048 tokens), plus unified K = V on global layers<sup>14</sup>; and (4) gemma-4-E4B-it-qat-w4a16-ct uses **static, symmetric INT4 without zero points** (Q4_0, group_size=32), not dynamic asymmetric quantization<sup>9</sup>.

## Architectural Verdict Table (Claims 1–8)

|  |  |  |  |  |
|----|----|----|----|----|
| **Claim** | **Verdict** | **Exact Source Quote** | **Source URL & Date** | **What It Changes for Me** |
| **1. E4B has 42 layers: 35 local sliding-window (512 tokens) + 7 global layers at \[5, 11, 17, 23, 29, 35, 41\].** | **VERIFIED** | "num_hidden_layers": 42, "sliding_window": 512<sup>10</sup>; "layer_types" opens with five "sliding_attention" entries<sup>10</sup> and ends with "full_attention"<sup>19</sup>; "We conserve a 5:1 ratio of local sliding window to global self-attention (4:1 for the 2.3B model)"<sup>9</sup>. | https://huggingface.co/google/gemma-4-E4B/blob/main/config.json (Apr 2026 release)<sup>2</sup>; https://huggingface.co/google/gemma-4-E4B-it/blob/ee0ef6023621cff504d758262d4e04895a5af4a2/config.json (Apr 2026 release)<sup>2</sup>; https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>. | Your E4B layer counts, 512-token local window, and 0-indexed global indices \[5, 11, 17, 23, 29, 35, 41\] are exact<sup>13</sup>. Note that engineering reports on Gemma 4's config also flag global_head_dim=512 (2× local head_dim=256), which breaks standalone FlashAttention-2—keep PyTorch SDPA during training<sup>20</sup>. |
| **2. Global layers use p-RoPE (p≈0.25) with an extended base frequency; local layers use RoPE base 10,000.** | **VERIFIED** | "use p -RoPE (Barbero et al., 2025) as positional encoding" and "The RoPE frequencies are set to 1M and 10k on global and local attention layers, respectively."<sup>9</sup>; "rope_parameters": { "full_attention": { "partial_rotary_factor": 0.25, "rope_theta": 1000000.0,<sup>10</sup>. | https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>; https://huggingface.co/google/gemma-4-E4B/blob/main/config.json (Apr 2026 release)<sup>2</sup>. | Confirmed verbatim (rope_theta=1,000,000.0 with partial_rotary_factor=0.25 on global layers; 10,000.0 on local layers)<sup>9</sup>. Include training examples longer than 512 tokens so LoRA updates actually exercise global p-RoPE paths rather than only local sliding windows. |
| **3. Layers ~24–41 share KV cache projections; K and V remain distinct (no K = V).** | **VERIFIED** *(with critical LoRA caveat)* | "Finally, we share the KV cache with ratios of 20/35 and 18/42 for the E2B and E4B model."<sup>9</sup>; "num_kv_shared_layers": 18<sup>10</sup>; "attention_k_eq_v": false<sup>19</sup>; "Gemma4TextAttention in the KV-shared layers ( layer_idx \>= num_hidden_layers - num_kv_shared_layers"<sup>11</sup>. | https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>; https://huggingface.co/google/gemma-4-E4B/blob/main/config.json (Apr 2026 release)<sup>2</sup>; https://huggingface.co/google/gemma-4-E4B-it/blob/ee0ef6023621cff504d758262d4e04895a5af4a2/config.json (Apr 2026 release)<sup>2</sup>; https://github.com/vllm-project/llm-compressor/issues/3523 (2026)<sup>11</sup>. | Exact shared span is **layers 24–41** (42 - 18 = 24), and K ≠ V holds on E4B (attention_k_eq_v: false, unlike 12B/26B/31B)<sup>10</sup>. **Critical caveat:** layers 24–41 do *not* run k_proj/v_proj—they reuse KV caches from earlier owner layers (0–23)<sup>12</sup>. Global KV LoRA must target owner **layer 23** (and 17), not just 29/35/41. |
| **4. PLE has ~670M params + large main embedding; keep PLE, ViT, USM frozen; any published PLE-instability guidance?** | **CORRECTED** *(PLE instability: **NOT FOUND**)* | "hidden_size": 2560, "hidden_size_per_layer_input": 256<sup>10</sup>; "The vocabulary we use has 262k entries." / "E2B and E4B use per-layer embeddings... making them 2.3B and 4.5B effective out of 5B and 8B total parameters respectively." / "150M vision encoder" / "305M audio encoder... As with the vision encoder, we keep weights frozen during pre-training."<sup>9</sup>; "Keep per-layer embeddings frozen during LoRA : Standard LoRA targets the attention and MLP projections."<sup>24</sup>. | https://huggingface.co/google/gemma-4-E4B/blob/main/config.json (Apr 2026 release)<sup>2</sup>; https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>; https://gemma.ai/tuning/best-practices/ (2026)<sup>24</sup>. | **Your numbers are inverted:** main tied embedding (262,144 × 2,560) is **671.09M**, whereas PLE (262,144 × 42 × 256) is **2.819B** (~4.2× larger than claimed)<sup>13</sup>. Keep PLE, ViT (150M), and USM (305M) frozen per the Gemma 4 tuning guide<sup>9</sup>. No primary source reports PLE-specific training *instability*—the documented instability is float16 overflow in the audio encoder during attention masking, solved by bfloat16<sup>24</sup>. |
| **5. Built-in MTP speculative drafter exists (~4 layers, dim 256).** | **CORRECTED** *(specs verified; "built-in" false)* | "The Transformer block has model dimension 256 for E2B and E4B, 1024 for 26B-A4B and 31B, three local, and one global attention layers."<sup>9</sup>; "By pairing a Gemma 4 model with its corresponding drafter..."<sup>6</sup>; "The assistant was therefore an explicitly deployed auxiliary model rather than an implicit or internally derived prediction head."<sup>25</sup>. | https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>; https://blog.google/innovation-and-ai/technology/developers-tools/multi-token-prediction-gemma-4/ (May 5, 2026)<sup>6</sup>; https://huggingface.co/collections/google/gemma-4-qat-q4-0 (updated Jul 20, 2026)<sup>7</sup>; https://arxiv.org/html/2609.35188v1 (Sep 2026)<sup>25</sup>. | **4 layers (3 local + 1 global), dim 256** is exact for E4B (dim 1,024 for 31B), but it is **not built into** the base checkpoint—it ships as a separate ~78.8M companion checkpoint (google/gemma-4-E4B-it-assistant / ...-qat-q4_0-unquantized-assistant)<sup>7</sup>. LoRA will not corrupt it during training, but shifting final-layer activations may lower speculative acceptance rates at serve time<sup>5</sup>. |
| **6. 31B has 64 layers, 1024/2048 sliding windows, and tolerates 4–6k-char system prompts without instruction-drift.** | **CORRECTED** *(drift guarantee: **NOT FOUND**)* | "num_hidden_layers": 60, "num_key_value_heads": 16, "num_kv_shared_layers": 0<sup>15</sup>; "The model declares sliding_window: 1024 and 50 of its 60 layers are marked sliding_attention in layer_types."<sup>17</sup>; "12B, 26B A4B & 31B — Unified Keys & Values ( K = V , attention_k_eq_v: true )"<sup>14</sup>; "A model's performance can be influenced by the amount of context provided (longer context generally leads to better outputs, up to a certain point)."<sup>26</sup>. | https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json (Apr 2026 release)<sup>2</sup>; https://github.com/vllm-project/vllm/issues/39133 (2026)<sup>17</sup>; https://gemma.ai/learn/how-llms-work/ (2026)<sup>14</sup>; https://huggingface.co/google/gemma-4-31B-it (Apr 2026 release)<sup>2</sup>. | **31B has 60 layers (50 local + 10 global at \[5, 11, 17, 23, 29, 35, 41, 47, 53, 59\]), NOT 64**, and a strict **1,024-token** sliding window (never 2,048)<sup>13</sup>. No primary source guarantees zero instruction-drift at 4–6k characters (roughly ~1,000–1,500 tokens at ~4 chars/token), which directly straddles the 1,024-token local window boundary. |
| **7. QAT W4A16 uses linear INT4, dynamic block-wise scaling & zero points; any public NF4-LoRA-on-QAT degradation repros?** | **CORRECTED** *(NF4-vs-QAT LoRA repro: **NOT FOUND**)* | "dynamic": false, "group_size": 32, "num_bits": 4, ... "symmetric": true, "type": "int", "zp_dtype": null } } }, "format": "pack-quantized"<sup>18</sup>; "Q4_0 quantization: blockwise quantization, often referred to as Q4_0."<sup>9</sup>; "These use 4-bit integer weights with 16-bit activations (group_size=32) in compressed-tensors format"<sup>27</sup>. | https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/blame/6cd26aaa2357fb2bad8c51699a7558a4d1a965bb/config.json (Jun 2026 release)<sup>2</sup>; https://arxiv.org/html/2607.02770v1 (Jul 2, 2026)<sup>9</sup>; https://github.com/vllm-project/recipes/blob/main/Google/Gemma4.md (2026)<sup>27</sup>. | Scaling is **static** ("dynamic": false) and **symmetric with NO zero points** ("symmetric": true, "zp_dtype": null) at group_size=32<sup>18</sup>. No public primary reproduction of NF4-LoRA-on-QAT degradation was found, but metadata shows -qat-w4a16-ct derives from -qat-q4_0-unquantized (not vanilla -it)<sup>28</sup>—train bfloat16 LoRA directly on -qat-q4_0-unquantized instead of NF4 on -it. |
| **8. Sliding-window local attention interacts with vLLM prefix caching (known correctness/perf issues on 512-window models)?** | **VERIFIED** *(KV over-alloc, hangs & 0%-hit collapse; no 512-only silent corruption found)* | "vLLM currently allocates uniformly, so all 60 layers get full-context KV. That means ~83% of your KV memory allocation... is theoretically wasted headroom" / "The reported KV cache limit is real, but prefix caching bypasses it... Single-shot long prompts are broken -- a 12k-token RAG dump or document analysis will hang."<sup>17</sup>; "HybridKVCacheCoordinator.find_longest_cache_hit intersects per-group hit sets. If any one of the 5 groups loses its first-block entry, the whole intersection collapses to 0 at position 0."<sup>30</sup>; "A lookup must reject an endpoint if any physical block in its required window has been evicted."<sup>31</sup>. | https://github.com/vllm-project/vllm/issues/39133 (2026)<sup>17</sup>; https://github.com/vllm-project/vllm/issues/42948 (2026)<sup>30</sup>; https://github.com/vllm-project/vllm/issues/53786 (2026)<sup>31</sup>. | Expect **~83% theoretical KV over-allocation** on sliding layers (35/42 on E4B, matching 50/60 on 31B) unless patched, **single-shot long-prompt hangs** under tight KV budgets, and **0% prefix-cache hit collapse** under concurrent pool pressure across hybrid KV groups<sup>17</sup>. Cap --max-model-len to your workload and pass --limit-mm-per-prompt '{"image": 0, "audio": 0}' for text-only serving<sup>27</sup>. |

## Corrected Layer Geometry and Upper Global LoRA Targeting (Question 9)

The architectural differences between Gemma 4 E4B and Gemma 4 31B are structural rather than merely parametric: they determine which attention projection matrices exist in the upper third of each stack. Comparing both verified transformer topologies layer by layer exposes why reusing unverified internal indices or sharing a single LoRA target list across E4B and 31B silently targets nonexistent modules.

<img src="f:\AI\Benchmark\research_briefs\media\Gemma E4B and 31B Verification/media/image2.png" style="width:6.45833in;height:6.67708in" />

Putting the verified config.json and Technical Report fields side by side highlights every corrected count and index across both models<sup>9</sup>:

|  |  |  |  |
|----|----|----|----|
| **Architectural Field** | **Gemma 4 E4B (Verified)** | **Gemma 4 31B (Verified)** | **Discrepancy vs. Internal Docs** |
| num_hidden_layers | **42** (0–41)<sup>10</sup> | **60** (0–59)<sup>15</sup> | 31B corrected from 64 to **60** |
| Local / Global Layer Split | **35 local / 7 global** (5:1)<sup>9</sup> | **50 local / 10 global** (5:1)<sup>9</sup> | 31B has **10** global layers across 60 total |
| Global (full_attention) Indices | \[5, 11, 17, 23, 29, 35, 41\]<sup>10</sup> | \[5, 11, 17, 23, 29, 35, 41, 47, 53, 59\]<sup>13</sup> | 31B stops at **59** (no layers 60–63) |
| sliding_window (Local) | **512 tokens**<sup>10</sup> | **1,024 tokens**<sup>16</sup> | 31B is strictly **1,024** (never 2,048) |
| num_kv_shared_layers | **18** (trailing layers 24–41)<sup>9</sup> | **0** (all 60 layers own KV)<sup>15</sup> | E4B layers 24–41 omit k_proj/v_proj<sup>12</sup> |
| attention_k_eq_v (Global) | **false** (distinct K and V)<sup>19</sup> | **true** (unified K = V)<sup>14</sup> | 31B global layers drop independent v_proj |
| Global / Local RoPE | Global: p-RoPE (0.25), 1M; Local: 10k<sup>9</sup> | Global: p-RoPE, 1M; Local: 10k<sup>9</sup> | Confirmed exact |
| Documented Context Window | **128K tokens**<sup>34</sup> | **256K tokens**<sup>26</sup> | 4–6k-char drift claim unverified |

These verified geometries force two direct adjustments to your "upper global layers" LoRA strategy:

1.  **On E4B, do not target upper global layers \[29, 35, 41\] alone if you expect long-range KV adaptation.** Because num_kv_shared_layers = 18 assigns trailing layers 24–41 to read cached KV tensors computed by earlier owner layers (0–23), an AWS Inferentia2 porting field report tracing the Hugging Face transformers Gemma 4 forward pass confirms that shared layers do not execute their own k_proj or v_proj<sup>10</sup>. (Note: the 15-layer example on gemma.ai/tuning/best-practices/ illustrates E2B's 35 - 20 = 15 non-shared layers, not E4B's 42 - 18 = 24<sup>9</sup>.) On E4B, **layer 23 is the highest global layer that writes to the global KV cache**<sup>13</sup>. Adapting how upper global layers retrieve and attend to long system prompts (\>512 tokens) therefore requires targeting **layer 23** (and ideally **layer 17**) across q_proj, k_proj, v_proj, and o_proj, while limiting attention LoRA on layers 29, 35, 41 to q_proj and o_proj alongside MLP projections (gate_proj, up_proj, down_proj).

2.  **On 31B, clamp upper-global targeting to index 59 and account for K = V.** Targeting layers 60–63 fails or silently drops adapters because the upper global layers sit at \[41, 47, 53, 59\] (upper third) or \[35, 41, 47, 53, 59\] (upper half)<sup>13</sup>. All 60 layers on 31B own their KV cache (num_kv_shared_layers: 0)<sup>15</sup>, but because attention_k_eq_v: true unifies Keys and Values on global layers<sup>14</sup>, global attention LoRA operates on q_proj, k_proj, and o_proj rather than a separate v_proj.

Practitioner and cloud-provider fine-tuning notes also surface three silent Gemma 4 training traps worth guarding against in LoRA v2. First, **train in bfloat16**, because the Gemma 4 tuning guide explicitly warns that E2B/E4B's audio encoder can overflow float16 during attention masking<sup>24</sup>. Second, **keep PyTorch SDPA rather than standalone FlashAttention-2**, as a Nodus Compute engineering guide (summarizing Google's best-practices checklist) notes that Gemma 4's 512-dimensional global attention heads are unsupported by standalone FlashAttention-2<sup>21</sup>. Third, **validate chat-template BOS tokens, stop tokens (\<end_of_turn\>, ID 106), and use_cache behavior under gradient checkpointing**, since community fine-tuning reports (including a Hugging Face Hindi E4B LoRA post and Nodus Compute's guide) document double-BOS corruption, rambling evals when stopping only on EOS, and garbled E2B/E4B generations when unpatched gradient-checkpointing stacks force use_cache=False<sup>21</sup>.

## Parameter Anatomy, QAT Mismatch, and vLLM Serving Hazards (Claims 4, 5, 7, 8)

### The 4.2× PLE Parameter Inversion and Freezing Rules (Claim 4)

Your internal documentation reversed the sizes of E4B's main embedding matrix and its Per-Layer Embedding (PLE) lookup tables. Exact arithmetic from google/gemma-4-E4B/config.json (vocab_size = 262,144, hidden_size = 2,560, num_hidden_layers = 42, hidden_size_per_layer_input = 256)<sup>9</sup> clarifies E4B's true 8.0B stored parameter breakdown:

<img src="f:\AI\Benchmark\research_briefs\media\Gemma E4B and 31B Verification/media/image1.png" style="width:6.45833in;height:5.21875in" />

The Gemma 4 tuning guide explicitly directs practitioners to **"Keep per-layer embeddings frozen during LoRA : Standard LoRA targets the attention and MLP projections"** and sets Embedding LR: Frozen for LoRA/QLoRA SFT (reserving a 2x to 5x lower LR of 1e-5 strictly for continued pre-training)<sup>24</sup>. The Technical Report likewise confirms that both the 150M ViT vision encoder and 305M USM Conformer audio encoder remain frozen during pre-training<sup>9</sup>, while the tuning guide reminds users to keep weight tying between input token embeddings and lm_head enabled when saving checkpoints<sup>24</sup>. Crucially, **no primary source reports training instability caused by unfreezing PLE**—both the tuning guide and developer analyses motivate freezing PLE on VRAM and optimizer-state savings (keeping 2.82B lookup-table parameters frozen) with minimal task loss unless adapting to a specialized new vocabulary<sup>24</sup>.

### External MTP Drafter vs. Fine-Tuned Target Models (Claim 5)

The Gemma 4 Technical Report confirms that the MTP speculative drafter uses **4 Transformer layers (three local and one global attention layer) with model dimension 256 for E2B/E4B** and **1,024 for 26B-A4B/31B**<sup>9</sup>. However, it is **not** embedded inside the base E4B checkpoint. Released separately on May 5, 2026 under the naming pattern google/gemma-4-\[variant\]-it-assistant (alongside a 78.8M-parameter QAT-matched companion, google/gemma-4-E4B-it-qat-q4_0-unquantized-assistant), it deploys as an explicit auxiliary model<sup>6</sup>. Per Google's blog and an NYU RITS technical summary of Google's MTP release, the drafter reuses the target's input embeddings and KV cache while conditioning on the target model's last-layer activations<sup>5</sup>. Because the target model retains final verification authority, mounting a LoRA adapter on E4B preserves bit-exact output fidelity under speculative decoding—but large LoRA shifts to final-layer activations or output structure can lower draft token acceptance rates and reduce the advertised up-to-3× latency speedup<sup>5</sup>.

### Static Symmetric QAT W4A16-CT and the NF4 Mounting Mismatch (Claim 7)

Inspection of google/gemma-4-E4B-it-qat-w4a16-ct/config.json refutes the claim of dynamic scaling and zero points: the checkpoint applies **static, symmetric, 4-bit linear integer quantization with group_size=32 and no zero points** ("dynamic": false, "group_size": 32, "num_bits": 4, "symmetric": true, "type": "int", "zp_dtype": null, "format": "pack-quantized")<sup>18</sup>. This aligns directly with Section 2.5 of the Gemma 4 Technical Report (Q4_0 quantization: blockwise quantization, often referred to as Q4_0)<sup>9</sup> and the official vLLM Gemma 4 recipe (4-bit integer weights with 16-bit activations (group_size=32) in compressed-tensors format)<sup>27</sup>.

**No primary or peer-reviewed public reproduction specifically benchmarking bitsandbytes-NF4 LoRA adapters mounted onto Gemma 4 QAT W4A16-CT checkpoints was found.** (The closest public Gemma 4 quantization-mismatch observation is an August 13, 2026 community post on the Google AI Developers Forum reporting 68–77% greedy output divergence between Gemma 4 QAT Q4_0 and PTQ Q4_K_M checkpoints on an RTX 5070 Ti<sup>41</sup>.) Even without a published NF4-on-QAT benchmark, Hugging Face model-lineage metadata surfaced by LLM Explorer and Facthory identifies the root architectural mismatch behind your internal regressions: google/gemma-4-E4B-it-qat-w4a16-ct is quantized from **google/gemma-4-E4B-it-qat-q4_0-unquantized**, *not* from the vanilla BF16 google/gemma-4-E4B-it checkpoint<sup>7</sup>. Training a QLoRA adapter on vanilla -it quantized into non-uniform NormalFloat4 (bitsandbytes) and then mounting that adapter onto -it-qat-w4a16-ct compounds two mismatches—QAT-retrained base weights versus non-QAT weights, and non-uniform NF4 quantization error versus uniform symmetric Q4_0 (group_size=32, no zero point) quantization error<sup>18</sup>. Because a cloud-provider sizing summary reports E4B BF16 LoRA peaking at ~17 GB VRAM (fitting comfortably on a single 24 GB GPU)<sup>21</sup>, training bfloat16 LoRA directly on google/gemma-4-E4B-it-qat-q4_0-unquantized<sup>7</sup> removes both sources of base-weight and quantization-grid drift before serving on gemma-4-E4B-it-qat-w4a16-ct.

### vLLM Sliding-Window and Prefix-Caching Failure Modes (Claim 8)

Three vLLM GitHub issues document real serving hazards for hybrid sliding-window architectures under prefix caching, though none isolates a silent token-level correctness bug unique to sliding_window=512. First, in vllm#39133 (filed on Gemma 4 31B's 50 sliding / 10 global stack), maintainers and users confirmed that vLLM allocates KV blocks uniformly across all layers at --max-model-len rather than capping sliding-window layers at their window size, wasting **~83% of KV memory headroom**—a ratio identical to E4B's 35/42 sliding-layer split<sup>13</sup>. In that same thread, users reported that while short-turn chat continues working because prefix caching bypasses the tight effective limit, **single-shot long prompts (such as 12k-token RAG dumps) hang** once physical KV headroom is exhausted<sup>17</sup>.

Second, in vllm#42948 (reproduced on DeepSeek-V4-Flash's 5-group hybrid topology), instrumentation of vLLM v1's block_pool.py showed that HybridKVCacheCoordinator.find_longest_cache_hit intersects cache-hit sets across every hybrid KV group, while \_maybe_evict_cached_block runs unconditionally in get_new_blocks<sup>30</sup>. Under pool pressure, evicting the first-block entry in *any* single hybrid KV group causes **the entire prefix-cache hit to collapse to 0%** rather than degrading gracefully<sup>30</sup>. Third, vllm#53786 documents that sparse sliding-window retention requires prefix-cache lookups to reject a cached endpoint whenever *any* physical block intersecting \[max(0, p - (sliding_window - 1)), p) has been evicted, necessitating independent window re-validation whenever speculative decoding drops tail tokens<sup>31</sup>. To mitigate these memory and cache-eviction failure modes on Gemma 4, vLLM's official Gemma 4 recipe recommends clamping --max-model-len to your actual workload and passing --limit-mm-per-prompt '{"image": 0, "audio": 0}' on text-only deployments so multimodal profiling does not consume scarce KV headroom<sup>27</sup>.

## Mechanistic Interpretability: Tool-Calling and Instruction-Following Layers (Question 10)

**No published mechanistic-interpretability or SAE study exists yet for Gemma 4** (including E4B layers 23–41). Without blending model generations, the table below summarizes published findings strictly from prior-generation **Gemma 3**, **Gemma 2**, and cross-family probing studies:

|  |  |  |  |
|----|----|----|----|
| **Model Generation (Explicit)** | **Study & Date** | **Layer Region Identified** | **Exact Primary Finding** |
| **Gemma 3 27B-IT** | arXiv:2605.06890v1 (May 2026)<sup>44</sup> | **Late residual layers** (4 post-block layers encoded with Gemma Scope SAEs) | "Localization of tool-decision signals to sparse features and late layers, with feature ablation." Tool-Need (call vs. no-call) and Tool-Risk probes peak in late layers and respond causally to feature ablation<sup>44</sup>. |
| **Gemma 3 4B** | arXiv:2605.07990v3 (May 2026)<sup>46</sup> | **Middle layers** (activation steering across Gemma 3 4B, Qwen 3 4B, Llama 3.1 8B) | "In the middle layers, on Gemma 3 4B, Qwen 3 4B and Llama 3.1 8B, the steering direction switches more pairs. So part of the tool choice is made before the..."<sup>46</sup> |
| **Gemma 3 family (270M–27B)** | arXiv:2605.11426v1 (May 2026)<sup>47</sup> | **Full stack via GemmaScope 2** (McDougall et al., 2025) | Uses pretrained GemmaScope 2 SAEs and transcoders to diagnose SFT-induced representational drift across instruction-following tasks<sup>47</sup>. |
| **Gemma 2 9B-IT** (and **2B-IT**) | arXiv:2602.01425v1 (Feb 2026)<sup>48</sup>; arXiv:2611.20405v1 (Nov 2026)<sup>49</sup> | **Layer 20** (plus **layers 9, 25, and 31** in 9B-IT; **Layer 12** in 2B-IT) | Honest-vs.-deceptive system-prompt instruction-pair probes cleanly separate intent at **layer 20** after sweeps across layers 20, 25, and 31<sup>48</sup>; refusal and register-steering directions localize across **layers 9, 20, and 31**<sup>49</sup>. |
| **Cross-family instruction models** | arXiv:2604.06015 (Apr 2026)<sup>50</sup> | **Distributed across layers** (probing + cross-task transfer) | "instruction-following is better characterized as skillful coordination of diverse linguistic capabilities rather than deployment of a single abstract constraint-checking process"<sup>50</sup>. |

Treated strictly as a **prior-generation heuristic** rather than verified Gemma 4 circuitry, Gemma 2 and Gemma 3 interpretability points to a two-stage division: **middle layers** mediate system-prompt framing and early tool selection (such as Gemma 3 4B's middle layers and Gemma 2 9B-IT's layer 20)<sup>46</sup>, while **late layers** execute final tool-need gating and risk/refusal decisions (as observed in Gemma 3 27B-IT)<sup>44</sup>, with general constraint compliance coordinated across broader depth<sup>50</sup>. Applied pragmatically to Gemma 4 E4B's 42-layer KV-sharing topology, targeting **layers 17–23** (covering mid-depth routing *and* the highest global KV owner, **layer 23**) alongside q_proj, o_proj, and MLPs across **layers 24–41** aligns prior-generation mechanistic priors with E4B's verified weight graph<sup>10</sup>.

## Net Impact on Your LoRA v2 Config

1.  **Fix E4B upper-layer LoRA targets:** Include KV-owning global **layer 23** (and 17) with full q/k/v/o + MLP adaptation, and drop dead k_proj/v_proj targets on KV-shared layers **24–41** (adapting q_proj, o_proj, and MLPs there instead)<sup>10</sup>.

2.  **Fix 31B layer bounds and K = V:** Clamp 31B layer indices to **0–59** (upper global targets \[41, 47, 53, 59\], never 60–63), account for attention_k_eq_v: true on global layers (no separate v_proj), and size system prompts knowing local sliding attention cuts off strictly at **1,024 tokens** (512 on E4B)<sup>10</sup>.

3.  **Eliminate the NF4-to-QAT mismatch:** Stop training NF4 QLoRA on vanilla gemma-4-E4B-it for w4a16-ct deployment; train **bfloat16 LoRA directly on google/gemma-4-E4B-it-qat-q4_0-unquantized** (matching the static symmetric Q4_0, group_size=32, no-zero-point lineage) using **PyTorch SDPA** rather than FlashAttention-2<sup>7</sup>.

4.  **Keep PLE, ViT, and USM frozen—and re-baseline VRAM:** Keep the **2.82B** PLE lookup table (not 670M), 150M ViT, and 305M USM audio encoder frozen per the Gemma 4 tuning guide, retain tied embeddings when saving, and audit single-BOS plus \<end_of_turn\> (ID 106) stop-token handling<sup>9</sup>.

5.  **Harden vLLM serving and re-benchmark MTP post-LoRA:** Pass --limit-mm-per-prompt '{"image": 0, "audio": 0}' and a workload-tight --max-model-len to mitigate vLLM's ~83% sliding-window KV over-allocation and hybrid prefix-cache eviction collapses, and re-measure draft acceptance rate if pairing your adapter with the external google/gemma-4-E4B-it-assistant MTP drafter<sup>5</sup>.

#### Works cited

1.  Gemma 4: Byte for byte, the most capable open models - Google Blog, [<u>https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/</u>](https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/)

2.  Gemma - Google DeepMind, [<u>https://deepmind.google/models/gemma/</u>](https://deepmind.google/models/gemma/)

3.  GLQ quantized model + auto-generated card - Hugging Face, [<u>https://huggingface.co/xv0y5ncu/gemma-4-12B-it-GLQ-trellis-3inst-4bpw/commit/ec1006773fabe460efc2f89c83afcb3fe63e6934</u>](https://huggingface.co/xv0y5ncu/gemma-4-12B-it-GLQ-trellis-3inst-4bpw/commit/ec1006773fabe460efc2f89c83afcb3fe63e6934)

4.  Gemma 4 31B vs Gemma 4 E4B: Benchmarks & Cost - BenchLM, [<u>https://benchlm.ai/compare/gemma-4-31b-vs-gemma-4-e4b</u>](https://benchlm.ai/compare/gemma-4-31b-vs-gemma-4-e4b)

5.  Gemma 4 Gets Multi-Token Prediction Drafters: 3x Faster Inference, [<u>https://rits.shanghai.nyu.edu/ai/gemma-4-gets-multi-token-prediction-drafters-3x-faster-inference-same-outputs/</u>](https://rits.shanghai.nyu.edu/ai/gemma-4-gets-multi-token-prediction-drafters-3x-faster-inference-same-outputs/)

6.  Multi-token-prediction in Gemma 4 - Google Blog, [<u>https://blog.google/innovation-and-ai/technology/developers-tools/multi-token-prediction-gemma-4/</u>](https://blog.google/innovation-and-ai/technology/developers-tools/multi-token-prediction-gemma-4/)

7.  Gemma 4 QAT Q4_0 - a google Collection - Hugging Face, [<u>https://huggingface.co/collections/google/gemma-4-qat-q4-0</u>](https://huggingface.co/collections/google/gemma-4-qat-q4-0)

8.  google/gemma-4-E4B-it-qat-w4a16-ct · vLLM optimized version for, [<u>https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1</u>](https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1)

9.  Gemma 4 Technical Report - arXiv, [<u>https://arxiv.org/html/2607.02770v1</u>](https://arxiv.org/html/2607.02770v1)

10. config.json · google/gemma-4-E4B at main - Hugging Face, [<u>https://huggingface.co/google/gemma-4-E4B/blob/main/config.json</u>](https://huggingface.co/google/gemma-4-E4B/blob/main/config.json)

11. GPTQ and AWQ fail on Gemma-4 E2B/E4B: KV-shared layers (no, [<u>https://github.com/vllm-project/llm-compressor/issues/3523</u>](https://github.com/vllm-project/llm-compressor/issues/3523)

12. Porting Gemma-4 (2B / 4B / 12B) to AWS Inferentia2 - DEV Community, [<u>https://dev.to/aws-builders/porting-gemma-4-2b-4b-12b-to-aws-inferentia2-4lhb</u>](https://dev.to/aws-builders/porting-gemma-4-2b-4b-12b-to-aws-inferentia2-4lhb)

13. [<u>unknown_url</u>](http://docs.google.com/unknown_url)

14. How LLMs work (with Gemma 4), [<u>https://gemma.ai/learn/how-llms-work/</u>](https://gemma.ai/learn/how-llms-work/)

15. config.json · google/gemma-4-31B-it at main - Hugging Face, [<u>https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json</u>](https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json)

16. visual-memory/PersonaChat-ERNIE-enhanced-gemma-4-31B-it, [<u>https://huggingface.co/datasets/visual-memory/PersonaChat-ERNIE-enhanced-gemma-4-31B-it</u>](https://huggingface.co/datasets/visual-memory/PersonaChat-ERNIE-enhanced-gemma-4-31B-it)

17. Gemma 4 31B INT4 on 2×24GB GPUs (TP=2): GPU KV cache size is, [<u>https://github.com/vllm-project/vllm/issues/39133</u>](https://github.com/vllm-project/vllm/issues/39133)

18. Blame for config.json · google/gemma-4-E4B-it-qat-w4a16-ct at, [<u>https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/blame/6cd26aaa2357fb2bad8c51699a7558a4d1a965bb/config.json</u>](https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/blame/6cd26aaa2357fb2bad8c51699a7558a4d1a965bb/config.json)

19. config.json · google/gemma-4-E4B-it at ee0ef60 - Hugging Face, [<u>https://huggingface.co/google/gemma-4-E4B-it/blob/ee0ef6023621cff504d758262d4e04895a5af4a2/config.json</u>](https://huggingface.co/google/gemma-4-E4B-it/blob/ee0ef6023621cff504d758262d4e04895a5af4a2/config.json)

20. RavenXAILabs/mlx-gemma4: First MLX implementation of ... - GitHub, [<u>https://github.com/DeadByDawn101/mlx-gemma4</u>](https://github.com/DeadByDawn101/mlx-gemma4)

21. How do you fine-tune Gemma with LoRA on a cloud GPU?, [<u>https://www.nodus-compute.ai/blog/fine-tune-gemma-with-lora/</u>](https://www.nodus-compute.ai/blog/fine-tune-gemma-with-lora/)

22. Gemma 4 31B SFT + LoRA: pre-clip grad norms in the ... - GitHub, [<u>https://github.com/PrimeIntellect-ai/prime-rl/issues/2362</u>](https://github.com/PrimeIntellect-ai/prime-rl/issues/2362)

23. Preparing for release! · google/gemma-4-E4B-it at 292a7e2, [<u>https://huggingface.co/google/gemma-4-E4B-it/commit/292a7e278a400932df35f9fd4b1501edd04133a5</u>](https://huggingface.co/google/gemma-4-E4B-it/commit/292a7e278a400932df35f9fd4b1501edd04133a5)

24. Gemma 4 fine-tuning best practices, [<u>https://gemma.ai/tuning/best-practices/</u>](https://gemma.ai/tuning/best-practices/)

25. A Performance Engineering Study of Multi-Token Prediction in GPU, [<u>https://arxiv.org/html/2609.35188v1</u>](https://arxiv.org/html/2609.35188v1)

26. google/gemma-4-31B-it - Hugging Face, [<u>https://huggingface.co/google/gemma-4-31B-it</u>](https://huggingface.co/google/gemma-4-31B-it)

27. Gemma4.md - vllm-project/recipes - GitHub, [<u>https://github.com/vllm-project/recipes/blob/main/Google/Gemma4.md</u>](https://github.com/vllm-project/recipes/blob/main/Google/Gemma4.md)

28. gemma-4-E4B-it-qat-w4a16-ct by google - Facthory, [<u>https://facthory.com/models/google/gemma-4-E4B-it-qat-w4a16-ct/</u>](https://facthory.com/models/google/gemma-4-E4B-it-qat-w4a16-ct/)

29. Gemma 4 E4B It Qat W4a16 Ct by google - LLM Explorer, [<u>https://llm-explorer.com/model/google%2Fgemma-4-E4B-it-qat-w4a16-ct,5Sg4wCitXwGAB5WqM0jC3N</u>](https://llm-explorer.com/model/google%2Fgemma-4-E4B-it-qat-w4a16-ct,5Sg4wCitXwGAB5WqM0jC3N)

30. \[Bug\]: Prefix-cache 0% hit on re-sent request — DeepSeek-V4-Flash, [<u>https://github.com/vllm-project/vllm/issues/42948</u>](https://github.com/vllm-project/vllm/issues/42948)

31. \[Feature\]\[KV cache\] Support fine-grained prefix hits for sliding, [<u>https://github.com/vllm-project/vllm/issues/53786</u>](https://github.com/vllm-project/vllm/issues/53786)

32. Gemma 4 Fine-tuning Guide \| Unsloth Documentation, [<u>https://unsloth.ai/docs/models/gemma-4/train</u>](https://unsloth.ai/docs/models/gemma-4/train)

33. \[BUG\] Serving google/gemma-4-E4B-it crashes ... - GitHub, [<u>https://github.com/modular/modular/issues/6665</u>](https://github.com/modular/modular/issues/6665)

34. google/gemma-4-E4B - Hugging Face, [<u>https://huggingface.co/google/gemma-4-E4B</u>](https://huggingface.co/google/gemma-4-E4B)

35. google/gemma-4-E4B-it-qat-w4a16-ct • hfviewer, [<u>https://hfviewer.com/google/gemma-4-E4B-it-qat-w4a16-ct</u>](https://hfviewer.com/google/gemma-4-E4B-it-qat-w4a16-ct)

36. openTPU/docs/formats.md at main - FeSens - GitHub, [<u>https://github.com/FeSens/openTPU/blob/main/docs/formats.md</u>](https://github.com/FeSens/openTPU/blob/main/docs/formats.md)

37. Fine-tuning Gemma 4 for Hindi on a Free GPU - Hugging Face, [<u>https://huggingface.co/blog/pankajpandey-dev/train-gemma-with-hindi</u>](https://huggingface.co/blog/pankajpandey-dev/train-gemma-with-hindi)

38. EmbeddingGemma 2: the encoders are optional, the text model is not, [<u>https://ai.satyajit.si/articles/embeddinggemma-2</u>](https://ai.satyajit.si/articles/embeddinggemma-2)

39. How Gemma 4's Per-Layer Embeddings Actually Work, [<u>https://dev.to/shreya111111/how-gemma-4s-per-layer-embeddings-actually-work-and-why-e2b-punches-above-2b-4l68</u>](https://dev.to/shreya111111/how-gemma-4s-per-layer-embeddings-actually-work-and-why-e2b-punches-above-2b-4l68)

40. Gemma 4 MTP Drafter: Get 3x Faster Inference (2026 Guide), [<u>https://www.buildfastwithai.com/blogs/gemma-4-mtp-drafter-faster-inference</u>](https://www.buildfastwithai.com/blogs/gemma-4-mtp-drafter-faster-inference)

41. Latest Gemma topics - Google AI Developers Forum, [<u>https://discuss.ai.google.dev/c/gemma/10</u>](https://discuss.ai.google.dev/c/gemma/10)

42. Youssefx64/llm-quantization-cookbook: A practical, hands ... - GitHub, [<u>https://github.com/Youssefx64/llm-quantization-cookbook</u>](https://github.com/Youssefx64/llm-quantization-cookbook)

43. Advanced LLM Engineering - DEV Community, [<u>https://dev.to/rhuturaj_takle/advanced-llm-engineering-261d</u>](https://dev.to/rhuturaj_takle/advanced-llm-engineering-261d)

44. Beyond the Black Box: Interpretability of Agentic AI Tool Use - arXiv, [<u>https://arxiv.org/html/2605.06890v1</u>](https://arxiv.org/html/2605.06890v1)

45. 1\. Introduction - arXiv, [<u>https://arxiv.org/html/2605.06890</u>](https://arxiv.org/html/2605.06890)

46. Tool Calling is Linearly Readable and Steerable in Language Models, [<u>https://arxiv.org/html/2605.07990v3</u>](https://arxiv.org/html/2605.07990v3)

47. A Mechanistic Investigation of Supervised Fine Tuning - arXiv, [<u>https://arxiv.org/html/2605.11426v1</u>](https://arxiv.org/html/2605.11426v1)

48. Building Better Deception Probes Using Targeted Instruction Pairs, [<u>https://arxiv.org/html/2602.01425v1</u>](https://arxiv.org/html/2602.01425v1)

49. Decomposing the Refusal Direction into Category-Aligned ... - arXiv, [<u>https://arxiv.org/html/2611.20405v1</u>](https://arxiv.org/html/2611.20405v1)

50. How LLMs Follow Instructions:Skillful Coordination, Not a Universal, [<u>https://arxiv.org/html/2604.06015</u>](https://arxiv.org/html/2604.06015)
