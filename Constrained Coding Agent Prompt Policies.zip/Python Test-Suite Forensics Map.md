# Offline Test-Suite Forensics for Air-Gapped Python Agents: FastAPI, Requests, Rich, and HTTPX

Running targeted pytest nodes inside air-gapped 2-vCPU containers under a 180-second command budget fails far more often from pytest plugin mismatches, strict warning promotion, and environment-coupled fixtures than from actual code regressions. Across FastAPI, Requests, Rich, and HTTPX, the highest-leverage operational rule is to preserve each repository's native pyproject.toml pytest configuration, pass overrides exclusively via -o, and execute a strict two-step **collect-only then run-exact-nodes** pipeline filtered to test\_\*.py / \*\_test.py targets<sup>1</sup>. Never pass -p no:anyio inside FastAPI or HTTPX (where it breaks async collection and fixture resolution), never run an unfiltered tests/test_requests.py sweep in Requests (where abandoned httpbin("delay/10") calls bleed 19.35s + 8.00s = 27.35s onto unrelated tests and static certificates can fail on aged clocks or modern OpenSSL), always scrub terminal environment variables and force UTF-8 in Rich, and always pass -m "not network" in HTTPX<sup>1</sup>.

Three evidence boundaries govern this map. First, verified per-node wall-clock runtimes for FastAPI on a 2-vCPU container and the collection-versus-execution time split for Requests' tests/test_requests.py are **NOT FOUND** in public upstream documentation or issue trackers; only timeout caps, CI job totals, and specific server-sleep bleed timings are documented<sup>3</sup>. Second, while all four repositories have documented environment-fragile test categories, exact individual test node names for several Rich fragility classes (Live, RichHandler, Rule/Table) and an exhaustive inventory of every dirty-equals/inline-snapshot consumer across FastAPI's test tree are **NOT FOUND** in public indices and must be confirmed locally in the collect-only step. Third, because your container is air-gapped and test files are read-only, every workaround below relies solely on CLI flags, environment variables, -k filters, and --deselect arguments.

## 1. FastAPI Test-Suite Forensics

FastAPI's modern test suite (master, https://github.com/fastapi/fastapi/blob/master/pyproject.toml) is large—a third-party FastAPI contributor wiki (factory.com) counts 581 test files totaling 74,543 lines, and an arXiv repository analysis (arxiv.org/html/2607.12223v1) counts 221 files under tests/test_tutorial/ alone<sup>3</sup>. Its native pytest configuration lives under \[tool.pytest\] (rather than \[tool.pytest.ini_options\], requiring pytest \>=9.0 on recent master) with addopts = \["--strict-config", "--strict-markers", "--ignore=docs_src"\], strict_xfail = true, filterwarnings = \["error"\], and a per-test timeout = "20" enforced via pytest-timeout<sup>3</sup>.

### 1(a) Why -p no:anyio Breaks Async Test Collection and Execution

Passing -p no:anyio disables AnyIO's auto-loaded pytest plugin (anyio/pytest_plugin.py), which breaks FastAPI and Starlette async suites across four sequential pytest hook stages<sup>1</sup>. First, pytest_configure initializes the plugin and registers the anyio marker<sup>13</sup>; because FastAPI's pyproject.toml sets --strict-markers in addopts, disabling the plugin leaves @pytest.mark.anyio and module-level pytestmark = pytest.mark.anyio unregistered and aborts **collection** immediately<sup>3</sup>. Second, AnyIO's @pytest.hookimpl(tryfirst=True) def pytest_pycollect_makeitem(collector, name, obj) inspects coroutine test functions (iscoroutinefunction(inner_func)) carrying an anyio marker and dynamically attaches pytest.mark.usefixtures("anyio_backend")(obj) during collection<sup>12</sup>. Without that hook, anyio_backend is never defined or injected, raising fixture 'anyio_backend' not found at setup (https://github.com/agronholm/anyio/issues/33)<sup>16</sup>. Third, pytest_fixture_setup wraps isasyncgenfunction and iscoroutinefunction fixtures for the active AnyIO runner, while pytest_pyfunc_call executes coroutine tests via get_runner(backend_name, backend_options)<sup>12</sup>. On modern pytest (following pytest-dev/pytest#12930, detailed in https://github.com/agronholm/anyio/issues/803), unhandled async fixtures and coroutine tests fail outright with a "no plugin or hook that handled it" error<sup>15</sup>.

<img src="f:\AI\Benchmark\research_briefs\media\Python Test-Suite Forensics Map/media/image3.png" style="width:6.45833in;height:3.52083in" />

In a Kaggle developer-agent competition postmortem (https://www.kaggle.com/competitions/gemma-4-developer-agent/discussion/757893), dropping -p no:anyio alone rescued 79 failing evaluations—all 54 native Starlette fixes and 25 of 43 Uvicorn fixes—because their test clients depend on AnyIO plugin fixtures<sup>1</sup>. A dedicated FastAPI repository issue specifically about -p no:anyio breaking collection was **NOT FOUND**; the relevant FastAPI async-testing threads instead document anyio_backend setup and missing trio failures introduced after FastAPI \>=0.69.0 (https://github.com/fastapi/fastapi/discussions/11280, https://github.com/fastapi/fastapi/issues/4459, https://github.com/fastapi/fastapi/issues/4473)<sup>17</sup>.

### 1(b) Tests Requiring dirty-equals and inline-snapshot and Missing-Package Behavior

FastAPI's tests dependency group on master declares dirty-equals \>=0.9.0 and inline-snapshot \>=0.21.1<sup>3</sup>. Earlier releases tracked lower pins—FastAPI's release notes record bumping inline-snapshot from 0.13.0 to 0.14.0 in PR \#13017 and bumping dirty-equals from 0.6.0 to 0.8.0, while commit 9f4ecf5 (PR \#14864, February 8, 2026) expanded inline-snapshot OpenAPI assertions ahead of Pydantic v2 changes and PR \#14876 referenced inline-snapshot=review<sup>20</sup>. Confirmed consumers include:

- tests/test_security_http_digest_description.py (test_openapi_schema via from inline_snapshot import snapshot)<sup>22</sup>

- tests/test_tutorial/test_path_operation_configurations/test_tutorial002.py (from dirty_equals import IsList and from inline_snapshot import ...)<sup>23</sup>

- tests/test_tutorial/test_behind_a_proxy/test_tutorial002.py (from inline_snapshot import snapshot)<sup>24</sup>

- tests/test_tutorial/test_handling_errors/test_tutorial005.py and tests/test_tutorial/test_handling_errors/test_tutorial006.py (from dirty_equals import IsDict)<sup>25</sup>

- tests/test_tutorial/test_dataclasses/test_tutorial002.py (from dirty_equals import IsDict, IsOneOf)<sup>27</sup>

- Newer test_openapi_schema tests across the suite using inline_snapshot for full-schema assertions (https://github.com/fastapi/fastapi/discussions/16215)<sup>11</sup>

An exhaustive file list across all 581 FastAPI test files is **NOT FOUND** in public indices. Because every confirmed consumer imports dirty_equals or inline_snapshot unconditionally at **module top level**, omitting either library causes pytest to abort **collection** on that file with ModuleNotFoundError during module import (ERROR collecting tests/...)<sup>22</sup>. In addition, because inline-snapshot supplies CLI options and FastAPI enforces --strict-config, passing any --inline-snapshot=... flag when the package is absent fails immediately during argument/config parsing (on master, \[tool.inline-snapshot\] defaults are commented out)<sup>3</sup>.

### 1(c) Slow and Environment-Dependent Tests at Recent Versions

FastAPI's test suite executes in-process through Starlette's TestClient or httpx.AsyncClient(transport=ASGITransport(app=app))<sup>11</sup>. Specific tests requiring outbound network access or external SSL certificates inside FastAPI's own repository were **NOT FOUND**. Digest authentication tests such as tests/test_security_http_digest_description.py (test_security_http_digest, test_security_http_digest_no_credentials, test_security_http_digest_incorrect_scheme_credentials, and test_openapi_schema) run purely in-process over TestClient without network or TLS dependencies, though the module requires inline-snapshot at import time<sup>22</sup>.

Environment fragility in FastAPI instead centers on import paths, backend parametrization, optional extras, and strict warning promotion. As noted in the factory.com FastAPI contributor wiki, scripts/test.sh exports PYTHONPATH=./docs_src so the 221 files under tests/test_tutorial/ can import documented examples directly; omitting PYTHONPATH=./docs_src causes immediate ModuleNotFoundError failures during collection<sup>10</sup>. On FastAPI \>=0.69.0, AnyIO parametrizes @pytest.mark.anyio tests (such as tests/test_tutorial/test_async_tests/test_main_a.py) across both asyncio and trio, so environments lacking trio fail every \[trio\] node with ModuleNotFoundError: No module named 'trio' (https://github.com/fastapi/fastapi/discussions/11280)<sup>19</sup>. Specialized test subtrees also depend on optional packages declared in \[dependency-groups\].tests, including sqlmodel \>=0.0.31 (tests/test_tutorial/test_sql_databases/, tests/test_tutorial/test_async_sql_databases/), flask and a2wsgi, strawberry-graphql, pwdlib\[argon2\] and pyjwt, opentelemetry-\*/logfire/sentry-sdk, and pytest-codspeed (tests/benchmarks/)<sup>3</sup>. Finally, filterwarnings = \["error"\] and strict_xfail = true turn incidental dependency deprecations into test failures<sup>3</sup>, pytest-timeout enforces a 20-second limit per test against event-loop hangs (https://github.com/fastapi/fastapi/issues/4249)<sup>3</sup>, Windows TestClient portal teardown historically raised ValueError: set_wakeup_fd only works in main thread (https://github.com/fastapi/fastapi/issues/5421)<sup>35</sup>, and platform-skipped sibling tests (such as fastapi_14186) tripped naive JUnit XML validators<sup>1</sup>.

### 1(d) Minimal Node-Selection Commands and Runtimes

For 1–5 targeted nodes on 2 vCPUs, bypass scripts/test.sh's -n auto --dist loadgroup worker overhead<sup>11</sup> and export PYTHONPATH=./docs_src:

> Bash
>
> PYTHONPATH=./docs_src pytest -q --no-header -n 0 --no-cov -k "not trio" tests/test_file.py::test_name

Omit -n 0 or --no-cov if pytest-xdist or pytest-cov are not installed in the container image, and omit -k "not trio" if trio is present and the bug fix touches async backend behavior. **Typical runtimes**: Verified per-node wall-clock runtimes for FastAPI on a 2-vCPU container were **NOT FOUND** in public sources; only the 20-second per-test timeout cap in pyproject.toml is documented<sup>3</sup>.

### FastAPI Top 10 Environment-Fragile Test Files and Honest Workarounds

|  |  |  |  |  |
|----|----|----|----|----|
| **\#** | **Test File / Node Name** | **Environment Requirement & Failure Mode** | **Version Scope** | **Honest Workaround (No Regression Hiding)** |
| 1 | tests/test_tutorial/test_async_tests/test_main_a.py<sup>31</sup> | Requires PYTHONPATH=./docs_src, AnyIO plugin active, and trio for \[trio\] nodes (discussions/11280<sup>19</sup>). | FastAPI \>=0.69.0<sup>19</sup> | Export PYTHONPATH=./docs_src; never pass -p no:anyio; append -k "not trio" only if trio is absent. |
| 2 | tests/test_security_http_digest_description.py::test_openapi_schema<sup>22</sup> | Top-level inline-snapshot import; ModuleNotFoundError at collection if missing (PR \#14864<sup>22</sup>). | Recent master (Feb 2026+)<sup>22</sup> | Target non-snapshot files if inline-snapshot is absent; verify importability in Step 1 collect-only. |
| 3 | tests/test_tutorial/test_path_operation_configurations/test_tutorial002.py<sup>23</sup> | PYTHONPATH=./docs_src, dirty-equals, and inline-snapshot at module import<sup>11</sup>. | Recent master | Export PYTHONPATH=./docs_src; --ignore only during unrelated sweeps if optional test libs are absent. |
| 4 | tests/test_tutorial/test_behind_a_proxy/test_tutorial002.py<sup>24</sup> | PYTHONPATH=./docs_src and inline-snapshot at module import<sup>11</sup>. | Recent master | Export PYTHONPATH=./docs_src; verify importability via --collect-only. |
| 5 | tests/test_tutorial/test_handling_errors/test_tutorial005.py<sup>26</sup> | PYTHONPATH=./docs_src and dirty-equals (IsDict) at module import<sup>11</sup>. | Recent master / Pydantic v2 era | Export PYTHONPATH=./docs_src; do not deselect when fixing error-handling code. |
| 6 | tests/test_tutorial/test_handling_errors/test_tutorial006.py<sup>25</sup> | PYTHONPATH=./docs_src and dirty-equals (IsDict) at module import<sup>11</sup>. | Recent master / Pydantic v2 era | Export PYTHONPATH=./docs_src; target exact node ID rather than full directory. |
| 7 | tests/test_tutorial/test_dataclasses/test_tutorial002.py<sup>27</sup> | PYTHONPATH=./docs_src and dirty-equals (IsDict, IsOneOf) at module import<sup>11</sup>. | Recent master | Export PYTHONPATH=./docs_src; run node-level target only. |
| 8 | tests/test_tutorial/test_sql_databases/ & tests/test_tutorial/test_async_sql_databases/<sup>32</sup> | PYTHONPATH=./docs_src, sqlmodel \>=0.0.31, writable filesystem for local SQLite DB fixtures<sup>3</sup>. | Recent master | Export PYTHONPATH=./docs_src; run serially (-n 0) to avoid cross-worker SQLite lock contention. |
| 9 | tests/test_tutorial/test_security/test_tutorial005_an_py310.py (and \_py310 variants)<sup>11</sup> | Python \>=3.10, PYTHONPATH=./docs_src, pwdlib\[argon2\], pyjwt (pyproject.toml<sup>3</sup>). | Recent master (Python \>=3.10) | Match Python version suffix (\_py310 vs pre-Annotated); export PYTHONPATH=./docs_src. |
| 10 | tests/benchmarks/<sup>11</sup> | Requires pytest-codspeed \>=4.3.0 (pyproject.toml<sup>3</sup>) and adds non-regression benchmark runtime. | Recent master | Always pass --ignore=tests/benchmarks alongside --ignore=docs_src during bug-fix runs. |

## 2. Requests Test-Suite Forensics

Requests (https://github.com/psf/requests/blob/main/pyproject.toml) pins pytest-httpbin==2.1.0, httpbin~=0.10.0, pytest-cov, and pytest-mock on main, and supports pytest up to the 9.x series (#7364)<sup>36</sup>. Its tests/conftest.py defines clean_proxy_environ, wraps pytest-httpbin's httpbin and httpbin_secure fixtures, and provides nosan_server<sup>38</sup>. Critically, if pytest-httpbin is absent or fails to load (for example, due to a broken markupsafe dependency), pytest does **not** report a missing plugin; instead, tests/conftest.py's @pytest.fixture def httpbin(httpbin): wrapper fails test setup with recursive dependency involving fixture 'httpbin' detected (https://github.com/psf/requests/issues/7016; https://github.com/pytest-dev/pytest/issues/6110)<sup>38</sup>.

### 2(a) Flaky and Broken Tests: Mock httpbin, Digest Auth, and Expired TLS Certificates

Requests exhibits three publicly documented failure clusters that repeatedly break air-gapped agent runs. First, static X.509 certificates checked into tests/certs/valid/server/, tests/certs/expired/, and tests/certs/mtls/ act as a clock and OpenSSL trap<sup>6</sup>. Two tests in TestPreparingURLs—tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_tls_settings_verify_bundle_unexpired_cert and tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_mtls_settings—fail when either the container clock passes the checked-in valid certificate expiration date on an older fixed commit or the certificates are regenerated with OpenSSL \>=3.2.0 (https://github.com/psf/requests/issues/6896; https://github.com/psf/requests/issues/7617)<sup>4</sup>. In https://github.com/psf/requests/issues/7631 (measured at commit 611c616), TestPreparingURLs::test_different_connection_pool_for_tls_settings_verify_bundle_unexpired_cert was noted as an unrelated baseline failure present before any patch<sup>4</sup>. Separately, tests/test_requests.py::TestRequests::test_https_warnings expects SubjectAltNameWarning and broke against pytest-httpbin \>=1.0.0 (which added IP SAN entries in kevin1024/pytest-httpbin#52, tracked in https://github.com/psf/requests/issues/5530) and again on Requests 2.31.0 with pytest-httpbin 2.0.0 (https://github.com/psf/requests/issues/6639)<sup>46</sup>. On Requests 2.25.x–2.27.x with Werkzeug \>=2.0.1 / Flask \>=2.0 on Python 3.6+, tests/test_requests.py::TestRequests::test_pyopenssl_redirect reliably fails the TLS handshake with \[SSL: HTTP_REQUEST\] (https://github.com/psf/requests/issues/5846)<sup>49</sup>. When targeting HTTPS tests directly, pytest-httpbin also requires trusting its self-signed CA bundle via REQUESTS_CA_BUNDLE=\$(python -m pytest_httpbin.certs)<sup>47</sup>.

Second, TestTimeout suffers from severe single-thread server-sleep bleed inside pytest-httpbin (https://github.com/psf/requests/issues/7631)<sup>4</sup>. Three test calls—tests/test_requests.py::TestTimeout::test_stream_timeout (timeout=2.0) and both parametrizations of tests/test_requests.py::TestTimeout::test_read_timeout (timeout=0.1)—request httpbin("delay/10") and abandon the connections once the client times out<sup>4</sup>. Because pytest-httpbin serves requests synchronously in a background thread, the abandoned handlers continue sleeping for 10 seconds each; in a full run, that latency lands on whichever httpbin tests run next—19.35s on one-line TestTimeout::test_encoded_methods and 8.00s on TestTimeout::test_none_timeout\[None\], totaling 19.35s + 8.00s = 27.35s of phantom wait time<sup>4</sup>.

<img src="f:\AI\Benchmark\research_briefs\media\Python Test-Suite Forensics Map/media/image1.png" style="width:6.45833in;height:4.84375in" />

Third, Digest Auth and httpbin network flakiness split sharply by version. Modern Requests runs Digest Auth locally via TestRequests.digest_auth_algo = ("MD5", "SHA-256", "SHA-512") against httpbin("digest-auth", "auth", "user", "pass", authtype, "never") (https://github.com/psf/requests/blob/main/tests/test_requests.py)<sup>44</sup>, and upstream issue threads showing flakiness in local pytest-httpbin digest auth tests on modern Requests (\>=2.28) were **NOT FOUND**. By contrast, on legacy commits spanning Requests v2.0 through v2.4 (documented in https://github.com/SWE-bench/SWE-bench/issues/700 and https://github.com/swe-bench/SWE-bench/issues/167 for instances psf\_\_requests-1724, 1766, 1921, 2317), the suite defaulted to the live public internet (HTTPBIN = os.environ.get('HTTPBIN_URL', 'http://httpbin.org/'))<sup>51</sup>. In an offline container—or whenever httpbin.org returns HTTP 502/504—every httpbin-backed test fails, including test_requests.py::RequestsTestCase::test_DIGEST_AUTH_RETURNS_COOKIE, test_DIGEST_HTTP_200_OK_GET, test_DIGESTAUTH_QUOTES_QOP_VALUE, test_basicauth_with_netrc (also flagged in https://arxiv.org/html/2502.06994v2), test_HTTP_302_ALLOW_REDIRECT_GET, test_POSTBIN_GET_POST_FILES, test_POSTBIN_GET_POST_FILES_WITH_DATA, test_different_encodings_dont_break_post, test_generic_cookiejar_works, test_json_param_post_content_type_works, and test_manual_redirect_with_partial_body_read<sup>45</sup>. On v2.0–v2.4, offline agents can only pass httpbin nodes if HTTPBIN_URL points to an already-running local httpbin service; otherwise only pure-unit nodes pass<sup>51</sup>.

### 2(b) Single-Node Selection and Collection vs. Execution Time Split

Always target Requests tests with class-qualified node IDs (pytest -q tests/test_requests.py::TestRequests::\<test_name\> on \>=2.5, or tests/test_requests.py::RequestsTestCase::\<test_name\> on v2.0–v2.4)<sup>51</sup>. Direct node selection prevents pure-unit tests (such as test_path_is_not_double_encoded or URL preparation checks) from spinning up httpbin/httpbin_secure threads and completely avoids the 27.35-second TestTimeout server-sleep bleed<sup>4</sup>. **Typical collection vs. execution time split**: Measured collection-only versus execution benchmarks for tests/test_requests.py were **NOT FOUND** in public sources; the only verified runtime figures are the 19.35s and 8.00s execution stalls documented in psf/requests#7631<sup>4</sup>.

### Requests Top 10 Environment-Fragile Test Files and Honest Workarounds

|  |  |  |  |  |
|----|----|----|----|----|
| **\#** | **Test File / Node Name** | **Environment Requirement & Failure Mode** | **Version Scope** | **Honest Workaround (No Regression Hiding)** |
| 1 | tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_tls_settings_verify_bundle_unexpired_cert<sup>4</sup> | Unexpired tests/certs/valid/server/server.pem; fails past cert expiry or after OpenSSL \>=3.2.0 regen (#6896, \#7631<sup>4</sup>). | 2.32.x / aged commits<sup>4</sup> | --deselect explicitly when patch is unrelated to TLS connection pooling. |
| 2 | tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_mtls_settings<sup>6</sup> | Valid tests/certs/mtls/ chain; breaks if regenerated with OpenSSL \>=3.2.0 (#6896, \#7617<sup>6</sup>). | 2.32.x + OpenSSL \>=3.2.0<sup>6</sup> | --deselect explicitly unless modifying mTLS/adapter pool keys. |
| 3 | tests/test_requests.py::TestRequests::test_https_warnings<sup>46</sup> | Expects SubjectAltNameWarning; broke with pytest-httpbin \>=1.0.0 (#5530) and 2.0.0 (#6639)<sup>46</sup>. | 2.23–2.31 with mismatched pytest-httpbin<sup>46</sup> | --deselect tests/test_requests.py::TestRequests::test_https_warnings when pytest-httpbin mismatches commit. |
| 4 | tests/test_requests.py::TestRequests::test_pyopenssl_redirect<sup>49</sup> | Requires Werkzeug \<2.0 / Flask \<2.0 with pyOpenSSL + pytest-httpbin (#5846<sup>49</sup>). | 2.25.x–2.27.x on Python 3.6+<sup>49</sup> | --deselect unless editing pyOpenSSL / TLS redirect code. |
| 5 | tests/test_requests.py::TestTimeout::test_stream_timeout<sup>4</sup> | Abandons httpbin("delay/10") after 2.0s, stalling background pytest-httpbin thread (#7631<sup>4</sup>). | Through recent main (611c616)<sup>4</sup> | Run in isolation if testing timeouts; never bundle ahead of unrelated httpbin nodes. |
| 6 | tests/test_requests.py::TestTimeout::test_read_timeout<sup>4</sup> | Abandons 2x httpbin("delay/10") calls after 0.1s, causing ~19.79s server stall (#7631<sup>4</sup>). | Through recent main (611c616)<sup>4</sup> | Select explicitly via exact node ID; avoid sweeping TestTimeout for non-timeout fixes. |
| 7 | tests/test_requests.py::TestTimeout::test_encoded_methods & test_none_timeout\[None\]<sup>4</sup> | Absorbs 19.35s / 8.00s phantom wait if scheduled after TestTimeout delay tests (#7631<sup>4</sup>). | Through recent main (611c616)<sup>4</sup> | Run by exact node ID alone so test_read_timeout/test_stream_timeout never execute first. |
| 8 | test_requests.py::RequestsTestCase::test_DIGEST_AUTH_RETURNS_COOKIE, test_DIGEST_HTTP_200_OK_GET, test_DIGESTAUTH_QUOTES_QOP_VALUE<sup>51</sup> | Hits live http://httpbin.org/ on legacy commits; fails offline or on 502/504 (SWE-bench#700, \#167<sup>51</sup>). | Requests v2.0–v2.4<sup>51</sup> | Export HTTPBIN_URL to a local container httpbin if available; otherwise select non-httpbin unit nodes. |
| 9 | tests/test_requests.py::TestRequests::test_basicauth_with_netrc (legacy: RequestsTestCase::test_basicauth_with_netrc)<sup>44</sup> | Depends on httpbin + netrc / HOME isolation (SWE-bench#700<sup>45</sup>). | v2.0–main | Run with isolated HOME=\$(mktemp -d) so host ~/.netrc cannot pollute auth assertions. |
| 10 | tests/test_requests.py::test_content_length_for_string_data_counts_bytes & test_response_iter_lines_reentrant<sup>38</sup> | Requires pytest-httpbin (recursive fixture error if absent, \#7016<sup>38</sup>) and urllib3 \>=2.x; iter_lines_reentrant is xfail<sup>44</sup>. | 2.31+ / urllib3 1.x vs 2.x<sup>38</sup> | Confirm pytest-httpbin appears in pytest --version before targeting any httpbin-fixture node. |

## 3. Rich Test-Suite Forensics

Rich (https://github.com/Textualize/rich/blob/main/pyproject.toml, v15.0.0 on main) carries minimal pytest plugin overhead: \[tool.pytest.ini_options\] sets only testpaths = \["tests"\], with no filterwarnings = \["error"\], no async plugins, and no network fixtures<sup>55</sup>. Its environment fragility stems almost entirely from terminal auto-detection, locale encoding, platform skips, and stdout capture.

Four environment mechanisms govern Rich test reliability. First, tests/test_console.py (1,135 lines at https://github.com/Textualize/rich/blob/master/tests/test_console.py) directly exercises is_terminal, FORCE_COLOR, NO_COLOR, and TERM (for example, lines 984–992 setting FORCE_COLOR=1 and TERM=xterm..., cited in https://github.com/astral-sh/uv/issues/7352)<sup>7</sup>. Any inherited container variables (NO_COLOR, FORCE_COLOR, COLORTERM, TERM=dumb, or non-default COLUMNS/LINES) alter detected color systems and wrapping across console and layout tests (Table, Rule, Columns, and Measure option propagation was also addressed in https://github.com/Textualize/rich/issues/4028)<sup>7</sup>. Second, pytest's stdout redirection interacts with Rich's encoding and terminal detection: https://github.com/Textualize/rich/issues/3437 and https://github.com/Textualize/rich/issues/2411 document pytest-captured subprocesses falling back to WindowsConsoleFeatures(vt=False, truecolor=False), legacy_windows=True, and encoding='cp1252', breaking box-drawing output (such as console.print(Rule()) without a title) unless Python runs with -X utf8 or PYTHONUTF8=1 (until Python 3.15 PEP 686 makes UTF-8 default)<sup>5</sup>; in minimal Linux containers using the POSIX C locale, forcing LC_ALL=C.UTF-8 and PYTHONUTF8=1 prevents analogous ASCII encoding fallback. Third, platform-conditional skips appear in tests/test_console.py (@pytest.mark.skipif(sys.platform == "win32", reason="does not run on windows...")) and tests/test_pretty.py<sup>56</sup>, and the Kaggle agent-harness audit flagged rich_3486 as a task where a platform-skipped sibling test broke naive JUnit XML prefix matching<sup>1</sup>. Fourth, RichHandler writes directly to stdout and interacts subtly with pytest log capturing (https://github.com/Textualize/rich/discussions/2256)<sup>60</sup>, while Live / console.status refresh threads can race with concurrent console.print calls (https://github.com/Textualize/rich/issues/1530)<sup>61</sup>.

### Safest Node-Level Invocation Pattern for Rich

Launch Rich tests inside a scrubbed terminal environment with explicit UTF-8 encoding and neutral TERM, leaving COLUMNS/LINES unset unless a test manages them internally:

> Bash
>
> env -u NO_COLOR -u FORCE_COLOR -u COLORTERM -u COLUMNS -u LINES -u CLICOLOR -u CLICOLOR_FORCE \\\
> TERM=xterm-256color PYTHONUTF8=1 LC_ALL=C.UTF-8 LANG=C.UTF-8 \\\
> pytest -q --no-header tests/test_console.py::\<test_name\>

### Rich Top 10 Environment-Fragile Test Files / Areas and Honest Workarounds

*Evidence note: Exact file paths are verified for rows 1–6 (for rows 5–6, upstream failure issue threads were **NOT FOUND**, so the workarounds represent preventive encoding/width hygiene grounded in \#2411 and \#3437). Rows 7–10 capture verified upstream fragility mechanisms whose exact pytest function names inside tests/ were **NOT FOUND** in public indices.*

|  |  |  |  |  |
|----|----|----|----|----|
| **\#** | **Test File / Node Name** | **Environment Requirement & Failure Mode** | **Version Scope** | **Honest Workaround (No Regression Hiding)** |
| 1 | tests/test_console.py (color/TTY env tests, lines ~984–992)<sup>7</sup> | Sensitive to inherited NO_COLOR, FORCE_COLOR, COLORTERM, TERM (astral-sh/uv#7352<sup>7</sup>). | Rich 12.x–15.x | Scrub env with env -u NO_COLOR -u FORCE_COLOR -u COLORTERM and set TERM=xterm-256color. |
| 2 | tests/test_console.py (POSIX-only tests with skipif(sys.platform == "win32"))<sup>56</sup> | Requires POSIX (sys.platform != "win32"); skipped on Windows<sup>56</sup>. | All modern Rich | Run on Linux container; ensure harness ignores \<skipped\> siblings in JUnit XML<sup>1</sup>. |
| 3 | tests/test_console.py (redirected stdout / encoding tests)<sup>5</sup> | Pytest stdout capture triggers legacy/non-UTF-8 detection (rich#3437, rich#2411<sup>5</sup>). | Rich \>=12.4.4, Python \<3.15<sup>5</sup> | Export PYTHONUTF8=1 LC_ALL=C.UTF-8 LANG=C.UTF-8 (or python -X utf8 -m pytest). |
| 4 | tests/test_pretty.py<sup>59</sup> | Contains conditional skipped nodes (s in pytest output<sup>59</sup>); Python repr sensitivity across versions. | All modern Rich | Target exact node IDs from Step 1 collect-only; never assume zero skips in file-level runs. |
| 5 | tests/test_progress.py::test_open_text_mode (and tests/test_progress.py)<sup>62</sup> | Preventive guard: text-mode file I/O depends on default locale encoding (specific failure thread: **NOT FOUND**). | All modern Rich | Run with PYTHONUTF8=1 LC_ALL=C.UTF-8; select exact node ID. |
| 6 | tests/test_traceback.py<sup>65</sup> | Preventive guard: console width (COLUMNS) and UTF-8 box-drawing defaults (specific failure thread: **NOT FOUND**). | All modern Rich | Unset COLUMNS/LINES and force UTF-8 so Console defaults stay deterministic. |
| 7 | Live / console.status concurrency tests (exact node name: **NOT FOUND**)<sup>61</sup> | Threading race between Live refresh thread and console.print (rich#1530<sup>61</sup>); worsened under 2-vCPU contention. | Rich \>=10.x | Run serially (never -n auto) to avoid CPU starvation of refresh threads. |
| 8 | RichHandler logging tests (exact node name: **NOT FOUND**)<sup>60</sup> | Pytest capture intercepts logs differently from RichHandler direct stdout writes (discussions/2256<sup>60</sup>). | All modern Rich | Avoid global -s; preserve default pytest capture unless a specific node requires it. |
| 9 | Rule / Table / Columns / Measure tests (exact node name: **NOT FOUND**)<sup>57</sup> | Option propagation (rich#4028<sup>57</sup>) and CP-1252 Rule() failure without title (rich#2411<sup>58</sup>). | Rich 12.x–15.x | Unset COLUMNS; enforce PYTHONUTF8=1 LC_ALL=C.UTF-8. |
| 10 | rich_3486 platform-skipped sibling test (exact node name: **NOT FOUND**)<sup>1</sup> | Sibling test skipped on Linux tripped JUnit prefix matching ({req_base}\_) in agent harnesses<sup>1</sup>. | PR \#3486 era | Target exact node IDs without wildcard prefixes; fail only on \<failure\>/\<error\> in JUnit XML<sup>1</sup>. |

## 4. HTTPX Test-Suite Forensics

HTTPX (https://github.com/encode/httpx/blob/master/pyproject.toml) is built for fast, hermetic verification: GitHub Actions CI runs complete in 56–75 seconds (rising to 2m30s–3m11s on Python 3.15 in PR \#3841), and a local full sweep of 1,378 tests finished in 4.63 seconds on Python 3.14<sup>8</sup>. Its \[tool.pytest.ini_options\] defines addopts = "-rxXs", filterwarnings = \["error", ...\] (ignoring only custom sys.excepthook and trio.TrioDeprecationWarning), and two custom markers: copied_from and network<sup>2</sup>.

### Network vs. Offline-Safe Subsets and Sync vs. Async Selection

HTTPX explicitly registers the network marker in pyproject.toml for air-gapped builds ("network: marks tests which require network connection. Used in 3rd-party build environments that have network disabled."), making -m "not network" mandatory offline<sup>2</sup>. The primary network-dependent test is tests/client/test_proxies.py::test_async_proxy_close, decorated with @pytest.mark.network and issuing await client.get("http://example...") through PROXY_URL (https://github.com/encode/httpx/discussions/2121, https://github.com/encode/httpx/discussions/2270)<sup>66</sup>. On older commits before network was registered in pyproject.toml (circa 0.23–0.25, discussions/2208, discussions/2270), @pytest.mark.network emitted PytestUnknownMarkWarning, which filterwarnings = \["error"\] promoted to a failure; downstream packagers bypassed it with --deselect tests/client/test_proxies.py::test_async_proxy_close<sup>67</sup>. Almost every other HTTP test is offline-safe because it connects to the loopback server fixture in tests/conftest.py (a TestServer subclass of uvicorn.Server running in a background thread)<sup>70</sup>.

Sync and async client tests are cleanly partitioned. tests/client/test_client.py (e.g., test_get) runs synchronous def test\_\* functions against httpx.Client<sup>9</sup>, whereas tests/client/test_async_client.py (375 lines at https://github.com/encode/httpx/blob/master/tests/client/test_async_client.py) marks async tests with @pytest.mark.anyio (e.g., test_get, test_get_invalid_url, test_build_request, test_post, test_post_json), which AnyIO parametrizes into \[asyncio\] and \[trio\] nodes<sup>67</sup>. Mixed files such as tests/client/test_auth.py contain both sync (test_sync_auth) and async (test_basic_auth\[asyncio\]) nodes, while tests/test_timeouts.py holds async test_write_timeout<sup>9</sup>. Because AnyIO removed --anyio-backends<sup>74</sup>, restrict async runs to asyncio via explicit node IDs (tests/client/test_async_client.py::test_get\[asyncio\]) or -k "not trio".

### Common Fixture Requirements and Python 3.13/3.14 Landmines

Three dependency and interpreter interactions dominate HTTPX test fragility. First, under Python 3.14 with unpatched uvicorn (prior to Kludex/uvicorn#2723) and HTTPX prior to \#3693, uvicorn's deprecated asyncio.iscoroutinefunction() triggers a fatal DeprecationWarning under filterwarnings = \["error"\], compounded by Python 3.14's stricter asyncio.get_event_loop() / server.run() rules in background threads—causing server-fixture setup to **hang indefinitely** across test_async_client.py, test_client.py, and test_event_hooks.py (https://github.com/encode/httpx/discussions/3616; stall guards were later added in PR \#3835)<sup>8</sup>. Passing -W ignore::DeprecationWarning neutralizes the fatal warning component, though pre-#3693 commits on Python 3.14 still require a hard shell timeout guard. Second, on Python \>=3.13.3 prior to commit 8216567, tests/test_timeouts.py::test_write_timeout\[trio\] fails because Trio emits ResourceWarning: Async generator 'httpx.\_content.ByteStream.\_\_aiter\_\_' was garbage collected before it had been exhausted, which filterwarnings = \["error"\] converts to an error (https://github.com/encode/httpx/issues/3686, xfailed on Python \>=3.14 in \#3645)<sup>73</sup>. Third, optional extras gate specific modules: tests/test_main.py requires \[cli\] (click, rich, pygments; failing 8–10 tests when missing or incompatible, discussions/2121, discussions/3429)<sup>66</sup>; tests/test_decoders.py requires brotli/brotlicffi and compatible chardet (updated for chardet 6.0 and pytest 9.1 in PR \#3837)<sup>2</sup>; tests/client/test_async_client.py::test_get uses http2=True (h2)<sup>9</sup>; and TLS tests such as tests/test_config.py::test_load_ssl_with_keylog require trustme and cryptography (and failed on PyPy 3.10 in discussions/3430 / pypy/pypy#5141)<sup>9</sup>.

### HTTPX Top 10 Environment-Fragile Test Files and Honest Workarounds

|  |  |  |  |  |
|----|----|----|----|----|
| **\#** | **Test File / Node Name** | **Environment Requirement & Failure Mode** | **Version Scope** | **Honest Workaround (No Regression Hiding)** |
| 1 | tests/client/test_proxies.py::test_async_proxy_close<sup>66</sup> | @pytest.mark.network; attempts live request to http://example... via PROXY_URL (#2121, \#2270<sup>66</sup>). | All versions | Always pass -m "not network" (plus --deselect on pre-marker-registration 0.23–0.25 commits). |
| 2 | tests/test_timeouts.py::test_write_timeout\[trio\]<sup>73</sup> | Trio emits ResourceWarning on ByteStream.\_\_aiter\_\_, promoted by filterwarnings = \["error"\] (#3686<sup>73</sup>). | Python \>=3.13.3 prior to 8216567<sup>73</sup> | Target \[asyncio\] (test_write_timeout\[asyncio\]) unless fixing Trio stream cleanup. |
| 3 | tests/client/test_async_client.py::test_get (and server tests)<sup>9</sup> | Requires uvicorn server, anyio\[trio\], h2 (http2=True); hangs on Py3.14 + unpatched uvicorn (#3616<sup>9</sup>). | Python 3.14 pre-#3693 / old uvicorn<sup>9</sup> | Never pass -p no:anyio; add -W ignore::DeprecationWarning and shell timeout 140s on Py3.14; -k "not trio" if trio is absent. |
| 4 | tests/client/test_client.py::test_get (and server tests)<sup>9</sup> | Requires background-thread uvicorn server; hangs on Py3.14 + unpatched uvicorn (#3616<sup>9</sup>). | Python 3.14 pre-#3693 / old uvicorn<sup>9</sup> | Add -W ignore::DeprecationWarning and enforce shell timeout 140s. |
| 5 | tests/client/test_event_hooks.py::test_event_hooks & test_event_hooks_raising_exception<sup>9</sup> | Depends on server fixture; hung/failed under Py3.14 background loop rules (#3616<sup>9</sup>). | Python 3.14 pre-#3693<sup>9</sup> | Isolate single node under timeout 140s with -W ignore::DeprecationWarning. |
| 6 | tests/test_main.py (all CLI tests)<sup>66</sup> | Requires \[cli\] extras (click, rich, pygments) and compatible Click API (#2121, \#3429<sup>66</sup>). | All versions | Only target tests/test_main.py when modifying CLI code. |
| 7 | tests/test_decoders.py<sup>8</sup> | Requires brotli/brotlicffi and matching chardet (PR \#3837 fixed chardet 6.0 / pytest 9.1<sup>8</sup>). | All versions (chardet 6.0 era) | Select specific codec node (e.g., -k "gzip") if optional brotli is absent. |
| 8 | tests/test_config.py::test_load_ssl_with_keylog<sup>76</sup> | Requires trustme, cryptography, and CPython SSLKEYLOGFILE support; failed on PyPy 3.10 (#3430<sup>76</sup>). | PyPy 3.10 (pypy#5141)<sup>76</sup> | --deselect on affected PyPy 3.10 images; runs cleanly on CPython with trustme. |
| 9 | tests/client/test_auth.py (line 273 netrc test & test_basic_auth)<sup>9</sup> | Skips on Python \>=3.11 due to stdlib netrc passwordless-entry change; requires anyio\[trio\] for async nodes<sup>9</sup>. | Python \<3.11 vs \>=3.11<sup>9</sup> | Isolate HOME=\$(mktemp -d); filter -k "not trio" if trio is absent. |
| 10 | tests/test_utils.py (exact node name: **NOT FOUND**)<sup>66</sup> | Vulnerable to third-party deprecation warnings promoted by filterwarnings = \["error"\] (#2208<sup>69</sup>). | Older commits (0.23–0.25) | Narrow -W ignore::... to the offending third-party module rather than silencing all warnings. |

## 5. Cross-Cutting Pytest Plugin, JUnit XML, and Two-Step Agent Patterns

A Kaggle developer-agent competition postmortem (https://www.kaggle.com/competitions/gemma-4-developer-agent/discussion/757893) auditing 277 rescued evaluation tasks found that harness-level pytest mistakes—not repository defects—accounted for the bulk of false failures: preserving repository pytest configs rescued 101 tasks, dropping -p no:anyio rescued 79 tasks (54 Starlette, 25 Uvicorn), filtering targets to test\_\*.py/\*\_test.py rescued 65 tasks, fixing skipped-sibling JUnit prefix matching rescued 24 tasks (including rich_3486 and fastapi_14186), and removing a 10 MiB JUnit output cap rescued 8 tasks (python-multipart)<sup>1</sup>.

<img src="f:\AI\Benchmark\research_briefs\media\Python Test-Suite Forensics Map/media/image2.png" style="width:6.45833in;height:4.84375in" />

### 5(a) Pytest Plugin Landmines When Running Single Nodes

Plugin interactions frequently determine whether a single-node run succeeds cleanly or crashes in setup. Passing -p no:anyio is fatal in FastAPI, Starlette, Uvicorn, and HTTPX<sup>1</sup>; it belongs solely in projects that rely on pytest-asyncio and inherit anyio only as a transitive dependency of httpx (for example, keeping asyncpg connections on a single loop)<sup>77</sup>. Conversely, -p no:randomly is safe for single-node debugging and isolating order-dependent flakiness when pytest-randomly is present in the environment<sup>78</sup>.

Within AnyIO itself, five behaviors and version-specific bugs trap automated runners: --anyio-backends was removed in a backwards-incompatible release (https://github.com/agronholm/anyio/blob/master/docs/versionhistory.rst), so backend filtering must use -k "not trio" or \[asyncio\] node IDs<sup>74</sup>; default strict anyio_mode activates only on async def functions marked @pytest.mark.anyio and ignores sync tests requesting async fixtures (agronholm/anyio#803)<sup>14</sup>; AnyIO 4.0.0 broke ContextVar visibility from sync fixtures running after async fixtures until commits 9cb6a71/0d72d3f (agronholm/anyio#614)<sup>80</sup>; AnyIO 4.13.0 hangs silently on Trio when an async fixture is fetched dynamically via request.getfixturevalue() (agronholm/anyio#1148)<sup>81</sup>; and AnyIO 4.14.0 introduced a regression (agronholm/anyio#1179, from \#1121) in which any test raising a pytest OutcomeException (pytest.skip(), pytest.xfail(), pytest.fail(), or unmet pytest.raises()) breaks teardown of higher-scoped async-generator fixtures holding a cancel scope (RuntimeError: Attempted to exit cancel scope in a different task than it was entered in), reported confusingly against the *last* test in the session—making tight node isolation that omits unrelated skipping tests doubly valuable<sup>82</sup>.

Regarding pytest-asyncio and asyncio_mode, overwriting a repository's pytest.ini drops asyncio_mode = auto, markers, and plugin registrations<sup>1</sup>. Conversely, if pytest-asyncio is globally installed inside an AnyIO-native repository (FastAPI or HTTPX), pytest auto-loads both plugins and pytest-asyncio can emit mode warnings or attempt to claim async def tests (encode/httpx#2121, agronholm/anyio#803)<sup>15</sup>; passing -p no:asyncio isolates AnyIO cleanly. Finally, on a 2-vCPU container running 1–10 nodes, pytest-xdist (-n auto) spawns redundant workers and duplicates session fixtures (server, httpbin) for net slowdown; override with -n 0 and --no-cov whenever those plugins are loaded.

### 5(b) Does --junitxml Change Test Behavior?

Direct test logic regressions triggered by --junitxml inside FastAPI, Requests, Rich, or HTTPX were **NOT FOUND**. However, three operational side effects demand strict guardrails. First, --junitxml couples tightly to capture flags: -s / --capture=no strips stdout/stderr from the XML report (https://github.com/pytest-dev/pytest/issues/4593)<sup>83</sup>, whereas --capture=tee-sys (pytest \>=5.4) live-prints while still capturing for JUnit, and -o junit_logging=all or system-out controls log inclusion (https://github.com/pytest-dev/pytest/issues/6139)<sup>84</sup>; in **Rich**, changing --capture also alters redirected-stdout detection (rich#3437, rich#2411)<sup>5</sup>. Second, leaving junit_log_passing_tests enabled can bloat JUnit XML past 10 MiB sandbox output caps and cause silent truncation<sup>1</sup>, so always pass -o junit_log_passing_tests=false and read the file directly from disk. Third, JUnit XML validators must match exact node IDs or parametrized {req_base}\[ prefixes—never {req_base}\_—and fail solely on \<failure\> or \<error\> elements so platform-skipped siblings (rich_3486, fastapi_14186) never cause false rejections<sup>1</sup>.

### 5(c) Safest Two-Step "Collect-Only First, Then Run Selected Nodes" Pattern

Never pass raw modified .py paths to pytest—helper modules and fixture data files crash collection (65 fixes in<sup>1</sup>)—and never overwrite pyproject.toml or pytest.ini (101 fixes in<sup>1</sup>). Encode this two-step collect-then-run pattern into your agent harness:

> Bash
>
> \# STEP 1: Collect-only discovery on strictly filtered test\_\*.py / \*\_test.py targets\
> \# Reveals exact parametrized node IDs (e.g., \[asyncio\] vs \[trio\]) without starting server fixtures.\
> timeout 45s pytest --collect-only -q --no-header \\\
> \<REPO_ENV_AND_SAFE_FLAGS\> \\\
> \<FILTERED_TEST_FILES\> \> /tmp/collected_nodes.txt\
> rc=\$?\
> \# Exit code 0 = OK; 2 = collection/import error (inspect stderr; abort Step 2); 5 = 0 tests matched.\
> \
> \# Filter collected lines strictly to valid node IDs (must contain '::'), applying repo-specific exclusions:\
> grep '::' /tmp/collected_nodes.txt \| grep -E '\<TARGET_TEST_REGEX\>' \> /tmp/selected_nodes.txt\
> \
> \# STEP 2: Execute ONLY the verified node IDs inside a hard wall-clock guard (\< 180s container cap)\
> \# Preserve repository config; override only non-destructive options via -o.\
> mapfile -t NODES \< /tmp/selected_nodes.txt\
> timeout 140s pytest -q --no-header -o junit_log_passing_tests=false \\\
> \<REPO_ENV_AND_SAFE_FLAGS\> \\\
> "\${NODES\[@\]}"

## 6. Per-Repo Agent Cheat-Sheets (Prompt Laws)

Encode the following four profiles directly into your agent's command dispatcher and prompt laws.

### FastAPI Prompt Laws

- **Mandatory environment**: Always prefix invocations with PYTHONPATH=./docs_src<sup>11</sup>.

- **Forbidden flags**: NEVER pass -p no:anyio (breaks --strict-markers collection and anyio_backend fixture injection<sup>1</sup>); NEVER overwrite pyproject.toml.

- **Safe node-selection command**:\
  Bash\
  PYTHONPATH=./docs_src timeout 140s pytest -q --no-header --ignore=docs_src --ignore=tests/benchmarks -k "not trio" tests/path/to/test_file.py::test_name\
  \
  *(Omit -k "not trio" when trio is installed and the fix touches async backends; append -n 0 --no-cov if pytest-xdist / pytest-cov are loaded, or -p no:asyncio if pytest-asyncio interferes.)*

- **Explicit ignores & collection hazards**: Keep --ignore=docs_src and --ignore=tests/benchmarks<sup>3</sup>. If dirty-equals or inline-snapshot are absent in an older container, Step 1 --collect-only will hit top-level ModuleNotFoundError on dependent files (e.g., tests/test_security_http_digest_description.py, tests/test_tutorial/test_handling_errors/test_tutorial005.py)<sup>22</sup>; narrow targets to non-dependent nodes unless the fix explicitly targets those files.

- **Warning landmine**: filterwarnings = \["error"\] and timeout = "20" are active by default<sup>3</sup>; pass a narrowly scoped -W ignore:... only for unrelated third-party deprecations.

### Requests Prompt Laws

- **Mandatory pre-flight check**: Confirm pytest-httpbin appears in pytest --version plugins; if absent, any httpbin-fixture node fails setup with recursive dependency involving fixture 'httpbin' detected (#7016)<sup>38</sup>. For HTTPS nodes, export REQUESTS_CA_BUNDLE=\$(python -m pytest_httpbin.certs)<sup>47</sup>. Always isolate HOME=\$(mktemp -d) to block ~/.netrc leakage.

- **Forbidden pattern**: NEVER sweep pytest tests/test_requests.py wholesale (triggers 27.35s TestTimeout delay bleed \#7631 and expired/OpenSSL-3.2+ certificate failures \#6896)<sup>4</sup>.

- **Safe node-selection command**:\
  Bash\
  HOME=\$(mktemp -d) timeout 140s pytest -q --no-header tests/test_requests.py::TestRequests::\<test_name\>\
  \
  (On legacy v2.0–v2.4 commits, use RequestsTestCase::\<test_name\> and export HTTPBIN_URL to a local container httpbin if present; otherwise target non-httpbin unit nodes only<sup>51</sup>.)

- **Explicit deselects (for broader class sweeps)**:

  - --deselect tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_tls_settings_verify_bundle_unexpired_cert (expired cert / OpenSSL \>=3.2 \#6896, \#7631<sup>4</sup>)

  - --deselect tests/test_requests.py::TestPreparingURLs::test_different_connection_pool_for_mtls_settings (OpenSSL \>=3.2 cert regen \#6896<sup>6</sup>)

  - --deselect tests/test_requests.py::TestRequests::test_https_warnings (2.23–2.31 with pytest-httpbin \>=1.0/2.0, \#5530, \#6639<sup>46</sup>)

  - --deselect tests/test_requests.py::TestRequests::test_pyopenssl_redirect (2.25.x–2.27.x with Werkzeug \>=2.0, \#5846<sup>49</sup>)

  - Never schedule TestTimeout::test_stream_timeout or TestTimeout::test_read_timeout ahead of unrelated httpbin tests (#7631)<sup>4</sup>.

### Rich Prompt Laws

- **Mandatory environment**: Scrub terminal color/size env vars and force UTF-8 (PYTHONUTF8=1 LC_ALL=C.UTF-8 LANG=C.UTF-8 TERM=xterm-256color) to lock down Console auto-detection (#2411, \#3437, astral-sh/uv#7352)<sup>5</sup>.

- **Forbidden pattern**: Do not pass -n auto on 2 vCPUs (risks starving Live refresh threads \#1530<sup>61</sup>) and do not pass -s globally (alters redirected-stdout detection \#3437<sup>5</sup>).

- **Safe node-selection command**:\
  Bash\
  env -u NO_COLOR -u FORCE_COLOR -u COLORTERM -u COLUMNS -u LINES -u CLICOLOR -u CLICOLOR_FORCE \\\
  TERM=xterm-256color PYTHONUTF8=1 LC_ALL=C.UTF-8 LANG=C.UTF-8 \\\
  timeout 140s pytest -q --no-header tests/test\_\<module\>.py::\<test_name\>

- **Explicit deselects & harness rule**: No permanent Linux deselects are required under UTF-8; ensure JUnit XML evaluation counts only \<failure\>/\<error\> and never fails on platform-skipped sibling nodes (rich_3486<sup>1</sup>).

### HTTPX Prompt Laws

- **Mandatory flags**: Always pass -m "not network" (pyproject.toml<sup>2</sup>). Never pass -p no:anyio<sup>1</sup>.

- **Sync vs. Async targeting**: Target tests/client/test_client.py::\<name\> for sync httpx.Client fixes and tests/client/test_async_client.py::\<name\>\[asyncio\] for async httpx.AsyncClient fixes<sup>9</sup>. Use -k "not trio" if trio is absent (never --anyio-backends, which was removed<sup>74</sup>).

- **Safe node-selection command**:\
  Bash\
  timeout 140s pytest -q --no-header -m "not network" tests/client/test_async_client.py::test_get\[asyncio\]

- **Explicit deselects & Python 3.13/3.14 guardrails**:

  - --deselect tests/client/test_proxies.py::test_async_proxy_close (required on older 0.23–0.25 commits lacking network marker registration \#2208, \#2270<sup>67</sup>).

  - --deselect tests/test_timeouts.py::test_write_timeout\[trio\] on Python \>=3.13.3 commits prior to 8216567 (#3686 Trio ResourceWarning<sup>73</sup>).

  - --deselect tests/test_config.py::test_load_ssl_with_keylog on PyPy 3.10 images (#3430<sup>76</sup>).

  - On Python 3.14 with unpatched uvicorn where server-fixture tests hang under filterwarnings = \["error"\] (#3616<sup>9</sup>), append -W ignore::DeprecationWarning and keep the hard timeout 140s guard.

#### Works cited

1.  The Gemma 4 Developer Agent Competition - Google - Kaggle, [<u>https://www.kaggle.com/competitions/gemma-4-developer-agent/discussion/757893</u>](https://www.kaggle.com/competitions/gemma-4-developer-agent/discussion/757893)

2.  pyproject.toml - encode/httpx - GitHub, [<u>https://github.com/encode/httpx/blob/master/pyproject.toml</u>](https://github.com/encode/httpx/blob/master/pyproject.toml)

3.  fastapi/pyproject.toml at master - GitHub, [<u>https://github.com/fastapi/fastapi/blob/master/pyproject.toml</u>](https://github.com/fastapi/fastapi/blob/master/pyproject.toml)

4.  TestTimeout abandons three delay/10 requests and later tests wait, [<u>https://github.com/psf/requests/issues/7631</u>](https://github.com/psf/requests/issues/7631)

5.  \[BUG\] \`rich\` reverts to legacy Windows APIs when stdout is redirected, [<u>https://github.com/Textualize/rich/issues/3437</u>](https://github.com/Textualize/rich/issues/3437)

6.  Regenerating tests/certs/ with OpenSSL \>= 3.2.0 causes test failures, [<u>https://github.com/psf/requests/issues/6896</u>](https://github.com/psf/requests/issues/6896)

7.  Add additional Color Environment Variables+Values \#7352 - GitHub, [<u>https://github.com/astral-sh/uv/issues/7352</u>](https://github.com/astral-sh/uv/issues/7352)

8.  All workflows - GitHub, [<u>https://github.com/encode/httpx/actions</u>](https://github.com/encode/httpx/actions)

9.  Tests hang in Python 3.14.0rc1 \#3616 - encode httpx - GitHub, [<u>https://github.com/encode/httpx/discussions/3616</u>](https://github.com/encode/httpx/discussions/3616)

10. TestMiner: Software Testing Analysis for GitHub Repositories - arXiv, [<u>https://arxiv.org/html/2607.12223v1</u>](https://arxiv.org/html/2607.12223v1)

11. Testing – FastAPI wiki \| Factory, [<u>https://factory.com/open-source-wikis/fastapi?page=how-to-contribute%2Ftesting.md</u>](https://factory.com/open-source-wikis/fastapi?page=how-to-contribute/testing.md)

12. Lib/site-packages/anyio/pytest_plugin.py · main, [<u>https://forge.apps.education.fr/edupyter/edupyter312/-/blob/main/Lib/site-packages/anyio/pytest_plugin.py</u>](https://forge.apps.education.fr/edupyter/edupyter312/-/blob/main/Lib/site-packages/anyio/pytest_plugin.py)

13. anyio/pytest_plugin.py · salmankhanpm/build-tools at, [<u>https://huggingface.co/salmankhanpm/build-tools/blob/00f404fe2dd994181c18c2161e796a2e95e59d6a/anyio/pytest_plugin.py</u>](https://huggingface.co/salmankhanpm/build-tools/blob/00f404fe2dd994181c18c2161e796a2e95e59d6a/anyio/pytest_plugin.py)

14. backend/venv/lib/python3.12/site-packages/anyio/pytest_plugin.py, [<u>https://gitlab.inf.uva.es/fraalva/containerlab-orchestrator/-/blob/main/backend/venv/lib/python3.12/site-packages/anyio/pytest_plugin.py?ref_type=heads</u>](https://gitlab.inf.uva.es/fraalva/containerlab-orchestrator/-/blob/main/backend/venv/lib/python3.12/site-packages/anyio/pytest_plugin.py?ref_type=heads)

15. Sync methods do not trigger async fixtures even if pytest.mark.anyio, [<u>https://github.com/agronholm/anyio/issues/803</u>](https://github.com/agronholm/anyio/issues/803)

16. pytest plugin doesn't interoperate with trio · Issue \#33 · agronholm, [<u>https://github.com/agronholm/anyio/issues/33</u>](https://github.com/agronholm/anyio/issues/33)

17. testing: "There is no current event loop in thread 'MainThread'." \#4459, [<u>https://github.com/fastapi/fastapi/issues/4459</u>](https://github.com/fastapi/fastapi/issues/4459)

18. async test is RuntimeError: no running event loop in router with await, [<u>https://github.com/fastapi/fastapi/issues/4473</u>](https://github.com/fastapi/fastapi/issues/4473)

19. Async testing documentation is missing details on selecting anyio, [<u>https://github.com/fastapi/fastapi/discussions/11280</u>](https://github.com/fastapi/fastapi/discussions/11280)

20. Release Notes - FastAPI - Tiangolo.com, [<u>https://fastapi.tiangolo.com/release-notes/</u>](https://fastapi.tiangolo.com/release-notes/)

21. hackerspace-bremen-public/spacemanager \| hack \| modify, [<u>https://git.hackerspace-bremen.de/hackerspace-bremen-public/spacemanager/commits/commit/f297a9cd13efe4d44ffa117e873ba97ab6a58655/backend/pyproject.toml</u>](https://git.hackerspace-bremen.de/hackerspace-bremen-public/spacemanager/commits/commit/f297a9cd13efe4d44ffa117e873ba97ab6a58655/backend/pyproject.toml)

22. tests/test_security_http_digest_description.py at e89a37e - Sailfork, [<u>https://sailfork.com/ycdemo/fastapi/blob/e89a37e50d27f124b77e947b7965b6df75052a35/tests/test_security_http_digest_description.py</u>](https://sailfork.com/ycdemo/fastapi/blob/e89a37e50d27f124b77e947b7965b6df75052a35/tests/test_security_http_digest_description.py)

23. fastapi/tests/test_tutorial/test_path_operation_configurations, [<u>https://github.com/tiangolo/fastapi/blob/master/tests/test_tutorial/test_path_operation_configurations/test_tutorial002.py</u>](https://github.com/tiangolo/fastapi/blob/master/tests/test_tutorial/test_path_operation_configurations/test_tutorial002.py)

24. paths - fess/code, [<u>https://codesearch.codelibs.org/search?q=paths&num=10&sdh=&ex_q=timestamp%3A%5Bnow%2Fd-6M+TO+\*%5D&start=150</u>](https://codesearch.codelibs.org/search?q=paths&num=10&sdh&ex_q=timestamp:%5Bnow/d-6M+TO+*%5D&start=150)

25. Coverage for tests/test_tutorial/test_handling_errors/test_tutorial006, [<u>https://smokeshow.helpmanual.io/596g3w3g380f201c2b3a/z_fe08789717296f82_test_tutorial006_py.html</u>](https://smokeshow.helpmanual.io/596g3w3g380f201c2b3a/z_fe08789717296f82_test_tutorial006_py.html)

26. Coverage for tests/test_tutorial/test_handling_errors/test_tutorial005, [<u>https://smokeshow.helpmanual.io/596g3w3g380f201c2b3a/z_fe08789717296f82_test_tutorial005_py.html</u>](https://smokeshow.helpmanual.io/596g3w3g380f201c2b3a/z_fe08789717296f82_test_tutorial005_py.html)

27. tests/test_tutorial/test_dataclasses/test_tutorial002.py at 2e35b17, [<u>https://sailfork.com/ycdemo/fastapi/blob/2e35b176cf5ff73e4cb035322f0af8157d654f7d/tests/test_tutorial/test_dataclasses/test_tutorial002.py</u>](https://sailfork.com/ycdemo/fastapi/blob/2e35b176cf5ff73e4cb035322f0af8157d654f7d/tests/test_tutorial/test_dataclasses/test_tutorial002.py)

28. \_get_flat_body_params doesn't deduplicate shared cached ... - GitHub, [<u>https://github.com/fastapi/fastapi/discussions/16215</u>](https://github.com/fastapi/fastapi/discussions/16215)

29. fastapi/docs/en/docs/advanced/async-tests.md at master - GitHub, [<u>https://github.com/fastapi/fastapi/blob/master/docs/en/docs/advanced/async-tests.md</u>](https://github.com/fastapi/fastapi/blob/master/docs/en/docs/advanced/async-tests.md)

30. Unit Testing: mocking request.state \#13449 - fastapi - GitHub, [<u>https://github.com/fastapi/fastapi/discussions/13449</u>](https://github.com/fastapi/fastapi/discussions/13449)

31. FastAPI 异步测试实战：用AnyIO 与HTTPX AsyncClient 编写async, [<u>https://blog.csdn.net/gitblog_00289/article/details/155009528</u>](https://blog.csdn.net/gitblog_00289/article/details/155009528)

32. FastAPI 集成SQL 数据库实战：基于SQLModel 的单模型与多模型, [<u>https://blog.csdn.net/gitblog_00525/article/details/150956430</u>](https://blog.csdn.net/gitblog_00525/article/details/150956430)

33. Use of \`passlib\` module · fastapi fastapi · Discussion \#11523 · GitHub, [<u>https://github.com/tiangolo/fastapi/discussions/11523?sort=top</u>](https://github.com/tiangolo/fastapi/discussions/11523?sort=top)

34. FastAPI 0.69 app with SQLAlchemy hangs in pytest when HTTPError, [<u>https://github.com/fastapi/fastapi/issues/4249</u>](https://github.com/fastapi/fastapi/issues/4249)

35. getting (set_wakeup_fd only works in main thread) when i my unit, [<u>https://github.com/fastapi/fastapi/issues/5421</u>](https://github.com/fastapi/fastapi/issues/5421)

36. psf/requests at mostlypython.com - GitHub, [<u>https://github.com/psf/requests?ref=mostlypython.com</u>](https://github.com/psf/requests?ref=mostlypython.com)

37. pyproject.toml - psf/requests - GitHub, [<u>https://github.com/psf/requests/blob/main/pyproject.toml</u>](https://github.com/psf/requests/blob/main/pyproject.toml)

38. recursive dependency involving fixture 'httpbin' detected when, [<u>https://github.com/psf/requests/issues/7016</u>](https://github.com/psf/requests/issues/7016)

39. psf/requests — Source walkthrough guide \| EVEMISS Technology, [<u>https://evemisstechnology.com/ai-frontier/repository/psf/requests/source-walkthrough</u>](https://evemisstechnology.com/ai-frontier/repository/psf/requests/source-walkthrough)

40. psf/requests — 原始碼導讀指南 - evemiss, [<u>https://evemisstechnology.com/zh-TW/ai-frontier/repository/psf/requests/source-walkthrough/</u>](https://evemisstechnology.com/zh-TW/ai-frontier/repository/psf/requests/source-walkthrough/)

41. recursive dependency involving fixture 'httpbin' detected · Issue \#6110, [<u>https://github.com/pytest-dev/pytest/issues/6110</u>](https://github.com/pytest-dev/pytest/issues/6110)

42. OpenSSL 4 removed built-in logic for SKID and AKID \#7617 - GitHub, [<u>https://github.com/psf/requests/issues/7617</u>](https://github.com/psf/requests/issues/7617)

43. ossguard/README.md at main - kirankotari - GitHub, [<u>https://github.com/kirankotari/ossguard/blob/main/README.md</u>](https://github.com/kirankotari/ossguard/blob/main/README.md)

44. requests/tests/test_requests.py at main · psf/requests - GitHub, [<u>https://github.com/psf/requests/blob/main/tests/test_requests.py</u>](https://github.com/psf/requests/blob/main/tests/test_requests.py)

45. SyncMind: Measuring Agent Out-of-Sync Recovery in Collaborative, [<u>https://arxiv.org/html/2502.06994v2</u>](https://arxiv.org/html/2502.06994v2)

46. 2.31.0: pytest fails in \`tests/test_requests.py::TestRequests ... - GitHub, [<u>https://github.com/psf/requests/issues/6639</u>](https://github.com/psf/requests/issues/6639)

47. GitHub - kevin1024/pytest-httpbin: Easily test your HTTP library, [<u>https://github.com/kevin1024/pytest-httpbin</u>](https://github.com/kevin1024/pytest-httpbin)

48. Test test_https_warnings is not functional with pytest-httpbin 1.0, [<u>https://github.com/psf/requests/issues/5530</u>](https://github.com/psf/requests/issues/5530)

49. TestRequests.test_pyopenssl_redirect is broken in CI \#5846 - GitHub, [<u>https://github.com/psf/requests/issues/5846</u>](https://github.com/psf/requests/issues/5846)

50. tests/test_requests.py - external/github.com/kennethreitz/requests, [<u>https://chromium.googlesource.com/external/github.com/kennethreitz/requests/+/master/tests/test_requests.py</u>](https://chromium.googlesource.com/external/github.com/kennethreitz/requests/+/master/tests/test_requests.py)

51. \[Dataset/Verified\] Network flakiness (httpbin.org) and polluted, [<u>https://github.com/SWE-bench/SWE-bench/issues/700</u>](https://github.com/SWE-bench/SWE-bench/issues/700)

52. Failing benchmark instances · Issue \#167 · SWE-bench ... - GitHub, [<u>https://github.com/swe-bench/SWE-bench/issues/167</u>](https://github.com/swe-bench/SWE-bench/issues/167)

53. dougalldeepmind/2026-09-24-swebench-qwen36-0-da-15, [<u>https://huggingface.co/datasets/dougalldeepmind/2026-09-24-swebench-qwen36-0-da-15</u>](https://huggingface.co/datasets/dougalldeepmind/2026-09-24-swebench-qwen36-0-da-15)

54. Fix a Failing CI Build in a Python Project \| Rush, [<u>https://getrush.ai/run/fix-failing-ci/python/</u>](https://getrush.ai/run/fix-failing-ci/python/)

55. rich/pyproject.toml at main · Textualize/rich - GitHub, [<u>https://github.com/Textualize/rich/blob/main/pyproject.toml</u>](https://github.com/Textualize/rich/blob/main/pyproject.toml)

56. rich/tests/test_console.py at main · Textualize/rich - GitHub, [<u>https://github.com/Textualize/rich/blob/master/tests/test_console.py</u>](https://github.com/Textualize/rich/blob/master/tests/test_console.py)

57. \[BUG\] Failure to propagate formatting overrides via ConsoleOptions, [<u>https://github.com/Textualize/rich/issues/4028</u>](https://github.com/Textualize/rich/issues/4028)

58. \[BUG\] UnicodeEncodeError on Windows with ruler. \#2411 - GitHub, [<u>https://github.com/Textualize/rich/issues/2411</u>](https://github.com/Textualize/rich/issues/2411)

59. Contributing to open source: rich 2073 - mathspp, [<u>https://mathspp.com/blog/contributing-to-open-source-rich-2073</u>](https://mathspp.com/blog/contributing-to-open-source-rich-2073)

60. Unable to see logs when running pytest \#2256 - GitHub, [<u>https://github.com/Textualize/rich/discussions/2256</u>](https://github.com/Textualize/rich/discussions/2256)

61. \[BUG\] live displays and console printing are not thread safe \#1530, [<u>https://github.com/Textualize/rich/issues/1530</u>](https://github.com/Textualize/rich/issues/1530)

62. \[Bug\] Python AST & Linker — Module-level functional type factories, [<u>https://github.com/FinanceFlash/unvibecode/issues/739</u>](https://github.com/FinanceFlash/unvibecode/issues/739)

63. microsoft/FEA-Bench · Datasets at Hugging Face, [<u>https://huggingface.co/datasets/microsoft/FEA-Bench</u>](https://huggingface.co/datasets/microsoft/FEA-Bench)

64. Luo2003/fea-bench · Datasets at Hugging Face, [<u>https://huggingface.co/datasets/Luo2003/fea-bench</u>](https://huggingface.co/datasets/Luo2003/fea-bench)

65. Build log - OSS-Fuzz Status, [<u>https://oss-fuzz-build-logs.storage.googleapis.com/log-80de67e2-1e32-4d55-8142-0319d3b0182d.txt</u>](https://oss-fuzz-build-logs.storage.googleapis.com/log-80de67e2-1e32-4d55-8142-0319d3b0182d.txt)

66. 0.22.0: pytest is failing · encode httpx · Discussion \#2121 - GitHub, [<u>https://github.com/encode/httpx/discussions/2121</u>](https://github.com/encode/httpx/discussions/2121)

67. Support rpm build/test style. · encode httpx · Discussion \#2270 · GitHub, [<u>https://github.com/encode/httpx/discussions/2270</u>](https://github.com/encode/httpx/discussions/2270)

68. [<u>https://ns4.zugaina.org/AJAX/Ebuild/56246722/View</u>](https://ns4.zugaina.org/AJAX/Ebuild/56246722/View)

69. 0.22.0: pytest warnings · encode httpx · Discussion \#2208 - GitHub, [<u>https://github.com/encode/httpx/discussions/2208</u>](https://github.com/encode/httpx/discussions/2208)

70. httpx.Response.iter_text has empty string for iterator's last item \#2995, [<u>https://github.com/encode/httpx/discussions/2995</u>](https://github.com/encode/httpx/discussions/2995)

71. Turn GitHub Issues into Pull Requests for a Python Project - Rush, [<u>https://getrush.ai/run/github-issue-to-pr/python/</u>](https://getrush.ai/run/github-issue-to-pr/python/)

72. httpx/tests/client/test_async_client.py at master - GitHub, [<u>https://github.com/encode/httpx/blob/master/tests/client/test_async_client.py</u>](https://github.com/encode/httpx/blob/master/tests/client/test_async_client.py)

73. test_write_timeout(trio) is failing on python3.14 · Issue \#3686 - GitHub, [<u>https://github.com/encode/httpx/issues/3686</u>](https://github.com/encode/httpx/issues/3686)

74. anyio/docs/versionhistory.rst at master - agronholm - GitHub, [<u>https://github.com/agronholm/anyio/blob/master/docs/versionhistory.rst</u>](https://github.com/agronholm/anyio/blob/master/docs/versionhistory.rst)

75. Test failures in presence of httptools · encode httpx · Discussion \#3429, [<u>https://github.com/encode/httpx/discussions/3429</u>](https://github.com/encode/httpx/discussions/3429)

76. \`tests/test_config.py::test_load_ssl_with_keylog\` failure with PyPy3.10, [<u>https://github.com/encode/httpx/discussions/3430</u>](https://github.com/encode/httpx/discussions/3430)

77. api/pyproject.toml at master · vulnersCom/api - GitHub, [<u>https://github.com/vulnersCom/api/blob/master/pyproject.toml</u>](https://github.com/vulnersCom/api/blob/master/pyproject.toml)

78. Testing overview \| simple_module_python, [<u>https://docs.py.simplemodule.dev/testing/overview</u>](https://docs.py.simplemodule.dev/testing/overview)

79. pyproject.toml - aio-libs/aioftp · GitHub, [<u>https://github.com/aio-libs/aioftp/blob/master/pyproject.toml</u>](https://github.com/aio-libs/aioftp/blob/master/pyproject.toml)

80. contextvars setup when mixing sync and async pytest fixtures in, [<u>https://github.com/agronholm/anyio/issues/614</u>](https://github.com/agronholm/anyio/issues/614)

81. Trio backend hangs instead of failing when dynamically accessing, [<u>https://github.com/agronholm/anyio/issues/1148</u>](https://github.com/agronholm/anyio/issues/1148)

82. pytest plugin: a test raising OutcomeException (skip/xfail/failed, [<u>https://github.com/agronholm/anyio/issues/1179</u>](https://github.com/agronholm/anyio/issues/1179)

83. junitxml output capture while going to console \#4593 - pytest - GitHub, [<u>https://github.com/pytest-dev/pytest/issues/4593</u>](https://github.com/pytest-dev/pytest/issues/4593)

84. Pytest: Print to console and capture output in the junit report?, [<u>https://stackoverflow.com/questions/37073957/pytest-print-to-console-and-capture-output-in-the-junit-report</u>](https://stackoverflow.com/questions/37073957/pytest-print-to-console-and-capture-output-in-the-junit-report)

85. How to capture stdout/stderr output - pytest documentation, [<u>https://docs.pytest.org/en/stable/how-to/capture-stdout-stderr.html</u>](https://docs.pytest.org/en/stable/how-to/capture-stdout-stderr.html)

86. logging output in junitxml · Issue \#6139 · pytest-dev/pytest - GitHub, [<u>https://github.com/pytest-dev/pytest/issues/6139</u>](https://github.com/pytest-dev/pytest/issues/6139)
