# Version-Locked Compatibility and Tuning Brief: vLLM + Compressed-Tensors W4A16 + LoRA on 4x NVIDIA L4

As of **November 23, 2026**, your target stack—Gemma 4-class compressed-tensors QAT W4A16 (group_size=32) checkpoints with PEFT LoRA adapters on Kaggle 4x NVIDIA L4 (sm_89, 96 GB total, tensor_parallel_size=4)—is viable for **text-only serving without speculative decoding**, provided you pin **vLLM 0.32.0 (Oct 18, 2026)** on pre-R580 CUDA 12.9 hosts or **vLLM 0.34.0 (Nov 16, 2026)** on R580+ CUDA 13.0 hosts, upgrade **PEFT to 0.22.0 (Nov 13, 2026)** while keeping torchao uninstalled, and cap LoRA rank to **r \<= 16** until upstream compressed-tensors correctness issues are verified resolved<sup>1</sup>. Three critical constraints govern deployment today: (1) **vLLM \#62340** (Open) makes Gemma 4 MTP speculative decoding and --enable-lora mutually exclusive due to a startup pre_projection shape-mismatch crash<sup>7</sup>; (2) **vLLM \#50059** (Open) demonstrates that r \>= 32 all-layer LoRA adapters over compressed-tensors INT4 W4A16 (group_size=32) produce weak, non-reproducible outputs on 0.17.1–0.24.0, whereas slicing to r \<= 16 restores determinism<sup>1</sup>; and (3) per an October 24, 2026 advisory audit (https://eurokommerz.at/blog/vllm-security-advisories-which-version/), **vLLM 0.33.0 (Nov 2, 2026)** dropped CUDA 12.9 builds entirely in favor of CUDA 13.0 requiring an NVIDIA **R580+ driver**, making 0.32.0 your hard ceiling if Kaggle's host driver is older<sup>4</sup>.

For the 31B QAT W4A16 checkpoint (google/gemma-4-31B-it-qat-w4a16-ct, 19.8 GB total<sup>8</sup>) at max_model_len=32768 across 4 concurrent multi-turn agent sessions, first-principles VRAM modeling (no public empirical 4x L4 31B telemetry was found: **NOT FOUND**) projects **~8.0–10.6 GiB/GPU of KV/prefix-cache headroom** inside a 21.6 GiB cap (gpu_memory_utilization=0.90 on 24 GiB L4 cards)—*only* because vLLM V1's hybrid KV-cache manager caps the 50 sliding-window layers (sliding_window=1024) to ~2k tokens while allocating 32k solely on the 10 global layers (4.06 GiB/GPU in BF16 vs. 27.50 GiB/GPU if uncapped)<sup>9</sup>. Because BF16 KV cache fits easily for 4 concurrent sessions, default to --kv-cache-dtype auto (BF16) rather than --kv-cache-dtype fp8 to avoid head_dim=256/512 prefill latency regressions and uncalibrated reasoning drift observed in vLLM's Hopper/Blackwell study<sup>10</sup>. Pair this with --limit-mm-per-prompt '{"image": 0, "audio": 0}' to eliminate multimodal warmup and ~1.03 GiB/GPU of potential vision encoder overhead<sup>10</sup>, and lock --default-chat-template-kwargs '{"enable_thinking": true}' server-side so LiteLLM's drop_params=True cannot silently disable thinking mode and trigger the reasoning-parser structured-output bypass<sup>12</sup>.

## Deliverable A: Version-Pinned Compatibility Matrix

The matrix below maps vLLM, PEFT, and quantization behavior across exact release dates as of November 23, 2026. Claims apply strictly to the versions indicated; unverified interactions are marked explicitly.

|  |  |  |  |  |  |
|----|----|----|----|----|----|
| **Component / Feature** | **vLLM 0.17.1–0.24.0 (Spring–Mid 2026)** | **vLLM 0.26.0–0.30.0 (Summer–Sep 22, 2026)** | **vLLM 0.31.0 (Oct 5, 2026) & 0.32.0 (Oct 18, 2026)** | **vLLM 0.33.0 (Nov 2, 2026) & 0.34.0 (Nov 16, 2026)** | **Evidence & Issue Tracking** |
| **CUDA Build / Driver Req.** | CUDA 12.x builds<sup>12</sup> | CUDA 12.9 / 13.0 (v0.29.0-cu129 verified)<sup>14</sup> | **Last CUDA 12.9 builds (0.32.0)**; works on pre-R580 hosts<sup>4</sup> | **CUDA 13.0 builds only**; requires NVIDIA **R580+ driver**<sup>4</sup> | Advisory audit & PyPI/deps.dev<sup>4</sup> |
| **Gemma 4 Native + Parsers** | Early gemma4-cu130 / 0505 previews (Apr 2, 2026); tool-parser init bug fixed Apr 2<sup>12</sup> | Supported (gemma4 tool & reasoning parsers, Gemma4ForConditionalGeneration)<sup>12</sup> | Stable; gemma4, gemma4_mtp, gemma4_mm, gemma4_unified in CLI (v0.31.0 docs)<sup>17</sup> | Stable; L4 Gemma 4 E2B QAT W4A16 + drafter served unpatched on 0.33.0<sup>18</sup> | Recipe, forums & docs<sup>12</sup> |
| **Compressed-Tensors W4A16 (INT4 pack-quantized) + LoRA (r \<= 16)** | Deterministic & accurate (r=8 / r=16 verified on 0.17.1, 0.24.0)<sup>1</sup> | Loads via Marlin W4A16 (16-bit acts) + unfused Punica LoRA<sup>19</sup> | Supported for dense models; crashes if fused module has mixed ignore shards (#62308)<sup>21</sup> | Supported for dense models; VLLM_MARLIN_INPUT_DTYPE removed (always 16-bit acts)<sup>20</sup> | \#9120, \#50059, \#62308<sup>1</sup> |
| **Compressed-Tensors W4A16 (g32) + LoRA (r \>= 32)** | **BROKEN on tested OLMo-32B**: weak, non-reproducible at temp=0 (0.17.1, 0.24.0)<sup>1</sup> | **UNVERIFIED / HIGH RISK**: \#50059 Open & unassigned<sup>1</sup> | **UNVERIFIED / HIGH RISK**: \#50059 Open (unstale Nov 2026)<sup>1</sup> | **UNVERIFIED / HIGH RISK**: fix status **NOT FOUND** for NVIDIA Marlin path<sup>1</sup> | Open Issue \#50059<sup>1</sup> |
| **Compressed-Tensors FP8 (W8A8) + LoRA** | Supported on sm_89+ (L4/Ada)<sup>23</sup>; MoE FP8 LoRA Triton-only (#29424)<sup>24</sup> | Supported on sm_89+<sup>23</sup> | Supported on sm_89+<sup>23</sup> | Supported on sm_89+ (FP8 linear kernel / W8A16 Marlin fallback)<sup>23</sup> | Docs & \#29424<sup>23</sup> |
| **Gemma 4 MTP + LoRA (--enable-lora)** | Older versions misclassify MTP as draft_model and fail init<sup>26</sup> | **CRASHES AT STARTUP**: pre_projection shape mismatch (v0.26.0, \#62340)<sup>7</sup> | **UNVERIFIED / ASSUME BROKEN**: \#62340 Open; drafters never run LoRA<sup>7</sup> | **UNVERIFIED / ASSUME BROKEN**: \#62340 Open; MTP+LoRA corruption in \#50602/#53488<sup>7</sup> | \#62340, \#53488, \#50602<sup>7</sup> |
| **PEFT rank_pattern / alpha_pattern** | Silently dropped; global lora_alpha / r applied<sup>30</sup> | Silently dropped through v0.30.0 (#59799)<sup>30</sup> | Supported post-#59801 in latest PEFTHelper.get_rank_and_scaling()<sup>30</sup> | Supported in latest PEFTHelper (vllm/lora/peft_helper.py)<sup>31</sup> | \#59799, PR \#59801, docs<sup>30</sup> |
| **Prefix Caching + Hybrid Sliding Window** | Supported in V1 (V0 raised NotImplementedError, \#3881)<sup>32</sup> | Supported in V1; avoid reusing lora_name (#30931)<sup>34</sup> | Supported (prefix_cache_retention_interval); V1 hybrid manager<sup>35</sup> | Supported (prefix_cache_retention_interval); V1/V2 runners<sup>33</sup> | \#3881, \#30931, CacheConfig<sup>32</sup> |
| **Security Posture (CVEs)** | Affected by 17+ High/Moderate 2026 advisories<sup>4</sup> | Affected by GHSA-h3rc-6mm3-gc2m (--trust-remote-code RCE)<sup>4</sup> | 0.31.0 closes RCE; 0.32.0 closes Pillow/audio/SHM CVEs; 0.32.0 affected by Nov 18 CVEs (130685/130686)<sup>4</sup> | 0.33.0 & 0.34.0 not affected by tracked High CVEs as of Nov 22, 2026<sup>36</sup> | Advisory & CVE trackers<sup>4</sup> |

### Compressed-Tensors + LoRA Mechanics and Open Issues (Question 1)

vLLM's official LoRA-plus-quantization documentation (https://docs.vllm.ai/en/stable/features/quantization/, https://docs.vllm.ai/en/latest/features/lora/) historically highlighted only QLoRA (bitsandbytes), GPTQ, and AWQ<sup>1</sup>, leaving compressed-tensors + LoRA under-documented even though compressed-tensors LoRA loading was patched in **vLLM \#9120** (https://github.com/vllm-project/vllm/issues/9120)<sup>22</sup>. On NVIDIA Ada (sm_89), compressed-tensors INT4 W4A16 checkpoints (format: "pack-quantized", scheme CompressedTensorsWNA16) run through **Marlin W4A16 kernels**, which now strictly operate on 16-bit activations—VLLM_MARLIN_INPUT_DTYPE has been removed and setting it raises an error<sup>20</sup>. Because the fused W4A16+LoRA kernel interface proposed in **vLLM \#67330** (https://github.com/vllm-project/vllm/issues/67330, rdna_hybrid_w4a16_lora_apply) is scoped strictly to AMD gfx1151 at TP=1<sup>19</sup>, NVIDIA L4 always executes the unfused 3-step path: LoRA shrink, base Marlin W4A16 GEMM, and LoRA expand via punica_gpu.py<sup>19</sup>. For other quant formats on sm_89, compressed-tensors **FP8 W8A8** is natively hardware-accelerated on Ada Lovelace (compute capability \>= 8.9)<sup>23</sup>, and MoE LoRA tracking in **vLLM \#29424** (https://github.com/vllm-project/vllm/issues/29424, Nov 25, 2025) confirms compressed_tensors W4A16, FP8 (Triton-only, not CUTLASS), GPTQ, and AWQ support while marking bitsandbytes and GGUF unsupported for MoE LoRA<sup>24</sup>. Conversely, mxfp4-pack-quantized (which hits Marlin MoE dimension-alignment crashes in **\#38022**, https://github.com/vllm-project/vllm/issues/38022, Mar 24, 2026<sup>41</sup>) and nvfp4 lack native Ada acceleration.

The highest-risk open bug for your exact W4A16 format is **vllm-project/vllm#50059** (https://github.com/vllm-project/vllm/issues/50059, labeled quantization Jul 27, 2026; active/unstale Nov 2026)<sup>1</sup>. Testing LoRA over a compressed-tensors INT4 W4A16 **group_size=32** checkpoint (OLMo-3.1-32B-Instruct, matching the exact group_size=32 INT4 W4A16 format used by Google's official gemma-4-31B-it-qat-w4a16-ct and gemma-4-E4B-it-qat-w4a16-ct<sup>8</sup>) on vLLM 0.17.1 and 0.24.0 (RTX 5090), the reporter found that rank-32 all-layer adapters (q/k/v/o/gate/up/down) yielded substantially weaker outputs than the BF16 reference and were **non-reproducible at temperature=0** across server restarts and busy sessions<sup>1</sup>. Crucially, slicing the exact same adapter to **rank 16** restored determinism, and a rank-8 partial-layer adapter matched reference strength with zero variance, whereas raising --max-lora-rank did nothing<sup>1</sup>. Although \#50059 was not tested on 0.25+ (due to an unrelated KeyError: 'rope_theta' in newer transformers) or directly on Gemma 4, the issue remains **Open and unassigned** with no confirmed fix in 0.32.0–0.34.0 (**NOT FOUND**). Treat r \> 16 on compressed-tensors W4A16 g32 as unverified and high-risk until you run a local temperature=0 parity test against your dequantized BF16 reference across two separate server restarts.

Two additional loading boundaries apply to compressed-tensors checkpoints. First, **vllm-project/vllm#62308** (https://github.com/vllm-project/vllm/issues/62308, Oct 18, 2026; affects v0.32.0 and main @ 371745e) documents a construction-time crash (ValueError: Found different quantization schemes for the shards of ... in compressed_tensors/utils.py:66) whenever a pack-quantized checkpoint places one sub-projection of a fused layer (such as qkv_proj) in its ignore list while quantizing sibling shards; --enable-lora does not bypass this because configure_quant_config binds the class-level packed_modules_mapping before LoRA rebinds the instance mapping<sup>21</sup>. Second, for your edge model with Per-Layer Embeddings (PLE), a TPU community deep dive (https://dev.to/gde/gemma-4-e2b-on-a-single-tpu-v6e-chip-a-serving-deep-dive-53n, vLLM 0.23.1rc1 tpu-inference) found int4 compressed-tensors unimplemented for per_layer_model_projection on TPU<sup>13</sup>, whereas on **NVIDIA L4 CUDA with vLLM 0.33.0**, a community AWS Lambda benchmark (https://xbill999.medium.com/gemma-4-on-aws-lambda-with-a-gpu-e2b-on-an-nvidia-l4-day-one-d5e5808dd2d2) loaded and served Gemma 4 E2B QAT W4A16 (compressed-tensors) without patches<sup>18</sup>, and Google publishes official google/gemma-4-E4B-it-qat-w4a16-ct (9.8 GB) and google/gemma-4-31B-it-qat-w4a16-ct (19.8 GB) checkpoints for native vLLM serving (https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1)<sup>8</sup>. Verify that vLLM resolves natively to Gemma4ForConditionalGeneration—vLLM's transformers fallback explicitly does not support quantization + LoRA together (**\#13179**, https://github.com/vllm-project/vllm/issues/13179, Feb 2025)<sup>16</sup>—and never include embed_tokens or lm_head in quantized LoRA adapters (ValueError: ... is unsupported LoRA weight, \#2816, \#9280)<sup>38</sup>.

## Deliverable B: Recommended Pinned Stack for Kaggle Notebooks

As of **November 23, 2026**, Kaggle's preinstalled NVIDIA host driver dictates your vLLM pin. Inspect nvidia-smi before installation: per the October 24, 2026 release audit (https://eurokommerz.at/blog/vllm-security-advisories-which-version/), **vLLM 0.33.0 (Nov 2, 2026) and 0.34.0 (Nov 16, 2026) ship CUDA 13.0 builds only and require an NVIDIA R580+ driver**, whereas **vLLM 0.32.0 (Oct 18, 2026) is the final release with CUDA 12.9 wheels**<sup>4</sup>.

|  |  |  |  |  |
|----|----|----|----|----|
| **Package** | **Pinned Version (Pre-R580 / CUDA 12.9)** | **Pinned Version (R580+ / CUDA 13.0)** | **Release Date & Source** | **Engineering Rationale** |
| **vllm** | vllm==0.32.0 | vllm==0.34.0 | 0.32.0: Oct 18, 2026; 0.34.0: Nov 16, 2026 (https://pypi.org/project/vllm/, https://deps.dev/pypi/vllm)<sup>4</sup> | 0.32.0 is the last CUDA 12.9 build and fixes GHSA-h3rc-6mm3-gc2m plus Pillow/audio/SHM CVEs (CVE-2026-115913, https://nvd.nist.gov/vuln/detail/CVE-2026-115913)<sup>4</sup>; 0.34.0 clears Nov 18 High CVEs CVE-2026-130685/130686 per https://versionping.app/products/vllm<sup>36</sup>. |
| **peft** | peft==0.22.0 | peft==0.22.0 | Nov 13, 2026 (https://pypi.org/project/peft/, https://github.com/huggingface/peft/issues/3964)<sup>2</sup> | Ships PR \#3989 (merged Oct 16, 2026, commit c2d5f69), resolving the \#3964 is_torchao_available() crash<sup>3</sup>. |
| **torchao** | **UNINSTALL** (pip uninstall -y torchao) | **UNINSTALL** (pip uninstall -y torchao) | Latest PyPI: 0.18.0 (https://pypi.org/project/torchao/; exact release date **NOT FOUND**)<sup>43</sup> | Offers zero benefit for plain BF16 dequantized LoRA training; uninstalling removes Kaggle's stale 0.10.0 cleanly<sup>6</sup>. |
| **compressed-tensors** | compressed-tensors==0.20.1 (or vLLM's resolved pin \>=0.19.0) | compressed-tensors==0.20.1 | 0.20.1: Nov 14, 2026; 0.19.0: Oct 13, 2026 (https://www.freshports.org/misc/py-compressed-tensors/)<sup>44</sup> | Latest stable format library (pytorch\>=2.10.0, transformers\>=4.45.0)<sup>44</sup>. |
| **transformers** | Match vLLM 0.32.0's tested 5.x pin (\>=5.5.0, e.g., 5.20.2–5.22.2) | Match vLLM 0.34.0's tested 5.x pin (5.20.2–5.22.2) | 5.5.0: Apr 2, 2026<sup>45</sup>; 5.20.2: Nov 1, 2026<sup>46</sup>; exact Nov 23 latest patch: **NOT FOUND** | Gemma 4 requires transformers 5.x<sup>8</sup>; keep llmcompressor (0.15.0, Oct 28, 2026<sup>47</sup>) in a separate environment per vLLM docs (https://docs.vllm.ai/en/stable/features/quantization/llm_compressor/fp8/)<sup>23</sup>. |

### Deep Dive on the torchao / PEFT Pin (Question 3)

Your prior crash—ImportError: Found an incompatible version of torchao. Found version 0.10.0, but only versions above 0.16.0 are supported—is documented in **huggingface/peft#3964** (https://github.com/huggingface/peft/issues/3964)<sup>6</sup>. After PEFT PR \#3101 raised TORCHAO_MINIMUM_VERSION to 0.16.0, every PEFT release from **0.19.0 through 0.21.2 (Oct 1, 2026)** raised an unhandled ImportError inside is_torchao_available() whenever torchao \< 0.16.0 (such as Kaggle/Colab's preinstalled 0.10.0) existed in the environment<sup>6</sup>. Because both dispatch_torchao (src/peft/tuners/lora/torchao.py) and resolve_quantization_backend (src/peft/utils/quantization_utils.py) invoked is_torchao_available() on every targeted layer *before* verifying whether the layer's weight was actually a torchao tensor, standard BF16 get_peft_model and load_lora_weights calls crashed even when torchao was completely unused<sup>6</sup>.

**PR \#3989** (merged **October 16, 2026**, commit c2d5f69, shipped in **peft==0.22.0** on November 13, 2026; corroborated in https://github.com/NVIDIA-NeMo/Automodel/issues/4844) changed is_torchao_available() to warn once and return False on torchao \< 0.16.0, letting plain BF16 layers fall through cleanly<sup>2</sup>. Although installing **torchao \>= 0.16.0** (up to current **torchao==0.18.0**<sup>43</sup>; note that despite the error text saying "above 0.16.0", the version gate checks \< 0.16.0<sup>6</sup>) also satisfies the check, **uninstalling torchao remains the right call for BF16 dequantized training**: dispatch_torchao activates only for torchao-quantized weights, so pinning torchao \>= 0.16.0 delivers no LoRA speedups or memory paths for standard BF16 training while introducing unnecessary PyTorch ABI coupling in Kaggle notebooks<sup>6</sup>. Pin **peft==0.22.0** and retain pip uninstall -y torchao in your notebook setup cell.

## Multi-GPU TP=4 + LoRA and Speculative Decoding Realities

### tensor_parallel_size=4 + LoRA on L4-Class GPUs (Question 2)

No public Kaggle 4x L4 TP=4 LoRA benchmark issue was found (**NOT FOUND**), but upstream multi-GPU TP=4 LoRA bugs and Ada sm_89 limits directly affect your serving shape.

First, on **rank splitting and adapter VRAM**, vLLM's default (fully_sharded_loras=False) shards only half of each LoRA projection across TP ranks, replicating lora_A on column-parallel layers and lora_B on row-parallel layers<sup>49</sup>. For an all-layer Gemma 4 31B adapter at r=128 (1.82 GiB total in BF16), default partial sharding consumes **~1.00 GiB/GPU per max_loras slot**, whereas --fully-sharded-loras drops per-slot VRAM to **~0.46 GiB/GPU**<sup>10</sup>. Because Kaggle's 4x L4 nodes communicate over PCIe without NVLink—and Ada sm_89 cannot use Hopper/Blackwell's enable_allreduce_rms_fusion (https://docs.vllm.ai/en/stable/api/vllm/config/vllm/)<sup>51</sup>—enabling --fully-sharded-loras adds collective communication overhead. Keep fully_sharded_loras=False at r \<= 16 (where an all-layer adapter costs only ~0.125 GiB/GPU per slot) and enable --fully-sharded-loras only if you must serve multiple r=64–128 slots concurrently.

Second, on **CUDA graph capture and startup hangs**, **vllm-project/vllm#60845** (https://github.com/vllm-project/vllm/issues/60845) reports a TP=4 + --enable-lora failure characterized by skewed terminal NCCL activity across ranks depending on CUDA graph compilation mode (full issue body and patched version range: **NOT FOUND**)<sup>52</sup>. Similarly, **vllm-project/vllm#67488** (https://github.com/vllm-project/vllm/issues/67488) tracks LoRA behavior across v0.29.0-cu129 and v0.32.0-cu129 under default FULL_AND_PIECEWISE CUDA graphs<sup>14</sup>. Because vllm/lora/punica_wrapper/punica_gpu.py specializes captured CUDA graphs on lora_config.max_loras<sup>53</sup>, inflated max_loras values also slow torch.compile warmup (in v0.8.3/0.8.4, **\#16961**, https://github.com/vllm-project/vllm/issues/16961, hung for \>30 minutes at max_loras=3<sup>40</sup>). Keep --max-loras equal to your actual concurrent adapter count (1 or 2), set --max-lora-rank to your true maximum rank (https://docs.vllm.ai/en/latest/features/lora/)<sup>39</sup>, and if TP=4 stalls at startup or first decode, fall back to piecewise graphs (--compilation-config '{"cudagraph_mode": "PIECEWISE"}') or isolate with --enforce-eager<sup>16</sup>.

Third, **sleep/wake and dynamic multi-LoRA scheduling** carry two severe hazards. **vllm-project/vllm#48310** (https://github.com/vllm-project/vllm/issues/48310) documents that Level-2 sleep with LoRA enabled leaves wrapped parameter names and stacked adapter state incompatible with weight reload, causing wake_up() to return undefined contents<sup>54</sup>; never invoke sleep(level=2) with --enable-lora (terminate and restart the vLLM server cleanly between training and serving). Meanwhile, **vllm-project/vllm#30931** (https://github.com/vllm-project/vllm/issues/30931, reproduced on v0.11.1, TP=4) showed that LoRARequest.\_\_eq\_\_/\_\_hash\_\_ and vllm/v1/core/kv_cache_utils.py:\_gen_lora_extra_hash_keys() keyed prefix-cache blocks on lora_name rather than lora_int_id, causing hot-reloaded adapters that reuse a name to silently read stale KV blocks<sup>34</sup>. Always embed a weight-content hash in lora_name when using VLLM_ALLOW_RUNTIME_LORA_UPDATING=True, and route all turns of a session to the same adapter because base-model and LoRA requests do not share prefix-cache entries (**\#23301**, https://github.com/vllm-project/vllm/issues/23301)<sup>34</sup>.

### Speculative Decoding with MTP Drafters + LoRA on L4 (Question 4)

Per vLLM's MTP documentation (https://docs.vllm.ai/en/latest/features/speculative_decoding/mtp/, updated **October 15, 2026**), Gemma 4 assistant checkpoints use vLLM's dedicated gemma4_mtp path (vllm.v1.worker.gpu.spec_decode.gemma4) rather than generic draft_model speculation<sup>26</sup>:

> Bash
>
> --speculative-config '{"method":"mtp","model":"\<gemma4-assistant-checkpoint\>","num_speculative_tokens":1}'

Older vLLM builds that log SpeculativeConfig(method='draft_model', ...) treat the assistant checkpoint as a generic draft model and can fail initialization on multimodal Gemma 4 targets<sup>26</sup>. Setting num_speculative_tokens \> 1 runs multiple sequential forward passes on the same MTP layer with a warning, so vLLM recommends starting at 1<sup>26</sup>. On bandwidth-bound L4 GPUs with Gemma 4's 262,144-token vocabulary, Model Runner V2 also supports adding "draft_lm_head_quantization": "fp8" inside --speculative-config (~1 byte/weight, ~0.6 GiB extra weight footprint; target verification remains unquantized and lossless)<sup>9</sup>. Official TP=4 validation for gemma4_mtp was **NOT FOUND**—all official documentation examples use --tensor-parallel-size 1<sup>26</sup>.

**Do not combine MTP with --enable-lora in your current stack.** In **vllm-project/vllm#62340** (https://github.com/vllm-project/vllm/issues/62340, Open; reproduced on v0.26.0 with RedHatAI/gemma-4-26B-A4B-it-FP8-Dynamic + google/gemma-4-26B-A4B-it-assistant), enabling LoRA alongside Gemma 4 MTP crashes startup during memory profiling inside gemma4_mtp.py:422 (pre_projection receives input dim 3840 = 2816 + 1024 instead of 5632 = 2 \* 2816)<sup>7</sup>. Because GPUModelRunner.load_model calls load_lora_model() *before* self.drafter.load_model(self.model), Gemma4Proposer.\_maybe_share_embeddings (vllm/v1/spec_decode/gemma4.py:171) silently fails to attach the target's backbone-dim embed_tokens to the drafter; the only workaround is disabling either LoRA or MTP<sup>7</sup>. Furthermore, vLLM's LoRA config (https://docs.vllm.ai/en/latest/api/vllm/config/lora/) explicitly notes that speculative drafters never run LoRA adapters<sup>27</sup>, and separate open issues report non-NaN garbage outputs (#53488, https://github.com/vllm-project/vllm/issues/53488) and nondeterminism across 15 kernel variants (#50602, https://github.com/vllm-project/vllm/issues/50602, opened Jul 31, 2026) when stacking MTP + LoRA (+ FP8 KV cache)<sup>28</sup>.

For **base edge-model serving without LoRA**, measured L4 hardware speedups for E4B or 31B were **NOT FOUND**, but a community engineering benchmark on a single **NVIDIA L4** (AWS g6.2xlarge, AWS vLLM 0.33.0 image, https://xbill999.medium.com/gemma-4-on-aws-lambda-with-a-gpu-e2b-on-an-nvidia-l4-day-one-d5e5808dd2d2) tested Gemma 4 E2B QAT W4A16 (compressed-tensors) with Google's drafter<sup>18</sup>. Single-reply latency improved **1.63x** (256 tokens in **1.14–1.20 s** vs. **1.92–2.02 s** without the drafter), while baseline throughput without the drafter peaked at **3,614.4 output tok/s** at 48 concurrent requests<sup>18</sup>. Crucially, the drafter became throughput-negative at **16+ concurrent requests**, falling to **0.63x** throughput at 48 concurrent requests<sup>18</sup>. At your 4-session concurrency, MTP is attractive on L4 strictly for non-LoRA base edge-model endpoints and must stay disabled whenever --enable-lora is active.

## VRAM Anatomy and Throughput Tuning on 4x L4

### Serving the 31B QAT W4A16 Checkpoint on 4x L4 (Question 6)

No published 4x L4 (TP=4) VRAM telemetry for Gemma 4 31B QAT W4A16 was found (**NOT FOUND**); the capacity budget below is derived via first-principles accounting directly from google/gemma-4-31B-it/config.json (https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json) and anchored to Google's published google/gemma-4-31B-it-qat-w4a16-ct checkpoint size of **19.8 GB** (group_size=32, ~66% reduction from 59.0 GB BF16, https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1)<sup>8</sup>. The 31B dense architecture consists of 60 text layers (hidden_size=5376, intermediate_size=21504, vocab_size=262144 with tie_word_embeddings=true) arranged as 10 blocks of **5 sliding_attention layers** (num_key_value_heads=16, head_dim=256, sliding_window=1024) plus **1 full_attention layer** (num_global_key_value_heads=4, global_head_dim=512, attention_k_eq_v=true), alongside a 27-layer gemma4_vision encoder (hidden_size=1152, ~0.55B params)<sup>9</sup>. At group_size=32 (0.5 + 2/32 = 0.5625 bytes/param for 4-bit weights plus 16-bit group scales), total static weights equal 15.34 GiB quantized text linears (29.29B params) + 2.62 GiB BF16 tied embeddings (1.41B params) + 1.03 GiB BF16 vision encoder = 18.99 GiB (~20.4 GB decimal)<sup>10</sup>.

<img src="f:\AI\Benchmark\research_briefs\media\vLLM Quantized LoRA Serving Brief/media/image1.png" style="width:6.45833in;height:7.25in" />

Four sharding and spike mechanisms explain why this checkpoint fits cleanly under proper flags yet OOMs abruptly if misconfigured. First, KV heads shard **evenly** on TP=4: num_global_key_value_heads=4 and num_key_value_heads=16 divide cleanly by 4, giving every L4 exactly 1 global KV head and 4 sliding KV heads with zero head-replication waste<sup>9</sup>. Second, while text linears and VocabParallelEmbedding (2.62 GiB BF16 → 0.66 GiB/GPU) shard symmetrically (4.49 GiB/GPU text-only), an unsharded or replicated gemma4_vision encoder adds 1.03 GiB/GPU (5.52 GiB/GPU total) plus multimodal dummy-profiling buffers; passing --limit-mm-per-prompt '{"image": 0, "audio": 0}' skips multimodal profiling cleanly for text-only agent traffic<sup>10</sup>. Third, hybrid V1 sliding-window capping is non-negotiable: capping the 50 sliding layers to ~2,048 tokens reduces 4×32k BF16 KV cache from **27.50 GiB/GPU** (immediate OOM) to **4.06 GiB/GPU** (2.50 full + 1.56 sliding; or 2.81 GiB/GPU when attention_k_eq_v=true avoids duplicating V on global layers)<sup>9</sup>. Fourth, transient activation and logits spikes scale linearly with prefill chunk size: unchunked 32,768-token prefill uses ~1.48 GiB/GPU for MLP+attention activations and spikes **8.00 GiB/GPU** if full-prompt FP32 logits are materialized (32768 × (262144 / 4) × 4 B under final_logit_softcapping=30.0), whereas chunking to 2,048–4,096 tokens holds activations to **0.09–0.19 GiB/GPU**<sup>9</sup>.

In practice, three OOM signatures require specific mitigations: (1) torch.OutOfMemoryError during startup profile_run or multimodal warmup is resolved by adding --limit-mm-per-prompt '{"image": 0, "audio": 0}', lowering --max-num-batched-tokens to 4096 (or 2048), and capping --max-num-seqs 8<sup>10</sup>; (2) sudden mid-run OOM on a 32k prompt is prevented by forbidding prompt_logprobs and echo=True on LiteLLM requests<sup>10</sup>; and (3) ValueError: No available memory for the cache blocks at startup indicates either an uncapped KV fallback or over-allocated LoRA slots (fix by confirming V1 hybrid KV caching is active, tightening --max-lora-rank to your true rank<sup>39</sup>, or enabling --kv-cache-dtype fp8 to halve KV footprint to 2.03 GiB/GPU<sup>10</sup>).

### Throughput Tuning for 4 Concurrent Multi-Turn Agent Sessions (Question 5)

Your serving shape—4 concurrent multi-turn sessions, long growing prompts up to 32k tokens, ~4k output tokens including thinking traces (a TPU Gemma 4 benchmark observed ~2.4x completion token expansion with thinking enabled<sup>13</sup>), and --reasoning-parser gemma4 plus --tool-call-parser gemma4—is prefix-cache heavy and decode-latency sensitive.

**KV-Cache Dtype on L4 (sm_89):** Although L4 supports native FP8 (compute capability \>= 8.9, https://docs.vllm.ai/en/stable/features/quantization/llm_compressor/fp8/)<sup>23</sup> and vLLM's Gemma 4 recipe (https://recipes.vllm.ai/Google/gemma-4-31B-it) notes --kv-cache-dtype fp8 saves ~50% KV memory<sup>12</sup>, **no independent Ada/L4 (sm_89) FP8 KV-cache accuracy or latency benchmark for Gemma 4 was found (NOT FOUND)**. The primary available measurement is vLLM's **April 22, 2026** FP8 KV-cache engineering blog (https://vllm-project.github.io/2026/04/22/fp8-kvcache.html) on Hopper (H100/H200) and Blackwell (B200)<sup>11</sup>: on gemma-4-E2B (head_dim=256, sliding window 512), FP8 KV cache lowered decode ITL slope to **68% of BF16** (3.60e-05 vs. 5.30e-05 ms/tok) and amortized overhead well enough on 512-token sliding windows that --kv-cache-dtype-skip-layers sliding_window was unnecessary, **but** suffered a **~1.6x quadratic TTFT prefill regression** (1.12e-06 vs. 6.93e-07 ms/tok²) from register pressure under two-level FP32 accumulation on head_dim=256<sup>11</sup>. Furthermore, Gemma 4's heterogeneous head dimensions (256/512) automatically force TRITON_ATTN<sup>16</sup>, and uncalibrated FP8 KV cache (scale=1.0) showed up to 1–2 points of accuracy degradation on decode-heavy reasoning benchmarks<sup>11</sup>. Because BF16 hybrid KV cache consumes only **4.06 GiB/GPU** for your 4×32k sessions<sup>10</sup>, **keep --kv-cache-dtype auto (BF16)** for optimal prefill speed and reasoning fidelity, reserving --kv-cache-dtype fp8 only if you scale concurrency past ~8–12 sessions.

**Prefix Caching, Chunked Prefill, Concurrency, and Parser Coupling:** Keep --enable-prefix-caching on (default in V1). While vLLM V0 raised NotImplementedError("Sliding window is not allowed with prefix caching enabled!") (**Discussion \#3881**, https://github.com/vllm-project/vllm/discussions/3881, Apr 5, 2024)<sup>32</sup>, V1 (0.31.0+) supports hybrid sliding-window prefix caching via CacheConfig.prefix_cache_retention_interval (https://docs.vllm.ai/en/stable/api/vllm/config/cache/)<sup>35</sup>. Guard against three known edge cases: never combine prefix caching with "logprobs": 1 (AssertionError in \#8268<sup>63</sup>); monitor hit rates via vllm:prefix_cache_hits / vllm:prefix_cache_queries because gpu_prefix_cache_hit_rate_perc is deprecated<sup>63</sup>; and maintain sticky per-session adapter routing with unique versioned lora_names (#23301, \#30931)<sup>34</sup>. Pair prefix caching with default V1 chunked prefill bounded at --max-num-batched-tokens 4096 (or 2048 for tighter decode ITL), --max-num-seqs 8, and --async-scheduling per the official Gemma 4 recipe<sup>12</sup>. Finally, watch for a critical parser interaction: a Gemma 4 serving deep dive (https://dev.to/gde/gemma-4-e2b-on-a-single-tpu-v6e-chip-a-serving-deep-dive-53n, filed upstream as tpu-inference#3225 and identified as a general vLLM config coupling) showed that with --reasoning-parser gemma4 configured, **vLLM defers structured-output grammar enforcement until the reasoning block ends—so requests with thinking disabled sail through unconstrained with HTTP 200**<sup>13</sup>. Because LiteLLM with drop_params=True can strip non-standard chat_template_kwargs, force --default-chat-template-kwargs '{"enable_thinking": true}' on the server<sup>12</sup>, retain client-side JSON/tool schema validation<sup>13</sup>, and monitor vllm/parser/gemma4 (https://docs.vllm.ai/en/latest/api/vllm/parser/gemma4/) for \<\|channel\> marker edge cases (vllm-project/vllm#48217)<sup>64</sup>.

## Packaging PEFT LoRA Adapters in a Zip for vLLM (Question 7)

vLLM parses adapter metadata exclusively through PEFTHelper.from_local_dir() and PEFTHelper.from_dict() in vllm/lora/peft_helper.py (https://docs.vllm.ai/en/latest/api/vllm/lora/peft_helper/)<sup>31</sup>. When unpacking a .zip archive in Kaggle, extract to a **flat root directory** containing adapter_config.json and adapter_model.safetensors directly (no nested subdirectory), because vLLM looks up os.path.join(lora_path, "adapter_config.json")<sup>65</sup>. Critically, PEFTHelper.from_dict() validates required fields and then **silently drops every JSON key not declared on the PEFTHelper dataclass** (filtered_dict = {k: v for k, v in config_dict.items() if k in class_fields}, tracked in **vllm-project/vllm#60223**, https://github.com/vllm-project/vllm/issues/60223)<sup>65</sup>. Loading without an exception therefore does not guarantee semantic fidelity<sup>30</sup>.

|  |  |  |  |
|----|----|----|----|
| **adapter_config.json Field** | **vLLM PEFTHelper Behavior (Version-Conditional)** | **Exact Failure / Drift Signature** | **Packaging Rule** |
| **r, lora_alpha, target_modules** | **Required** in all versions (0.16–0.34.0)<sup>30</sup>. r \<= 0 raises ValueError (div-by-zero fixed in \_\_post_init\_\_)<sup>31</sup>. | ValueError: Missing required configuration fields: ...<sup>65</sup>; r \> max_lora_rank rejected in validate_legal (#67774, https://github.com/vllm-project/vllm/issues/67774)<sup>70</sup>. | Write explicit positive integers for r and lora_alpha, plus an explicit list\[str\] for target_modules. |
| **target_modules (list vs. regex str)** | Typed list\[str\] \| str, but vLLM matches leaf suffixes against packed_modules_mapping and get_supported_lora_modules()<sup>65</sup>. | State-dict key mismatch or accidental targeting of unsupported vision/PLE/embedding weights (#2816, \#35734)<sup>38</sup>. | **Never ship regex strings or "all-linear"**; serialize only explicit text linear leaf names (\["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"\]). |
| **layers_to_transform / layers_pattern** | **Silently dropped** by PEFTHelper.from_dict() across versions<sup>31</sup>; vLLM infers active layers strictly from tensor keys in adapter_model.safetensors. | Silent no-op in vLLM if safetensors only contains transformed layers; upstream PEFT (config.py) rejects layers_to_transform combined with str regex target_modules<sup>71</sup>. | Always pair layers_to_transform with a list\[str\] target_modules during training and verify only intended layer indices exist in adapter_model.safetensors. |
| **rank_pattern / alpha_pattern** | **\<= v0.30.0**: **Silently dropped** (#59799; postmortem https://dev.to/homelabpm/vllm-ignores-lora-rankpattern-and-alphapattern-and-serves-the-adapter-at-the-wrong-scale-4pek), applying one global lora_alpha / r<sup>30</sup>. **Post-#59801 / latest (0.31+/main)**: read in get_rank_and_scaling()<sup>30</sup>. | Silent 2x–4x per-module scaling corruption in \<= 0.30.0 with zero warning logs<sup>30</sup>. | Keep both empty ({}) with uniform r/lora_alpha, or pre-fold per-module scaling ratios into lora_B before zipping<sup>30</sup>. |
| **modules_to_save** | Rejected unless None (or \["classifier", "score"\] for classification models in latest vLLM)<sup>31</sup>. | ValueError: vLLM only supports modules_to_save being either None...<sup>31</sup>; embed_tokens/lm_head raises unsupported LoRA weight (#2816, \#9280)<sup>38</sup>. | Enforce "modules_to_save": null and assert zero embed_tokens or lm_head keys in adapter_model.safetensors. |
| **use_dora, bias, use_rslora** | use_rslora: true supported (lora_alpha / sqrt(r)). use_dora: true and bias != "none" are **rejected**<sup>31</sup>. | ValueError: vLLM does not yet support DoRA. / Adapter bias is not supported.<sup>65</sup>. | Enforce "use_dora": false and "bias": "none". |
| **init_lora_weights** | Latest PEFTHelper accepts boolean or string in ("gaussian", "eva", "orthogonal", "mica", "lora_ga")<sup>31</sup>. | Rejects base-mutating initializers ("pissa", "loftq", "olora") that assume modified base weights<sup>31</sup>. | Keep default true or "gaussian" during training. |

## Deliverable C: Flag Checklist for Your Exact Serving Shape

Use this baseline launch configuration for **4x NVIDIA L4 (sm_89), TP=4, 31B QAT W4A16 (compressed-tensors), 4 concurrent multi-turn agent sessions, 32k context, thinking + tool calling, LiteLLM drop_params=True, and LoRA**.

> Bash
>
> export VLLM_ALLOW_RUNTIME_LORA_UPDATING=False \# Set True ONLY with content-hashed lora_name (#30931)\
> unset VLLM_MARLIN_INPUT_DTYPE \# Removed in current vLLM; setting raises an error\
> \
> vllm serve google/gemma-4-31B-it-qat-w4a16-ct \\\
> --host 0.0.0.0 --port 8000 \\\
> --tensor-parallel-size 4 \\\
> --gpu-memory-utilization 0.90 \\\
> --max-model-len 32768 \\\
> --kv-cache-dtype auto \\\
> --enable-prefix-caching \\\
> --max-num-seqs 8 \\\
> --max-num-batched-tokens 4096 \\\
> --async-scheduling \\\
> --limit-mm-per-prompt '{"image": 0, "audio": 0}' \\\
> --enable-auto-tool-choice \\\
> --tool-call-parser gemma4 \\\
> --reasoning-parser gemma4 \\\
> --default-chat-template-kwargs '{"enable_thinking": true}' \\\
> --enable-lora \\\
> --max-loras 2 \\\
> --max-lora-rank 16 \\\
> --lora-modules '{"name": "agent-v1-a1b2c3d4", "path": "/kaggle/working/unpacked_lora", "base_model_name": "google/gemma-4-31B-it-qat-w4a16-ct"}'

Follow these five operational checks alongside the launch command:

1.  **Keep MTP mutually exclusive with LoRA**: Omit --speculative-config whenever --enable-lora is active (#62340)<sup>7</sup>. For a **non-LoRA** edge-model server (E4B/E2B), strip all --\*lora\* flags and add --speculative-config '{"method":"mtp","model":"\<assistant_ckpt\>","num_speculative_tokens":1}'<sup>26</sup>.

2.  **Enforce r \<= 16 unless locally parity-verified**: Do not raise --max-lora-rank to 32–128 on compressed-tensors W4A16 g32 without first passing a two-restart temperature=0 determinism check (#50059); if high ranks are later validated, add --fully-sharded-loras to cut per-slot VRAM from ~1.00 to ~0.46 GiB/GPU at r=128<sup>1</sup>.

3.  **Keep a CUDA-graph escape hatch ready**: If TP=4 + LoRA stalls on NCCL at startup or first decode (#60845), append --compilation-config '{"cudagraph_mode": "PIECEWISE"}' (or --enforce-eager during bisection)<sup>14</sup>.

4.  **Lock LiteLLM request hygiene**: Never send prompt_logprobs, echo=True, or logprobs (#8268 crash<sup>63</sup> plus 8.00 GiB/GPU FP32 logits spike<sup>10</sup>); set max_tokens \>= 4096 to accommodate ~2.4x reasoning-token expansion<sup>13</sup>; keep strict client-side schema validation active<sup>13</sup>.

5.  **Confirm native model resolution in startup logs**: Verify vLLM logs Gemma4ForConditionalGeneration (not Transformers fallback, \#13179) and CompressedTensorsWNA16 without mixed-shard ignore errors (#62308)<sup>16</sup>.

## Deliverable D: Top 5 Known Bugs to Defensively Code Around

Embed automated pre-flight assertions across each stage of your Kaggle training, packaging, and serving notebook so these five upstream failure modes fail fast before GPU quota is consumed.

<img src="f:\AI\Benchmark\research_briefs\media\vLLM Quantized LoRA Serving Brief/media/image2.png" style="width:6.45833in;height:3.52083in" />

### 1. Compressed-Tensors INT4 W4A16 (g32) High-Rank LoRA Drift (vllm-project/vllm#50059, Open)

Observed on vLLM 0.17.1 and 0.24.0 (https://github.com/vllm-project/vllm/issues/50059, active Nov 2026; unverified on 0.32.0–0.34.0), rank-32 all-layer LoRA adapters over compressed-tensors INT4 W4A16 (group_size=32) produce weak, non-reproducible outputs at temperature=0 across server restarts, while rank \<= 16 remains deterministic<sup>1</sup>. Defensively assert r \<= 16 in your adapter validation script before serving W4A16 checkpoints, and run a 3-prompt temperature=0 parity check comparing vLLM W4A16+LoRA outputs across two fresh server starts against your dequantized BF16 reference.

### 2. LoRA + Gemma 4 MTP Speculative Decoding Startup Crash (vllm-project/vllm#62340, Open)

Reproduced on vLLM v0.26.0 (https://github.com/vllm-project/vllm/issues/62340, Open; compounded by \#53488 and \#50602), combining --enable-lora with Gemma 4 MTP crashes engine startup in gemma4_mtp.py:422 (pre_projection shape mismatch) because LoRA wrapping breaks Gemma4Proposer.\_maybe_share_embeddings<sup>7</sup>. Add a hard launch-wrapper assertion—assert not (enable_lora and speculative_config)—so no notebook config can ever launch both simultaneously.

### 3. Reasoning Parser Silently Bypassing Structured-Output Grammar When Thinking Is Off (tpu-inference#3225)

Documented as a vLLM config coupling (https://dev.to/gde/gemma-4-e2b-on-a-single-tpu-v6e-chip-a-serving-deep-dive-53n), configuring --reasoning-parser gemma4 defers structured-output grammar enforcement until the thinking block ends, causing thinking-off requests to bypass schema enforcement silently while returning HTTP 200<sup>13</sup>. Because LiteLLM drop_params=True can silently strip chat_template_kwargs, hardcode --default-chat-template-kwargs '{"enable_thinking": true}' on the vLLM server<sup>12</sup> and wrap every LiteLLM tool/JSON response in strict Pydantic validation with retry handling<sup>13</sup>.

### 4. Prefix-Cache Contamination on Reused lora_name (vllm-project/vllm#30931) and Level-2 Sleep Corruption (#48310)

In vLLM 0.11.1 (TP=4), \#30931 (https://github.com/vllm-project/vllm/issues/30931) hashed prefix-cache blocks on lora_name instead of lora_int_id, serving stale KV states after hot-reloading weights under the same name<sup>34</sup>; separately, \#48310 (https://github.com/vllm-project/vllm/issues/48310) corrupts LoRA parameter wrappers across sleep(level=2) / wake_up()<sup>54</sup>. Compute lora_name = f"{adapter_id}-{sha256_of_safetensors\[:8\]}" deterministically from adapter_model.safetensors bytes before registering any adapter, and prohibit /sleep calls on LoRA-enabled engines (restart the server subprocess instead).

### 5. Silent adapter_config.json Field Drops (vllm-project/vllm#59799, \#60223) and PEFT torchao Crash (huggingface/peft#3964)

PEFTHelper.from_dict() (https://docs.vllm.ai/en/latest/api/vllm/lora/peft_helper/) silently discards unrecognized JSON keys—dropping rank_pattern/alpha_pattern in \<= v0.30.0 (#59799) and layers_to_transform across versions (#60223)—while rejecting modules_to_save, use_dora, and bias != "none"<sup>30</sup>; meanwhile, peft 0.19.0–0.21.2 crashes with ImportError when Kaggle's preinstalled torchao==0.10.0 is present (https://github.com/huggingface/peft/issues/3964)<sup>6</sup>. Pin peft==0.22.0 plus pip uninstall -y torchao<sup>3</sup>, and run a pre-zip sanitizer asserting a flat root (adapter_config.json + adapter_model.safetensors), isinstance(target_modules, list) containing only supported text projections, modules_to_save is None, use_dora is False, bias == "none", empty rank_pattern/alpha_pattern, and zero embed_tokens or lm_head keys in adapter_model.safetensors<sup>30</sup>.

#### Works cited

1.  LoRA on a compressed-tensors int4 (W4A16) model: rank-32 all, [<u>https://github.com/vllm-project/vllm/issues/50059</u>](https://github.com/vllm-project/vllm/issues/50059)

2.  peft - PyPI, [<u>https://pypi.org/project/peft/</u>](https://pypi.org/project/peft/)

3.  Commented out PEFT dependency in pyproject.toml \#4844 - GitHub, [<u>https://github.com/NVIDIA-NeMo/Automodel/issues/4844</u>](https://github.com/NVIDIA-NeMo/Automodel/issues/4844)

4.  vLLM Security Advisories 2026: Which Version \| Eurokommerz, [<u>https://eurokommerz.at/blog/vllm-security-advisories-which-version/</u>](https://eurokommerz.at/blog/vllm-security-advisories-which-version/)

5.  vllm \| PyPI - Open Source Insights, [<u>https://deps.dev/pypi/vllm</u>](https://deps.dev/pypi/vllm)

6.  An old, unused torchao install makes every LoRA/OFT injection fail, [<u>https://github.com/huggingface/peft/issues/3964</u>](https://github.com/huggingface/peft/issues/3964)

7.  LoRA + Gemma4 MTP speculative decoding crashes at startup, [<u>https://github.com/vllm-project/vllm/issues/62340</u>](https://github.com/vllm-project/vllm/issues/62340)

8.  google/gemma-4-E4B-it-qat-w4a16-ct · vLLM optimized version for, [<u>https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1</u>](https://huggingface.co/google/gemma-4-E4B-it-qat-w4a16-ct/discussions/1)

9.  [<u>https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json</u>](https://huggingface.co/google/gemma-4-31B-it/blob/main/config.json)

10. [<u>unknown_url</u>](http://docs.google.com/unknown_url)

11. [<u>https://vllm-project.github.io/2026/04/22/fp8-kvcache.html</u>](https://vllm-project.github.io/2026/04/22/fp8-kvcache.html)

12. Google/gemma-4-31B-it - vLLM Recipes, [<u>https://recipes.vllm.ai/Google/gemma-4-31B-it</u>](https://recipes.vllm.ai/Google/gemma-4-31B-it)

13. Gemma 4 E2B on a Single TPU v6e Chip: A Serving Deep Dive, [<u>https://dev.to/gde/gemma-4-e2b-on-a-single-tpu-v6e-chip-a-serving-deep-dive-53n</u>](https://dev.to/gde/gemma-4-e2b-on-a-single-tpu-v6e-chip-a-serving-deep-dive-53n)

14. \[Bug\]: v0.33.0 illegal memory access (Xid 31) during CUDA graph, [<u>https://github.com/vllm-project/vllm/issues/67488</u>](https://github.com/vllm-project/vllm/issues/67488)

15. vllm - PyPI, [<u>https://pypi.org/project/vllm/</u>](https://pypi.org/project/vllm/)

16. Gemma 4 Models - which vLLM version? Any PRs spotted? - Page 2, [<u>https://forums.developer.nvidia.com/t/gemma-4-models-which-vllm-version-any-prs-spotted/365490?page=2</u>](https://forums.developer.nvidia.com/t/gemma-4-models-which-vllm-version-any-prs-spotted/365490?page=2)

17. run-batch - vLLM docs, [<u>https://docs.vllm.ai/en/v0.31.0/cli/run-batch/</u>](https://docs.vllm.ai/en/v0.31.0/cli/run-batch/)

18. Gemma 4 on AWS Lambda with a GPU: E2B on an NVIDIA L4, Day, [<u>https://xbill999.medium.com/gemma-4-on-aws-lambda-with-a-gpu-e2b-on-an-nvidia-l4-day-one-d5e5808dd2d2</u>](https://xbill999.medium.com/gemma-4-on-aws-lambda-with-a-gpu-e2b-on-an-nvidia-l4-day-one-d5e5808dd2d2)

19. \[RFC\]: Kernel-owned LoRA fusion for quantized linear layers, [<u>https://github.com/vllm-project/vllm/issues/67330</u>](https://github.com/vllm-project/vllm/issues/67330)

20. Quantization - vLLM, [<u>https://docs.vllm.ai/en/stable/features/quantization/</u>](https://docs.vllm.ai/en/stable/features/quantization/)

21. \[Bug\]: Qwen3.8-Flash-Next checkpoints with quantized q/k/v and an, [<u>https://github.com/vllm-project/vllm/issues/62308</u>](https://github.com/vllm-project/vllm/issues/62308)

22. Unsupported base layer: QKVParallelLinear when loading lora to a, [<u>https://github.com/vllm-project/vllm/issues/9120</u>](https://github.com/vllm-project/vllm/issues/9120)

23. FP8 W8A8 - vLLM docs, [<u>https://docs.vllm.ai/en/stable/features/quantization/llm_compressor/fp8/</u>](https://docs.vllm.ai/en/stable/features/quantization/llm_compressor/fp8/)

24. \[Feature\]: MoE LoRA for quantized models \#29424 - vllm - GitHub, [<u>https://github.com/vllm-project/vllm/issues/29424</u>](https://github.com/vllm-project/vllm/issues/29424)

25. compressed_tensors - vLLM docs, [<u>https://docs.vllm.ai/en/latest/api/vllm/model_executor/layers/quantization/compressed_tensors/compressed_tensors/</u>](https://docs.vllm.ai/en/latest/api/vllm/model_executor/layers/quantization/compressed_tensors/compressed_tensors/)

26. [<u>https://docs.vllm.ai/en/latest/features/speculative_decoding/mtp/</u>](https://docs.vllm.ai/en/latest/features/speculative_decoding/mtp/)

27. lora - vLLM docs, [<u>https://docs.vllm.ai/en/latest/api/vllm/config/lora/</u>](https://docs.vllm.ai/en/latest/api/vllm/config/lora/)

28. \[Bug\]: LoRA linear path (lora_shrink/lora_expand) nondeterministic, [<u>https://github.com/vllm-project/vllm/issues/50602</u>](https://github.com/vllm-project/vllm/issues/50602)

29. \`prompt_logprobs\` silently corrupted for some requests when MTP, [<u>https://github.com/vllm-project/vllm/issues/53488</u>](https://github.com/vllm-project/vllm/issues/53488)

30. vLLM ignores LoRA rank_pattern and alpha_pattern and serves the, [<u>https://dev.to/homelabpm/vllm-ignores-lora-rankpattern-and-alphapattern-and-serves-the-adapter-at-the-wrong-scale-4pek</u>](https://dev.to/homelabpm/vllm-ignores-lora-rankpattern-and-alphapattern-and-serves-the-adapter-at-the-wrong-scale-4pek)

31. peft_helper - vLLM docs, [<u>https://docs.vllm.ai/en/latest/api/vllm/lora/peft_helper/</u>](https://docs.vllm.ai/en/latest/api/vllm/lora/peft_helper/)

32. HOW TO USE AUTOMATIC PREFIX CACHING FOR sliding window, [<u>https://github.com/vllm-project/vllm/discussions/3881</u>](https://github.com/vllm-project/vllm/discussions/3881)

33. Automatic Prefix Caching - vLLM docs, [<u>https://docs.vllm.ai/en/latest/features/automatic_prefix_caching/</u>](https://docs.vllm.ai/en/latest/features/automatic_prefix_caching/)

34. \[Bug\]: Prefix Cache Corruption with LoRA with the same name but, [<u>https://github.com/vllm-project/vllm/issues/30931</u>](https://github.com/vllm-project/vllm/issues/30931)

35. vllm.config.cache, [<u>https://docs.vllm.ai/en/stable/api/vllm/config/cache/</u>](https://docs.vllm.ai/en/stable/api/vllm/config/cache/)

36. vLLM current version, release history and CVE alerts - versionPing, [<u>https://versionping.app/products/vllm</u>](https://versionping.app/products/vllm)

37. NVD-CVE-2026-115913 - NIST, [<u>https://nvd.nist.gov/vuln/detail/CVE-2026-115913</u>](https://nvd.nist.gov/vuln/detail/CVE-2026-115913)

38. Support for Deploying 4-bit Fine-Tuned Model with LoRA on vLLM, [<u>https://discuss.vllm.ai/t/support-for-deploying-4-bit-fine-tuned-model-with-lora-on-vllm/1186</u>](https://discuss.vllm.ai/t/support-for-deploying-4-bit-fine-tuned-model-with-lora-on-vllm/1186)

39. LoRA Adapters - vLLM docs, [<u>https://docs.vllm.ai/en/latest/features/lora/</u>](https://docs.vllm.ai/en/latest/features/lora/)

40. \[Bug\]: vllm 0.8.4 v1 startup time is too long when using lora \#16961, [<u>https://github.com/vllm-project/vllm/issues/16961</u>](https://github.com/vllm-project/vllm/issues/16961)

41. \[Bug\]: Marlin MoE kernel fails with MXFP4-quantized GPT-OSS 20B, [<u>https://github.com/vllm-project/vllm/issues/38022</u>](https://github.com/vllm-project/vllm/issues/38022)

42. \[Doc\]: Clarify QLoRA (Quantized Model + LoRA) Support in ... - GitHub, [<u>https://github.com/vllm-project/vllm/issues/13179</u>](https://github.com/vllm-project/vllm/issues/13179)

43. torchao - PyPI, [<u>https://pypi.org/project/torchao/</u>](https://pypi.org/project/torchao/)

44. FreshPorts -- misc/py-compressed-tensors: Library for storing and, [<u>https://www.freshports.org/misc/py-compressed-tensors/</u>](https://www.freshports.org/misc/py-compressed-tensors/)

45. Peft 0.18.1 crashing when fine-tuning - Hugging Face Forums, [<u>https://discuss.huggingface.co/t/peft-0-18-1-crashing-when-fine-tuning/174916</u>](https://discuss.huggingface.co/t/peft-0-18-1-crashing-when-fine-tuning/174916)

46. Gemma 4 in Rust on TorchTPU: A Native TPU Rig With PyO3 and, [<u>https://dev.to/gde/gemma-4-in-rust-on-torchtpu-a-native-tpu-rig-with-pyo3-and-mcp-47j1</u>](https://dev.to/gde/gemma-4-in-rust-on-torchtpu-a-native-tpu-rig-with-pyo3-and-mcp-47j1)

47. llmcompressor - PyPI, [<u>https://pypi.org/project/llmcompressor/</u>](https://pypi.org/project/llmcompressor/)

48. peft - piwheels, [<u>https://www.piwheels.org/project/peft/</u>](https://www.piwheels.org/project/peft/)

49. vllm-lora-serving-reading.md - Jackie2049/perpetual-learning - GitHub, [<u>https://github.com/Jackie2049/perpetual-learning/blob/main/notebook/frameworks/vllm-lora-serving-reading.md</u>](https://github.com/Jackie2049/perpetual-learning/blob/main/notebook/frameworks/vllm-lora-serving-reading.md)

50. Multi-LoRA Serving Capacity Planning: Working Sets and RAM, [<u>https://gpusmith.com/articles/en/multi-lora-serving-adapter-working-set-planning</u>](https://gpusmith.com/articles/en/multi-lora-serving-adapter-working-set-planning)

51. vllm.config.vllm, [<u>https://docs.vllm.ai/en/stable/api/vllm/config/vllm/</u>](https://docs.vllm.ai/en/stable/api/vllm/config/vllm/)

52. \[Bug\]: CUDA graphs deadlock fully-sharded fused-MoE LoRA, [<u>https://github.com/vllm-project/vllm/issues/60845</u>](https://github.com/vllm-project/vllm/issues/60845)

53. vllm/vllm/lora/punica_wrapper/punica_gpu.py at main - GitHub, [<u>https://github.com/vllm-project/vllm/blob/main/vllm/lora/punica_wrapper/punica_gpu.py</u>](https://github.com/vllm-project/vllm/blob/main/vllm/lora/punica_wrapper/punica_gpu.py)

54. \[RFC\] Sleep/Wake Correctness for RL · Issue \#48310 - vllm - GitHub, [<u>https://github.com/vllm-project/vllm/issues/48310</u>](https://github.com/vllm-project/vllm/issues/48310)

55. LoRA Adapters - vLLM docs, [<u>https://docs.vllm.ai/en/v0.6.5/usage/lora.html</u>](https://docs.vllm.ai/en/v0.6.5/usage/lora.html)

56. During testing of the LoRA model, the "enable-prefix-caching, [<u>https://github.com/vllm-project/vllm/issues/23301</u>](https://github.com/vllm-project/vllm/issues/23301)

57. vllm/vllm/config/speculative.py at main - GitHub, [<u>https://github.com/vllm-project/vllm/blob/main/vllm/config/speculative.py</u>](https://github.com/vllm-project/vllm/blob/main/vllm/config/speculative.py)

58. gemma4 - vLLM docs, [<u>https://docs.vllm.ai/en/v0.34.0/api/vllm/v1/worker/gpu/spec_decode/gemma4/</u>](https://docs.vllm.ai/en/v0.34.0/api/vllm/v1/worker/gpu/spec_decode/gemma4/)

59. speculative - vLLM docs, [<u>https://docs.vllm.ai/en/v0.11.2/api/vllm/config/speculative/</u>](https://docs.vllm.ai/en/v0.11.2/api/vllm/config/speculative/)

60. Same Command, Different Answer: vLLM's Runtime LoRA Path, [<u>https://openreview.net/pdf?id=KqQzNXZ62T</u>](https://openreview.net/pdf?id=KqQzNXZ62T)

61. Gemma 4 Usage Guide - vLLM Recipes, [<u>https://docs.vllm.ai/projects/recipes/en/stable/Google/Gemma4.html</u>](https://docs.vllm.ai/projects/recipes/en/stable/Google/Gemma4.html)

62. Attention Backend Feature Support - vLLM docs, [<u>https://docs.vllm.ai/en/latest/design/attention_backends/</u>](https://docs.vllm.ai/en/latest/design/attention_backends/)

63. 4 Reasons Why vLLM Prefix Caching Fails and How to Fix, [<u>https://book.st-hakky.com/en/data-science/vllm-prefix-caching-ineffective-causes</u>](https://book.st-hakky.com/en/data-science/vllm-prefix-caching-ineffective-causes)

64. Gemma4 parser - vLLM docs, [<u>https://docs.vllm.ai/en/latest/api/vllm/parser/gemma4/</u>](https://docs.vllm.ai/en/latest/api/vllm/parser/gemma4/)

65. vllm/vllm/lora/peft_helper.py at tip-0003-v3-stepbind-v016, [<u>https://git.tensorcash.org/tensorcash/vllm/src/branch/tip-0003-v3-stepbind-v016/vllm/lora/peft_helper.py</u>](https://git.tensorcash.org/tensorcash/vllm/src/branch/tip-0003-v3-stepbind-v016/vllm/lora/peft_helper.py)

66. How to convert a single safetensors file to PEFT format - Diffusers, [<u>https://discuss.huggingface.co/t/how-to-convert-a-single-safetensors-file-to-peft-format/173103</u>](https://discuss.huggingface.co/t/how-to-convert-a-single-safetensors-file-to-peft-format/173103)

67. trl/trl/experimental/async_grpo/async_grpo_trainer.py at main - GitHub, [<u>https://github.com/huggingface/trl/blob/main/trl/experimental/async_grpo/async_grpo_trainer.py</u>](https://github.com/huggingface/trl/blob/main/trl/experimental/async_grpo/async_grpo_trainer.py)

68. \[Bug\]: LoRA adapters using PEFT features vLLM does not ... - GitHub, [<u>https://github.com/vllm-project/vllm/issues/60223</u>](https://github.com/vllm-project/vllm/issues/60223)

69. The world's first bug bounty platform for AI/ML - huntr, [<u>https://huntr.com/bounties/f4048f54-29e7-4e6b-955b-d23ab7dcce4f</u>](https://huntr.com/bounties/f4048f54-29e7-4e6b-955b-d23ab7dcce4f)

70. \[Bug\]: LoRA adapter with rank \> max_lora_rank kills the engine, [<u>https://github.com/vllm-project/vllm/issues/67774</u>](https://github.com/vllm-project/vllm/issues/67774)

71. peft/src/peft/tuners/lora/config.py at main · huggingface/peft - GitHub, [<u>https://github.com/huggingface/peft/blob/main/src/peft/tuners/lora/config.py</u>](https://github.com/huggingface/peft/blob/main/src/peft/tuners/lora/config.py)

72. \[Bug\]: Unable to Run W4A16 GPTQ Quantized Models · Issue \#19098, [<u>https://github.com/vllm-project/vllm/issues/19098</u>](https://github.com/vllm-project/vllm/issues/19098)
