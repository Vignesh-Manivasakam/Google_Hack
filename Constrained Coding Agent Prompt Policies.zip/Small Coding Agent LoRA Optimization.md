# Decision-Ready Fine-Tuning Brief: Gemma 4 E4B LoRA v2 for Autonomous Repository Bug Fixing

Your v1 jump from 1/30 (3.3%) to 5/30 (16.7%) on 26–30 trajectories captures the initial tool-format and patch-submission floor, but two structural bottlenecks now cap your ceiling far more severely than raw trajectory count alone. First, your v1 LoRA targeted layers \[23, 29, 30, 35, 41\]—yet in Gemma 4 E4B (num_hidden_layers = 42, num_kv_shared_layers = 18), engineering audits in vLLM llm-compressor and MLX confirm that layers 24–41 reuse keys and values from layers 0–23 and do not execute their own k_proj/v_proj projections during the forward pass, while global layers additionally tie K = V {verified in source}<sup>1</sup>. Four of your five adapted layers therefore carried inert K/V adapters, leaving layers 0–22—which compute 100% of the shared KV states fed into the upper stack—completely frozen {inferred by you}. Second, 100% of your v1 corpus comes from a 31B teacher solving tasks *with golden localization hints*, creating an unhinted-deployment distribution shift where the student learns patch formatting without learning repository search or recovery from wrong-file edits {inferred by you from}<sup>6</sup>.

With two realistic training cycles remaining before December 2, 2026 (one 0.3h run on 4×L4 per version) and a free local 16 GB GPU for 24/7 on-policy rollouts, the highest-return v2 strategy is **not** standalone DPO/KTO/GRPO, **not** adapter merging, and **not** aggressive 100-token prompt stripping. Instead, you should expand your corpus from ~28 to **60 deduplicated, per-task-capped trajectories** by adding **AggreVaTe/DAgger recovery traces** (unhinted local v1 failure prefixes completed by the 31B teacher, with loss masked to 0.0 on bad student turns) plus capped on-policy v1 successes, while unlocking **all 42 layers' active linear projections** (keeping Per-Layer Embeddings frozen) at r = 16, lora_alpha = 32, lora_dropout = 0.05, and a properly scaled LoRA learning rate of 1.2e-4 for 2 epochs {inferred by you}.

**Architectural Analog Mapping:** Because Gemma 4 E4B (~4.5B effective / ~8B stored, 42 layers, 5:1 local 512-token sliding-window attention to global p-RoPE attention, 18 KV-shared upper layers, Per-Layer Embeddings) released in April 2026 without a published SWE-bench LoRA scaling paper yet {verified in source}<sup>1</sup>, empirical evidence below maps explicitly from close public analogs: **Qwen3-4B** (effective-parameter-matched 4B dense SWE agent), **Qwen2.5-Coder-7B / Qwen3-8B / Llama-3.1-8B / Qwen3.5-9B** (stored-parameter-matched 7B–9B coding agents), and **Gemma 3 4B / Gemma 4 E2B** (identical 5:1/4:1 SWA-global and PLE mechanics).

## 1. Corpus Size Curve and Marginal Solve-Rate Projection (26 → 50 → 70 Trajectories)

Published 2024–2026 agent-SFT studies on 4B–9B models establish two consistent scaling properties: resolve rate rises **logarithmically** with unique-task trajectory count across four orders of magnitude without hitting saturation even at 16,639–300,000 trajectories {verified in source}<sup>11</sup>, while inside the sub-100 trajectory regime, **per-task diversity outweighs raw sample count**—allowing more than two trajectories from the same easy task actively degrades 7B solve rates {verified in source}<sup>14</sup>.

|  |  |  |  |  |  |  |
|----|----|----|----|----|----|----|
| **Study & Year** | **Public URL** | **Model & Scaffold** | **Trajectories / Tokens** | **Resolve Rate (SWE-bench / Eval)** | **Diminishing-Returns Threshold** | **Status** |
| **SWE-Gym** (Pan et al., 2024/2025)<sup>11</sup> | https://arxiv.org/html/2412.21139v2 | Qwen2.5-Coder-7B (OpenHands) | 491 trajs (~19 turns, ~18.6k–19k total tok/traj; ~9.1M total tok) | Verified: 1.8% → 10.6% (+8.8 pp); Lite: 1.0% → 10.0% (+9.0 pp) | **None at 491 trajs** (log-base-2 scaling curve still climbing) | {verified in source} |
| **SWE-Gym Small-N Cap** (Pan et al., 2024/2025)<sup>14</sup> | https://arxiv.org/html/2412.21139v1 | Qwen2.5-Coder-7B (MoatlessTools) | 0 → 36 → 62 → 82 → 172 trajs (cap 0/1/2/3/∞ per task) | Lite: 7.0% → 9.0% → 9.7% → 7.7% → 9.3% | **Negative returns past cap=2** (62 → 82 drops -2.0 pp from easy-task bias) | {verified in source} |
| **SWE-Dev** (THUDM, 2025)<sup>12</sup> | https://arxiv.org/html/2506.07636v1 | 7B & 32B coding agents | 574 → 16,639 trajs | 7B: 13.0% (574) → 22.8% (16.6k); full recipe 23.4% | **None at 16,639 trajs** (near-linear in log-log; top-65% filtered matches 100%) | {verified in source} |
| **SWE-Playground** (Dec 2025)<sup>15</sup> | https://arxiv.org/html/2512.12216v1 | 7B (SWE-Play-mix-7B) | 704 diverse trajs | Verified: 17.0% (+15.2 pp over base) | Outperforms 2k SWE-smith trajs via task diversity; not saturated | {verified in source} |
| **SWE-smith** (Yang et al., 2025)<sup>15</sup> | https://arxiv.org/html/2504.21798v2 | Qwen2.5-Coder-7B (SWE-agent) | 259–390 (ablations); 700 (SymPy); 2,000 (7B main table) | Ablations: 6.4%–7.8%; 2k 7B: 15.2% Verified (+13.4 pp), 11.7% Lite | Purely synthetic bugs show earlier diminishing returns than real PRs<sup>17</sup> | {verified in source} |
| **R2E-Gym** (Jain et al., 2025)<sup>13</sup> | https://arxiv.org/html/2504.07164v1 | Qwen2.5-Coder-7B (OpenHands) | 3.23k–3.3k SFT trajs | Verified: 19.0% (+17.2 pp over base) | Not saturated at 3.3k | {verified in source} |
| **SWE-AGILE** (Apr 2026)<sup>19</sup> | https://arxiv.org/html/2604.11716v1 | 7B–8B & Qwen3-14B | 2.2k trajs (896 tasks, dynamic snapshot training) | New 7B–8B SFT standard; 14B hits 30.06% vs 26.8% (3.3k R2E-Gym) | Dynamic context snapshots shift sample-efficiency curve upward | {verified in source} |
| **SWE-Hero / Zero** (Apr 2026)<sup>13</sup> | https://arxiv.org/html/2604.01496v1 | 7B (OpenHands) | 300k exec-free (Zero) + small exec-grounded (Hero) | Verified: 46.8% (Zero-7B) → 52.7% (Hero-7B) | **None at 300k trajs**; scale drives cross-repo and cross-language transfer | {verified in source} |
| **MetaCurate** (Oct 2026)<sup>20</sup> | https://arxiv.org/html/2610.23134v1 | Qwen3.5-9B | 200 curated vs 1,000 curated vs 4,286 full | 60.3% (top-200) vs 58.7% (random-200); 1k curated ≈ 4.3k full (63.1%) | Curation yields ~4× data efficiency; trajectory quality \> raw volume | {verified in source} |
| **Revisiting DAgger** (May 2026)<sup>6</sup> | https://arxiv.org/html/2605.12913v1 | Qwen3-4B & Qwen3-8B (OpenHands) | SWE-Gym train pool (SFT vs DAgger) | 4B: 11.2% → 22.9% (SFT) → 27.3% (DAgger); 8B: 7.7% → 23.4% → 29.8% | Pure offline SFT plateaus below DAgger due to covariate shift | {verified in source} |
| **AgentTuning / AgentBank** (2023–2024)<sup>21</sup> | https://arxiv.org/html/2310.12823v2 / https://arxiv.org/html/2410.07706 | Llama-2-7B / 13B | 1,866 trajs (AgentInstruct) → 50,000+ (AgentBank) | 1.8k reduces format/loop errors; 50k unlocks unseen generalization | 1.8k insufficient for OOD agent generalization at 7B; scaling holds at 50k | {verified in source} |
| **FireAct** (Chen et al., 2023)<sup>23</sup> | https://arxiv.org/html/2403.03101v3 | Llama-2-7B / 13B (ReAct QA) | 200–500 GPT-4 trajs (HotpotQA) | Strong in-domain QA gains | No saturation threshold reported in cited extracts (non-SWE QA) | {verified in source} |

<img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image7.png" style="width:6.45833in;height:6.69792in" />

### Quantitative Projection: Marginal Gain per +10 Trajectories (26 → 50 → 70)

Because SWE-Dev 7B reports a near-linear scaling curve against log trajectory volume, <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image3.png" style="width:2.88134in;height:0.21844in" /> {verified in source}<sup>12</sup>, we can anchor the doubling slope b for your 4.5B-effective model {inferred by you}. On cross-repository SWE-bench Verified, SWE-Dev 7B improved from 13.0% at 574 trajectories to 22.8% at 16,639 trajectories (log2(16639 / 574) = 4.86 doublings), giving b = 9.8 / 4.86 ≈ 2.0 pp per doubling {verified in source}<sup>12</sup>. Inside the sub-100 trajectory regime on SWE-bench Lite, SWE-Gym 7B's capped RFT moved from 9.0% at 36 trajectories to 9.7% at 62 trajectories (0.78 doublings), giving b ≈ 0.9 pp per doubling before turning negative at cap=3 {verified in source}<sup>14</sup>.

Your competition evaluates four fixed Python repositories (FastAPI, Rich, Requests, HTTPX), which closely resembles SWE-smith's repository-specialized regime where smaller datasets transfer more efficiently than open-domain benchmarks<sup>16</sup>. However, your initial +13.3 pp leap (1/30 → 5/30) on ~26 trajectories reflects the steep **format-compliance and submission-floor phase**—in SWE-Gym 7B, initial SFT cut empty patches by -12.0 pp and stuck-in-loop failures by -18.6 pp {verified in source}<sup>11</sup>, and AgentTuning likewise attributes early 7B gains to eliminating formatting errors and duplicated loops<sup>25</sup>. Once format compliance is established (~25–30 clean trajectories), marginal gains from *purely adding more off-policy trajectories* compress into the reasoning slope, realistically **b ≈ 2.0–4.0 pp per doubling** of unique tasks at 4.5B-effective {inferred by you}:

- **Moving 26 → 50 trajectories (+24 unique trajs = 0.94 doublings):** A conservative cross-repo slope (b = 1.0–2.0) predicts **+0.9 to +1.9 pp** (+0.4 to +0.8 pp per +10 trajs); an optimistic 4-repo in-domain slope (b = 3.5–4.0) predicts **+3.3 to +3.8 pp** (+1.4 to +1.6 pp per +10 trajs), or roughly **+0.3 to +1.1 solves** on your 30-task holdout {inferred by you}.

- **Moving 50 → 70 trajectories (+20 unique trajs = 0.49 doublings):** Logarithmic compression nearly halves marginal return per trajectory. Conservative predicts **+0.5 to +1.0 pp** (+0.25 to +0.5 pp per +10 trajs); optimistic predicts **+1.7 to +1.9 pp** (+0.85 to +1.0 pp per +10 trajs), or roughly **+0.15 to +0.6 solves** on 30 tasks {inferred by you}.

- **Measurement Noise Reality:** At 5/30 (16.7%), a single 30-task tournament has a 1-sigma binomial standard error of ±6.8 pp (±2.0 solves). Adding 20–40 *more* hinted teacher trajectories alone is unlikely to clear evaluation noise unless paired with the **on-policy recovery composition** (Section 2) and **full-stack active-layer LoRA fix** (Section 3) {inferred by you}.

## 2. Trajectory Composition: Hinted Teacher vs. On-Policy Error Recovery and Per-Turn Weighting

Your 31B teacher solved 27/99 training tasks *with golden localization hints*. Multiple 2026 studies show that distilling solely from privileged or hint-conditioned teachers creates a structural train–test mismatch: the teacher jumps directly to the golden file via a conditional mapping <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image15.png" style="width:0.94564in;height:0.21822in" /> that an unhinted student cannot reliably recover, inducing shortcut-like traces and failing to teach search or error recovery {verified in source}<sup>7</sup>. Leveraging your free local 16 GB GPU to generate unhinted v1 rollouts and turn them into **AggreVaTe/DAgger recovery trajectories** directly targets this bottleneck.

|  |  |  |  |  |
|----|----|----|----|----|
| **Study & Year** | **Public URL** | **Finding on Composition / Mixing / Weighting** | **Quantified Effect (≤9B / Analog)** | **Status** |
| **Revisiting DAgger in LLM-Agents** (May 2026)<sup>6</sup> | https://arxiv.org/html/2605.12913v1 | Mixture rollouts <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image5.png" style="width:2.09619in;height:0.219in" /> with teacher labeling student-visited states (turn-level DAgger or trajectory-level AggreVaTe) | **Qwen3-4B**: SFT 22.9% → AggreVaTe 24.5% → **DAgger 27.3% (+4.4 pp)**; **Qwen3-8B**: SFT 23.4% → **DAgger 29.8% (+6.4 pp)** on SWE-bench Verified | {verified in source} |
| **OracleImitator** (Nov 2026)<sup>7</sup> & **PTD** (Jun 2026)<sup>8</sup> | https://arxiv.org/html/2611.26598v1 / https://arxiv.org/html/2606.07000v2 | Answer-revealing/privileged hints induce unrecoverable conditional ambiguity <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image15.png" style="width:0.94564in;height:0.21822in" /> and shortcut-like teacher traces | Complete solution hints caused the largest token <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image1.png" style="width:0.17855in;height:0.22056in" />NLL shift and shortcut behavior vs structured hints | {verified in source} |
| **DMAST** (Mar 2026)<sup>26</sup> | https://arxiv.org/html/2603.04364v2 | Oracle-guided CoT risks **privilege leakage** (referencing hints unavailable at test time); filtering leaked phrases is essential | Auditing eliminated privilege-leak phrases and lifted Stage 2 TSR (19.5% → 23.3% MiniWob++, 5.1% → 8.2% VisualWebArena) | {verified in source} |
| **HinT-SD** (May 2026)<sup>27</sup> & **WebKD** (Oct 2026)<sup>28</sup> | https://arxiv.org/html/2605.17873v1 / https://arxiv.org/html/2610.19834v1 | Localizing failure-relevant steps in student rollouts and applying teacher corrective supervision only on those turns beats full offline SFT | HinT-SD outperformed SFT by **+13.4 pp (BFCL v3 Avg@4)** and **+11.6 pp (AppWorld Avg@4)** at 2.26× lower step time vs dense per-turn feedback | {verified in source} |
| **ATLaS** (Mar 2025)<sup>29</sup> | https://arxiv.org/pdf/2503.02197 | Keeping full context as input but computing loss only on ~30% critical steps (Plan Creation, Critical Observation, Critical Action, Self-Correction) beats 100%-step SFT | Llama-3.1-8B consistently beat full-trajectory SFT on both held-in and held-out agent tasks | {verified in source} |
| **JET** (Nov 2026)<sup>31</sup> | https://arxiv.org/html/2611.22539v1 | Uniform SFT underweights short halting/submission turns; normalized halting weight <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image2.png" style="width:1.02181in;height:0.21896in" /> sharpens stopping decisions without inflating loss | Preserves task score while reducing unnecessary tool calls via weighted CE | {verified in source} |
| **Exploring Expert Failures (EEF)** (Apr 2025)<sup>32</sup> & **AgentHER** (Mar 2026)<sup>33</sup> | https://arxiv.org/html/2504.13145v2 / https://arxiv.org/html/2603.21357v4 | Raw failed rollouts hurt standard SFT; failures help only when mining verified sub-actions (EEF) or relabeling minor errors (w ≥ 0.3) for DPO (AgentHER) | Recovers utility from 60–75% discarded rollouts only after discarding major/irrecoverable errors (w \< 0.3) | {verified in source} |
| **AgentTuning** (2023)<sup>21</sup> & **Gemma 4 Docs** (Google, 2026)<sup>10</sup> | https://arxiv.org/html/2310.12823v2 / https://gemma.ai/tuning/best-practices/ | Pure narrow-agent SFT risks forgetting; Google's Gemma 4 tuning docs advise 5%–15% general replay data | AgentTuning found mixing general ShareGPT data (η = 0.2 agent) outperformed 100% agent-only SFT on unseen tasks at 7B | {verified in source} |

<img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image12.png" style="width:6.45833in;height:6.35417in" />

### Evidence-Backed Composition & Per-Turn Weighting Recipe

Given your 31B teacher plus 24/7 free local 16 GB GPU rollouts, the best-supported **60-trajectory v2 corpus** shifts away from 100% hinted teacher traces toward a balanced three-tier mix {inferred by you}:

First, retain **~45% (~27 trajectories, 1 per task) of clean hinted 31B teacher solves**, but run a deterministic regex/LLM audit to strip privilege-leak phrases (any CoT mentioning a hint rather than grounding file discovery in the issue text or grep output) {verified audit pattern in}<sup>26</sup>. Second, construct **~35% (~21 trajectories) of AggreVaTe student-prefix → teacher-recovery traces**: roll out LoRA v1 *unhinted* locally on the remaining training tasks until it hits a realistic failure state (wrong file inspected, failing pytest traceback, or syntax/edit error after 3–6 turns), then hand that exact prefix to your 31B teacher (providing the golden hint only to the teacher and omitting it from the saved transcript) to diagnose, repair, pass tests, and emit submit_patch. Mask loss to **w = 0.0 on all erroneous student turns** and compute cross-entropy strictly on the teacher's recovery turns {verified mechanism in}<sup>6</sup>. Third, add **~20% (~12 trajectories) of on-policy v1 successes** sampled locally at T = 0.6–0.8 that pass all 8 guards, strictly enforcing a **cap of ≤2 total trajectories per task instance** (teacher + student combined) to prevent SWE-Gym's easy-task skew {verified cap rule in}<sup>14</sup>. Include **0% raw unrecovered failures** in SFT {verified in source}<sup>11</sup>. (Optionally mix 4–6 clean Python/CoT general-reasoning replay samples, ~8% of corpus, per Google's Gemma 4 tuning guide<sup>10</sup>, though at 2 epochs with dropout this is secondary.)

For per-turn weighting, adopt JET's normalized weighted cross-entropy so upweighting pivotal turns shifts gradient allocation without inflating effective step size {verified equation in}<sup>31</sup>:

<img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image6.png" style="width:6.45833in;height:0.68872in" />

Assign w_t = 0.0 to user/tool observations and erroneous student prefix turns, w_t = 1.0 to routine read/search assistant turns, **w_t = 1.5** to post-traceback self-correction and patch-edit turns, and **w_t = 2.0** to the final verified submit_patch halting turn {inferred weights from}<sup>29</sup>.

## 3. LoRA Specifics on Small Data (\<100k–200k Tokens) & the Gemma 4 E4B Layer Trap

Your v1 configuration (r = 8, alpha = 16, lr = 7e-5, 7 linear projections on layers \[23, 29, 30, 35, 41\]) chose the right module family (Attention + MLP), but ran directly into an architectural trap specific to Gemma 4 E4B alongside well-documented depth and learning-rate penalties in small-data LoRA literature.

|  |  |  |  |  |
|----|----|----|----|----|
| **Study / Doc & Year** | **Public URL** | **Architectural / Hyperparameter Finding** | **Relevance to Gemma 4 E4B (\<200k Tokens)** | **Status** |
| **vLLM llm-compressor \#3523** (2026)<sup>3</sup> & **MLX / E4B Atlas** (2026)<sup>4</sup> | https://github.com/vllm-project/llm-compressor/issues/3523 / https://huggingface.co/datasets/juiceb0xc0de/gemma-4-e4b-it-atlas | Engineering issue reports confirm E4B sets num_kv_shared_layers = 18: **layers 0–23 own K/V projections; layers 24–41 reuse shared_kv_states and never run their own k_proj/v_proj in forward.** Global layers also tie K = V<sup>1</sup> | **Direct v1 bottleneck:** 4 of 5 v1 layers (29, 30, 35, 41) sit inside 24–41 (inert K/V adapters) while KV-producing layers 0–22 were frozen | {verified in source} |
| **Gemma 4 Best Practices** (Google, 2026)<sup>10</sup> | https://gemma.ai/tuning/best-practices/ | Official vendor guidance: **keep Per-Layer Embeddings (PLE) frozen** during LoRA; train in bf16; standard LoRA LR 2e-4 (10× FullFT 1e-5); expect higher starting CE loss on E4B (normal—do not abort or spike LR) | Validates bf16 dequant, freezing PLE, and raising LR above 7e-5 | {verified in source} |
| **LoRA Without Regret** (Thinking Machines Lab, Sep 2025)<sup>36</sup> & **Qwen3-4B Repro**<sup>38</sup> | https://thinkingmachines.ai/blog/lora/ / https://github.com/michaelbzhu/lora-without-regret | Research blog study shows LoRA matches FullFT iff applied to **all layers, especially MLPs** (Attn-only r=256 loses to MLP-only r=128), capacity \> dataset bits, and LR ≈ **10× FullFT** (~15× for \<100 steps); independent Qwen3-4B repro peaked at 1.2e-4 (r=1) to 2.5e-4 (r=256) | Contradicts 5-layer subset; confirms r=8–16 is far above capacity limits at \<200k tokens; supports 1.2e-4 LR | {verified in source} |
| **LoRA Learns Less and Forgets Less** (Biderman et al., 2024)<sup>39</sup> | https://arxiv.org/html/2405.09673v1 | On code/math (Llama-2-7B): **All \> MLP \> Attention**; target modules matter more than rank; optimal code LoRA LR ~10× FullFT (5e-4 vs 5e-5); r=16 on All modules is optimal tradeoff | Strongly supports full-depth All-module LoRA at r=16 | {verified in source} |
| **Adaptive-LoRA** (Oct 2026)<sup>40</sup>, **Aletheia** (Apr 2026)<sup>42</sup> & **Mid-Layer Study** (Jul 2025)<sup>44</sup> | https://arxiv.org/html/2610.34756v1 / https://arxiv.org/html/2604.15351v1 / https://arxiv.org/html/2507.17075v4 | MLP mediates **58.4%** of LoRA causal effect vs 41.6% Attn; top **30%–50% of layers** carry \>80% gradient signal (L0–L2 universally important + task-specific mid/upper layers); middle layers (17–32) yield better coding/reasoning-safety tradeoffs than early or late layers alone | 5/42 layers (11.9%) sits well below the 30–50% active-signal band | {verified in source} |
| **LoRA Dropout** (Lin et al., 2024)<sup>46</sup> & **Small-Data LoRA** (Sep 2026)<sup>47</sup> | https://arxiv.org/html/2404.09610v1 / https://arxiv.org/html/2609.13918v1 | Dropout on LoRA matrices acts as weighted L2 regularization (+2.9 pp on small RTE benchmark); lora_dropout = 0.05 is standard on small datasets (N=360) | Supports lora_dropout = 0.05 + weight_decay = 0.01 at \<200k tokens | {verified in source} |
| **NEFTune** (Jain et al., 2024)<sup>48</sup> vs **LoRA+NEFTune Audit** (Feb 2025)<sup>49</sup> & **NER/QA**<sup>50</sup> | https://arxiv.org/html/2310.05914v2 / https://arxiv.org/html/2502.05087v3 | Original NEFTune boosted FullFT single-turn chat (with strong verbosity increase); minor +1–2% gains appeared on single-turn NER/QA (α=0.1–5)<sup>50</sup>, **but a controlled LoRA audit found NEFTune neither reduced memorization nor improved accuracy—highest accuracy occurred at noise = 0**<sup>49</sup> | **Skip NEFTune.** No published evidence of benefit on multi-turn coding-agent LoRA; risks JSON drift and frozen-PLE mismatch | {verified in source} |

<img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image13.png" style="width:6.45833in;height:3.52083in" />

### Concrete Guidance on Depth, Rank, Alpha, LR, Dropout, and Noise Injection

Expanding from 5 upper layers to **all 42 layers' active linear projections**—specifically q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj across layers 0–23 (skipping v_proj on global layers \[5, 11, 17, 23\] if attention_k_eq_v=True in your checkpoint config), and q_proj, o_proj, gate_proj, up_proj, down_proj across layers 24–41, while freezing all per_layer\* PLE tables and vision/audio towers—resolves both the KV-sharing dead zone and the full-depth MLP+Attention requirement {inferred by you from}<sup>3</sup>. On 4×L4 (96 GB total VRAM), a dequantized bf16 Gemma 4 E4B model (~16 GB weights) with an r = 16 full-stack adapter adds less than ~1 GB of adapter weights plus AdamW state and fits comfortably inside your 0.3h run for ~60 trajectories (~180k–220k active tokens) {inferred by you from}<sup>52</sup>.

Set **r = 16, lora_alpha = 32** (alpha / r = 2.0), **lora_dropout = 0.05**, and **weight_decay = 0.01**, with **NEFTune disabled (0.0)**. At \<250k supervised tokens, r = 16 across all 42 layers sits comfortably above the information-capacity threshold<sup>36</sup> while keeping LoRA's implicit low-rank regularization against unintended memorization<sup>49</sup>. (Practitioner claims that "coding requires r = 64 or 128" are FOLKLORE at \<250k tokens: rank bottlenecks in Biderman et al.<sup>39</sup> and Thinking Machines<sup>36</sup> emerge only on multi-million-token / 100k-example datasets.) Raise your peak learning rate from 7e-5 to **1.2e-4** with 10% linear warmup and cosine decay to 1.2e-5: Google's Gemma 4 guide recommends 2e-4<sup>10</sup> and the Qwen3-4B reproduction peaked at 1.2e-4–2.5e-4<sup>38</sup>, so 1.2e-4 captures the ~10× FullFT regime while hedging against the larger aggregate residual-stream update of 42 adapted layers on a QAT-dequantized checkpoint {inferred by you}.

## 4. Post-SFT Preference / RL Step (DPO / KTO / GRPO / Self-Improve Loops): Plain Verdict

**Plain Verdict: NO — do NOT spend one of your two remaining training runs on online GRPO or offline trajectory-level DPO/KTO.** At ≤9B parameters with \<100 unique tasks and a 0.3h cloud budget, online GRPO is both compute-infeasible and empirically near-zero on 4B–8B SWE agents (+0.4 to +0.5 pp over base), while offline trajectory-level DPO/KTO on \<50 pass/fail pairs carries a substantial risk of probability collapse and regression {verified in source}<sup>6</sup>. Your second remaining adapter run (v3) has markedly higher expected ROI as **DAgger / capped Rejection-Sampling SFT Round 2**.

|  |  |  |  |  |  |
|----|----|----|----|----|----|
| **Method & Study (Year)** | **Public URL** | **Model Size & Data Scale** | **Concrete Result on ≤9B Coding / Agent Tasks** | **Feasibility in 0.3h / \<100 Tasks** | **Status** |
| **GRPO (Online RLVR)** — *Revisiting DAgger* (May 2026)<sup>6</sup> | https://arxiv.org/html/2605.12913v1 | Qwen3-4B & Qwen3-8B (SkyRL-v0 RL vs SWE-Gym SFT/DAgger) | **4B: 11.2% → 11.6% (+0.4 pp)** vs SFT 22.9% & DAgger 27.3%; **8B: 7.7% → 8.2% (+0.5 pp)** on SWE-bench Verified | **Infeasible.** Requires parallel Docker rollouts + long horizon; all-fail groups cause advantage collapse<sup>8</sup> | {verified in source} |
| **RLVR / GRPO vs SRL** (Oct 2025)<sup>57</sup> | https://arxiv.org/html/2510.25992v1 | Qwen2.5-7B (1k hard tasks / 5k SWE trajs) | Authors report *"While RLVR can improve generalization over SFT, the gains are marginal"* under sparse binary rewards | **Poor ROI** at 99 tasks with ~17% student solve rate | {verified in source} |
| **RAFT++ vs GRPO** (Apr 2025)<sup>58</sup> | https://arxiv.org/pdf/2504.11343 | Llama-3.2-3B & Qwen2.5-Math-7B | **Rejection-sampling fine-tuning (RAFT/RFT) learns faster in early compute budgets**; GRPO overtakes only after large rollout budgets | **Favors RFT/DAgger** under a 0.3h budget | {verified in source} |
| **Trajectory DPO (ETO) vs Step CSO** (Feb 2026)<sup>59</sup> | https://arxiv.org/html/2602.03412v2 | 7B–8B multi-turn agents | Trajectory-level ETO yields +3.0 pp over SFT (38.9%) due to coarse credit assignment; step-level CSO beats it but needs K=5 branching rollouts per step | **High credit-assignment noise** on \<50 pass/fail pairs | {verified in source} |
| **DPOP / DPO Failure Modes** (Pal et al., 2024<sup>55</sup>; Survey 2024<sup>56</sup>; SamPO 2024<sup>60</sup>; Co-Evo 2025<sup>54</sup>) | https://arxiv.org/html/2402.13228v1 / https://arxiv.org/html/2410.15595v3 | 7B–8B preference optimization | Close chosen/rejected pairs drive **both chosen and rejected probabilities downward**<sup>55</sup>; DPO implicit-reward models drop -3% avg / -7% max OOD<sup>56</sup>; length bias<sup>60</sup> & win≪loss instability<sup>54</sup> | **High regression risk** on \<100 overlapping repo trajectories | {verified in source} |
| **Small-N Preference / KTO Evidence** (Aug 2026)<sup>62</sup> | https://arxiv.org/html/2608.30902v1 | Small LLMs (n = 10–1,000 seed pairs) | *No independent benchmark was found demonstrating KTO gains on ≤9B coding agents at N\<100.* Even in probe-expanded preference pipelines, gains only begin rising past **100+ labeled pairs** (plateau ~500), and small models degenerate under noisy preference labels | **Unverified & marginal** at your N | {verified in source} |
| **Agentic-DPO** (Jul 2026)<sup>64</sup> | https://arxiv.org/html/2607.10601v1 | Qwen3.5-2B / 4B / 9B (ToolBench / τ-bench / Mind2Web) | 4B: SFT 46.2% → Agentic-DPO 68.4%, **but requires multi-round step-level hard negatives + SFT anchor (L_ADPO + λ L_SFT) + schema perturbation** | Does not transfer to single-run trajectory DPO on 30–40 tasks | {verified in source} |
| **Iterative On-Policy RFT** — *SWE-Gym* (2024/2025)<sup>11</sup> | https://arxiv.org/html/2412.21139v2 | Qwen2.5-Coder-7B (MoatlessTools) | Two rounds of capped on-policy SFT: 7.0% → 9.0% → 10.0% (+3.0 pp), cutting empty patches 56.3% → 23.3% | **Directly fits v2 → v3** using free local 16 GB GPU | {verified in source} |

Mechanistically, preference optimization breaks down at your scale because on 99 training tasks (where the student solves ~15–20% and the hinted teacher solves ~27%), you can form at most ~30–40 task-matched pass/fail pairs. In multi-turn repo debugging, passing and failing trajectories frequently share 60–80% identical opening inspection turns before diverging on one patch hunk or test check. Vanilla trajectory-level DPO pushes down the log-probability of *every* token in the rejected rollout—including valid grep and file-inspection calls—triggering DPOP's simultaneous probability collapse {verified in source}<sup>55</sup> and verbosity/length bias {verified in source}<sup>60</sup>. Reserving v3 for **DAgger Round 2** (sampling failures from v2 locally → teacher recovery → clean joint SFT from base) avoids these failure modes completely {inferred by you}.

## 5. Adapter Merging (TIES / DARE / Task-Vector Merging): Failure Modes & Verdict

**Verdict: NO — merging separate "formatting prior" and "logic" LoRAs is very unlikely to beat training one unified adapter on the combined ~60-trajectory corpus.** No primary benchmark in the retrieved literature directly tests merging a dedicated "formatting prior" LoRA with a "logic" LoRA on coding agents; however, audited 2026 same-base LoRA merging studies demonstrate that even the strongest post-hoc mergers suffer a **-6.7 to -8.5 pp coding drop** on HumanEval, while DARE drops **-17.1 pp** {verified in source}<sup>65</sup>.

|  |  |  |  |  |
|----|----|----|----|----|
| **Study / Doc & Year** | **Public URL** | **Finding on LoRA Merging (TIES / DARE / TA / SVD)** | **Concrete Numbers & Failure Modes** | **Status** |
| **Audited LoRA Merging** (Nov 2026)<sup>65</sup> | https://arxiv.org/html/2611.10684 | Audited 4-adapter LoRA merges on Llama-3.1-8B-Instruct (replicated on Mistral-7B-v0.3): Naive, TA (λ=0.5), TIES (d=0.5), DARE (d=0.5), MagMax | **HumanEval pass@1:** Base 62.8% → TA 56.1% (-6.7 pp), TIES 54.3% (-8.5 pp), **DARE 45.7% (-17.1 pp)**, Naive 44.5% (-18.3 pp) | {verified in source} |
| **KnOTS** (Stoica et al., Oct 2024)<sup>66</sup> & **DO-Merging** (May 2025)<sup>67</sup> | https://arxiv.org/pdf/2410.19735 / https://arxiv.org/html/2505.15875v1 | LoRA updates have much lower CKA alignment and wider magnitude variance than FullFT, causing standard FFT mergers to degrade unless SVD-aligned | Naive/FFT LoRA merging trails SVD-aligned KnOTS/DO-Merging by 3%–4.3% | {verified in source} |
| **PICO** (Apr 2026)<sup>68</sup> & **Factor Cross-Term Study** (Oct 2026)<sup>69</sup> | https://arxiv.org/pdf/2604.16826 / https://arxiv.org/html/2610.31017 | Output matrix <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image10.png" style="width:0.1735in;height:0.21433in" /> over-accumulates shared directions; merging <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image11.png" style="width:0.16081in;height:0.22513in" /> and <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image10.png" style="width:0.1735in;height:0.21433in" /> factors separately injects spurious <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image8.png" style="width:0.4668in;height:0.21784in" /> cross-terms and <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image16.png" style="width:0.49544in;height:0.21676in" /> scale collapse | Naive <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image14.png" style="width:0.40983in;height:0.22068in" /> factor averaging lowers open-book retention by **17.6–34.8 points** vs properly scaled update merging | {verified in source} |
| **DARE** (Yu et al., ICML 2024)<sup>70</sup> | https://arxiv.org/html/2311.03099v3 | Explicit failure boundary: *"DARE can work well when absolute values of SFT delta parameters are small (within 0.002); otherwise DARE may fail"*; drop-rate tolerance shrinks on smaller models | High-LR LoRA deltas on 4.5B models frequently violate the ≤0.002 small-delta condition | {verified in source} |
| **TIES-Merging** (Yadav et al., NeurIPS 2023)<sup>71</sup> & **HF PEFT Guide**<sup>72</sup> | https://arxiv.org/pdf/2306.01708 / https://huggingface.co/blog/peft_merging | Full-model TIES trims to top-20% (k=0.2); HF PEFT LoRA docs recommend **cat first**, then linear or ties (density=0.5, majority_sign_method="frequency"), and warn **dare_ties performs poorly** | Rank mismatch throws early errors in non-SVD methods<sup>74</sup>; safe_merge=True needed to catch NaNs<sup>73</sup> | {verified in source} |
| **PEFT GitHub Issues** (2026)<sup>76</sup> | https://github.com/huggingface/peft/issues | **\#4133**: add_weighted_adapter silently drops layers when target filters differ; **\#4169**: ties/dare_ties elect sign *before* applying weights; **\#4178**: silent no-op on existing adapter name | Merging v1 (5 layers) with v2 (42 layers) triggers silent layer dropping | {verified in source} |

<img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image9.png" style="width:6.45833in;height:6.51042in" />

Because your entire ~60-trajectory dataset trains jointly in **one 0.3h run**, joint SFT strictly dominates splitting data across two adapters and merging them afterward {inferred by you}. Only if you decide to test a zero-training-cost merge between two *identically structured* adapters (same 42-layer config, same r = 16, e.g., an Epoch-1.5 vs Epoch-2.0 soup, or a formatting-heavy + logic-heavy pair) should you merge at all—and in that case, avoid dare_ties, dare_linear, and factor-level ties. Use PEFT's **cat** method first (exact additive update <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image4.png" style="width:1.67269in;height:0.21818in" /> at rank 2r with zero <img src="f:\AI\Benchmark\research_briefs\media\Small Coding Agent LoRA Optimization/media/image8.png" style="width:0.4668in;height:0.21784in" /> cross-terms), or **ties_svd** computed in float32 (density k = 0.5, majority_sign_method = "frequency", scaling lambda = \[0.35, 0.65\] weighting logic over formatting), followed by merge_and_unload(safe_merge=True) to guard against NaNs {verified PEFT API & density in}<sup>65</sup>; {asymmetric lambda & float32 SVD guard inferred}.

## 6. Small-Context Regime: 512-Token Local Window & 497-Token System Prompt vs. Prompt Distillation

In Gemma 4 E4B, 35 of 42 layers enforce a 512-token sliding window while only 7 global layers (\[5, 11, 17, 23, 29, 35, 41\]) attend across full history using K = V compression and proportional RoPE (p = 0.25) {verified in source}<sup>1</sup>. A 497-token system prompt therefore occupies **97.1% of the 512-token local window on Turn 0** (leaving only 15 tokens of local overlap with the GitHub issue) and **exits all 35 local layers completely by Turn 1** once the issue and initial bash output exceed 512 tokens—which happens on virtually every repo-level task (SWE-Gym averages ~18.6k tokens/trajectory) {verified in source}<sup>14</sup>. No primary benchmark directly compares ~100-token vs ~500-token system prompts with LoRA on a 512-token SWA coding agent; the closest evidence comes from prompt-baking, context-distillation, and interface-perturbation studies below.

|  |  |  |  |  |
|----|----|----|----|----|
| **Study & Year** | **Public URL** | **Evidence on Prompt Baking / Context Distillation + LoRA** | **Implication for 497-Token vs ~100-Token Prompt** | **Status** |
| **Prompt Baking** (Bhargava et al., Sep 2024)<sup>79</sup> | https://arxiv.org/html/2409.13697 | KL logit distillation bakes prompt behavior into weights (r² alignment 0.69 → 0.98; unseen SQuAD -16.24 → 0.96); **re-prompting a baked model (Prompt Pursuit) outperforms either alone**; requires a "critical mass" of logit supervision | Pure hard-label SFT on 60 trajectories lacks logit critical mass to replace all hard rules; hybrid baking + concise prompt is stronger | {verified in source} |
| **Context Distillation on Qwen3-8B** (Apr 2026)<sup>80</sup> | https://arxiv.org/pdf/2604.02339 | Evaluated baking natural-language operational rules into Qwen3-8B; **explicitly found LoRA performed worse than full-parameter distillation** for pure rule internalization | Do **not** rely on LoRA alone to memorize strict negative invariants ("never mutate test files") | {verified in source} |
| **Latent Memory & Self-Gating** (May 2026)<sup>81</sup> | https://arxiv.org/html/2605.28889v1 | Uncontrolled mixing of LoRA-baked memory and shifted explicit prompts degrades accuracy sharply (InfiniteICL fell 39.73 → 8.38 ROUGE-L under shift) | Never alter the system prompt between training and evaluation | {verified in source} |
| **Prefix Compression & Attention Sinks** (May 2026<sup>82</sup>; Sep 2026<sup>84</sup>) | https://arxiv.org/html/2605.18226v1 / https://arxiv.org/html/2609.02737v1 | Aggressive token compression collapses structural/label tokens<sup>83</sup>, whereas a **short fixed preamble** fills the attention sink cleanly and limits global-layer prefix decay<sup>82</sup> | Retain tool JSON schemas and binary-scoring guards in ~150–200 tokens; cut prose lectures | {verified in source} |
| **PIPE Interface Shortcutting** (Feb 2026)<sup>85</sup> | https://arxiv.org/html/2602.01611v1 | Trajectory-SFT agents develop high Interface Reliance and degrade under prompt/schema changes unseen during SFT | Any trimmed prompt shipped in v2 MUST replace the system header across 100% of v2 training traces | {verified in source} |

### Verdict for Q6: Hybrid ~175–200-Token Invariant Prompt Over Ultra-Short ~100-Token Stripping

Compressing down to **~100 tokens + LoRA is unlikely to outperform keeping 497 tokens + LoRA** at 60 trajectories, because LoRA underperforms full-parameter context distillation on rulebook internalization<sup>80</sup> and aggressive compression risks dropping exact tool-schema tokens<sup>83</sup>. However, **trimming 497 → ~175–200 tokens** offers a cleaner architectural win {inferred by you}: keep exact tool JSON signatures and hard binary-scoring invariants ("never touch test files", "verify all pytest suites pass before submit_patch", "emit valid JSON") so the 7 global layers retain a crisp attention-sink anchor<sup>84</sup>, while cutting ~300 tokens of multi-paragraph workflow advice that your 60 multi-turn trajectories already demonstrate directly into the weights. Crucially, you must swap the 497-token header for the exact ~175–200-token v2 prompt inside **every v2 training trajectory before training** (offline distillation from 497-token teacher → 180-token student)<sup>80</sup>; if you cannot sanity-check the trimmed header beforehand, keep the exact 497-token prompt for v2 rather than introducing train–test mismatch.

## 7. Highest-ROI Single Change per GPU-Hour & the \#1 Overfitting Trap

|  |  |  |  |  |
|----|----|----|----|----|
| **Question** | **Answer** | **Primary Evidence & Mechanism** | **Expected Impact** | **Status** |
| **ONE Change with Highest +Solves per Cloud GPU-Hour** | **Unlock all 42 layers' active Attention + MLP projections (fixing Gemma 4 E4B's dead KV-shared layers 24–41 & frozen 0–22) + raise LR to 1.2e-4** *(paired with free local-GPU AggreVaTe/DAgger recovery data)* | num_kv_shared_layers = 18 means 4/5 of v1 layers had inert K/V projections and layers 0–22 were frozen<sup>3</sup>; Thinking Machines & Biderman et al. show full-depth MLP+Attn + ~10× FullFT LR closes the LoRA-FullFT gap<sup>36</sup> | **~0 extra cloud GPU-hours** (fits inside same 0.3h run); removes an architectural ceiling worth **+1.5 to +3.0 solves** on 30 tasks | {verified mechanism} / {inferred delta} |
| **Highest Total +Solves Data Change (0 Cloud GPU-Hours)** | **Add ~21 AggreVaTe/DAgger recovery trajectories** (unhinted local v1 failure prefix → 31B teacher recovery, loss-masked on bad student turns) | *Revisiting DAgger* (May 2026) reports **+4.4 pp on 4B** and **+6.4 pp on 8B** over offline SFT on SWE-bench Verified<sup>6</sup>; mitigates hinted-teacher shortcutting<sup>7</sup> | **+1.5 to +2.5 solves** on 30 tasks (0 cloud GPU-hours via free local 16 GB GPU) | {verified mechanism} / {inferred delta} |
| **\#1 Most Common Overfitting Failure Mode (\<100 Trajectories)** | **Multi-epoch replay "forking" + easy-task / interface-shortcut memorization** (running \>2 epochs or uncapped easy tasks while chasing ±2-solve noise on a 30-task holdout) | *Forking* (Oct 2026)<sup>86</sup> shows validation loss diverges sharply at epoch boundaries—amplified by local token-embedding tables (PLE analog, even when frozen); SWE-Gym<sup>14</sup> shows cap\>2 drops 7B score -2.0 pp; PIPE<sup>85</sup> documents brittle interface shortcuts; SWE-smith<sup>16</sup> finds \>25% repetitive loops | Training loss drops steadily while private holdout solve rate degrades (-2 to -5 solves) | {verified in source} |

Teams at the 26–65 trajectory scale repeatedly fall into this overfitting trap because Epoch 1 and Epoch 2 improve cleanly, making it tempting to push to 4–5 epochs or dump dozens of locally generated easy-task passes into the corpus. As demonstrated by *Forking* (Oct 2026), replaying a narrow corpus causes train and validation loss to split abruptly at epoch boundaries—and architectures using local token-embedding lookup tables (directly analogous to Gemma 4 E4B's Per-Layer Embeddings, even when kept frozen) accelerate this replay-driven sharpening {verified in source}<sup>86</sup>. Paired with ±2.0 solves binomial noise on a 30-task holdout, teams mistake a lucky +1 swing on Epoch 4 for genuine progress and ship a memorized adapter that falls into 10-turn command loops<sup>16</sup> on unseen issues. Cap training strictly at **2 epochs** (matching the anti-overfitting reduction from 4 to 2 epochs reported for SWE-Lego on Qwen3-8B<sup>87</sup>), enforce **≤2 trajectories per task**, and save checkpoints at 1.5 and 2.0 epochs.

## Recommended v2 Configuration Block

Every line below fits strictly inside **one 0.3h wall-clock training run on 4×L4 (96 GB)** using dequantized bf16 weights (zero NF4/bitsandbytes) preceded by free 24/7 rollouts on your local 16 GB GPU.

|  |  |  |  |
|----|----|----|----|
| **Parameter** | **Recommended v2 Setting** | **Rationale / Mechanism** | **Confidence** |
| **Base Checkpoint & Precision** | gemma-4-e4b-it-qat-w4a16-ct dequantized to bf16; vision/audio towers & **PLE tables frozen** | Matches your prior empirical finding (bf16 vs NF4) and official Google Gemma 4 tuning docs<sup>10</sup> | **High** |
| **Total Corpus Size** | **60 clean trajectories** (~180k–220k active assistant tokens; ~2.0–2.4× v1 active tokens) | ~1.1–1.2 doublings of unique tasks (26–30 → 60) comfortably inside 0.3h on 4×L4<sup>12</sup> | **High** |
| **Composition %** | **45% (~27)** hinted teacher solves (privilege-leak audited, 1/task) + **35% (~21)** AggreVaTe student-failure→teacher-recovery + **20% (~12)** on-policy v1 successes (capped ≤2 total trajs/task) + **0%** raw failures | Mitigates hinted-teacher localization shift<sup>6</sup> and avoids SWE-Gym cap\>2 easy-task bias<sup>14</sup> | **High** |
| **Per-Turn Loss Weighting** | Normalized weighted CE (JET Eq. 5): 0.0 user/tool/bad student prefix; 1.0 routine search/read; 1.5 post-traceback self-correction & patch edits; 2.0 final submit_patch halting turn | Focuses gradient on decisive recovery and halting turns without inflating loss magnitude<sup>27</sup> | **Medium-High** |
| **Target Layers & Modules** | **All 42 layers (0–41)**: q,k,v,o,gate,up,down on layers 0–23 (skip v_proj on global \[5,11,17,23\] if attention_k_eq_v=True); q,o,gate,up,down on layers 24–41 (skipping unused k_proj/v_proj) | Fixes Gemma 4 E4B num_kv_shared_layers=18 trap<sup>3</sup> & satisfies full-depth MLP+Attn rule<sup>36</sup> | **High** |
| **LoRA Rank & Alpha** | r = 16, lora_alpha = 32 (alpha/r = 2.0), bias = "none" | Exceeds information capacity for \<250k tokens while preserving low-rank anti-memorization regularization<sup>36</sup> | **High** |
| **LoRA Dropout & Regularization** | lora_dropout = 0.05, weight_decay = 0.01, max_grad_norm = 1.0, **NEFTune = OFF (0.0)** | Weighted L2 guard for small data<sup>46</sup>; avoids NEFTune LoRA null/regression result<sup>49</sup> | **Medium-High** |
| **Epochs & Batch Size** | **2 epochs** (save at 1.5 and 2.0 epochs); effective batch size **4 trajectories** (1/GPU × 4 L4, grad_accum = 1 → **30 optimizer steps**; or ~60–120 steps if chunked into independent packed windows) | Prevents Epoch 3+ replay forking<sup>86</sup>; small-to-moderate batch size avoids LoRA instability<sup>88</sup> | **High** |
| **LR & Schedule** | Peak **lr = 1.2e-4**, AdamW (β₁=0.9, β₂=0.95), **10% linear warmup**, **cosine decay to 1.2e-5** (min LR ratio 0.1) | Aligns with ~10× FullFT LoRA rule<sup>10</sup>, tempered from 2e-4 for 42-layer QAT stability | **Medium-High** |
| **System Prompt** | **Strict train–test parity:** Trim to **~175–200 tokens** (hard invariants + tool JSON schemas only) *only if* re-headered across all 60 v2 training traces; otherwise keep 497 tokens unchanged | Frees Turn-0 local window without risking LoRA rule-forgetting or interface shift<sup>80</sup> | **Medium** |
| **Post-SFT Plan (for v3)** | **Skip DPO/KTO/GRPO & Merging.** Reserve v3 for **DAgger Round 2** (local v2 failure prefixes → 31B teacher recoveries → ~80–90 total trajs, fresh LoRA from base) | Leverages +4.4 pp DAgger advantage on 4B<sup>6</sup>; avoids DPO collapse<sup>55</sup> and merge coding loss<sup>65</sup> | **High** |

## Ranked Top-5 Changes by Expected Solve Delta (30-Task Holdout)

Individual deltas below are non-additive upper-bound estimates ({inferred by you} from 4B–8B benchmarks<sup>3</sup>); combined realistic v1 → v2 target is **5/30 → 8–10/30 (27%–33%)**.

1.  **Expand LoRA from 5 Upper Layers (\[23,29,30,35,41\]) to All 42 Active Layers (Fixing Gemma 4 E4B's Shared-KV Trap) + Raise LR (7e-5 → 1.2e-4)** — *Expected Delta: +1.5 to +3.0 solves (+5 to +10 pp) \| Extra Cloud Cost: ~0h (same 0.3h run).* Unlocks KV-producing layers 0–22, eliminates inert K/V adapters on 24–41, and moves MLP+Attention adaptation into the FullFT-matching regime<sup>3</sup>.

2.  **Add ~21 AggreVaTe/DAgger Recovery Trajectories (Unhinted Local v1 Failure Prefix → 31B Teacher Recovery, Masked Bad Turns)** — *Expected Delta: +1.5 to +2.5 solves (+5 to +8 pp) \| Extra Cloud Cost: 0h (rollouts generated on free local 16 GB GPU).* Directly addresses the hinted-teacher localization shift and trains traceback recovery (+4.4 pp verified on Qwen3-4B SWE-bench Verified<sup>6</sup>).

3.  **Add ~12 Capped On-Policy v1 Successes (Strictly ≤2 Total Trajectories per Task) + Audit/Strip Privilege-Leak Phrases from Teacher CoT** — *Expected Delta: +0.5 to +1.5 solves (+2 to +5 pp) \| Extra Cloud Cost: 0h (free local GPU).* Safely doubles unique-task coverage (26–30 → 60) while preventing SWE-Gym's cap\>2 degradation (-2.0 pp<sup>14</sup>) and DMAST's oracle-hint leakage<sup>26</sup>.

4.  **Apply Normalized Critical-Turn Loss Weighting (1.5× Recovery/Edit, 2.0× Final submit_patch Halting Turn) + lora_dropout = 0.05** — *Expected Delta: +0.5 to +1.0 solves (+2 to +3 pp) \| Extra Cloud Cost: 0h.* Prevents short decisive edit and halting tokens from being drowned out across ~19-turn transcripts<sup>29</sup> and regularizes small-data adaptation<sup>46</sup>.

5.  **Trim System Prompt (497 → ~180 tokens) with Mandatory Train–Test Re-Headering (Offline Context Distillation)** — *Expected Delta: +0.0 to +0.8 solves (+0 to +2.5 pp, higher variance) \| Extra Cloud Cost: 0h.* Frees ~315 tokens of Turn-0 512-token local attention for the issue statement while preserving hard invariants in global layers<sup>82</sup>; execute *only* if uniformly applied to 100% of v2 training trajectories<sup>85</sup>.

## Explicit Do-Not-Do List at This Data Scale

- **DO NOT train for 3–5 epochs** on 60 trajectories—you risk replay-aligned "forking"<sup>86</sup>, interface shortcutting<sup>85</sup>, and \>25% repetitive command loops<sup>16</sup>. Stop at 2 epochs.

- **DO NOT spend v2 or v3 on online GRPO or offline trajectory-level DPO/KTO**—GRPO adds +0.4 pp at 4B<sup>6</sup> and exceeds your 0.3h budget, while trajectory DPO on \<50 overlapping repo-debugging pairs triggers DPOP probability collapse and length hacking<sup>55</sup>.

- **DO NOT split your corpus into separate "formatting" and "logic" LoRAs for TIES/DARE merging**—even optimal Task Arithmetic and TIES lose 6.7–8.5 pp on HumanEval coding (-17.1 pp for DARE)<sup>65</sup>, and merging mismatched 5-layer and 42-layer adapters triggers PEFT's silent layer-drop bug (peft#4133)<sup>76</sup>.

- **DO NOT attach LoRA to k_proj/v_proj in layers 24–41 or unfreeze Per-Layer Embeddings (PLE)** on Gemma 4 E4B—layers 24–41 reuse earlier KV states<sup>3</sup>, and Google's Gemma 4 tuning docs explicitly instruct keeping PLE frozen during LoRA<sup>10</sup>.

- **DO NOT include \>2 trajectories from the same training task** (even if your local 16 GB GPU yields dozens of easy passes)—SWE-Gym's 7B capping ablation showed cap=3 reversed resolve rates by -2.0 pp<sup>14</sup>.

- **DO NOT compute SFT loss on raw unrecovered failure trajectories**—either discard them or convert their prefix into a teacher-completed recovery trajectory with loss masked to 0.0 on the erroneous student turns<sup>11</sup>.

- **DO NOT enable NEFTune**—controlled LoRA testing found no memorization reduction and highest accuracy at zero noise<sup>49</sup>, while adding verbosity<sup>48</sup> and PLE-mismatch risk.

- **DO NOT switch to an ultra-short (~100-token) prompt only at inference time** or strip hard test-integrity/JSON rules from the prompt—LoRA trails full fine-tuning on pure rulebook baking<sup>80</sup>, and train–test prompt shifts degrade trajectory-SFT agents<sup>81</sup>.

- **DO NOT over-react to ±1 solve swings on your 30-task holdout tournament** (1-sigma = ±2.0 solves); log **diagnostic leading indicators** alongside binary solves (empty-patch rate, stuck-in-loop rate, valid-JSON rate, and first-file localization recall<sup>11</sup>) to confirm real capability gains before launching v3.

#### Works cited

1.  Gemma 4 - LM Studio, [<u>https://lmstudio.ai/models/gemma-4</u>](https://lmstudio.ai/models/gemma-4)

2.  Gemma 4: Google DeepMind's Most Capable Open Multimodal, [<u>https://ai.plainenglish.io/gemma-4-google-deepminds-most-capable-open-multimodal-models-3a7f3e47e764</u>](https://ai.plainenglish.io/gemma-4-google-deepminds-most-capable-open-multimodal-models-3a7f3e47e764)

3.  GPTQ and AWQ fail on Gemma-4 E2B/E4B: KV-shared layers (no, [<u>https://github.com/vllm-project/llm-compressor/issues/3523</u>](https://github.com/vllm-project/llm-compressor/issues/3523)

4.  juiceb0xc0de/gemma-4-e4b-it-atlas · Datasets at Hugging Face, [<u>https://huggingface.co/datasets/juiceb0xc0de/gemma-4-e4b-it-atlas</u>](https://huggingface.co/datasets/juiceb0xc0de/gemma-4-e4b-it-atlas)

5.  Gemma 4 E2B/E4B QAT checkpoints fail to load: KV-shared layers, [<u>https://github.com/ml-explore/mlx-swift-lm/issues/338</u>](https://github.com/ml-explore/mlx-swift-lm/issues/338)

6.  Revisiting DAgger in the Era of LLM-Agents - arXiv, [<u>https://arxiv.org/html/2605.12913v1</u>](https://arxiv.org/html/2605.12913v1)

7.  Active Feature Acquisition by Distilling an Oracle Teacher - arXiv, [<u>https://arxiv.org/html/2611.26598v1</u>](https://arxiv.org/html/2611.26598v1)

8.  Privileged Tutoring Distillation for Multimodal Policy Optimization, [<u>https://arxiv.org/html/2606.07000v2</u>](https://arxiv.org/html/2606.07000v2)

9.  Gemma 4: What Computer Vision Engineers Actually Need to Know, [<u>https://datature.io/blog/gemma-4-what-computer-vision-engineers-actually-need-to-know</u>](https://datature.io/blog/gemma-4-what-computer-vision-engineers-actually-need-to-know)

10. Gemma 4 fine-tuning best practices, [<u>https://gemma.ai/tuning/best-practices/</u>](https://gemma.ai/tuning/best-practices/)

11. Training Software Engineering Agents and Verifiers with SWE-Gym, [<u>https://arxiv.org/html/2412.21139v2</u>](https://arxiv.org/html/2412.21139v2)

12. SWE-Dev: Building Software Engineering Agents with Training and, [<u>https://arxiv.org/html/2506.07636v1</u>](https://arxiv.org/html/2506.07636v1)

13. From SWE-Zero to SWE-Hero: Execution-free to Execution-based, [<u>https://arxiv.org/html/2604.01496v1</u>](https://arxiv.org/html/2604.01496v1)

14. Training Software Engineering Agents and Verifiers with SWE-Gym, [<u>https://arxiv.org/html/2412.21139v1</u>](https://arxiv.org/html/2412.21139v1)

15. Training Versatile Coding Agents in Synthetic Environments - arXiv, [<u>https://arxiv.org/html/2512.12216v1</u>](https://arxiv.org/html/2512.12216v1)

16. SWE-smith: Scaling Data for Software Engineering Agents - arXiv, [<u>https://arxiv.org/html/2504.21798v2</u>](https://arxiv.org/html/2504.21798v2)

17. Immersion in the GitHub Universe: Scaling Coding Agents to Mastery, [<u>https://arxiv.org/html/2602.09892v1</u>](https://arxiv.org/html/2602.09892v1)

18. R2E-Gym - Hugging Face, [<u>https://huggingface.co/R2E-Gym</u>](https://huggingface.co/R2E-Gym)

19. SWE-AGILE: A Software Agent Framework for Efficiently Managing, [<u>https://arxiv.org/html/2604.11716v1</u>](https://arxiv.org/html/2604.11716v1)

20. Evolving Curation Filters for High-Quality Agentic Coding Data - arXiv, [<u>https://arxiv.org/html/2610.23134v1</u>](https://arxiv.org/html/2610.23134v1)

21. AgentTuning: Enabling Generalized Agent Abilities for LLMs - arXiv, [<u>https://arxiv.org/html/2310.12823v2</u>](https://arxiv.org/html/2310.12823v2)

22. AgentBank: Towards Generalized LLM Agents via Fine-Tuning on, [<u>https://arxiv.org/html/2410.07706</u>](https://arxiv.org/html/2410.07706)

23. arXiv:2401.05268v4 \[cs.CL\] 26 May 2024, [<u>https://arxiv.org/pdf/2401.05268</u>](https://arxiv.org/pdf/2401.05268)

24. KnowAgent: Knowledge-Augmented Planning for LLM-Based Agents, [<u>https://arxiv.org/html/2403.03101v3</u>](https://arxiv.org/html/2403.03101v3)

25. AgentTuning: Enabling Generalized Agent Abilities for LLMs, [<u>https://aclanthology.org/2024.findings-acl.181.pdf</u>](https://aclanthology.org/2024.findings-acl.181.pdf)

26. Robustifying Multimodal Web Agents Against Cross-Modal Attacks, [<u>https://arxiv.org/html/2603.04364v2</u>](https://arxiv.org/html/2603.04364v2)

27. HinT-SD: Targeted Hindsight Self-Distillation for Long-Horizon Agents, [<u>https://arxiv.org/html/2605.17873v1</u>](https://arxiv.org/html/2605.17873v1)

28. Teaching Agents in their Own Style: Blackbox Teacher Distillation for, [<u>https://arxiv.org/html/2610.19834v1</u>](https://arxiv.org/html/2610.19834v1)

29. ATLaS: Agent Tuning via Learning Critical Steps - arXiv, [<u>https://arxiv.org/html/2503.02197v1</u>](https://arxiv.org/html/2503.02197v1)

30. ATLaS: Agent Tuning via Learning Critical Steps - arXiv, [<u>https://arxiv.org/pdf/2503.02197</u>](https://arxiv.org/pdf/2503.02197)

31. JET: Just-Enough Exploration Tuning for Efficient Tool-Calling, [<u>https://arxiv.org/html/2611.22539v1</u>](https://arxiv.org/html/2611.22539v1)

32. Exploring Expert Failures Improves LLM Agent Tuning - arXiv, [<u>https://arxiv.org/html/2504.13145v2</u>](https://arxiv.org/html/2504.13145v2)

33. Hindsight Experience Replay for LLM Agent Trajectory Relabeling, [<u>https://arxiv.org/html/2603.21357v4</u>](https://arxiv.org/html/2603.21357v4)

34. Gemma 4 Cheat Sheet & Quick Reference - CheatSheets.zip, [<u>https://cheatsheets.zip/gemma4</u>](https://cheatsheets.zip/gemma4)

35. Gemma-4-E4B-it fails to load · Issue \#299 - vllm-metal - GitHub, [<u>https://github.com/vllm-project/vllm-metal/issues/299</u>](https://github.com/vllm-project/vllm-metal/issues/299)

36. LoRA Without Regret - Thinking Machines Lab, [<u>https://thinkingmachines.ai/blog/lora/</u>](https://thinkingmachines.ai/blog/lora/)

37. LoRA Without Regret — Intermediate Paper (Free) - Rajesh Beri, [<u>https://www.beri.net/learning/thinking-machines-lora-without-regret</u>](https://www.beri.net/learning/thinking-machines-lora-without-regret)

38. michaelbzhu/lora-without-regret - GitHub, [<u>https://github.com/michaelbzhu/lora-without-regret</u>](https://github.com/michaelbzhu/lora-without-regret)

39. LoRA Learns Less and Forgets Less - arXiv, [<u>https://arxiv.org/html/2405.09673v1</u>](https://arxiv.org/html/2405.09673v1)

40. Layer Sparsity for Adaptive Fine-Tuning via Path Patching - arXiv, [<u>https://arxiv.org/html/2610.34756v1</u>](https://arxiv.org/html/2610.34756v1)

41. Layer Sparsity for Adaptive Fine-Tuning via Path Patching - arXiv, [<u>https://arxiv.org/pdf/2610.34756</u>](https://arxiv.org/pdf/2610.34756)

42. Aletheia: Gradient-Guided Layer Selection forEfficient LoRA Fine, [<u>https://arxiv.org/html/2604.15351v1</u>](https://arxiv.org/html/2604.15351v1)

43. Aletheia: Gradient-Guided Layer Selection for Efficient LoRA Fine, [<u>https://arxiv.org/pdf/2604.15351</u>](https://arxiv.org/pdf/2604.15351)

44. LoRA is All You Need for Safety Alignment of Reasoning LLMs - arXiv, [<u>https://arxiv.org/html/2507.17075v4</u>](https://arxiv.org/html/2507.17075v4)

45. LoRA is All You Need for Safety Alignment of Reasoning LLMs - arXiv, [<u>https://arxiv.org/html/2507.17075v3</u>](https://arxiv.org/html/2507.17075v3)

46. LoRA Dropout as a Sparsity Regularizer for Overfitting Control - arXiv, [<u>https://arxiv.org/html/2404.09610v1</u>](https://arxiv.org/html/2404.09610v1)

47. LoRA Fine-Tuned Models for Control Systems Course Q&A - arXiv, [<u>https://arxiv.org/html/2609.13918v1</u>](https://arxiv.org/html/2609.13918v1)

48. NEFTune: Noisy Embeddings Improve Instruction Finetuning - arXiv, [<u>https://arxiv.org/html/2310.05914v2</u>](https://arxiv.org/html/2310.05914v2)

49. Mitigating Unintended Memorization with LoRA in Federated ... - arXiv, [<u>https://arxiv.org/html/2502.05087v3</u>](https://arxiv.org/html/2502.05087v3)

50. Instruction Finetuning DeepSeek-R1-8B Model Using LoRA and, [<u>https://arxiv.org/pdf/2606.10392</u>](https://arxiv.org/pdf/2606.10392)

51. Fine-Tuning LLMs for Reliable Medical Question-Answering Services, [<u>https://arxiv.org/html/2410.16088v1</u>](https://arxiv.org/html/2410.16088v1)

52. LoRA vs full fine-tuning: when is LoRA good enough? \| Nodus Blog, [<u>https://www.nodus-compute.ai/blog/lora-vs-full-fine-tuning/</u>](https://www.nodus-compute.ai/blog/lora-vs-full-fine-tuning/)

53. wangzhang/gemma-4-E4B-it-abliterix - Hugging Face, [<u>https://huggingface.co/wangzhang/gemma-4-E4B-it-abliterix</u>](https://huggingface.co/wangzhang/gemma-4-E4B-it-abliterix)

54. Co-Evolving Agents: Learning from Failures as Hard Negative - arXiv, [<u>https://arxiv.org/html/2511.22254v1</u>](https://arxiv.org/html/2511.22254v1)

55. Fixing Failure Modes of Preference Optimisation with DPO-Positive, [<u>https://arxiv.org/html/2402.13228v1</u>](https://arxiv.org/html/2402.13228v1)

56. A Comprehensive Survey of Direct Preference Optimization - arXiv, [<u>https://arxiv.org/html/2410.15595v3</u>](https://arxiv.org/html/2410.15595v3)

57. Supervised Reinforcement Learning: From Expert Trajectories to, [<u>https://arxiv.org/html/2510.25992v1</u>](https://arxiv.org/html/2510.25992v1)

58. A Minimalist Approach to LLM Reasoning: from Rejection Sampling, [<u>https://arxiv.org/pdf/2504.11343</u>](https://arxiv.org/pdf/2504.11343)

59. Verified Critical Step Optimization for LLM Agents - arXiv, [<u>https://arxiv.org/html/2602.03412v2</u>](https://arxiv.org/html/2602.03412v2)

60. Eliminating Biased Length Reliance of Direct Preference ... - arXiv, [<u>https://arxiv.org/html/2406.10957v4</u>](https://arxiv.org/html/2406.10957v4)

61. Minor DPO reject penalty to increase training robustness - arXiv, [<u>https://arxiv.org/pdf/2408.09834</u>](https://arxiv.org/pdf/2408.09834)

62. Low-Resource Preference Adaptation of LLMs via Activation-Based, [<u>https://arxiv.org/html/2608.30902v1</u>](https://arxiv.org/html/2608.30902v1)

63. Low-Resource Preference Adaptation of LLMs via Activation ... - arXiv, [<u>https://arxiv.org/pdf/2608.30902</u>](https://arxiv.org/pdf/2608.30902)

64. From Imitation to Agentic Policy Optimization on Expert Trajectories, [<u>https://arxiv.org/html/2607.10601v1</u>](https://arxiv.org/html/2607.10601v1)

65. Audit Before You Merge: Provenance, Probing, and Continual LoRA, [<u>https://arxiv.org/html/2611.10684</u>](https://arxiv.org/html/2611.10684)

66. Model merging with svd to tie the knots - arXiv, [<u>https://arxiv.org/pdf/2410.19735</u>](https://arxiv.org/pdf/2410.19735)

67. Decouple and Orthogonalize: A Data-Free Framework for LoRA, [<u>https://arxiv.org/html/2505.15875v1</u>](https://arxiv.org/html/2505.15875v1)

68. Crowded in B-Space: Calibrating Shared Directions for LoRA Merging, [<u>https://arxiv.org/pdf/2604.16826</u>](https://arxiv.org/pdf/2604.16826)

69. What Open-Book Scores Measure in Document-Level LoRA Adapters, [<u>https://arxiv.org/html/2610.31017</u>](https://arxiv.org/html/2610.31017)

70. Absorbing Abilities from Homologous Models as a Free Lunch - arXiv, [<u>https://arxiv.org/html/2311.03099v3</u>](https://arxiv.org/html/2311.03099v3)

71. TIES-Merging: Resolving Interference When Merging Models - arXiv, [<u>https://arxiv.org/pdf/2306.01708</u>](https://arxiv.org/pdf/2306.01708)

72. PEFT welcomes new merging methods - Hugging Face, [<u>https://huggingface.co/blog/peft_merging</u>](https://huggingface.co/blog/peft_merging)

73. LoRA - Hugging Face, [<u>https://huggingface.co/docs/peft/v0.12.0/en/package_reference/lora</u>](https://huggingface.co/docs/peft/v0.12.0/en/package_reference/lora)

74. \[Discussion\] allow new merging methods from \`peft\` · Issue \#6892, [<u>https://github.com/huggingface/diffusers/issues/6892</u>](https://github.com/huggingface/diffusers/issues/6892)

75. Merge LoRAs - Hugging Face, [<u>https://huggingface.co/docs/diffusers/main/using-diffusers/merge_loras</u>](https://huggingface.co/docs/diffusers/main/using-diffusers/merge_loras)

76. Issues · huggingface/peft - GitHub, [<u>https://github.com/huggingface/peft/issues</u>](https://github.com/huggingface/peft/issues)

77. Google's Gemma 4 is Weirder than you Realize - Devansh, [<u>https://machine-learning-made-simple.medium.com/googles-gemma-4-is-weirder-than-you-realize-17d00d95b0d5</u>](https://machine-learning-made-simple.medium.com/googles-gemma-4-is-weirder-than-you-realize-17d00d95b0d5)

78. Remembering the Prompt — LLMs, from the beginning, [<u>https://ceres1.space/posts/llms-from-the-beginning/remembering-the-prompt/</u>](https://ceres1.space/posts/llms-from-the-beginning/remembering-the-prompt/)

79. Abstract - arXiv, [<u>https://arxiv.org/html/2409.13697</u>](https://arxiv.org/html/2409.13697)

80. SIEVE: Sample-Efficient Parametric Learning from Natural Language, [<u>https://arxiv.org/pdf/2604.02339</u>](https://arxiv.org/pdf/2604.02339)

81. Context Distillation as Latent Memory Management - arXiv, [<u>https://arxiv.org/html/2605.28889v1</u>](https://arxiv.org/html/2605.28889v1)

82. Context Memorization for Efficient Long Context Generation - arXiv, [<u>https://arxiv.org/html/2605.18226v1</u>](https://arxiv.org/html/2605.18226v1)

83. Context Memorization for Efficient Long Context Generation - arXiv, [<u>https://arxiv.org/pdf/2605.18226</u>](https://arxiv.org/pdf/2605.18226)

84. Language Models Can Control Their Own Attention - arXiv, [<u>https://arxiv.org/html/2609.02737v1</u>](https://arxiv.org/html/2609.02737v1)

85. What Do Agents Learn from Trajectory-SFT: Semantics or Interfaces?, [<u>https://arxiv.org/html/2602.01611v1</u>](https://arxiv.org/html/2602.01611v1)

86. Forking: Sudden Overfitting Under Replay - arXiv, [<u>https://arxiv.org/html/2610.00394v1</u>](https://arxiv.org/html/2610.00394v1)

87. Function-Aware Fill-in-the-Middle as Mid-Training for Coding Agent, [<u>https://arxiv.org/html/2607.12463v1</u>](https://arxiv.org/html/2607.12463v1)

88. LoRA Without Regret: A Practitioner's Guide to Reliable Fine-Tuning, [<u>https://www.ikangai.com/lora-without-regret-a-practitioners-guide-to-reliable-fine-tuning/</u>](https://www.ikangai.com/lora-without-regret-a-practitioners-guide-to-reliable-fine-tuning/)
