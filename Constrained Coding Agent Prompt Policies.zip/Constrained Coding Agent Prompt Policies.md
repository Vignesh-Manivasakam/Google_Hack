# Prompt- and Policy-Level Techniques Brief for a Fixed 9-Tool Coding Agent

Across 2024–2026 empirical evaluations on SWE-bench Verified, SWE-bench Pro, and Terminal-Bench 2.0, three findings map directly onto your 147-trace failure taxonomy (NoMatchError at 92.3% of tool errors, right-file logic failures at 37.2%, empty/no-edit runs at 30.8%, wrong-file localization at 24.4%, and prose-only turns at 29%). First, **prompt polarity and prefill discipline outperform verbose coaching**: a 2026 controlled study of coding-agent rules on SWE-bench Verified (Guardrails Beat Guidance, https://arxiv.org/pdf/2604.11088, Apr 2026) found that every individually beneficial rule is a *negative constraint* ("do not X") and that state-dependent process rules outperform generic architecture/style directives by 10.4 percentage points<sup>1</sup>, while a 2026 small-model prefill benchmark (https://arxiv.org/html/2610.02001, 2026) observed instruction-following degrade on 2–9B models whenever large, weakly relevant prefill stacks precede the task<sup>2</sup>. Second, **first-shot edit precision and fresh local context dominate under quantized budgets**: in a 2026 Kaggle Gemma-4 developer-agent competition writeup (https://www.kaggle.com/competitions/gemma-4-developer-agent-paper/writeups/from-local-validation-to-live-evaluation, 2026), 0 of 10 observed episodes recovered via a second edit after an initial pytest failure<sup>3</sup>, and Termination Lag (https://arxiv.org/pdf/2611.14960, Nov 2026) showed across five models that 38%–82% of solved SWE-bench runs already had the correct fix on their very first source edit<sup>4</sup>. Third, **part of your 29% prose-only turns may stem from vLLM's Gemma-4 serving/parser interaction rather than prompt disobedience**: upstream vLLM issues \#44522 (Jun 2026) and \#53431 (Aug 2026) document raw \<\|tool_call\> leaks into assistant text and silent turn drops on bare \<\|tool_call\>:name openers<sup>6</sup>.

Every technique below transfers strictly into your fixed 9-tool contract (run_command, read_file, edit_file, write_file, get_status, submit_patch, get_code_neighbors, search_similar_code, get_code_subgraph), declarative YAML prompt, and per-task config budgets—requiring zero harness rewrites, new tools, or external retrieval layers. Techniques are tagged {measured in paper} when supported by controlled benchmarks or academic studies, {practitioner folklore} when sourced from production harness prompts, tool telemetry, or engineering blogs, and {your inference} when bridging architectural mechanics (such as Gemma-4's 512-token local sliding window) to prompt policy. One overarching boundary condition applies throughout: Diff-XYZ (https://arxiv.org/html/2510.12487v2, 2025) and Validity Is Not Repaired by Pre-Edit Prompting (https://arxiv.org/html/2603.25764v3, Mar 2026) demonstrate that prompt-level guardrails sharply cut mechanical failures (wrong-file drift, NoMatchError, skipped tests, scratch pollution) but show diminishing returns on deep semantic misreadings in smaller models<sup>8</sup>.

## 1. Localization Policy: Published Accuracy and 9-Tool Transfer

Published localization architectures span four paradigms: fixed hierarchical funnels (Agentless), stratified AST APIs (AutoCodeRover), hybrid semantic search with tree search (Moatless / SWE-Search), and shell-driven exploration (SWE-agent, mini-SWE-agent, OpenHands). On SWE-bench Lite with GPT-4/4o backbones, structured localization reaches 61.7%–77.7% file-level accuracy, 42.3%–52.0% function-level accuracy, and 29.0%–35.3% line-level accuracy<sup>10</sup>. Across interactive harnesses, OpenHands achieves 60%+ Acc@5 across file, class, and function levels on SWE-bench Lite and LocBench (dropping to at most 35.2% file, 28.5% class, and 22.0% function on the harder, multi-artifact MULocBench; https://arxiv.org/html/2509.25242v1, Sep 2025)<sup>14</sup>, while SWE-Explore (https://arxiv.org/abs/2606.07297, Jun 2026, via technical summary<sup>15</sup>) shows that modern agents find the right files roughly 65% of the time yet recall only 15%–19% of load-bearing lines—and context efficiency predicts downstream resolve rate with Pearson *r* = 0.950<sup>15</sup>. Under your 150-line read_file cap, targeted windowing matters as much as file discovery.

<img src="f:\AI\Benchmark\research_briefs\media\Constrained Coding Agent Prompt Policies/media/image1.png" style="width:6.45833in;height:8.875in" />

Step-count reporting across localization papers is heterogeneous—AutoCodeRover and SWE-agent papers generally report end-to-end cost or total trajectory turns rather than isolated localization step counts, so direct cross-paper step efficiency comparisons are incomplete. Where measured, procedural funnels require the fewest calls: **Agentless** ({measured in paper}, Xia et al., https://arxiv.org/html/2407.01489v1, 2024; v2 2024) completes localization in three fixed stages—repository tree plus embedding retrieval to rank top files (77.7% file hit in stage 1<sup>11</sup>; 68.7%–69.7% file, 51.0%–52.0% function, and 34.3%–35.3% line in final patches<sup>10</sup>), a compressed **skeleton format** listing only class/function signatures and docstrings, and ±10-line edit windows<sup>11</sup>. A 2026 reasoning-guided Agentless extension (https://arxiv.org/html/2601.18044v1, 2026) lifted SWE-bench Verified file Hit@1 from 71.4% to 85.0% and element Exact Match from 36% to 69% simply by requiring an explicit rationale tying each candidate's behavior to the bug report before ranking<sup>17</sup>. Every part of Agentless's skeleton stage transfers directly to run_command: running rg -n "^(class \|def \| def )" \<file\> produces a signature map with exact line numbers in one shell call, eliminating blind 150-line paging.

**AutoCodeRover** ({measured in paper}, Zhang et al., ISSTA 2024, https://arxiv.org/html/2404.05427v2, 2024) reaches 62.3% file, 42.3% function, and 29.0% line accuracy on SWE-bench Lite (GPT-4) and 28.8% resolve on Verified (GPT-4o) by using stratified AST search APIs that return signatures before full implementations<sup>10</sup>. Adding repository-wide call-graph structure (RepoGraph, https://arxiv.org/html/2410.14684v1, 2024) boosts file accuracy by +4.6 to +5.6 percentage points across Agentless, AutoCodeRover, and SWE-agent<sup>10</sup>, while CoSIL (https://arxiv.org/html/2503.22424v3, 2025) measured that removing module call-graph and iterative function-graph search drops localization performance by 10% and 20%, respectively<sup>21</sup>. Because your get_code_neighbors and get_code_subgraph tools already expose an AST graph via dotted symbol paths, AutoCodeRover's stratified workflow transfers cleanly: first run rg -n to discover the exact file and symbol name, construct the dotted path (pkg.mod.Class.method), then invoke get_code_neighbors to map callers and siblings before reading code bodies.

**Moatless Tools and SWE-Search** ({measured in paper}, Örwall 2024; Antoniades et al., ICLR 2025, https://arxiv.org/html/2410.20285v1, 2024–2025) pair semantic code search with AST lookups and strict state transitions (Search → Identify → Plan → Edit), reaching 73.3% file and 52.0% function accuracy on Lite (GPT-4o) and 38.3% resolve with Claude 3.5 Sonnet<sup>13</sup>. SWE-Search adds Monte Carlo Tree Search (up to 3 expansions per node and 100 iterations, or 20 iterations in SWE-Exp<sup>24</sup>) for a +23% relative resolve lift<sup>24</sup>. While MCTS branching cannot transfer into a single linear LlmAgent, two Moatless lessons do transfer: strict linear phase discipline (preventing premature jumps to edit_file) and **hybrid semantic-plus-lexical retrieval**. In a 2026 study of compact 1–1.7B localization agents (https://arxiv.org/pdf/2610.05099, 2026), semantic search reached 67.34% File F1 in an average of just 2.06 retrieval calls on SWE-bench Lite, whereas lexical grep achieved higher class and function F1 inside localized files<sup>26</sup>. The 2026 Kaggle Gemma-4 150-line benchmark corroborates this split: dense embeddings achieved 51% full-repo file recall vs. 34%–38% for call-graph or AST-only search, whereas lexical BM25 and AST-HorizonGraph windowing tied at 65%–69% inside gold files—20–24 percentage points ahead of sequential 150-line paging (45%)<sup>3</sup>.

**SWE-agent, mini-SWE-agent, and OpenHands** ({measured in paper}, Yang et al., NeurIPS 2024, https://arxiv.org/abs/2405.15793; https://github.com/swe-agent/mini-swe-agent, 2025–2026) rely on shell-centric navigation. SWE-agent reaches 61.7% file, 46.3% function, and 32.3% line accuracy on Lite (GPT-4o)<sup>10</sup>, while OpenHands averages 58.22 assistant turns with thinking enabled vs. 94.08 without thinking (Open-SWE-Traces, EMNLP Findings 2026, https://aclanthology.org/2026.findings-emnlp.131.pdf)<sup>27</sup> and spans 19–95 median steps across models on Verified<sup>5</sup>. Notably, mini-SWE-agent exceeds 74% on SWE-bench Verified using bash alone<sup>28</sup>, confirming that disciplined rg/find queries via run_command seamlessly cover any case where a dotted symbol path is not yet known. Finally, arXiv:2604.00167 (Apr 2026, https://arxiv.org/html/2604.00167v1) demonstrated on SWE-Bench-Mini that even under *oracle* localization, **function-level context** outperforms full-file context (45.6% vs. 42.6% resolve rate, Friedman *p* = 0.0017) with the lowest variance across 10 trials (*σ* = 1.5)<sup>29</sup>.

Translating these findings into your 9-tool contract yields a strict 3-step localization funnel in steps 1–4: run one run_command with rg -n "\<identifier_or_error\>" (or find/search_similar_code when the issue uses behavioral prose without code names), run a one-call rg -n "^(class \|def \| def )" skeleton on the top 1–2 files, trace callers and siblings with get_code_neighbors, and only then issue targeted 30–80 line read_file calls around the exact candidate functions.

## 2. Test-Selection Policy and Pre-Existing Failures

Under a 180-second command timeout and 6-minute wall clock, running a full repository test suite—which can exceed 30 minutes per issue on large Python codebases (TestPrune, https://arxiv.org/html/2510.18270v1, Oct 2025)—is infeasible<sup>30</sup>. Conversely, skipping tests carries severe silent-regression risk: a 2026 verification-frontier study across 100 SWE-bench Verified instances (https://openreview.net/attachment?id=hEIt7k3Lny&name=pdf, 2026) found that completion-only acceptance (running no tests) lets through a **silent regression on 18.8% \[95% CI: 15.3%, 22.6%\]** of accepted patches<sup>31</sup>.

Published evidence supports **issue-scoped, node-level test selection**—with an explicit caveat regarding missing micro-benchmarks. No independent study in the available 2024–2026 literature measures exact wall-clock seconds saved by node-level pytest path::test_fn vs. full-file pytest path sweeps. However, TestPrune ({measured in paper}, https://arxiv.org/html/2510.18270v1, 2025) measured the impact of replacing broad repository test runs (Agentless's default 79.5 tests per instance, precision 0.28, coverage recall 0.66) with a compact issue-relevant subset: beyond avoiding 30+ minute suite sweeps and flaky unrelated failures, focused test selection lifted Agentless's end-to-end SWE-bench solve rate by **+9.4% to +12.9% relative**<sup>30</sup>.

Balancing speed against PASS_TO_PASS regression risk requires understanding SWE-bench's test geometry ({measured in paper}). Each SWE-bench instance averages ~9.1 FAIL_TO_PASS tests and ~51 PASS_TO_PASS regression tests<sup>32</sup>. The 2026 verification-frontier study formalizes the probability of missing *K* failing tests when running *m* of *N* tests as C(N−K, m) / C(N, m), and observes that even the benchmark's own PASS_TO_PASS sets leave at least a **4.8% lower bound** of undetected specification/regression gaps<sup>31</sup>. Consequently, verifying only a synthetic reproduction script leaves PASS_TO_PASS regressions unguarded, while running a targeted existing test file or -k slice captures most adjacent invariants within seconds.

Across production harnesses ({practitioner folklore}), two selection conventions dominate. First, map the edited module or symbol to existing tests via shell search (\`rg -l "" tests/ \|

\| find tests -name "") rather than guessing test filenames from issue prose alone (paralleling UTGenerator's file-to-test mapping, ACL 2025, https://aclanthology.org/2025.acl-long.189.pdf \[cite: 33\]). Second, standardize on -x --tb=short -q (pytest -k "" -x --tb=short -q, or Django's ./tests/runtests.py app.test_mod.TestCls.test_fn\[cite: 34\]) so tracebacks fail fast and remain well under your 5,000-characterrun_commandcap \[cite: 35, 36, 37\]. Watch for a documentedpytest CLI pitfall ({practitioner folklore}, https://help.aliyun.com/en/agent-sandbox/building-the-swe-agent, 2026): parameterized node IDs containing spaces or parentheses fail exact CLI matching unless quoted or selected with -k\[cite: 38\]. Use a two-tier ladder: Tier 1 confirms Fail→Pass on a minimal/tmp/repro.pyscript (Anthropic 2024<sup>39</sup>, SWE-agent<sup>40</sup>); Tier 2 runs the-knode slice and, if fast and green, runs the single mapped test file with--maxfail=3\`.

Pre-existing failing tests are a documented source of false-regression thrashing. A practitioner synthesis of SWE-bench verification patterns (https://agentpatterns.ai/verification/baseline-aware-test-evaluation-issue-resolution/, 2026) cites that **7.8% of test-passing patches fail** when testers cannot distinguish pre-existing failures from newly introduced regressions ({practitioner folklore} summary of benchmark findings)<sup>41</sup>. Top harnesses solve this via differential baselining: **AgentWhetters** (1st place, Sprint 3 SWE-bench Pro, https://github.com/paulwhitten/AgentWhetters-swe-bench-pro-purple-simple_loop, 2026) runs the discovered test command once at startup to filter pre-existing failures<sup>42</sup>; **Agentless** (2024) runs existing tests on the unpatched commit to isolate the green baseline<sup>30</sup>; **SWE-agent** (2024) shifts pre-existing linter error lines so old faults never trigger rollbacks<sup>40</sup>; and **Refact.ai** (#2 SWE-bench Verified at 74.40%, https://refact.ai/blog/2025/1-agent-on-swe-bench-verified-using-claude-4-sonnet/, Jun 2025) checks specifically that *pre-existing green* tests remain unbroken<sup>43</sup>. Inside your 9-tool contract ({your inference}), run your targeted -k test once before editing—or, whenever an unexpected failure appears post-edit, run git stash && pytest \<failing_node\> -x --tb=short -q; git stash pop in one run_command to prove within seconds whether your patch caused it.

## 3. Edit Reliability: Eliminating the 92.3% NoMatchError Bottleneck

Exact-match string replacement is a widespread bottleneck across coding agents, not an anomaly of your harness. In SWE-Edit ({measured in paper}, https://arxiv.org/pdf/2604.26102, Apr/May 2026), monolithic str_replace_editor baselines achieve only **75.6%–82.0% edit success** even with frontier models—roughly one failed edit in five—before specialized adaptive editing lifts success to 93.9%–95.9% (+12.8 to +18.3 pp)<sup>44</sup>. (A vendor marketing page from Morph, https://www.morphllm.com/common-errors/error-editing-file, claims a steeper 35% string-match failure rate rising to 45% on \>500-line files and 50%+ after 30 edits; treat those vendor numbers as directional only<sup>46</sup>.)

Three empirical mechanisms explain why NoMatchError accounts for 92.3% of your tool errors and define the ceiling of prompt-only mitigations. First, **history compression destroys verbatim quote fidelity**: telemetry from the Distil proxy benchmark ({practitioner folklore} / tool maintainer benchmark, https://github.com/dshakes/distil, Sep 2026) measured **39.3% byte-exact old_string quote loss** on real coding traffic before exact-quote preservation<sup>47</sup>. Combined with your 14,336-token compaction boundary and Gemma-4's 512-token local attention window, any edit_file built from an older read is highly susceptible to blank-line omission and outdenting—the exact failure modes Aider documented in 2024 (https://aider.chat/docs/unified-diffs.html), where disabling flexible whitespace matching increased edit errors **9×** and emotional-appeal prompts ("tip \$2000") actively worsened scores<sup>48</sup>. Second, **format prompting exhibits a sharp small-model ceiling**: in Diff-XYZ ({measured in paper}, Glukhov et al., https://arxiv.org/html/2510.12487v2, 2025), explicit format rules lifted GPT-4.1 Apply Rate from 0.36 to 0.79 (Parse Rate 0.43→0.99), Claude 4 Sonnet from 0.65 to 0.89 (Parse 0.79→1.00), and GPT-4.1-mini from 0.13 to 0.64, yet **GPT-4.1-nano dropped from 0.32 to 0.28 and GPT-4o-mini dropped from 0.40 to 0.29**<sup>8</sup>. Third, **first-shot edit accuracy is decisive for quantized Gemma-4**: in the 2026 Kaggle Gemma-4 study (small sample, *N* = 10), 0 of 10 episodes recovered on a second edit after an initial pytest failure<sup>3</sup>.

Five prompt- and policy-level mitigations directly target these failure modes inside your fixed edit_file tool:

1.  **Immediate 20–35 line read_file right before every edit_file** ({practitioner folklore} in Anthropic/Claude Code docs<sup>50</sup>; {your inference} for Gemma-4 attention physics): Reading 25–30 lines (~350–450 tokens) on the turn immediately preceding edit_file places verbatim indentation and blank lines inside Gemma-4 E4B's 512-token local sliding window (and 31B's 1,024-token window), allowing all local layers—not only sparse global layers—to copy characters verbatim<sup>52</sup>. Mandate this re-read after compaction or any prior edit to the same file.

2.  **Line-number prefix prohibition paired with a BAD/GOOD exemplar** ({practitioner folklore} in Anthropic/Claude Code/Opus/Fable prompts<sup>51</sup>; paired-example gain {measured in paper} in Bohr, https://arxiv.org/abs/2511.13972, 2025<sup>58</sup>): Explicitly forbid copying read_file line-number prefixes and, in the 31B prompt, show a 2-line BAD/GOOD pair (BAD: "42: return val" vs. GOOD: " return val").

3.  **Small unique anchor hunks (3–8 lines)** ({practitioner folklore}<sup>46</sup>): Keep old_string to 1–2 unique unchanged lines above and below the edited lines; large 25+ line blocks multiply the chance of a dropped comment, blank line, or outdented block<sup>48</sup>.

4.  **No identical retry + cat -A whitespace probe** ({practitioner folklore} empirically derived in SWE-agent<sup>40</sup>): SWE-agent explicitly instructs "If a command did not work once it will not work the second time unless you modify it!" to break edit loops<sup>40</sup>. After one NoMatchError, prohibit retrying edit_file blindly; require a fresh 25-line read_file or run_command with sed -n 'START,ENDp' \<file\> \| cat -A to reveal tabs (^I) and trailing spaces.

5.  **2-strike fallback to write_file on short files (≤150 lines)** ({measured in paper} basis in AdaEdit / arXiv:2604.27296<sup>49</sup> and SWE-Edit<sup>44</sup>; {your inference} for trigger): AdaEdit found full rewrite always applies and is cheaper on ~50%–60% of short function-level edits<sup>49</sup>, and SWE-Edit achieved 95.9% reliability by switching adaptively between find-replace and whole-file rewrite<sup>44</sup>. For files ≤150 lines (which fit in one read_file), allow read_file(1, 150) → write_file → git diff after two NoMatchError failures; forbid write_file on \>150-line files to avoid truncation<sup>48</sup>.

## 4. Context Discipline Under 14.3k Compaction and 512-Token Local Attention

Gemma-4's hybrid attention design dictates how information survives across turns (Gemma 4 Architecture, Apr 2026, https://www.arunbaby.com/ml-system-design/0077-gemma4-architecture-deep-dive/<sup>52</sup>; https://machine-learning-made-simple.medium.com/googles-gemma-4-is-weirder-than-you-realize-17d00d95b0d5<sup>53</sup>; https://lmstudio.ai/models/gemma-4<sup>54</sup>). Edge variants (E2B/E4B) interleave local sliding-window attention with global full-context attention at a **4:1 (E2B) or 5:1 (E4B)** ratio using a **512-token sliding window** and 4:1–8:1 GQA compression; the 31B Dense model uses 60 layers at a **5:1 ratio** (50 local, 10 global) with a **1,024-token sliding window**, 2:1 local GQA, and 8:1 global GQA with K=V weight sharing, always ending on a global layer<sup>52</sup>. Because your environment strips thinking tokens from history on every turn (whereas Gemma-4's official model card recommends preserving thinking on tool-call turns<sup>59</sup>) and compacts history at 14,336 tokens, mid-trajectory hypotheses and older file reads rapidly decay out of fine-grained local attention and then vanish entirely upon compaction.

<img src="f:\AI\Benchmark\research_briefs\media\Constrained Coding Agent Prompt Policies/media/image3.png" style="width:6.45833in;height:3.52083in" />

Four evidence-backed conventions keep state coherent across both 14.3k compaction and short local attention:

First, **externalize state to /tmp/state.md and recite it into the recency window** ({practitioner folklore}, Anthropic *Effective Context Engineering for AI Agents*, Sep 2025, and Peak Ji / Manus, Jul 2025<sup>60</sup>). Both Anthropic and Manus converge on maintaining a short structured note file (todo.md / NOTES.md) that is rewritten or re-read periodically so goals, verified file:line coordinates, test commands, and ruled-out hypotheses re-enter the tail of the context window—counteracting *Lost in the Middle* (Liu et al., TACL 2023) and *Context Rot* (Chroma, Jul 2025)<sup>61</sup>. Keeping /tmp/state.md to ≤15 lines and reading it back post-compaction or after step 12 replaces the episodic continuity lost to thought-stripping without dirtying /workspace.

Second, **delay hitting the 14.3k compaction trigger via observation hygiene** ({measured in paper}). In The Complexity Trap (Lindenbauer et al., JetBrains Research, NeurIPS DL4C 2025, https://arxiv.org/abs/2508.21433), LLM summarization induced **trajectory elongation** because lossy summaries masked raw error patterns, causing agents to repeat dead ends<sup>66</sup> (an engineering analysis citing that NeurIPS study notes that ~84% of agent turn tokens are tool observations<sup>69</sup>). Although FrogNano (https://arxiv.org/html/2609.07925v1, Sep 2026) confirmed that summary compaction recovers substantial performance at tight 16K budgets<sup>70</sup>, delaying compaction preserves both raw failure traces and exact quote fidelity<sup>47</sup>. Instruct the agent to pipe noisy run_command outputs (\| head -n 50 or \| tail -n 50), redirect verbose logs to /tmp/out.log, and request tight 25–50 line read_file windows rather than 150 lines by default<sup>62</sup>.

Third, **keep the system prompt byte-static to protect vLLM KV-cache reuse** ({measured in paper}). Context Has a Price (https://arxiv.org/abs/2611.22238, Nov 2026, \>20,000 runs across seven locally served open models) measured 94%–98% cache-read shares in agent loops (mirroring 95.6% across 8,058 Claude Code and Codex sessions) and proved that mutating early prompt bytes invalidates the prefix cache—turning naive context pruning from a 19%–25% uncached savings into an 87%–116% cost *increase* under cache pricing<sup>71</sup>. Never insert dynamic timestamps or turn counters into the system prompt<sup>61</sup>.

Fourth, **scale system prompt length to model capacity** ({measured in paper} with size-dependent caveat). On small models (2–9B), arXiv:2610.02001 (Oct 2026) documented degraded instruction-following under multi-thousand-token prefill manifests and linear-to-super-linear prefill latency (0.20 ms/token at 4B), pinning total static prefill—including tool schemas—at 774–797 tokens<sup>2</sup>. Combined with Guardrails Beat Guidance (2026)—where only 3 of 18 curated rules helped while 4 distorted and 11 were inert<sup>1</sup>—and attention-sink preamble sizing on Gemma-4 (arXiv:2609.02737, Sep 2026<sup>72</sup>), an **ultra-short ~100-token system prompt** of pure negative guardrails is well supported for your small model. Conversely, no controlled SWE-bench ablation shows \<150 tokens beating 500–800 tokens on 31B+ models: Guardrails Beat Guidance observed +7 to +14 pp gains over zero rules (per technical summary<sup>73</sup>) with no degradation up to 50 rules<sup>1</sup>, while Distyl AI's IFScale benchmark (cited in<sup>73</sup>) shows compliance drops to 68% at 500 instructions. Thus, a ~3,000-char (~650–700 token) prompt fits comfortably inside 31B's 1,024-token local window and well below instruction-overload ceilings.

## 5. Anti-Pathologies: Measured Fixes vs. Practitioner Folklore

### (a) No-Tool-Call Turns and Planning Prose (29% of Turns)

Before attributing all 29% prose-only turns to prompt compliance, audit raw vLLM completions for three documented serving/parser interactions ({measured in official docs & GitHub bug reports}). First, under tool_choice="auto", vLLM's decoding grammar explicitly permits plain-text responses; vLLM ≥0.8.3 supports tool_choice="required" and --tool-strict-level function to mechanically guarantee a tool call on every turn (https://docs.vllm.ai/en/v0.32.0/features/tool_calling/, 2026)<sup>74</sup>. Because submit_patch is itself a tool, tool_choice="required" has no exit conflict if exposed in your declarative YAML or vLLM serving config. Second, vLLM 0.22.0 leaked raw \<\|tool_call\> wire tokens into plain text **50%–56% of the time** whenever --reasoning-parser gemma4 was enabled alongside --tool-call-parser gemma4, fixed in commit 68dafcc (Jun 2026, https://github.com/vllm-project/vllm/issues/44522)<sup>6</sup>. Third, vLLM 0.26–0.27.1 (Aug 2026, https://github.com/vllm-project/vllm/issues/53431) silently drops Gemma-4 turns that emit a bare \<\|tool_call\>:name{...} opener (omitting call:), reproducing **8/8 times under greedy decoding (top_k=1)**<sup>7</sup>. At the prompt and sampling layer ({practitioner folklore} + {measured in paper} polarity<sup>1</sup>), place a hard prohibition on line 1 ("Never output prose without a tool call; keep reasoning in thinking tokens"), keep thinking budget at 768–1024 so deliberation finishes inside the thought block ({your inference}), and avoid both high temperatures (which destabilize tool syntax<sup>77</sup>) and pure greedy top_k=1 if bare-opener drops appear<sup>7</sup>.

### (b) Premature Submit After py_compile Without pytest

Premature termination without functional verification is a measured, cross-model pathology ({measured in paper}). Terminal-Bench 2.0's ICLR 2026 error analysis across 16 frontier models (https://proceedings.iclr.cc/paper_files/paper/2026/file/444a3737adaee10d86ad2ef5f74468e6-Paper-Conference.pdf, 2026) flags **"Verification: Stopping early without checking the work"** as one of three dominant failure classes<sup>78</sup>. Beyond Resolution Rates (Mehtiyev & Assunção, https://arxiv.org/html/2604.02547v1, Apr 2026; 9,374 trajectories on SWE-bench Verified) confirms that post-patch test loops consistently separate solved runs from failures even after controlling for task difficulty<sup>80</sup>, and the 2026 Kaggle Gemma-4 writeup specifically observes **"premature-submission logit drift"** in Gemma-4 31B<sup>3</sup>. Encode this as an explicit negative constraint naming the exact forbidden shortcut ({measured in paper} polarity<sup>1</sup> + {practitioner folklore} gate<sup>43</sup>): *"NEVER call submit_patch after only py_compile or import checks; you MUST pass both /tmp/repro.py (Fail→Pass) and targeted existing pytest tests."*

### (c) Hypothesis-Chasing vs. Adjacent-Mechanism Mirroring

Right-file logic failures (37.2% of your traces) reflect a measured architectural blind spot ({measured in paper}). Beyond Resolution Rates (Apr 2026) audited the 12 "easy" (≤10-line, single-file) SWE-bench Verified tasks that zero of 19 agents solved: the best agent located the gold file in **12/12** cases and edited it in **10/12**, yet failed **10/12** by **patching the wrong architectural layer**—treating a symptom at the caller/consumer rather than the root invariant at the callee/producer<sup>81</sup>. A 2025 SWE-bench failure taxonomy (https://arxiv.org/html/2509.13941v1, Sep 2025) similarly identifies **Non-Progressive Iteration** (cosmetic micro-edits in a loop) and **Blind Strategy Switching** as primary debugging traps<sup>82</sup>. Crucially, however, Validity Is Not Repaired by Pre-Edit Prompting (https://arxiv.org/html/2603.25764v3, Mar 2026) found that generic pre-edit guard prompts did *not* improve resolve rate on deep misreadings<sup>9</sup>—whereas reading actual code dependencies before editing predicted **+8.3 pp higher pass probability per standard deviation** (+17.8 pp from none to full dependency inspection on script-authoring tasks in OPENGAMEEVAL, https://openreview.net/pdf/83f37f37aa92604f6d4afc4b2ba6c1bb75c488cc.pdf, 2026)<sup>83</sup>. Therefore, avoid vague exhortations ("think deeply") and instead bind mirroring to concrete tool triggers ({your inference} grounded in<sup>81</sup>): mandate calling get_code_neighbors (or grepping sibling methods in the same class) before editing to copy existing codebase idioms, and impose a hard **2-strike rule**—after two edits fail the same test, stop patching that function and inspect upstream callers/callees via get_code_neighbors.

### (d) Scratch-File Pollution of git diff

Preventing untracked reproduction scripts and modified test files from contaminating the submitted diff is universal {practitioner folklore} across top harnesses rather than a formally ablated paper topic. SWE-agent (https://swe-agent.com/latest/usage/hello_world/, 2024–2025) intercepts submit to remind the model to delete reproduce_error.py and revert test edits via git checkout -- \<test_file\><sup>84</sup>, and Anthropic (2024<sup>39</sup>), SWE-eval<sup>85</sup>, and SWE-Sweep<sup>86</sup> all explicitly ban modifying existing tests. In your harness, combine a /tmp/-only rule (all repro scripts, logs, and /tmp/state.md live outside /workspace) with a mandatory free get_status check immediately before submit_patch.

## 6. Pacing Policy: Does Literature Corroborate an Early Educated Edit?

Your empirical observation—first edit by step 8–10 yielding 100% patch emission and 67% of solves within a 40-tool-call budget—is **strongly corroborated by two 2026 large-scale trajectory studies, subject to a strict lower-bound floor against blind edits in steps 1–3**. First, Trajectory Quality Score (TQS, {measured in paper}, EMNLP Findings 2026, https://aclanthology.org/2026.findings-emnlp.2264.pdf) evaluated **413,278 coding-agent trajectories** (where resolve rate rises monotonically from 54.1% in decile 1 to 86.9% in decile 10, \|*ρ*\| = 0.729)<sup>87</sup>. Its Substantive Commitment Pacing (SCP) component assigns peak score (1.0) when the first substantive edit occurs at relative trajectory fraction u = t\*/n between **0.20 and 0.50**, decaying smoothly for both earlier (u \< 0.20) and later (u \> 0.50) edits<sup>87</sup>. Mapped onto a 40-tool-call cap (0.20 × 40 = step 8 through 0.50 × 40 = step 20), your step 8–10 threshold sits squarely at the opening boundary of the optimal zone. Second, Termination Lag ({measured in paper}, Cim et al., https://arxiv.org/pdf/2611.14960, Nov 2026) evaluated every intermediate repository state across five models and found that **38%–82% of solved runs already had the correct fix on their very first source edit**, after which agents wasted a median **35%–60% of their steps** before stopping—and broke a previously correct fix in **1%–8%** of runs<sup>4</sup>.

<img src="f:\AI\Benchmark\research_briefs\media\Constrained Coding Agent Prompt Policies/media/image2.png" style="width:6.45833in;height:7.38542in" />

At the same time, Beyond Resolution Rates ({measured in paper}, https://arxiv.org/html/2604.02547v1, Apr 2026) supplies an essential counter-caveat against rushing blindly. Although naive pooling makes failed runs appear 14.0%–111.9% longer than resolved runs, controlling for task difficulty across 9,374 trajectories reverses the relationship: **resolved trajectories are longer on 63% of contested tasks (*p* \< 10⁻⁸)**<sup>89</sup>. What distinguishes winners from losers in the opening 10 steps is **decision ordering**: read → read → read → write outperforms premature read → write across every framework studied<sup>81</sup>. Synthesizing all three studies yields a two-sided pacing law ({your inference}): enforce a mandatory exploration floor in steps 1–4 (localize, inspect callers/siblings, confirm /tmp/repro.py fails), commit the first educated edit by steps 6–12 (eliminating your 30.8% no-edit-empty timeouts), and call submit_patch immediately once repro, targeted pytest, and free get_status pass—eliminating post-fix lag and accidental regressions<sup>5</sup>.

## 7. Deliverable A: Master Technique Table and 9-Tool Transferability Verdict

|  |  |  |  |  |
|----|----|----|----|----|
| **Domain & Technique** | **Key Evidence (URL + Year)** | **Evidence Tag** | **9-Tool Transferability Verdict** | **Exact Implementation in Your 9-Tool Contract** |
| **Agentless 3-stage skeleton localization** (tree → signature skeleton → targeted lines) | Xia et al. (https://arxiv.org/html/2407.01489v1, 2024): 68.7–77.7% file / 51–52% func<sup>10</sup>; reason-before-rank (https://arxiv.org/html/2601.18044v1, 2026): 85% file Hit@1<sup>17</sup> | {measured in paper} | **Direct Transfer** | run_command: rg -n "^(class \|def \| def )" file.py to get exact function line numbers before read_file. |
| **Hybrid dense + lexical localization** (semantic for file discovery, rg for symbols) | arXiv:2610.05099 (https://arxiv.org/pdf/2610.05099, 2026: 67.3% File F1 in 2.06 calls)<sup>26</sup>; Kaggle Gemma-4 150-line bench (2026: dense 51% repo file recall vs 34–38% AST)<sup>3</sup> | {measured in paper} | **Adapted Transfer** | Use rg -n for identifiers/tracebacks; seed search_similar_code with dotted module path on purely behavioral issues. |
| **AST call-graph & sibling expansion** (AutoCodeRover / CoSIL / RepoGraph) | RepoGraph (https://arxiv.org/html/2410.14684v1, 2024: +4.6–5.6 pp file)<sup>10</sup>; CoSIL (https://arxiv.org/html/2503.22424v3, 2025: −10–20% w/o graph)<sup>21</sup> | {measured in paper} | **Direct Transfer** | After finding target symbol via rg, call get_code_neighbors / get_code_subgraph on its dotted path before editing. |
| **Moatless MCTS tree search & value agent** | Antoniades et al. (https://arxiv.org/html/2410.20285v1, ICLR 2025: +23% relative resolve lift)<sup>24</sup> | {measured in paper} | **Does Not Transfer** (branching); **Partial** (phase gating) | Cannot branch in single LlmAgent; transfer only strict linear phase order (Search → Identify → Plan → Edit). |
| **Issue-scoped pytest node / -k selection + -x --tb=short -q** | TestPrune (https://arxiv.org/html/2510.18270v1, 2025: +9.4–12.9% relative solve lift, avoids \>30m sweeps)<sup>30</sup>; harness docs<sup>35</sup> | {measured in paper} + {practitioner folklore} | **Direct Transfer** | Map edited file to test file via rg -l "\<symbol\>" tests/; run pytest \<file\> -k "\<sym\>" -x --tb=short -q (or Django runtests.py). |
| **Baseline-aware differential test check** (pre-edit baseline / git stash) | AgentWhetters (GitHub, 2026)<sup>42</sup>; AgentPatterns synthesis (https://agentpatterns.ai/verification/baseline-aware-test-evaluation-issue-resolution/, 2026: 7.8% fail gap)<sup>41</sup> | {practitioner folklore} | **Direct Transfer** | Run targeted test once pre-edit; if post-edit fails unexpectedly, run git stash && pytest \<node\> -x; git stash pop via run_command. |
| **Two-tier verification gate** (repro Fail→Pass + existing P2P tests) | Verification Frontier (https://openreview.net/attachment?id=hEIt7k3Lny&name=pdf, 2026: 18.8% silent regressions w/o tests)<sup>31</sup> | {measured in paper} | **Direct Transfer** | Require /tmp/repro.py Fail→Pass AND targeted existing pytest green before submit_patch; ban py_compile-only submits. |
| **Fresh 20–35 line read_file immediately before edit_file** | Distil telemetry (https://github.com/dshakes/distil, 2026: 39.3% quote loss post-compression)<sup>47</sup>; Gemma-4 512-tok SWA (2026)<sup>52</sup> | {practitioner folklore} + {your inference} | **Direct Transfer** | Mandate read_file(start, end) of ≤35 lines on the turn directly before edit_file (especially post-compaction). |
| **Strip line numbers + BAD/GOOD example + ≤8-line anchor hunks** | Claude Code / Opus prompts (2025–2026)<sup>51</sup>; Bohr (https://arxiv.org/abs/2511.13972, 2025) BAD/GOOD gain<sup>58</sup>; Aider (2024)<sup>48</sup> | {practitioner folklore} + {measured in paper} | **Direct Transfer** | Include explicit negative rule + 2-line BAD/GOOD example in 31B prompt; concise prohibition in small-model prompt. |
| **No identical retry + cat -A whitespace probe + short-file write_file escape** | SWE-agent (2024)<sup>40</sup>; SWE-Edit (https://arxiv.org/pdf/2604.26102, 2026: 75.6–82%→95.9%)<sup>44</sup>; AdaEdit (2026)<sup>49</sup> | {measured in paper} + {your inference} | **Adapted Transfer** | After 1 NoMatchError: read_file or sed -n 'X,Yp' f \| cat -A. After 2 failures on ≤150-line file: read_file + write_file + git diff. |
| **External /tmp/state.md notebook & goal recitation** | Anthropic (Sep 2025) & Manus (Jul 2025)<sup>60</sup>; Complexity Trap (https://arxiv.org/abs/2508.21433, 2025)<sup>66</sup> | {practitioner folklore} + {your inference} | **Direct Transfer** | Maintain ≤15-line /tmp/state.md (targets, repro cmd, ruled-out hypotheses); re-read post-compaction or after step 12. |
| **Negative-constraint framing & ultra-short small-model prefill** | Guardrails Beat Guidance (https://arxiv.org/pdf/2604.11088, 2026)<sup>1</sup>; arXiv:2610.02001 (2026)<sup>2</sup>; Context Has a Price (Nov 2026)<sup>71</sup> | {measured in paper} | **Direct Transfer** | Rewrite positive style rules as prohibitions; cap small-model prompt at ~100 tokens; keep static for vLLM KV cache. |
| **vLLM tool_choice="required" & Gemma-4 parser audit** | vLLM Docs (https://docs.vllm.ai/en/v0.32.0/features/tool_calling/, 2026)<sup>75</sup>; vLLM \#44522 & \#53431 (2026)<sup>6</sup> | Official docs / bug reports | **Config-Only / Diagnostic** | If exposed in YAML/vLLM serving config, enforce tool_choice="required", verify commit 68dafcc, avoid greedy top_k=1. |
| **Pacing: explore steps 1–4, first edit by step 8–12, stop on green** | TQS (EMNLP 2026: peak u in 0.20–0.50)<sup>87</sup>; Termination Lag (https://arxiv.org/pdf/2611.14960, Nov 2026)<sup>5</sup>; Beyond Res. Rates (2026)<sup>81</sup> | {measured in paper} | **Direct Transfer** | Encode explicit step milestones and immediate post-verification stop rule in system prompt. |

## 8. Deliverable B: Two Prompt Skeletons

### Skeleton 1: Small-Model Distilled System Prompt (~100 Tokens, 8 Laws — Gemma-4 E4B / 512-Token Local Window)

This 92-word (~105–115 token) static prompt uses exclusively negative constraints and state-dependent triggers so it occupies minimal space inside Gemma-4 E4B's 512-token local sliding window and 14.3k compaction budget.

Fix /workspace bug. Obey 8 laws:

1.  Never output prose without a tool call.

2.  Locate via rg/find + AST tools; never page sequentially.

3.  Re-read 20-30 target lines right before edit_file.

4.  Strip line numbers in edit_file; match exact whitespace, ≤8-line hunks, never repeat failed edits.

5.  Mirror sibling idioms; after 2 failures, trace callers.

6.  Put repro/notes in /tmp only; never edit tests.

7.  Land first educated edit by step 8-12.

8.  Never submit_patch after py_compile alone; pass repro + targeted pytest -x --tb=short + clean get_status, then submit.

|  |  |  |  |  |
|----|----|----|----|----|
| **Law** | **Core Mechanism** | **Evidence Source (URL + Year)** | **Evidence Tag** | **Confidence** |
| **Law 1** | Ban prose-only turns | Guardrails polarity (https://arxiv.org/pdf/2604.11088, 2026)<sup>1</sup>; vLLM tool docs (2026)<sup>75</sup>; practitioner tool rules<sup>76</sup> | {measured in paper} (polarity) + {practitioner folklore} | **High** (pair with vLLM parser audit) |
| **Law 2** | Search + AST first; ban sequential paging | Kaggle Gemma-4 150-line bench (2026: 65–69% vs 45% paging)<sup>3</sup>; Agentless (2024)<sup>11</sup>; CoSIL (2025)<sup>21</sup> | {measured in paper} | **Very High** |
| **Law 3** | Immediate 20–30 line re-read before edit_file | Distil telemetry (https://github.com/dshakes/distil, 2026: 39.3% quote loss)<sup>47</sup>; Gemma-4 512-tok SWA (2026)<sup>52</sup> | {practitioner folklore} + {your inference} | **Very High** |
| **Law 4** | Strip line numbers; exact whitespace; ≤8-line hunk; no identical retry | SWE-Edit (https://arxiv.org/pdf/2604.26102, 2026)<sup>44</sup>; SWE-agent (2024)<sup>40</sup>; Claude Code prompts (2025–2026)<sup>51</sup> | {measured in paper} + {practitioner folklore} | **High** (small-model ceiling in Diff-XYZ<sup>8</sup>) |
| **Law 5** | Mirror siblings; 2-strike caller trace | Beyond Resolution Rates (https://arxiv.org/html/2604.02547v1, 2026: 10/12 wrong layer)<sup>81</sup>; OPENGAMEEVAL dep-read (+8.3 pp/SD, 2026)<sup>83</sup> | {measured in paper} + {your inference} | **Medium–High** (caveat: arXiv:2603.25764<sup>9</sup>) |
| **Law 6** | /tmp isolation; never edit existing tests | SWE-agent submit gate (2024–2025)<sup>84</sup>; Anthropic (2024)<sup>39</sup>; SWE-Sweep (2026)<sup>86</sup> | {practitioner folklore} | **Very High** |
| **Law 7** | First educated edit by step 8–12 | TQS (EMNLP 2026: peak u in 0.20–0.50 → steps 8–20)<sup>87</sup>; Termination Lag (Nov 2026)<sup>5</sup> | {measured in paper} | **High** |
| **Law 8** | Ban py_compile-only submit; repro + targeted pytest + get_status + stop | Verification Frontier (2026: 18.8% silent regressions)<sup>31</sup>; Terminal-Bench 2.0 (ICLR 2026)<sup>79</sup>; Termination Lag (2026)<sup>5</sup> | {measured in paper} | **Very High** |

### Skeleton 2: 31B-Model System Prompt Skeleton (~3,000 Chars — Gemma-4 31B / 1,024-Token Local Window)

This ~3,000-character (~650–700 token) static prompt fits inside Gemma-4 31B's 1,024-token local sliding window and preserves full vLLM KV-cache prefix reuse across turns.

\<edit_reliability\>

- ALWAYS call read_file on the target 20-35 lines immediately before edit_file (mandatory after compaction or any prior edit to that file).

- NEVER copy line-number prefixes into edit_file; match exact spaces/tabs:\
  BAD old_string: "42: return val"\
  GOOD old_string: " return val"

- Keep old_string small (3-8 lines) with 1-2 unique unchanged anchor lines above and below.

- NEVER repeat an identical failed edit_file. After 1 NoMatchError, run read_file or sed -n 'START,ENDp' \<file\> \| cat -A to inspect whitespace. After 2 failures on a file \<=150 lines, read_file the full file, use write_file, and verify via git diff.\
  \</edit_reliability\>

\<testing_and_verification\>

- NEVER call submit_patch after only syntax/import checks (py_compile).

- Step A (Repro): Write /tmp/repro.py; confirm it FAILS pre-edit and PASSES post-edit.

- Step B (Regression): Find the matching test file (rg -l "\<symbol\>" tests/). Run targeted tests with -x --tb=short -q (e.g., pytest tests/test_x.py -k "sym" -x --tb=short -q, or Django ./tests/runtests.py ...). NEVER run repo-wide sweeps.

- Pre-existing failures: On an unexpected post-edit test failure, run git stash && pytest \<node\> -x --tb=short -q; git stash pop to confirm your edit caused it.\
  \</testing_and_verification\>

\<context_and_pacing\>

- Pipe noisy bash output (\| head -n 50 or \> /tmp/out.log) to delay compaction.

- Maintain a \<=15-line /tmp/state.md (target file:line, root cause, repro/test cmds, ruled-out attempts); re-read after compaction or step 12.

- Pacing: Explore callers/repro first (steps 1-4); land your first educated edit by steps 6-12. After 2 failed edits on one hypothesis, STOP patching and re-check git diff + callers via get_code_neighbors.

- Pre-submit gate: Once /tmp/repro.py and targeted tests pass, call get_status (free) to confirm non-empty source diff, zero untracked files, and zero test edits—then call submit_patch immediately.\
  \</context_and_pacing\>

|  |  |  |  |  |
|----|----|----|----|----|
| **Section** | **Core Guardrails Encoded** | **Primary Evidence (URL + Year)** | **Evidence Tag** | **Confidence** |
| **\<contract\>** | Mandatory tool call per turn; /tmp/ scratch isolation; no unrelated refactoring | Guardrails Beat Guidance (https://arxiv.org/pdf/2604.11088, 2026)<sup>1</sup>; SWE-agent (2024)<sup>84</sup>; Anthropic (2024)<sup>39</sup> | {measured in paper} + {practitioner folklore} | **Very High** |
| **\<localization\>** | 3-stage funnel (rg/dense → 1-call AST skeleton → get_code_neighbors sibling/caller trace) | Agentless (2024)<sup>11</sup>; Kaggle Gemma-4 150-line bench (2026)<sup>3</sup>; Beyond Resolution Rates (2026: 10/12 wrong layer)<sup>81</sup>; CoSIL (2025)<sup>21</sup> | {measured in paper} | **Very High** |
| **\<edit_reliability\>** | Just-in-time 20–35 line read_file; BAD/GOOD line-number strip; 3–8 line hunks; cat -A + write_file 2-strike escape | Distil (2026: 39.3% quote loss)<sup>47</sup>; Bohr (2025)<sup>58</sup>; SWE-Edit (2026)<sup>44</sup>; SWE-agent (2024)<sup>40</sup>; AdaEdit (2026)<sup>49</sup> | {measured in paper} + {practitioner folklore} + {your inference} | **Very High** |
| **\<testing_and_verification\>** | Ban py_compile-only submit; /tmp/repro.py Fail→Pass; -x --tb=short -q node pytest; git stash baseline diff | Verification Frontier (2026: 18.8% silent regressions)<sup>31</sup>; TestPrune (2025: +9.4–12.9%)<sup>30</sup>; AgentWhetters (2026)<sup>42</sup> | {measured in paper} + {practitioner folklore} | **Very High** |
| **\<context_and_pacing\>** | Output truncation; /tmp/state.md compaction survival; steps 1–4 read / 6–12 first edit / 2-strike loop break; immediate stop on green + free get_status | Complexity Trap (2025)<sup>66</sup>; Manus (2025)<sup>64</sup>; TQS (EMNLP 2026)<sup>87</sup>; Termination Lag (Nov 2026)<sup>5</sup> | {measured in paper} + {practitioner folklore} + {your inference} | **High** |

## 9. Deliverable C: Top-5 Highest-Confidence Changes to Your Current Prompt Laws and Config

1.  **Mandate an immediate 20–35 line read_file directly before every edit_file, paired with a BAD/GOOD line-number strip rule and a no-identical-retry clause.** Directly attacks your dominant tool failure (NoMatchError = 92.3% of tool errors) by placing verbatim whitespace inside Gemma-4's 512/1,024-token local sliding window<sup>52</sup> and countering the 39.3% byte-exact quote loss after compression<sup>47</sup>. Pair with sed -n 'START,ENDp' \<file\> \| cat -A after one failure and a write_file + git diff escape after two failures on files ≤150 lines<sup>44</sup>.

2.  **Audit your vLLM Gemma-4 parser/sampling config alongside a line-1 negative prohibition on prose-only turns.** Directly targets your 29% no-tool-call turns: if exposed in your declarative YAML or vLLM serving config, set tool_choice="required"<sup>75</sup>, confirm your vLLM version includes the June 2026 Unify-Parser fix (#44522) so --reasoning-parser gemma4 is not leaking \<\|tool_call\> into text<sup>6</sup>, and avoid greedy top_k=1 if silent drops from Gemma-4's bare \<\|tool_call\>:name opener (#53431) appear<sup>7</sup>.

3.  **Flip generic positive directives into concrete negative guardrails and state-dependent triggers (Guardrails Beat Guidance polarity shift).** Replace broad advice ("be careful / follow conventions / test thoroughly," which empirically *distorts* pass rates<sup>1</sup>) with crisp prohibitions mapped to your trace failures: *never* page sequentially, *never* submit after py_compile alone, *never* repeat an identical failed edit, and *never* modify test files or write scratch files in /workspace.

4.  **Replace sequential read_file scanning with a 1-call bash AST skeleton (rg -n "^(class \|def \| def )") plus mandatory get_code_neighbors sibling/caller inspection before editing.** Simultaneously addresses wrong-file localization (24.4%) and right-file wrong-layer logic failures (37.2%), raising targeted 150-line window recall from 45% (sequential paging) toward 65%–69%<sup>3</sup> while countering the 10/12 wrong-architectural-layer failure pattern<sup>81</sup>.

5.  **Enforce the two-sided pacing law: explore steps 1–4, land the first educated edit by steps 6–12, and submit immediately once /tmp/repro.py + targeted pytest -x --tb=short -q + free get_status are green.** Attacks your 30.8% no-edit-empty rate by anchoring commitment to TQS's peak u in 0.20–0.50 band<sup>87</sup> while preventing Termination Lag's 35%–60% post-fix waste and 1%–8% patch-breaking regressions<sup>5</sup>.

## 10. Deliverable D: Cheap, Low-Risk SOTA Practices You Are Not Doing Yet

- **Differential baseline-aware testing via git stash (zero extra tools, ~5 seconds wall clock):** When an unexpected pytest failure appears post-edit, top 2026 SWE-bench Pro harnesses (AgentWhetters<sup>42</sup>) separate pre-existing failures from newly introduced regressions (addressing a 7.8% verification gap<sup>41</sup>). One run_command (git stash && pytest \<node\> -x --tb=short -q; git stash pop) stops phantom-regression chasing immediately.

- **Free get_status pre-submit hygiene gate (0 step-budget cost):** Because get_status is free in your contract, requiring it immediately before submit_patch costs zero tool-call budget while catching empty diffs (30.8% no-edit-empty), untracked /workspace scratch files, and accidental test edits<sup>84</sup>.

- **External /tmp/state.md compaction-survival notebook (1 write, zero git diff risk):** Writing a ≤15-line /tmp/state.md after localization—and re-reading it after compaction or step 12—preserves targets, repro/test commands, and ruled-out hypotheses across both thought-stripping and your 14.3k compaction cliff (Manus / Anthropic goal-recitation pattern<sup>60</sup>).

- **Output-budget truncation on every run_command (\| head -n 50 / --tb=short -q / \> /tmp/out.log):** Because tool outputs dominate trajectory token growth (~84% of turn tokens<sup>69</sup>), proactively capping command output delays compaction—preserving raw failure traces (Complexity Trap<sup>67</sup>), exact-quote fidelity<sup>47</sup>, and vLLM KV-cache prefix hits (Context Has a Price<sup>71</sup>).

- **Reason-before-rank target verification inside existing thinking tokens:** Borrowing from arXiv:2601.18044 (2026)—which lifted SWE-bench Verified file Hit@1 from 71.4% to 85.0% and element Exact Match from 36% to 69% by requiring an explicit behavioral rationale before ranking edit targets<sup>17</sup>—having the 31B model state *why* its chosen function is the root producer (rather than a caller/symptom) inside its existing 768–1024 thinking budget adds zero tool calls and zero history tokens.

#### Works cited

1.  Guardrails Beat Guidance: A Large-Scale Study of Rules, Skills, and, [<u>https://arxiv.org/pdf/2604.11088</u>](https://arxiv.org/pdf/2604.11088)

2.  Mingbird: A Local-First Agent Harness EnablingSmall Open Models, [<u>https://arxiv.org/html/2610.02001</u>](https://arxiv.org/html/2610.02001)

3.  From Local Validation to Live Evaluation \| Kaggle, [<u>https://www.kaggle.com/competitions/gemma-4-developer-agent-paper/writeups/from-local-validation-to-live-evaluation</u>](https://www.kaggle.com/competitions/gemma-4-developer-agent-paper/writeups/from-local-validation-to-live-evaluation)

4.  Termination Lag: Coding Agents Solve Early but Stop Late - arXiv, [<u>https://arxiv.org/pdf/2611.14960</u>](https://arxiv.org/pdf/2611.14960)

5.  Termination Lag: Coding Agents Find the Fix and Keep Going, [<u>https://blog.pebblous.ai/blog/termination-lag-coding-agents-stop-late/en/</u>](https://blog.pebblous.ai/blog/termination-lag-coding-agents-stop-late/en/)

6.  Gemma-4 tool call parser leaks raw tokens - GitHub, [<u>https://github.com/vllm-project/vllm/issues/44522</u>](https://github.com/vllm-project/vllm/issues/44522)

7.  \[Bug\]: Gemma4 tool parser silently drops the bare \<\|tool_call\>:name, [<u>https://github.com/vllm-project/vllm/issues/53431</u>](https://github.com/vllm-project/vllm/issues/53431)

8.  Diff-XYZ: A Benchmark for Evaluating Diff Understanding - arXiv, [<u>https://arxiv.org/html/2510.12487v2</u>](https://arxiv.org/html/2510.12487v2)

9.  Confident and Wrong: Silent Semantic Failures in Coding Agents, [<u>https://arxiv.org/html/2603.25764v3</u>](https://arxiv.org/html/2603.25764v3)

10. Enhancing AI Software Engineering with Repository-level Code Graph, [<u>https://arxiv.org/html/2410.14684v1</u>](https://arxiv.org/html/2410.14684v1)

11. Agentless :Demystifying LLM-based Software Engineering Agents, [<u>https://arxiv.org/html/2407.01489v1</u>](https://arxiv.org/html/2407.01489v1)

12. Agentless: Demystifying LLM-based Software Engineering Agents, [<u>https://www.alphaxiv.org/abs/2407.01489</u>](https://www.alphaxiv.org/abs/2407.01489)

13. From Historical Patches to Repair Plans: Outcome-Conditioned, [<u>https://raw.githubusercontent.com/mlresearch/v306/main/assets/li26ia/li26ia.pdf</u>](https://raw.githubusercontent.com/mlresearch/v306/main/assets/li26ia/li26ia.pdf)

14. A Benchmark for Localizing Code and Non-Code Issues in Software, [<u>https://arxiv.org/html/2509.25242v1</u>](https://arxiv.org/html/2509.25242v1)

15. SWE-Explore: The Benchmark That Finally Asks — Did Your Coding, [<u>https://mllog.dev/en/posts/swe-explore-benchmarking-coding-agents-repository-exploration/</u>](https://mllog.dev/en/posts/swe-explore-benchmarking-coding-agents-repository-exploration/)

16. Benchmarking How Coding Agents Explore Repositories - arXiv, [<u>https://arxiv.org/abs/2606.07297</u>](https://arxiv.org/abs/2606.07297)

17. RGFL: Reasoning Guided Fault Localization for Automated Program, [<u>https://arxiv.org/html/2601.18044v1</u>](https://arxiv.org/html/2601.18044v1)

18. AutoCodeRover: Autonomous Program Improvement - arXiv, [<u>https://arxiv.org/html/2404.05427v2</u>](https://arxiv.org/html/2404.05427v2)

19. AutoCodeRover: Autonomous Program Improvement - arXiv, [<u>https://arxiv.org/pdf/2404.05427</u>](https://arxiv.org/pdf/2404.05427)

20. Systemic literature review - DSpace, [<u>https://dspace.ut.ee/bitstreams/0c358681-71ae-465b-8d86-b39779eabda5/download</u>](https://dspace.ut.ee/bitstreams/0c358681-71ae-465b-8d86-b39779eabda5/download)

21. Issue Localization via LLM-Driven Iterative Code Graph Searching, [<u>https://arxiv.org/html/2503.22424v3</u>](https://arxiv.org/html/2503.22424v3)

22. A General Context-Aware Agent for Evolving Program Repair Agents, [<u>https://aclanthology.org/2026.findings-emnlp.210.pdf</u>](https://aclanthology.org/2026.findings-emnlp.210.pdf)

23. SWE-Fixer: Training Open-Source LLMs for Effective and Efficient, [<u>https://arxiv.org/html/2501.05040v3</u>](https://arxiv.org/html/2501.05040v3)

24. SWE-Search: Enhancing Software Agents with Monte Carlo Tree, [<u>https://arxiv.org/html/2410.20285v1</u>](https://arxiv.org/html/2410.20285v1)

25. SWE-Exp: Experience-Driven Software Issue Resolution, [<u>https://openreview.net/attachment?id=LnXBEvZKiN&name=pdf</u>](https://openreview.net/attachment?id=LnXBEvZKiN&name=pdf)

26. Small Agents with Semantic Search: Efficient Multilingual Code, [<u>https://arxiv.org/pdf/2610.05099</u>](https://arxiv.org/pdf/2610.05099)

27. OPEN-SWE-TRACES: Advancing Dual-Mode Multilingual, [<u>https://aclanthology.org/2026.findings-emnlp.131.pdf</u>](https://aclanthology.org/2026.findings-emnlp.131.pdf)

28. GitHub - SWE-agent/mini-swe-agent: The 100 line AI agent that, [<u>https://github.com/swe-agent/mini-swe-agent</u>](https://github.com/swe-agent/mini-swe-agent)

29. A Study on the Impact of Fault localization Granularity for Repository, [<u>https://arxiv.org/html/2604.00167v1</u>](https://arxiv.org/html/2604.00167v1)

30. Evaluating the Impact of Regression Tests on SWE Issue Resolution, [<u>https://arxiv.org/html/2510.18270v1</u>](https://arxiv.org/html/2510.18270v1)

31. Silent Regressions: The Verification Gap in Coding Agents, [<u>https://openreview.net/attachment?id=hEIt7k3Lny&name=pdf</u>](https://openreview.net/attachment?id=hEIt7k3Lny&name=pdf)

32. SWE-Bench: Real-World Software Benchmark - Emergent Mind, [<u>https://www.emergentmind.com/topics/swe-bench</u>](https://www.emergentmind.com/topics/swe-bench)

33. Agent 为什么越用越蠢？万字拆解AI 编程与智能体工程的“反直觉”落, [<u>https://developer.cloud.tencent.com/article/2780936</u>](https://developer.cloud.tencent.com/article/2780936)

34. SELF-HPO: SELF-EVOLVING CODING AGENTS VIA HARNESS, [<u>https://openreview.net/pdf/2ebe1d00f54a850d7f2444232bfcf3a9b1dc4df0.pdf</u>](https://openreview.net/pdf/2ebe1d00f54a850d7f2444232bfcf3a9b1dc4df0.pdf)

35. Raising the bar on SWE-bench Verified with Claude 3.5 Sonnet, [<u>https://www.anthropic.com/research/swe-bench-sonnet</u>](https://www.anthropic.com/research/swe-bench-sonnet)

36. SWE-agent — Deep Dive & Build-Your-Own Guide - DEV Community, [<u>https://dev.to/truongpx396/swe-agent-deep-dive-build-your-own-guide-ade</u>](https://dev.to/truongpx396/swe-agent-deep-dive-build-your-own-guide-ade)

37. Baseline-Aware Test Evaluation for Multi-Agent Issue Resolution, [<u>https://agentpatterns.ai/verification/baseline-aware-test-evaluation-issue-resolution/</u>](https://agentpatterns.ai/verification/baseline-aware-test-evaluation-issue-resolution/)

38. AgentWhetters-swe-bench-pro-purple-simple_loop - GitHub, [<u>https://github.com/paulwhitten/AgentWhetters-swe-bench-pro-purple-simple_loop</u>](https://github.com/paulwhitten/AgentWhetters-swe-bench-pro-purple-simple_loop)

39. Refact.ai Agent achieved leading results on SWE-bench Multimodal, [<u>https://refact.ai/blog/2025/1-agent-on-swe-bench-verified-using-claude-4-sonnet/</u>](https://refact.ai/blog/2025/1-agent-on-swe-bench-verified-using-claude-4-sonnet/)

40. SWE-Edit: Rethinking Code Editing for Efficient SWE-Agent - arXiv, [<u>https://arxiv.org/pdf/2604.26102</u>](https://arxiv.org/pdf/2604.26102)

41. (PDF) SWE-Edit: Rethinking Code Editing for Efficient SWE-Agent, [<u>https://www.researchgate.net/publication/404308337_SWE-Edit_Rethinking_Code_Editing_for_Efficient_SWE-Agent</u>](https://www.researchgate.net/publication/404308337_SWE-Edit_Rethinking_Code_Editing_for_Efficient_SWE-Agent)

42. Error Editing File: Fix AI Code Edit Failures in Claude Code ... - Morph, [<u>https://www.morphllm.com/common-errors/error-editing-file</u>](https://www.morphllm.com/common-errors/error-editing-file)

43. GitHub - dshakes/distil: Compression with a quality contract, [<u>https://github.com/dshakes/distil</u>](https://github.com/dshakes/distil)

44. Unified diffs make GPT-4 Turbo 3X less lazy - Aider, [<u>https://aider.chat/docs/unified-diffs.html</u>](https://aider.chat/docs/unified-diffs.html)

45. Edit Format Selection: Diff vs. Search-Replace vs. Full Rewrite, [<u>https://agentpatterns.ai/tool-engineering/llm-edit-format-selection/</u>](https://agentpatterns.ai/tool-engineering/llm-edit-format-selection/)

46. py - GitHub Gist, [<u>https://gist.github.com/stewartcelani/0ff23918786f514bd2ecfb4bf0c92912</u>](https://gist.github.com/stewartcelani/0ff23918786f514bd2ecfb4bf0c92912)

47. Claude Code Built-in Tools Reference \| vtrivedy, [<u>https://vtrivedy.com/posts/claudecode-tools-reference/</u>](https://vtrivedy.com/posts/claudecode-tools-reference/)

48. Gemma 4: the three architectural decisions that changed what a, [<u>https://www.arunbaby.com/ml-system-design/0077-gemma4-architecture-deep-dive/</u>](https://www.arunbaby.com/ml-system-design/0077-gemma4-architecture-deep-dive/)

49. Google's Gemma 4 is Weirder than you Realize - Devansh, [<u>https://machine-learning-made-simple.medium.com/googles-gemma-4-is-weirder-than-you-realize-17d00d95b0d5</u>](https://machine-learning-made-simple.medium.com/googles-gemma-4-is-weirder-than-you-realize-17d00d95b0d5)

50. Gemma 4 - LM Studio, [<u>https://lmstudio.ai/models/gemma-4</u>](https://lmstudio.ai/models/gemma-4)

51. Mythos system prompt - GitHub Gist, [<u>https://gist.github.com/gsans/b3007997f8900003c8ff58125a45e15e</u>](https://gist.github.com/gsans/b3007997f8900003c8ff58125a45e15e)

52. benchflow/skillsbench - OpenReward, [<u>https://openreward.ai/benchflow/skillsbench</u>](https://openreward.ai/benchflow/skillsbench)

53. cchistory: Tracking Claude Code System Prompt and Tool Changes, [<u>https://mariozechner.at/posts/2025-08-03-cchistory/</u>](https://mariozechner.at/posts/2025-08-03-cchistory/)

54. agent-style/SOURCES.md at main - GitHub, [<u>https://github.com/yzhao062/agent-style/blob/main/SOURCES.md</u>](https://github.com/yzhao062/agent-style/blob/main/SOURCES.md)

55. google/gemma-4-12B - Hugging Face, [<u>https://huggingface.co/google/gemma-4-12B</u>](https://huggingface.co/google/gemma-4-12B)

56. Context Engineering Hands-On \| PDF - Scribd, [<u>https://www.scribd.com/document/1065491727/Context-Engineering-Hands-On</u>](https://www.scribd.com/document/1065491727/Context-Engineering-Hands-On)

57. Context engineering · The System Around the Model, [<u>https://henrypl.com/ebooks/the-system-around-the-model/chapter-4</u>](https://henrypl.com/ebooks/the-system-around-the-model/chapter-4)

58. Context Engineering: Helping an Agent See What It Needs to ... - Yi Liu, [<u>https://yl.do/en/posts/context-engineering/</u>](https://yl.do/en/posts/context-engineering/)

59. context-engineering, AI Coding Skill for Claude Code, skills-hub.ai, [<u>https://skills-hub.ai/skills/openrig-context-engineering</u>](https://skills-hub.ai/skills/openrig-context-engineering)

60. Goal Recitation: Countering Drift in Long Sessions - AgentPatterns.ai, [<u>https://agentpatterns.ai/context-engineering/goal-recitation/</u>](https://agentpatterns.ai/context-engineering/goal-recitation/)

61. codex-claude-code-config/alternatives/context-management.md at, [<u>https://github.com/AnastasiyaW/codex-claude-code-config/blob/main/alternatives/context-management.md</u>](https://github.com/AnastasiyaW/codex-claude-code-config/blob/main/alternatives/context-management.md)

62. Simple Observation Masking Is as Efficient as LLM Summarization, [<u>https://arxiv.org/abs/2508.21433</u>](https://arxiv.org/abs/2508.21433)

63. The Complexity Trap: Simple Observation Masking Is as Efficient as, [<u>https://www.alphaxiv.org/abs/2508.21433v1</u>](https://www.alphaxiv.org/abs/2508.21433v1)

64. Source: The Complexity Trap: Simple Observation Masking Is as, [<u>https://aitanyan.com/wiki/sources/lindenbauer-2025-complexity-trap/</u>](https://aitanyan.com/wiki/sources/lindenbauer-2025-complexity-trap/)

65. Context Pruning for AI Agents: Methods and Implementation \[2026\], [<u>https://atlan.com/know/ai-agent/ai-agent-context/how-to-implement-context-pruning-ai-agents/</u>](https://atlan.com/know/ai-agent/ai-agent-context/how-to-implement-context-pruning-ai-agents/)

66. FrogNano: Training a 4B Coding Agent via Online Task Synthesis, [<u>https://arxiv.org/html/2609.07925v1</u>](https://arxiv.org/html/2609.07925v1)

67. Adding and Removing Context for LLM Coding Agents under Prefix, [<u>https://www.researchgate.net/publication/418027192_Context_Has_a_Price_Adding_and_Removing_Context_for_LLM_Coding_Agents_under_Prefix_Caching</u>](https://www.researchgate.net/publication/418027192_Context_Has_a_Price_Adding_and_Removing_Context_for_LLM_Coding_Agents_under_Prefix_Caching)

68. Language Models Can Control Their Own Attention - arXiv, [<u>https://arxiv.org/html/2609.02737v2</u>](https://arxiv.org/html/2609.02737v2)

69. Guardrails Beat Guidance in Coding Agents - Content Research, [<u>https://taygotech.org/content/articles/2026-04-29-guardrails-beat-guidance.html</u>](https://taygotech.org/content/articles/2026-04-29-guardrails-beat-guidance.html)

70. Tool Calling - vLLM docs, [<u>https://docs.vllm.ai/en/latest/features/tool_calling/</u>](https://docs.vllm.ai/en/latest/features/tool_calling/)

71. Tool Calling - vLLM Documentation, [<u>https://docs.vllm.ai/en/v0.32.0/features/tool_calling/</u>](https://docs.vllm.ai/en/v0.32.0/features/tool_calling/)

72. 13 AI Agent Project Ideas, Beginner to Pro \| Crio.Do Resources, [<u>https://resources.criodo.com/ai-agents/ai-agent-project-ideas/</u>](https://resources.criodo.com/ai-agents/ai-agent-project-ideas/)

73. Achieving SLM SOTA 74.8% on SWE-bench Verified with a 27B Model, [<u>https://blog-en.fltech.dev/entry/2026/04/07/swebench</u>](https://blog-en.fltech.dev/entry/2026/04/07/swebench)

74. TERMINAL-BENCH: BENCHMARKING AGENTS ON HARD, [<u>https://proceedings.iclr.cc/paper_files/paper/2026/file/444a3737adaee10d86ad2ef5f74468e6-Paper-Conference.pdf</u>](https://proceedings.iclr.cc/paper_files/paper/2026/file/444a3737adaee10d86ad2ef5f74468e6-Paper-Conference.pdf)

75. How Public Evals Work, Where They Break, and What Should Change, [<u>https://eugeneyan.com/writing/public-evals</u>](https://eugeneyan.com/writing/public-evals)

76. Beyond Resolution Rates: Behavioral Drivers of Coding Agent, [<u>https://www.researchgate.net/publication/403529909_Beyond_Resolution_Rates_Behavioral_Drivers_of_Coding_Agent_Success_and_Failure</u>](https://www.researchgate.net/publication/403529909_Beyond_Resolution_Rates_Behavioral_Drivers_of_Coding_Agent_Success_and_Failure)

77. Behavioral Drivers of Coding Agent Success and Failure, [<u>https://agentpatterns.ai/patterns/agent-design/behavioral-drivers-agent-success/</u>](https://agentpatterns.ai/patterns/agent-design/behavioral-drivers-agent-success/)

78. An Empirical Study on Failures in Automated Issue Solving - arXiv, [<u>https://arxiv.org/html/2509.13941v1</u>](https://arxiv.org/html/2509.13941v1)

79. Benchmarking Agentic Programming and Exploration in a Stateful, [<u>https://openreview.net/pdf/83f37f37aa92604f6d4afc4b2ba6c1bb75c488cc.pdf</u>](https://openreview.net/pdf/83f37f37aa92604f6d4afc4b2ba6c1bb75c488cc.pdf)

80. Hello world - SWE-agent documentation, [<u>https://swe-agent.com/latest/usage/hello_world/</u>](https://swe-agent.com/latest/usage/hello_world/)

81. SWE-EVAL: TRAJECTORY-ENHANCED EVALUATION - OpenReview, [<u>https://openreview.net/pdf/718d11ac06d7a23ec0e5d83c04712da246fa0434.pdf</u>](https://openreview.net/pdf/718d11ac06d7a23ec0e5d83c04712da246fa0434.pdf)

82. Can Agents Autonomously Find and Fix Bugs? - SWE-sweep, [<u>https://swesweep.com/paper</u>](https://swesweep.com/paper)

83. A Structural Scoring Framework for Selecting Coding-Agent, [<u>https://aclanthology.org/2026.findings-emnlp.2264.pdf</u>](https://aclanthology.org/2026.findings-emnlp.2264.pdf)

84. (PDF) Termination Lag: Coding Agents Solve Early but Stop Late, [<u>https://www.researchgate.net/publication/417837624_Termination_Lag_Coding_Agents_Solve_Early_but_Stop_Late</u>](https://www.researchgate.net/publication/417837624_Termination_Lag_Coding_Agents_Solve_Early_but_Stop_Late)

85. Behavioral Drivers of Coding Agent Success and Failure - arXiv, [<u>https://arxiv.org/html/2604.02547v1</u>](https://arxiv.org/html/2604.02547v1)

86. arXiv:2410.20285v6 \[cs.AI\] 2 Apr 2025, [<u>https://arxiv.org/pdf/2410.20285?</u>](https://arxiv.org/pdf/2410.20285)
