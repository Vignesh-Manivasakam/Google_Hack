# Local v4 Drop-in Package (Python 3.12 + RTX 2000 Ada 16GB Remote GPU Machine)
**Release Date:** Nov 20, 2026 (v4.0 Production Release)

## 🚀 What is this?
Complete drop-in package for the local Windows SWE-gemma harness on your remote GPU machine (`gemma-4-developer-agent\`).
Contains the full benchmark dataset (`hinted_train_99_tasks.jsonl`, `splits_99_30.json`, `fresh_24_eval.json`, `tasks.jsonl`), candidate configurations (`submission_E4B_F3_v2`, `submission_B6d`), and hardened runtime harnesses.

## 🛠️ Key Capabilities in v4:

### 1. Embedded Benchmark Task Splits (No External Downloads Needed)
- **`hinted_train_99_tasks.jsonl`:** All 99 training tasks augmented with gold localization hints (gold file paths + modified symbols).
- **`splits_99_30.json`:** Deterministic 99-train / 30-holdout split manifest (0 contamination).
- **`fresh_24_eval.json`:** 24 fresh holdout benchmark tasks (12 fastapi, 9 rich, 3 requests).
- **`tasks.jsonl`:** Full 129-task unhinted competition dataset.

### 2. Multi-Mode Task Loading & Automatic Path Resolution
- Harness automatically searches: `--tasks_path`, `hinted_train_99_tasks.jsonl`, `tasks.jsonl`, `tasks_eval.jsonl`.
- New `--task_mode train99` and `--task_mode all` switches allow running all 99 tasks directly without artificial 20-task caps.
- Auto-detects 16GB GPU memory ceiling (RTX 2000 Ada) and automatically clamps `workers=1, batch_size=1` to guarantee 0.0 GB Windows WDDM paging thrash.

### 3. Integrated Candidate Profiles
- **`E4B_F3_v2`:** Compact 497-token Copilot prompt + 4 Engineering Failure-Trap Laws, optimized for 512-token local sliding window attention.
- **`B6d_31B`:** Upgraded 31B candidate with the FastAPI Six Laws (test-import inversion check, `docs_src/` target rule, node-level pytest piping: `pytest -x -q <file>::<node> | tail -20`), and `max_output_tokens=4096`, `thinking_budget=768`.

### 4. Robust Offline Re-Grading & SFT Export
- `regrade_overnight_patches.py` now supports `--tasks_path` with automatic fallback to `hinted_train_99_tasks.jsonl`.
- Saves multi-turn conversational `messages` with thoughts, tool calls, and observations for direct SFT builder ingestion.

## 📋 Included Files & Folders
- `hinted_train_99_tasks.jsonl`: 99 hinted train tasks for local rollout factory.
- `splits_99_30.json`: 99/30 split definition.
- `fresh_24_eval.json`: 24 fresh holdout evaluation tasks.
- `tasks.jsonl`: 129 ground truth tasks.
- `win_frontier_6harness_overnight.py`: Master overnight tournament & rollout harness.
- `win_local_sandbox.py`: Pure-Python Windows POSIX emulator & test execution sandbox.
- `win_harness_triage_parallel.py`: Batched triage matrix with expandable segments & SDPA.
- `win_phase2_tournament.py`: AST code graph indexer, 8192-tok SDPA Gemma engine helpers.
- `regrade_overnight_patches.py`: 0-GPU re-grader for saved patches.
- `submission_E4B_F3_v2/`: Complete ADK candidate folder for E4B F3_v2.
- `submission_B6d/`: Complete ADK candidate folder for B6d 31B.
- `README.md`: This document.

## ⚡ Quick Start Commands (Run inside `gemma-4-developer-agent\`):

### 1. Canary Validation on 1 task (Smoke Test, ~2 min)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2 --task_mode val20 --smoke1
```

### 2. Launch Local E4B Rollout Factory on 99 Train Tasks (Overnight Run)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2 --tasks_path hinted_train_99_tasks.jsonl --task_mode train99 --workers 1 --batch_size 1 --out_dir ..\e4b_rollout_factory
```

### 3. Launch Multi-Candidate Triage Matrix (VAL_20 Diagnostic Tasks)
```powershell
python -u win_frontier_6harness_overnight.py --candidates E4B_F3_v2,B6d_31B,B5_Lean_31B --task_mode val20 --workers 1 --batch_size 1
```

### 4. Re-grade Patches without loading GPU (0 GPU time, ~2 min)
```powershell
python -u regrade_overnight_patches.py --tasks_path hinted_train_99_tasks.jsonl --results_dir ..\e4b_rollout_factory
```

### 5. Export ADK-compliant submission zip
```powershell
python win_frontier_6harness_overnight.py --export_candidate E4B_F3_v2
```
