# 🏆 Frontier Harness Triage Leaderboard
**Last Updated:** 2026-11-18 15:56:49 IST  

## Stage 1: Canary 8 Rapid Elimination
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Avg Steps | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F4_OpenCode_Gate`** | `12.5%` (1/8) | `6/8` | `81.17%` | `7` | `19.25` | `63.97m` | OpenCode milestones + anti-loop circuit breaker |
| 2 | **`F3_Copilot_Sonnet`** | `12.5%` (1/8) | `5/8` | `72.33%` | `22` | `25.75` | `97.59m` | GitHub Copilot Sonnet 7-step + 4 Trap Laws |
| 3 | **`F6_Apex_Unified`** | `0.0%` (0/8) | `4/8` | `65.2%` | `19` | `28.38` | `111.86m` | Unified Cursor + Copilot 4 Laws + OpenCode + Claude |

## Stage 2: Finalists Validation Suite (VAL_20)
| Rank | Candidate ID | Resolved % (Count) | Patches | SCR % | EditFails | Time (min) | Paradigm / Notes |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| 1 | **`F4_OpenCode_Gate`** | `10.0%` (2/20) | `13/20` | `75.5%` | `15` | `180.18m` | OpenCode milestones + anti-loop circuit breaker |
